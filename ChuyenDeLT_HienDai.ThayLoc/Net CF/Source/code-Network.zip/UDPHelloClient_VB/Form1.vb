Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents txtMaxPackets As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.txtMaxPackets = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.button1 = New System.Windows.Forms.Button
        '
        'textBox1
        '
        Me.textBox1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.textBox1.Location = New System.Drawing.Point(8, 63)
        Me.textBox1.Multiline = True
        Me.textBox1.Size = New System.Drawing.Size(224, 152)
        Me.textBox1.Text = "textBox1"
        '
        'txtMaxPackets
        '
        Me.txtMaxPackets.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtMaxPackets.Location = New System.Drawing.Point(104, 15)
        Me.txtMaxPackets.Size = New System.Drawing.Size(96, 22)
        Me.txtMaxPackets.Text = "100"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(8, 15)
        Me.label1.Size = New System.Drawing.Size(80, 24)
        Me.label1.Text = "Max Packets:"
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(32, 223)
        Me.button1.Size = New System.Drawing.Size(176, 32)
        Me.button1.Text = "Listen for UDP packets"
        '
        'Form1
        '
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.txtMaxPackets)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub ListenForUDPPackets()
        ' Use a UDPClient to receive packets....
        Dim listenerIP As System.Net.IPEndPoint
        listenerIP = New System.Net.IPEndPoint(System.Net.IPAddress.Any, 8758)

        Dim listener As System.Net.Sockets.UdpClient
        listener = New System.Net.Sockets.UdpClient(listenerIP)

        Dim i As Integer
        For i = 1 To Convert.ToInt16(Me.txtMaxPackets.Text)

            ' Now receive the three datagrams from the listener
            Dim receivedIPInfo As System.Net.IPEndPoint
            receivedIPInfo = New System.Net.IPEndPoint(System.Net.IPAddress.Any, 0)

            Dim data As Byte()
            data = listener.Receive(receivedIPInfo)
            Me.textBox1.Text += ("GOT: " + System.Text.Encoding.ASCII.GetString(data, 0, data.Length) + "  FROM: " + receivedIPInfo.ToString())
        Next i
    End Sub
    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        ListenForUDPPackets()
    End Sub
End Class
