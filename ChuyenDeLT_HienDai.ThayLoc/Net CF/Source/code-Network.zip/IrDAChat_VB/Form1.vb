Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents cbHost As System.Windows.Forms.CheckBox
    Friend WithEvents lbInText As System.Windows.Forms.ListBox
    Friend WithEvents btnSend As System.Windows.Forms.Button
    Friend WithEvents txtSendText As System.Windows.Forms.TextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_IrDAClient As System.Net.Sockets.IrDAClient
    Private m_Connected As Boolean
    Private m_listenerThread As System.Threading.Thread


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.cbHost = New System.Windows.Forms.CheckBox
        Me.lbInText = New System.Windows.Forms.ListBox
        Me.btnSend = New System.Windows.Forms.Button
        Me.txtSendText = New System.Windows.Forms.TextBox
        Me.button1 = New System.Windows.Forms.Button
        '
        'cbHost
        '
        Me.cbHost.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.cbHost.Location = New System.Drawing.Point(128, 14)
        Me.cbHost.Size = New System.Drawing.Size(48, 24)
        Me.cbHost.Text = "Host"
        '
        'lbInText
        '
        Me.lbInText.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.lbInText.Location = New System.Drawing.Point(8, 142)
        Me.lbInText.Size = New System.Drawing.Size(224, 114)
        '
        'btnSend
        '
        Me.btnSend.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnSend.Location = New System.Drawing.Point(8, 102)
        Me.btnSend.Size = New System.Drawing.Size(72, 24)
        Me.btnSend.Text = "Send"
        '
        'txtSendText
        '
        Me.txtSendText.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtSendText.Location = New System.Drawing.Point(8, 70)
        Me.txtSendText.Size = New System.Drawing.Size(216, 22)
        Me.txtSendText.Text = "textBox3"
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(8, 14)
        Me.button1.Size = New System.Drawing.Size(112, 24)
        Me.button1.Text = "Connect"
        '
        'Form1
        '
        Me.Controls.Add(Me.cbHost)
        Me.Controls.Add(Me.lbInText)
        Me.Controls.Add(Me.btnSend)
        Me.Controls.Add(Me.txtSendText)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub WaitForConnection()
        Try
            Dim l_IrDAListener As System.Net.Sockets.IrDAListener
            l_IrDAListener = New System.Net.Sockets.IrDAListener("IRDA_CHAT_SERVER")

            ' Listen for anyone who wants to connect
            l_IrDAListener.Start()

            ' And now pull the first queued connection request out as an IrDAClient
            m_IrDAClient = l_IrDAListener.AcceptIrDAClient()

            MessageBox.Show("Accepted a connection", "Ready to chat")
            m_Connected = True

            ' Now spin off a thread that will listen for data that comes in through the IrDAClient connection...
            Me.m_listenerThread = New System.Threading.Thread(New System.Threading.ThreadStart(AddressOf ChatListener))
            m_listenerThread.Start()

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try

    End Sub
    Private Sub ChatListener()
        Dim l_StreamReader As System.IO.StreamReader
        l_StreamReader = Nothing

        While m_Connected
            l_StreamReader = New System.IO.StreamReader(Me.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII)
            Me.lbInText.Items.Add(l_StreamReader.ReadLine())
            l_StreamReader.Close()
        End While
    End Sub
    Private Sub MakeConnection()

        ' In this method, we attempt to connect with another device which is
        ' waiting for a connection.  We assume that the other device is
        ' called the "IRDA_CHAT_SERVER".  We will tell users what devices are
        ' in range with a MessageBox and then hope that "IRDA_CHAT_SERVER" is in
        ' range.
        Const MAX_DEVICES = 5
        Try
            Me.m_IrDAClient = New System.Net.Sockets.IrDAClient

            Dim l_foundAnyDevice As Boolean
            l_foundAnyDevice = False

            ' Find out who's out there to connect with...
            Dim l_DevsAvailable() As System.Net.Sockets.IrDADeviceInfo
            l_DevsAvailable = m_IrDAClient.DiscoverDevices(MAX_DEVICES)

            ' Show a MessageBox telling user every device we see out there
            Dim i As Integer
            i = 0
            While ((i < l_DevsAvailable.Length) And (m_Connected = False))
                Dim l_devInfo As System.Net.Sockets.IrDADeviceInfo
                l_devInfo = l_DevsAvailable(i)

                l_foundAnyDevice = True
                MessageBox.Show(l_devInfo.DeviceName, "Discovered IrDA device")

                ' Now try to connect to the devices, hoping it offers a service named "IRDA_CHAT_SERVER"
                Try
                    ' Assume that first device is offering a service that we want
                    Dim chatEndPoint As System.Net.IrDAEndPoint
                    chatEndPoint = New System.Net.IrDAEndPoint(l_DevsAvailable(0).DeviceID, "IRDA_CHAT_SERVER")
                    m_IrDAClient.Connect(chatEndPoint)

                    MessageBox.Show("Connected to chat server!", "Ready to chat")
                    m_Connected = True

                Catch exc As System.Net.Sockets.SocketException
                End Try

                If (l_foundAnyDevice) Then
                    ' Now spin off a thread that will listen for data that comes in through the IrDAClient connection...
                    Me.m_listenerThread = New System.Threading.Thread(New System.Threading.ThreadStart(AddressOf ChatListener))
                    m_listenerThread.Start()
                Else
                    MessageBox.Show("No devices found to chat with!", "Cannot chat")
                End If
            End While
        Catch ex As Exception
            MessageBox.Show(ex.ToString())

        End Try
    End Sub
    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        If (Me.cbHost.Checked) Then
            WaitForConnection()
        Else
            MakeConnection()
        End If
    End Sub

    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
        If (m_Connected) Then
            ' Grab a reference to the stream in the m_IrDAClient and send the text to it.
            Dim l_StreamWriter As System.IO.StreamWriter
            l_StreamWriter = New System.IO.StreamWriter(Me.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII)
            l_StreamWriter.WriteLine(Me.txtSendText.Text)
            l_StreamWriter.Close()
        Else
            MessageBox.Show("Must connect to remote party before sending text")
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_Connected = False

    End Sub
End Class
