Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private m_listenSocket As System.Net.Sockets.Socket
    Private m_connectedSocket As System.Net.Sockets.Socket
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button1 = New System.Windows.Forms.Button
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(24, 16)
        Me.button1.Size = New System.Drawing.Size(192, 32)
        Me.button1.Text = "Start listening for connections"
        '
        'Form1
        '
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        MessageBox.Show("About to start waiting for a connection")

        m_listenSocket = New System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, _
        System.Net.Sockets.SocketType.Stream, System.Net.Sockets.ProtocolType.Tcp)

        m_listenSocket.Bind(New System.Net.IPEndPoint(System.Net.IPAddress.Any, 8758))
        m_listenSocket.Listen(System.Net.Sockets.SocketOptionName.MaxConnections)

        m_connectedSocket = m_listenSocket.Accept()

        If (Not (m_connectedSocket Is Nothing)) Then
            If (m_connectedSocket.Connected) Then
                ' Someone has connected to us.  Send the string "Hello" and then disconnect.
                m_connectedSocket.Send(System.Text.Encoding.ASCII.GetBytes("Hello!"))
                m_connectedSocket.Close()
            End If
        End If

    End Sub
End Class
