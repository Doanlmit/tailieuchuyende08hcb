using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace ManagedChat_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox txtSendText;
		private System.Windows.Forms.Button btnSend;
		private System.Windows.Forms.ListBox lbInText;
		private System.Windows.Forms.CheckBox cbHost;
		private System.Windows.Forms.MainMenu mainMenu1;

		private IrDAClient m_IrDAClient;
		bool m_Connected;
		System.Threading.Thread m_listenerThread;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.button1 = new System.Windows.Forms.Button();
			this.txtSendText = new System.Windows.Forms.TextBox();
			this.btnSend = new System.Windows.Forms.Button();
			this.lbInText = new System.Windows.Forms.ListBox();
			this.cbHost = new System.Windows.Forms.CheckBox();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 8);
			this.button1.Size = new System.Drawing.Size(112, 24);
			this.button1.Text = "Connect";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtSendText
			// 
			this.txtSendText.Location = new System.Drawing.Point(8, 64);
			this.txtSendText.Size = new System.Drawing.Size(216, 22);
			this.txtSendText.Text = "textBox3";
			// 
			// btnSend
			// 
			this.btnSend.Location = new System.Drawing.Point(8, 96);
			this.btnSend.Size = new System.Drawing.Size(72, 24);
			this.btnSend.Text = "Send";
			this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
			// 
			// lbInText
			// 
			this.lbInText.Location = new System.Drawing.Point(8, 136);
			this.lbInText.Size = new System.Drawing.Size(224, 114);
			// 
			// cbHost
			// 
			this.cbHost.Location = new System.Drawing.Point(128, 8);
			this.cbHost.Size = new System.Drawing.Size(48, 24);
			this.cbHost.Text = "Host";
			// 
			// Form1
			// 
			this.Controls.Add(this.cbHost);
			this.Controls.Add(this.lbInText);
			this.Controls.Add(this.btnSend);
			this.Controls.Add(this.txtSendText);
			this.Controls.Add(this.button1);
			this.Menu = this.mainMenu1;
			this.Text = "ManagedChat";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void WaitForConnection()
		{
			try
			{
				IrDAListener l_IrDAListener = new IrDAListener("IRDA_CHAT_SERVER");

				// Listen for anyone who wants to connect
				l_IrDAListener.Start();

				// And now pull the first queued connection request out as an IrDAClient
				m_IrDAClient = l_IrDAListener.AcceptIrDAClient();

				MessageBox.Show("Accepted a connection", "Ready to chat");
				m_Connected = true;

				// Now spin off a thread that will listen for data that comes in through the IrDAClient connection...
				this.m_listenerThread = new System.Threading.Thread(new System.Threading.ThreadStart(ChatListener));
				m_listenerThread.Start();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		private void ChatListener()
		{
			StreamReader l_StreamReader = null;

			while (m_Connected)
			{
				l_StreamReader = new StreamReader(this.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII);
				this.lbInText.Items.Add(l_StreamReader.ReadLine());
				l_StreamReader.Close();
			}
		}

		private void MakeConnection()
		{
			// In this method, we attempt to connect with another device which is
			// waiting for a connection.  We assume that the other device is
			// called the "IRDA_CHAT_SERVER".  We will tell users what devices are
			// in range with a MessageBox and then hope that "IRDA_CHAT_SERVER" is in
			// range.
			const int MAX_DEVICES = 5;
			try
			{
				this.m_IrDAClient = new IrDAClient();

				bool l_foundAnyDevice = false;

				// Find out who's out there to connect with...
				IrDADeviceInfo[] l_DevsAvailable = m_IrDAClient.DiscoverDevices(MAX_DEVICES);
				
				// Show a MessageBox telling user every device we see out there
				foreach (IrDADeviceInfo l_devInfo in l_DevsAvailable)
				{
					l_foundAnyDevice = true;
					MessageBox.Show(l_devInfo.DeviceName, "Discovered IrDA device");

					// Now try to connect to the devices, hoping it offers a service named "IRDA_CHAT_SERVER"
					try
					{
						// Assume that first device is offering a service that we want
						IrDAEndPoint chatEndPoint = new IrDAEndPoint(l_DevsAvailable[0].DeviceID, "IRDA_CHAT_SERVER");
						m_IrDAClient.Connect(chatEndPoint);
					
						MessageBox.Show("Connected to chat server!", "Ready to chat");
						m_Connected = true;
						break;
					}
					catch (SocketException exc)
					{
					}
				}

				if (l_foundAnyDevice)
				{
					// Now spin off a thread that will listen for data that comes in through the IrDAClient connection...
					this.m_listenerThread = new System.Threading.Thread(new System.Threading.ThreadStart(ChatListener));
					m_listenerThread.Start();
				}
				else
				{
					MessageBox.Show("No devices found to chat with!", "Cannot chat");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}



		private void button1_Click(object sender, System.EventArgs e)
		{
			if (this.cbHost.Checked)
			{
				WaitForConnection();
			}
			else
			{
				MakeConnection();
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_Connected = false;
		}

		private void btnSend_Click(object sender, System.EventArgs e)
		{
			if (this.m_Connected)
			{
				// Grab a reference to the stream in the m_IrDAClient and send the text to it.
				StreamWriter l_StreamWriter = new StreamWriter(this.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII);
				l_StreamWriter.WriteLine(this.txtSendText.Text);
				l_StreamWriter.Close();
			}
			else
			{
				MessageBox.Show("Must connect to remote party before sending text");
			}
		}
	}
}
