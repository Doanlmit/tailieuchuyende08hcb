using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.IO;

namespace WebHello_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnMakeHTTPRequest;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtRemoteIP;
		private System.Windows.Forms.TextBox txtHTTPResponse;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.label1 = new System.Windows.Forms.Label();
			this.txtRemoteIP = new System.Windows.Forms.TextBox();
			this.btnMakeHTTPRequest = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.txtHTTPResponse = new System.Windows.Forms.TextBox();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(4, 0);
			this.label1.Size = new System.Drawing.Size(232, 24);
			this.label1.Text = "Remote IP Address or hostname ";
			// 
			// txtRemoteIP
			// 
			this.txtRemoteIP.Location = new System.Drawing.Point(4, 24);
			this.txtRemoteIP.Size = new System.Drawing.Size(228, 22);
			this.txtRemoteIP.Text = "http://www.yahoo.com";
			// 
			// btnMakeHTTPRequest
			// 
			this.btnMakeHTTPRequest.Location = new System.Drawing.Point(24, 48);
			this.btnMakeHTTPRequest.Size = new System.Drawing.Size(192, 24);
			this.btnMakeHTTPRequest.Text = "Make HTTP Request";
			this.btnMakeHTTPRequest.Click += new System.EventHandler(this.btnMakeHTTPRequest_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 80);
			this.label2.Size = new System.Drawing.Size(184, 16);
			this.label2.Text = "Response";
			// 
			// txtHTTPResponse
			// 
			this.txtHTTPResponse.Location = new System.Drawing.Point(8, 96);
			this.txtHTTPResponse.Multiline = true;
			this.txtHTTPResponse.Size = new System.Drawing.Size(224, 168);
			this.txtHTTPResponse.Text = "textBox2";
			// 
			// Form1
			// 
			this.Controls.Add(this.txtHTTPResponse);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.btnMakeHTTPRequest);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtRemoteIP);
			this.Menu = this.mainMenu1;
			this.Text = "HttpViewer";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnMakeHTTPRequest_Click(object sender, System.EventArgs e)
		{
			Uri l_Uri = new Uri(this.txtRemoteIP.Text);							
			HttpWebRequest l_WebReq = (HttpWebRequest)WebRequest.Create(l_Uri);
			HttpWebResponse l_WebResponse = (HttpWebResponse)l_WebReq.GetResponse();
			StreamReader l_SReader = new StreamReader(l_WebResponse.GetResponseStream());
			this.txtHTTPResponse.Text = l_SReader.ReadToEnd();				
		}
	}
}
