Public Class ChatPacket
    ' Internal member variables
    Private m_Serializer As SimpleSerializer
    Private m_Sender As String
    Private m_ChatText As String


    ' This method creates a new DataSet with the right schema to hold all of
    ' the state held inside this class.

    '
    ' Constructor
    '
    Public Sub New()

        m_Serializer = New SimpleSerializer
    End Sub

    ' Return to initialized state
    Public Sub Clear()

        m_Sender = ""
        m_ChatText = ""
    End Sub

    '
    '
    '
    Public Property Sender() As String
        Get
            Return m_Sender
        End Get
        Set(ByVal Value As String)
            m_Sender = Value
        End Set
    End Property
    '
    '
    '
    Public Property ChatText() As String
        Get
            Return m_ChatText
        End Get
        Set(ByVal Value As String)
            m_ChatText = Value
        End Set

    End Property

    Public Function ToString() As String
        Dim l_memoryStream As System.IO.MemoryStream = New System.IO.MemoryStream(200)

        m_Serializer.Serialize(Me.m_Sender, l_memoryStream)
        m_Serializer.Serialize(Me.m_ChatText, l_memoryStream)


        Dim toReturn As String
        toReturn = System.Text.Encoding.ASCII.GetString(l_memoryStream.GetBuffer(), 0, CInt(l_memoryStream.Length))

        l_memoryStream.Close()

        Return toReturn
    End Function
    Public Sub FromString(ByVal serializedChatPacket As String)

        Dim l_stringReader As System.IO.StringReader = New System.IO.StringReader(serializedChatPacket)

        Dim l_memoryStream As System.IO.MemoryStream = New System.IO.MemoryStream(200)
        l_memoryStream.Write(System.Text.Encoding.Default.GetBytes(serializedChatPacket), 0, System.Text.Encoding.Default.GetBytes(serializedChatPacket).Length)

        l_memoryStream.Seek(0, System.IO.SeekOrigin.Begin)

        Dim l_objects() As Object
        l_objects = m_Serializer.Deserialize(l_memoryStream)

        Me.m_Sender = CStr(l_objects(0))
        Me.m_ChatText = CStr(l_objects(1))
        l_memoryStream.Close()
    End Sub
End Class
