Public Class SimpleSerializer
    Public Sub New()
    End Sub
    Public Sub Serialize(ByVal objs As Object(), ByVal stream As System.IO.Stream)
        Serialize(objs, New System.IO.StreamWriter(stream))
    End Sub
    Public Sub Serialize(ByVal objs As Object(), ByVal writer As System.io.TextWriter)
        If (writer Is Nothing) Then
            Throw New ArgumentException("Cannot serialize to a null writer", "writer")
        End If
        If (objs Is Nothing) Then
            Exit Sub
        End If

        Dim obj As Object
        For Each obj In objs
            WriteObject(obj, writer)
        Next

        writer.Flush()
    End Sub
    Public Sub Serialize(ByVal obj As Object, ByVal stream As System.IO.Stream)
        Serialize(obj, New System.IO.StreamWriter(stream))
    End Sub
    Public Sub Serialize(ByVal obj As Object, ByVal writer As System.IO.TextWriter)

        If (writer Is Nothing) Then
            Throw New ArgumentException("Cannot serialize to a null writer", "writer")
        End If
        If (obj Is Nothing) Then
            Exit Sub
        End If

        WriteObject(obj, writer)
        writer.Flush()
    End Sub

    Protected Sub WriteObject(ByVal primObj As Object, ByVal writer As System.IO.TextWriter)
        Dim objType As System.Type

        objType = primObj.GetType()

        If (objType.IsPrimitive) Then
            writer.WriteLine("{0}={1}", objType.Name, PrimitiveToString(primObj))
        ElseIf TypeOf objType Is String Then
            writer.WriteLine("{0}={1}", objType.Name, CStr(primObj))
        ElseIf TypeOf objType Is DateTime Then
            writer.WriteLine("{0}={1}", objType.Name, System.Xml.XmlConvert.ToString(CDate(primObj)))
        Else
            Throw New InvalidOperationException("Can not serialize an object of type " + objType.Name)
        End If
    End Sub
    Public Function Deserialize(ByVal stream As System.IO.Stream) As Object()
        Return Deserialize(New System.IO.StreamReader(stream))
    End Function
    Public Function Deserialize(ByVal reader As System.IO.TextReader) As Object()

        If (reader Is Nothing) Then
            Throw New ArgumentException("Can not deserialize from a null reader", "reader")
        End If

        ' Read the objects from the file
        Dim obj As Object
        Dim objects As New ArrayList
        obj = ReadObject(reader)
        While (obj <> Nothing)
            If (obj <> Nothing) Then
                objects.Add(obj)
            End If
            ReadObject(reader)
        End While
        Return objects.ToArray()
    End Function
    Protected Function ReadObject(ByVal reader As System.IO.TextReader) As Object

        ' Get the line of data that represents the object
        Dim line As String
        line = reader.ReadLine()

        ' If there is no more data then return null.
        If ((line = Nothing) Or line.StartsWith("\0")) Then
            Return Nothing
        End If

        ' Seperate the tag from the data
        Dim sepNdx As Integer
        sepNdx = line.IndexOf("=")
        If (sepNdx <= 0) Then
            Throw New Exception("Serialization file is malformed")
        End If
        Dim tag, data As String
        tag = line.Substring(0, sepNdx)
        data = line.Substring(sepNdx + 1)

        ' the reader should be positioned on the node to deserialize
        Select Case (tag.ToLower())
            Case "boolean" : Return System.Xml.XmlConvert.ToBoolean(data)
            Case "byte" : Return System.Xml.XmlConvert.ToByte(data)
            Case "sbyte" : Return System.Xml.XmlConvert.ToSByte(data)
            Case "int16" : Return System.Xml.XmlConvert.ToInt16(data)
            Case "uint16" : Return System.Xml.XmlConvert.ToUInt16(data)
            Case "int32" : Return System.Xml.XmlConvert.ToInt32(data)
            Case "uint32" : Return System.Xml.XmlConvert.ToUInt32(data)
            Case "int64" : Return System.Xml.XmlConvert.ToInt64(data)
            Case "uint64" : Return System.Xml.XmlConvert.ToUInt64(data)
            Case "char" : Return System.Xml.XmlConvert.ToChar(data)
            Case "double" : Return System.Xml.XmlConvert.ToDouble(data)
            Case "single" : Return System.Xml.XmlConvert.ToSingle(data)
            Case "string" : Return data
            Case "datetime" : Return System.Xml.XmlConvert.ToDateTime(data)
            Case Else
                Throw New Exception(String.Format("Unsupported type, {0}, found in the serialization stream", tag))
        End Select

    End Function
    Protected Function PrimitiveToString(ByVal primObj As Object) As String
        Dim objType As Type
        objType = primObj.GetType()
        If TypeOf primObj Is Boolean Then
            Return System.Xml.XmlConvert.ToString(CBool(primObj))
        ElseIf TypeOf objType Is Byte Then
            Return System.Xml.XmlConvert.ToString(CByte(primObj))
        ElseIf TypeOf objType Is SByte Then
            Return System.Xml.XmlConvert.ToString(CByte(primObj))
        ElseIf TypeOf objType Is Short Then
            Return System.Xml.XmlConvert.ToString(CShort(primObj))
        ElseIf TypeOf objType Is UInt16 Then
            Return System.Xml.XmlConvert.ToString(CInt(primObj))
        ElseIf TypeOf objType Is Integer Then
            Return System.Xml.XmlConvert.ToString(CInt(primObj))
            'else if typeof objType is typeof uint16
            '	return System.Xml.XmlConvert.ToString((uint)primObj);
        ElseIf TypeOf objType Is Long Then
            Return System.Xml.XmlConvert.ToString(CLng(primObj))
            'else if if typeof objType is (objType == typeof(ulong))
            '	return System.Xml.XmlConvert.ToString((ulong)primObj);
        ElseIf TypeOf objType Is Char Then
            Return System.Xml.XmlConvert.ToString(CChar(primObj))
        ElseIf TypeOf objType Is Double Then
            Return System.Xml.XmlConvert.ToString(CDbl(primObj))
        ElseIf TypeOf objType Is Single Then
            Return System.Xml.XmlConvert.ToString(CSng(primObj))
        End If

        Throw New Exception("PrimitiveToString received an object that was not a primitive")
        Return String.Empty
    End Function
End Class
