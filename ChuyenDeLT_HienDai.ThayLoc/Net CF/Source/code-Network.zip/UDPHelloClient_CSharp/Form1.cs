using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace UDPHelloClient_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox txtMaxPackets;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.txtMaxPackets = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(32, 224);
			this.button1.Size = new System.Drawing.Size(176, 32);
			this.button1.Text = "Listen for UDP packets";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Size = new System.Drawing.Size(80, 24);
			this.label1.Text = "Max Packets:";
			// 
			// txtMaxPackets
			// 
			this.txtMaxPackets.Location = new System.Drawing.Point(104, 16);
			this.txtMaxPackets.Size = new System.Drawing.Size(96, 22);
			this.txtMaxPackets.Text = "100";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 64);
			this.textBox1.Multiline = true;
			this.textBox1.Size = new System.Drawing.Size(224, 152);
			this.textBox1.Text = "textBox1";
			// 
			// Form1
			// 
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.txtMaxPackets);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.button1);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Text = "UDP Client Listener";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void ListenForUDPPackets()
		{
			// Use a UDPClient to receive packets....
			IPEndPoint listenerIP = new IPEndPoint(IPAddress.Any, 8758); 
			UdpClient listener = new UdpClient(listenerIP); 

			for (int i = 0; i < Convert.ToInt16(this.txtMaxPackets.Text); i++)
			{     
				// Now receive the three datagrams from the listener
				IPEndPoint receivedIPInfo = new IPEndPoint(IPAddress.Any, 0);

				byte[] data = listener.Receive(ref receivedIPInfo);
				this.textBox1.Text += ("GOT: " + Encoding.ASCII.GetString(data, 0, data.Length) + "  FROM: " + receivedIPInfo.ToString());				     
			}
		}

		private void button1_Click(object sender, System.EventArgs e)
		{	
			ListenForUDPPackets();
		}
	}
}
