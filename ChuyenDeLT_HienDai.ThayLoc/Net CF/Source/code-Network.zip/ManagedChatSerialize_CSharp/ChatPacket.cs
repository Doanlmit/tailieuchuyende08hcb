using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Xml;
using System.IO;
using System.Text;

namespace ManagedChat_CSharp
{
	public class ChatPacket
	{
		// Internal member variables
		private SimpleSerializer m_Serializer;
		private string m_Sender;
		private string m_ChatText;


		// This method creates a new DataSet with the right schema to hold all of
		// the state held inside this class.
//		private DataSet CreateDataSet()
//		{
//			DataSet l_DataSet = new DataSet("ChatPacketDS");
//
//			// Create a data table that holds a "Name" and a "PhoneNumber"
//			DataTable  l_newTable = new DataTable("ManagedChatStateInfo");
//			l_newTable.Columns.Add(new DataColumn("m_Sender", typeof(System.String)));
//			l_newTable.Columns.Add(new DataColumn("m_ChatText", typeof(System.String)));
//			
//			// Add the data table to the DataSet's table collection
//			l_DataSet.Tables.Add(l_newTable);
//
//			l_DataSet.AcceptChanges();
//
//			return l_DataSet;
//		}

		//
		// Constructor
		//
		public ChatPacket()
		{
//			m_DataSet = CreateDataSet();
			m_Serializer = new SimpleSerializer();
		}


		// Return to initialized
		public void Clear()
		{
			m_Sender = "";
			m_ChatText = "";
//			m_DataSet.Clear();
//			m_DataSet.AcceptChanges();
		}

		//
		//
		//
		public String Sender
		{
			get
			{
				return m_Sender;
			}
			set
			{
				m_Sender = value;
			}
		}

		//
		//
		//
		public String ChatText
		{
			get
			{
				return m_ChatText;
			}
			set
			{
				m_ChatText = value;
			}
		}


		public override String ToString()
		{		
			
			MemoryStream l_memoryStream = new MemoryStream(200);

			m_Serializer.Serialize(this.m_Sender, l_memoryStream);
			m_Serializer.Serialize(this.m_ChatText, l_memoryStream);			
			

			string toReturn = Encoding.ASCII.GetString(l_memoryStream.GetBuffer(), 0, (int)l_memoryStream.Length);

			l_memoryStream.Close();	
			
			return toReturn;
		}


		public void FromString(string serializedChatPacket)
		{
			StringReader l_stringReader = new StringReader(serializedChatPacket);
			
			MemoryStream l_memoryStream = new MemoryStream(200);
			l_memoryStream.Write(Encoding.Default.GetBytes(serializedChatPacket), 0, Encoding.Default.GetBytes(serializedChatPacket).Length);

			l_memoryStream.Seek(0, System.IO.SeekOrigin.Begin);


			object[] l_objects = m_Serializer.Deserialize(l_memoryStream);

			this.m_Sender = (string)l_objects[0];
			this.m_ChatText = (string)l_objects[1];

			l_memoryStream.Close();
		}
	}
}