using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net.Sockets;
using System.Net;
using System.Text;

namespace UDPHelloServer_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Net.Sockets.Socket m_listenSocket;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtTargetPort;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtPacketsToSend;
		private System.Windows.Forms.TextBox txtIPAddress;
		private System.Net.Sockets.Socket m_connectedSocket;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtIPAddress = new System.Windows.Forms.TextBox();
			this.txtTargetPort = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtPacketsToSend = new System.Windows.Forms.TextBox();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(48, 208);
			this.button1.Size = new System.Drawing.Size(144, 40);
			this.button1.Text = "send UDP packets";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 8);
			this.label1.Size = new System.Drawing.Size(200, 24);
			this.label1.Text = "Target IP address:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 64);
			this.label2.Size = new System.Drawing.Size(208, 24);
			this.label2.Text = "Target port:";
			// 
			// txtIPAddress
			// 
			this.txtIPAddress.Location = new System.Drawing.Point(16, 32);
			this.txtIPAddress.Size = new System.Drawing.Size(208, 22);
			this.txtIPAddress.Text = "192.168.0.2";
			// 
			// txtTargetPort
			// 
			this.txtTargetPort.Location = new System.Drawing.Point(16, 88);
			this.txtTargetPort.Size = new System.Drawing.Size(208, 22);
			this.txtTargetPort.Text = "8758";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 128);
			this.label3.Size = new System.Drawing.Size(200, 24);
			this.label3.Text = "Packets to send";
			// 
			// txtPacketsToSend
			// 
			this.txtPacketsToSend.Location = new System.Drawing.Point(16, 152);
			this.txtPacketsToSend.Size = new System.Drawing.Size(200, 22);
			this.txtPacketsToSend.Text = "20";
			// 
			// Form1
			// 
			this.Controls.Add(this.txtPacketsToSend);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtTargetPort);
			this.Controls.Add(this.txtIPAddress);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.button1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			IPEndPoint senderIP = new IPEndPoint(IPAddress.Parse(this.txtIPAddress.Text), Convert.ToInt32(this.txtTargetPort.Text));
			
			UdpClient l_UdpClient = new UdpClient(); 
			l_UdpClient.Connect(senderIP); 

			for (int i = 0; i < Convert.ToInt32(this.txtPacketsToSend.Text); i++)
			{     
				l_UdpClient.Send(Encoding.ASCII.GetBytes("Hello_UDP_1"), Encoding.ASCII.GetBytes("Hello_UDP_1").Length); 
				System.Threading.Thread.Sleep(1000);
			}
   
			l_UdpClient.Close(); 


		}
	}
}
