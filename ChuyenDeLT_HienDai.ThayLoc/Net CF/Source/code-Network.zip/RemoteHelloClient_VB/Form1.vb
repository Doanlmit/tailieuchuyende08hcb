Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents checkbx_doDNS As System.Windows.Forms.CheckBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.checkbx_doDNS = New System.Windows.Forms.CheckBox
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.textBox2 = New System.Windows.Forms.TextBox
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.button1 = New System.Windows.Forms.Button
        '
        'checkbx_doDNS
        '
        Me.checkbx_doDNS.Location = New System.Drawing.Point(20, 75)
        Me.checkbx_doDNS.Size = New System.Drawing.Size(168, 24)
        Me.checkbx_doDNS.Text = "Do DNS Resolve"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(20, 227)
        Me.label3.Size = New System.Drawing.Size(200, 16)
        Me.label3.Text = "Remote Response: "
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(20, 107)
        Me.label2.Size = New System.Drawing.Size(184, 24)
        Me.label2.Text = "Port"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(20, 27)
        Me.label1.Size = New System.Drawing.Size(184, 24)
        Me.label1.Text = "Remote IP Address or hostname"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(20, 139)
        Me.textBox2.Size = New System.Drawing.Size(184, 22)
        Me.textBox2.Text = "8758"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(20, 51)
        Me.textBox1.Size = New System.Drawing.Size(184, 22)
        Me.textBox1.Text = "192.168.0.200"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(68, 171)
        Me.button1.Size = New System.Drawing.Size(112, 40)
        Me.button1.Text = "Connect"
        '
        'Form1
        '
        Me.Controls.Add(Me.checkbx_doDNS)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Try
            Dim l_EndPoint As System.Net.EndPoint
            If (Me.checkbx_doDNS.Checked) Then
                ' You can use a DNS name such as "www.mycomputer.net" and the DNS resolver
                ' will figure out the IP address based on the name
                Dim l_IPHostEntry As System.Net.IPHostEntry
                l_IPHostEntry = System.Net.Dns.Resolve(Me.textBox1.Text)
                l_EndPoint = New System.Net.IPEndPoint(l_IPHostEntry.AddressList(0), 8758)
            Else
                ' If your device does not have a DNS server available, you can
                ' express the remote IP address using DOT notation (eg 192.168.0.1)
                l_EndPoint = New System.Net.IPEndPoint(System.Net.IPAddress.Parse(Me.textBox1.Text), 8758)
            End If
            Dim l_Socket As System.Net.Sockets.Socket
            l_Socket = New System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, System.Net.Sockets.SocketType.Stream, System.Net.Sockets.ProtocolType.Tcp)

            l_Socket.Connect(l_EndPoint)
            If (l_Socket.Connected) Then

                ' l_Socket is now ready to send and receive data
                Dim l_Buffer(100) As Byte

                ' Get the message from the socket
                l_Socket.Receive(l_Buffer, l_Buffer.Length, System.Net.Sockets.SocketFlags.None)
                Dim l_receivedString As String
                l_receivedString = System.Text.Encoding.ASCII.GetString(l_Buffer, 0, l_Buffer.Length)
                Me.label3.Text = "Remote Response: " + l_receivedString
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
End Class
