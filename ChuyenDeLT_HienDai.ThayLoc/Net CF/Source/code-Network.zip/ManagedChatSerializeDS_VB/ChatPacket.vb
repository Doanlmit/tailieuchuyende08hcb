Public Class ChatPacket
    ' Internal member variables
    Private m_DataSet As DataSet
    Private m_Sender As String
    Private m_ChatText As String

    ' This method creates a new DataSet with the right schema to hold all of
    ' the state held inside this class.
    Private Function CreateDataSet() As DataSet
        Dim l_DataSet As DataSet
        l_DataSet = New DataSet("ChatPacketDS")

        ' Create a data table that holds a "Name" and a "PhoneNumber"
        Dim l_newTable As DataTable
        l_newTable = New DataTable("ManagedChatStateInfo")
        l_newTable.Columns.Add(New DataColumn("m_Sender", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("m_ChatText", System.Type.GetType("System.String")))

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)

        l_DataSet.AcceptChanges()

        Return l_DataSet
    End Function

    '
    ' Constructor
    '
    Sub New()
        m_DataSet = CreateDataSet()
    End Sub


    ' Return to initialized
    Public Sub Clear()

        m_Sender = ""
        m_ChatText = ""
        m_DataSet.Clear()
        m_DataSet.AcceptChanges()
    End Sub
    Public Function GetSender() As String

        Return m_Sender
    End Function
    Public Sub SetSender(ByVal value As String)
        m_Sender = value
    End Sub


    Public Function GetChatText() As String
        Return m_ChatText
    End Function

    Public Sub SetChatText(ByVal value As String)
        m_ChatText = value
    End Sub

    Public Function ToXml() As String
        ' Put the state information into the DataSet
        Dim l_newRow As DataRow
        l_newRow = m_DataSet.Tables(0).NewRow()
        l_newRow("m_Sender") = m_Sender
        l_newRow("m_ChatText") = m_ChatText
        m_DataSet.Tables(0).Rows.Add(l_newRow)

        m_DataSet.AcceptChanges()

        ' Ask for the XML Representation from the DataSet
        Return m_DataSet.GetXml()
    End Function

    Public Sub FromXml(ByVal serializedChatPacket As String)

        Clear()

        ' Wrap the string into a StringReader and XmlTextReader
        Dim l_StringReader As System.IO.StringReader
        l_StringReader = New System.IO.StringReader(serializedChatPacket)

        Dim l_XmlTextReader As System.Xml.XmlTextReader
        l_XmlTextReader = New System.Xml.XmlTextReader(l_StringReader)

        ' Consume the string into the dataset
        m_DataSet.ReadXml(l_XmlTextReader)

        ' Acquire member variables from the DataSet
        m_Sender = Convert.ToString(m_DataSet.Tables("ManagedChatStateInfo").Rows(0)("m_Sender"))
        m_ChatText = Convert.ToString(m_DataSet.Tables("ManagedChatStateInfo").Rows(0)("m_ChatText"))

    End Sub

End Class
