Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents txtHTTPResponse As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents btnMakeHTTPRequest As System.Windows.Forms.Button
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents txtRemoteIP As System.Windows.Forms.TextBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.txtHTTPResponse = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.btnMakeHTTPRequest = New System.Windows.Forms.Button
        Me.label1 = New System.Windows.Forms.Label
        Me.txtRemoteIP = New System.Windows.Forms.TextBox
        '
        'txtHTTPResponse
        '
        Me.txtHTTPResponse.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtHTTPResponse.Location = New System.Drawing.Point(8, 99)
        Me.txtHTTPResponse.Multiline = True
        Me.txtHTTPResponse.Size = New System.Drawing.Size(224, 168)
        Me.txtHTTPResponse.Text = "textBox2"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(8, 83)
        Me.label2.Size = New System.Drawing.Size(184, 16)
        Me.label2.Text = "Response"
        '
        'btnMakeHTTPRequest
        '
        Me.btnMakeHTTPRequest.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnMakeHTTPRequest.Location = New System.Drawing.Point(24, 51)
        Me.btnMakeHTTPRequest.Size = New System.Drawing.Size(192, 24)
        Me.btnMakeHTTPRequest.Text = "Make HTTP Request"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(4, 3)
        Me.label1.Size = New System.Drawing.Size(232, 24)
        Me.label1.Text = "Remote IP Address or hostname "
        '
        'txtRemoteIP
        '
        Me.txtRemoteIP.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtRemoteIP.Location = New System.Drawing.Point(4, 27)
        Me.txtRemoteIP.Size = New System.Drawing.Size(228, 22)
        Me.txtRemoteIP.Text = "http://www.yahoo.com"
        '
        'Form1
        '
        Me.Controls.Add(Me.txtHTTPResponse)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.btnMakeHTTPRequest)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.txtRemoteIP)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub btnMakeHTTPRequest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMakeHTTPRequest.Click
        Dim l_Uri As Uri
        l_Uri = New Uri(Me.txtRemoteIP.Text)

        Dim l_WebReq As System.Net.HttpWebRequest
        l_WebReq = System.Net.WebRequest.Create(l_Uri)

        Dim l_WebResponse As System.Net.WebResponse
        l_WebResponse = l_WebReq.GetResponse()

        Dim l_SReader As System.IO.StreamReader
        l_SReader = New System.IO.StreamReader(l_WebResponse.GetResponseStream())

        Me.txtHTTPResponse.Text = l_SReader.ReadToEnd()
    End Sub
End Class
