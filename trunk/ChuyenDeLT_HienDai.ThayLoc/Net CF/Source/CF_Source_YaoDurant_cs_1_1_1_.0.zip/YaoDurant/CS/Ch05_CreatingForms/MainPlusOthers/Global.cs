//-----------------------------------------------------------------------------
// Code from _Programming the .NET Compact Framework with C#_
// and _Programming the .NET Compact Framework with VB_
// (c) Copyright 2002-2004 Paul Yao and David Durant. 
// All rights reserved.
//-----------------------------------------------------------------------------

using System;

namespace MainPlusOthers
{
   /// <summary>
   /// Summary description for Global.
   /// </summary>
   public class Global
   {
      static internal FormTemperature frmTemperature;
      static internal FormPrecipitation frmPrecipitation;
      static internal FormPressure frmPressure;

      public Global()
      {
         //
         // TODO: Add constructor logic here
         //
      }
   }
}
