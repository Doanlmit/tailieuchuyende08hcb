' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.Windows.Forms
Imports System.Data

Imports WaterTempControl.YaoDurant.Types
Imports WaterTempControl.YaoDurant.Gui

Public Class FormMain
   Inherits System.Windows.Forms.Form

   Friend WithEvents wbTest As WaterBox
   Friend WithEvents cmdLoad As System.Windows.Forms.Button
   Friend WithEvents lblTemp As System.Windows.Forms.Label
   Friend WithEvents lblUofM As System.Windows.Forms.Label
   Friend WithEvents txtTemp As System.Windows.Forms.TextBox
   Friend WithEvents txtUofM As System.Windows.Forms.TextBox
   Friend WithEvents cmdConvert As System.Windows.Forms.Button
   Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
   Private Sub InitializeComponent()
      Me.MainMenu1 = New System.Windows.Forms.MainMenu
      Me.MenuItem1 = New System.Windows.Forms.MenuItem
      Me.MenuItem4 = New System.Windows.Forms.MenuItem
      Me.cmdLoad = New System.Windows.Forms.Button
      Me.lblTemp = New System.Windows.Forms.Label
      Me.lblUofM = New System.Windows.Forms.Label
      Me.txtTemp = New System.Windows.Forms.TextBox
      Me.txtUofM = New System.Windows.Forms.TextBox
      Me.cmdConvert = New System.Windows.Forms.Button
      '
      'MainMenu1
      '
      Me.MainMenu1.MenuItems.Add(Me.MenuItem1)
      '
      'MenuItem1
      '
      Me.MenuItem1.MenuItems.Add(Me.MenuItem4)
      Me.MenuItem1.Text = "File"
      '
      'MenuItem4
      '
      Me.MenuItem4.Text = "Exit"
      '
      'cmdLoad
      '
      Me.cmdLoad.Location = New System.Drawing.Point(16, 160)
      Me.cmdLoad.Text = "Load"
      '
      'lblTemp
      '
      Me.lblTemp.Location = New System.Drawing.Point(8, 24)
      Me.lblTemp.Text = "Temperature"
      '
      'lblUofM
      '
      Me.lblUofM.Location = New System.Drawing.Point(128, 24)
      Me.lblUofM.Text = "U of M"
      '
      'txtTemp
      '
      Me.txtTemp.Location = New System.Drawing.Point(8, 48)
      Me.txtTemp.Text = ""
      '
      'txtUofM
      '
      Me.txtUofM.Location = New System.Drawing.Point(128, 48)
      Me.txtUofM.Text = ""
      '
      'cmdConvert
      '
      Me.cmdConvert.Location = New System.Drawing.Point(144, 160)
      Me.cmdConvert.Text = "Convert"
      '
      'FormMain
      '
      Me.Controls.Add(Me.cmdConvert)
      Me.Controls.Add(Me.txtUofM)
      Me.Controls.Add(Me.txtTemp)
      Me.Controls.Add(Me.lblUofM)
      Me.Controls.Add(Me.lblTemp)
      Me.Controls.Add(Me.cmdLoad)
      Me.Menu = Me.MainMenu1
      Me.Text = "Form1"

   End Sub

#End Region

   Private Sub FormMain_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles MyBase.Load
      wbTest = New WaterBox("44f")
      wbTest.Location = New Point(Me.Width / 2 - wbTest.Width / 2, txtTemp.Bottom + 30)
      wbTest.Parent = Me
      wbTest.Focus()
   End Sub

   Private Sub cmdLoad_Click(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles cmdLoad.Click
      wbTest.Temperature = _
         New WaterTemp(txtTemp.Text + txtUofM.Text)
   End Sub

   Private Sub cmdConvert_Click(ByVal sender As System.Object, _
                                ByVal e As System.EventArgs _
                                ) _
                                Handles cmdConvert.Click
      wbTest.Temperature = _
         wbTest.Temperature.Convert(txtUofM.Text)
   End Sub

   Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
      Application.Exit()
   End Sub

End Class
