' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters.Binary

' <summary>
' One Generation.  Consists of a set of Rows.
' </summary>

   Friend Class LifeGeneration

#Region "Properties"
   '	An array of rows.  The heart of the generation.
   Friend Rows(LifeMain.noofCells) As LifeRow

   '	Generation count.
   Friend countGeneration As Integer 'ToDo: Unsigned Integers not supported

   '	Number of live cells in this generation.  
   '		Derived by obtaining the counts from
   '		the rows.  

   Friend ReadOnly Property noofLive() As Integer
      Get
         Dim ctLive As Integer = 0
         Dim j As Integer
         For j = lo To hi
            ctLive += Rows(j).noofLive
         Next j
         Return ctLive
      End Get
   End Property

   '	Some convenience fields.
   Friend hi, lo, middle As Integer

#End Region

#Region "System Methods"
   ' Constructor.
   Friend Sub New()
      '	Set the convenience fields.
      lo = Rows.GetLowerBound(0)
      hi = Rows.GetUpperBound(0)
      middle = lo + (hi - lo) / 2

      '	Create the rows.
      Dim j As Integer
      For j = lo To hi
         Rows(j) = New LifeRow
      Next j
   End Sub
#End Region

#Region "Internal Methods"
   Friend Function CalcNextGen() As LifeGeneration
      '	Each row is used to calculate its next
      '		generation.
      '	The target row, the row above, and the 
      '		row below must be examined to determine 
      '		the target row's next generation.
      '	The outermost border of cells is always
      '		left blank.
      Dim genNext As New LifeGeneration

      genNext.countGeneration = Me.countGeneration + 1

      genNext.Rows(lo) = New LifeRow
      Dim j As Integer
      For j = lo + 1 To hi - 1
         genNext.Rows(j) = Rows(j).CalcNextGen(Rows((j - 1)), Rows((j + 1)))
      Next j
      genNext.Rows(hi) = New LifeRow

      Return genNext
   End Function


   Friend Function CompareTo(ByVal genTarget As LifeGeneration) As Integer
      '	CompareTo tradionally returns three
      '		possible values, 0 (==), -1 (<)
      '		and +1 (>); and we wish to 
      '		maintain that convention.  But,
      '		for a generation, only "==" 
      '		and "!=" is meaningful.  So the 
      '		definition of "<" and ">" is somewhat 
      '		arbitrary here.
      If genTarget Is Nothing Then
         Return 1
      End If
      If Me.noofLive = 0 And genTarget.noofLive = 0 Then
         Return 0
      End If
      If Me.noofLive < genTarget.noofLive Then
         Return -1
      End If
      If Me.noofLive > genTarget.noofLive Then
         Return 1
      End If
      Dim j As Integer
      For j = lo To hi
         If Rows(j).CompareTo(genTarget.Rows(j)) = 0 Then
            GoTo ContinueFor1
         End If
         If Rows(j).CompareTo(genTarget.Rows(j)) < 0 Then
            Return -1
         End If
         If Rows(j).CompareTo(genTarget.Rows(j)) > 0 Then
            Return +1
         End If
ContinueFor1:
      Next j
      Return 0
   End Function


   Friend Sub Clear()
      '	Clear this generation.
      Dim j As Integer
      For j = lo To hi
         Rows(j) = New LifeRow
      Next j
      countGeneration = 0
   End Sub


   Friend Sub CopyTo(ByVal genTarget As LifeGeneration)
      '	Copy the relevant info from gen to gen.
      Dim j As Integer
      For j = lo To hi
         Me.Rows(j).CopyTo(genTarget.Rows(j))
      Next j
      genTarget.countGeneration = Me.countGeneration
   End Sub


   Friend Sub SetPattern(ByVal Pattern As LifeMain.lgpPattern)
      '	Convenience variables.
      Dim displayLo As Integer = middle - (LifeMain.noofDisplay - 1) / 2
      Dim displayHi As Integer = displayLo + (LifeMain.noofDisplay - 1)
      Dim gap As Integer = (middle - displayLo) / 3

      Clear()
      Select Case Pattern
         Case LifeMain.lgpPattern.lgpEmpty
         Case LifeMain.lgpPattern.lgpDiagonal
            Dim j As Integer
            For j = displayLo + 1 To displayHi - 1
               SetRow(j, New Integer() {j})
            Next j
         Case LifeMain.lgpPattern.lgpVertical
            Dim j As Integer
            For j = displayLo + gap To displayHi - gap
               SetRow(j, New Integer() {middle})
            Next j
         Case LifeMain.lgpPattern.lgpFlawedVertical
            Dim j As Integer
            For j = displayLo + gap To displayHi - gap
               SetRow(j, New Integer() {middle})
            Next j
            FlipCell(displayHi - gap, middle + 1)
         Case LifeMain.lgpPattern.lgpFiveCell
            SetRow(middle - 1, New Integer() {middle, middle + 1})
            SetRow(middle, New Integer() {middle - 1, middle})
            SetRow(middle + 1, New Integer() {middle})
         Case LifeMain.lgpPattern.lgpSixCell
            SetRow(middle - 1, New Integer() {middle, middle + 1})
            SetRow(middle, New Integer() {middle - 1, middle})
            SetRow(middle + 1, New Integer() {middle, middle + 1})
         Case LifeMain.lgpPattern.lgpSevenCell
            SetRow(middle - 2, New Integer() {middle})
            SetRow(middle - 1, New Integer() {middle - 2, middle - 1, middle + 1})
            SetRow(middle, New Integer() {middle - 1, middle + 1})
            SetRow(middle + 1, New Integer() {middle})
         Case LifeMain.lgpPattern.lgpEightCell
            SetRow(middle - 2, New Integer() {middle - 1})
            SetRow(middle - 1, New Integer() {middle - 1, middle + 1})
            SetRow(middle, New Integer() {middle - 1, middle, middle + 1})
            SetRow(middle + 1, New Integer() {middle - 1, middle + 1})
         Case LifeMain.lgpPattern.lgpTenCell
            SetRow(194, New Integer() {195, 196})
            SetRow(195, New Integer() {194, 195})
            SetRow(196, New Integer() {195})
            SetRow(315, New Integer() {298})
            SetRow(316, New Integer() {298, 299})
            SetRow(317, New Integer() {297, 298})
         Case LifeMain.lgpPattern.lgpBoard, LifeMain.lgpPattern.lgpSelfFix, LifeMain.lgpPattern.lgpSelfDestruct
            Dim j As Integer
            For j = lo To hi
               If j Mod 3 <> 0 Then
                  Dim k As Integer
                  For k = lo To hi
                     If k Mod 3 <> 0 Then
                        FlipCell(k, j)
                     End If
                  Next k
               End If
            Next j
            If Pattern = LifeMain.lgpPattern.lgpSelfFix Then
               FlipCell(middle, middle)
            End If
            If Pattern = LifeMain.lgpPattern.lgpSelfDestruct Then
               FlipCell(middle - 1, middle)
            End If
         Case LifeMain.lgpPattern.lgpGlider
            SetRow(middle - 1, New Integer() {middle})
            SetRow(middle, New Integer() {middle, middle + 1})
            SetRow(middle + 1, New Integer() {middle - 1, middle + 1})
         Case LifeMain.lgpPattern.lgpGliderMate
            SetRow(middle + 1 - 10, New Integer() {displayHi - (1 + 1), displayHi - (3 + 1)})
            SetRow(middle + 2 - 10, New Integer() {displayLo + (1 + 1), displayLo + (3 + 1), displayHi - (2 + 1), displayHi - (3 + 1)})
            SetRow(middle + 3 - 10, New Integer() {displayLo + (2 + 1), displayLo + (3 + 1), displayHi - (2 + 1)})
            SetRow(middle + 4 - 10, New Integer() {displayLo + (2 + 1)})
            SetRow(middle + 4 + 10, New Integer() {displayHi - 2})
            SetRow(middle + 5 + 10, New Integer() {displayLo + 2, displayHi - 2, displayHi - 3})
            SetRow(middle + 6 + 10, New Integer() {displayLo + 2, displayLo + 3, displayHi - 1, displayHi - 3})
            SetRow(middle + 7 + 10, New Integer() {displayLo + 1, displayLo + 3})
         Case LifeMain.lgpPattern.lgpGliderPump
            SetRow(middle - 5, New Integer() {middle + 6})
            SetRow(middle - 4, New Integer() {middle + 4, middle + 6})
            SetRow(middle - 3, New Integer() {middle - 5, middle + 3, middle + 5})
            SetRow(middle - 2, New Integer() {middle - 6, middle - 5, middle + 2, middle + 5, middle + 17, middle + 18})
            SetRow(middle - 1, New Integer() {middle - 7, middle - 6, middle - 1, middle - 0, middle + 3, middle + 5, middle + 17, middle + 18})
            SetRow(middle, New Integer() {middle - 17, middle - 16, middle - 8, middle - 7, middle - 6, middle - 1, middle - 0, middle + 4, middle + 6})
            SetRow(middle + 1, New Integer() {middle - 17, middle - 16, middle - 7, middle - 6, middle - 1, middle - 0, middle + 6})
            SetRow(middle + 2, New Integer() {middle - 6, middle - 5})
            SetRow(middle + 3, New Integer() {middle - 5})
         Case Else
      End Select
      countGeneration = 0
   End Sub


   Friend Sub SetRow(ByVal ixRow As Integer, ByVal arrayArgs() As Integer)
      '	Have the row do it.
      Rows(ixRow).SetRow(arrayArgs)
   End Sub


   Friend Sub FlipCell(ByVal ixRow As Integer, ByVal ixCell As Integer)
      '	Have the row do it.
      Rows(ixRow).FlipCell(ixCell)
   End Sub
#End Region

End Class
