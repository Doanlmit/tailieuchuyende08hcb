' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Windows.Forms

Namespace YaoDurant.Gui

   Public Class DateBox
      Inherits System.Windows.Forms.TextBox

#Region "Properties"

      ' Menu Text strings
      Dim astrMenu As String() = {"Info", "Format", "SetMinMax"}
      Dim astrInfo As String() = {"DayOfWeek: ", "Julian: "}
      Dim astrFormat(7 - 1) As String
      Dim astrMinMax As String() = _
         {"Set minimum date", "Set maximum date"}

      ' SubMenu index values.
      Private Enum MenuItemIndex
         miiInfo
         miiFormat
         miiMinMax
      End Enum 'MenuItemIndex

      Private Enum MinMaxIndex
         miiMin
         miiMax
      End Enum 'MinMaxIndex

      '	The Text.
      Public Overrides Property Text() As String
         Get
            Return MyBase.Text
         End Get
         Set(ByVal Value As String)
            Try
               '	To prevent an infinite loop...
               ' If we are being called because the Date
               '    property is being set, do not set 
               '    the Date property.  Else, set the Date
               '    to keep it in synch with the Text property.
               If boolSettingDate Or Value = String.Empty Then
                  MyBase.Text = Value
               Else
                  Me.Date = Convert.ToDateTime(Value)
               End If
            Catch ex As Exception
               ' Unable to convert value to DateTime.
               ' (Highly unlikely that "MyBase.Text = value;" 
               '    would cause the exception.)
               Throw New _
                  System.ArgumentException("Invalid Date", ex)
            Finally
            End Try
         End Set
      End Property

      ' Date.  
      '    The date contained and displayed in this control.
      Private boolSettingDate As Boolean
      Private m_Date As DateTime = DateTime.Today

      '  "Date" is a reserved word.  Must be in backets here.
      Public Property [Date]() As DateTime
         Get
            Return m_Date
         End Get
         Set(ByVal Value As DateTime)
            ' If the user has been inputting the Min or Max
            '    date, then store it in the appropriate
            '    property and restore the actual date.
            If m_MinChanging Then
               m_MinValue = Value
               m_MinChanging = False
               Me.Date = m_Date
               Return
            End If
            If m_MaxChanging Then
               m_MaxValue = Value
               m_MaxChanging = False
               Me.Date = m_Date
               Return
            End If

            ' Set the private date.
            m_Date = Value

            ' Set the Text property
            boolSettingDate = True
            Me.Text = m_Date.GetDateTimeFormats("d"c)(m_Format)
            boolSettingDate = False

            ' Set the background color to indicate whether 
            '    the date is within the user specified range
            '    or not.
            Me.BackColor = Color.White
            If Not (m_MinValue <= m_Date And _
                                  m_Date <= m_MaxValue) Then
               Me.BackColor = Color.Red
            End If
         End Set
      End Property

      ' Min and Max dates.
      Private m_MinChanging As Boolean
      Private m_MaxChanging As Boolean

      Private m_MinValue As DateTime = DateTime.MinValue

      Public Property MinValue() As DateTime
         Get
            Return m_MinValue
         End Get
         Set(ByVal Value As DateTime)
            m_MinValue = Value
         End Set
      End Property

      Private m_MaxValue As DateTime = DateTime.MaxValue

      Public Property MaxValue() As DateTime
         Get
            Return m_MaxValue
         End Get
         Set(ByVal Value As DateTime)
            m_MaxValue = Value
         End Set
      End Property

      ' Format.  
      '    An index into the GetDateTimeFormats('d') array.
      Private m_Format As Integer

      Public Property Format() As Integer
         Get
            Return m_Format
         End Get
         Set(ByVal Value As Integer)
            ' Set the format.
            m_Format = Value

            ' The left side of the next statement will call
            '     the Date property's Set accessor, which 
            '     will apply the specified format to the date.
            Me.Date = Me.Date
         End Set
      End Property

#End Region

#Region "Initialization and Termination"

      Public Sub New()
         ' Initialize date and format.
         Me.Date = DateTime.Today
         Me.Format = 6
         ' Just offer the first 7, of 131 possible, date formats.
         Array.Copy(DateTime.Today.GetDateTimeFormats(), 0, _
                    Me.astrFormat, 0, _
                    7)

         ' Set initial size
         Me.Width = CInt(Me.Font.Size) * 8

         ' Create the ContextMenu
         Me.ContextMenu = Me.BuildContextMenu()
      End Sub

#End Region

#Region "Base Class Overrides"

      ' Handle own Validating/Validated events.
      ' Note.  Cannot override OnValidated as it is  
      '    "inherited but not implemented" in 
      '    CompactFramework.
      Private Sub me_Validating(ByVal sender As Object, _
                                ByVal e As CancelEventArgs _
                                ) _
                                Handles MyBase.Validating
         ' Ensure that the Text property contains a date,
         '    and that that date lies within the MinDate 
         '    to MaxDate range.
         ' If test fails, set background color to red and
         '    set the EventArg's Cancel property to true
         '    to indicate that validation failed.
         Try
            '  The right side of the next statement will call
            '     the Text property's Get accessor to obtain 
            '     the string that the user entered.  The left 
            '     side will call the  Text property's Set 
            '     accessor, which will raise an exception if
            '     the string is not a valid date.
            Me.Text = Me.Text
         Catch
            Me.BackColor = Color.Red
            e.Cancel = True
         Finally
         End Try
      End Sub

#End Region

#Region "Menu Handlers and Utilities"

      Private Function BuildContextMenu() As ContextMenu
         ' Build the context menu for this class.
         Dim miWork As MenuItem
         Dim miWork2 As MenuItem
         Dim cmenuMe As New ContextMenu

         ' Sub menu - GeneralInfo
         '    Menu items for this submenu do not need a 
         '    handler, they are just informational entries
         '    such as the Day-of-Week that are completed
         '    as the context menu is being presented.
         miWork = New MenuItem
         miWork.Text = astrMenu(0)
         miWork.MenuItems.Add(New MenuItem)
         miWork.MenuItems.Add(New MenuItem)
         cmenuMe.MenuItems.Add(miWork)

         ' Sub menu - Formats
         '    Use GetDateTimeFormats('d') to 
         '    get the possible formats.
         miWork = New MenuItem
         miWork.Text = astrMenu(1)
         Dim dateFormat As String
         For Each dateFormat In astrFormat
            miWork2 = New MenuItem
            miWork2.Text = dateFormat
            AddHandler miWork2.Click, AddressOf mnuFormat_Click
            miWork.MenuItems.Add(miWork2)
         Next dateFormat
         cmenuMe.MenuItems.Add(miWork)

         ' Sub menu - MinMax
         miWork = New MenuItem
         miWork.Text = astrMenu(2)

         miWork2 = New MenuItem
         miWork2.Text = astrMinMax(0)
         miWork.MenuItems.Add(miWork2)
         AddHandler miWork2.Click, AddressOf mnuMinMax_Click

         miWork2 = New MenuItem
         miWork2.Text = astrMinMax(1)
         miWork.MenuItems.Add(miWork2)
         AddHandler miWork2.Click, AddressOf mnuMinMax_Click

         cmenuMe.MenuItems.Add(miWork)

         ' Some entries are dynamic.  Need to handle 
         '    the Popup event for this ContextMenu.
         AddHandler cmenuMe.Popup, AddressOf ContextMenu_Popup

         ' Done
         Return cmenuMe
      End Function


      Private Sub ContextMenu_Popup(ByVal sender As Object, _
                                    ByVal e As EventArgs)
         ' Fill in the "Info" SubMenu menu items.
         Dim miWork As MenuItem = _
            ContextMenu.MenuItems(CInt(MenuItemIndex.miiInfo))
         miWork.MenuItems(0).Text = _
            "DayOfWeek: " + Me.m_Date.DayOfWeek.ToString()
         miWork.MenuItems(1).Text = _
            "Julian: " + Me.m_Date.DayOfYear.ToString()
      End Sub


      Private Sub mnuFormat_Click(ByVal sender As Object, _
                                  ByVal e As System.EventArgs _
                                  )
         ' The Format property of this control is an index
         '    into the arry of formats, astrFormat.  The
         '    user has selected the format string from the
         '    context menu; we must find that string within
         '    the array and set the property to the string's
         '    index within the array.
         Me.Format = _
            Array.IndexOf(astrFormat, _
                          CType(sender, MenuItem).Text, _
                          0, _
                          astrFormat.GetLength(0) - 1)
      End Sub


      Private Sub mnuMinMax_Click(ByVal sender As Object, _
                                  ByVal e As System.EventArgs)
         ' To set the Min or Max allowable date, the user
         '    must use this control to do so.  Therefore,
         '    we must save the current date and set a 
         '    switch to indicate that we are in "MinMax
         '    change" mode.
         ' Once the user has completed specifying the 
         '    Min or Max date, we will set the MinMix
         '    date and restore the origional date.  This
         '    will be done in the Date property.
         Select Case _
            Array.IndexOf(astrMinMax, _
                          CType(sender, MenuItem).Text, _
                          0, _
                          astrMinMax.GetLength(0) - 1)
            Case CInt(MinMaxIndex.miiMin)
               m_MinChanging = True
            Case CInt(MinMaxIndex.miiMax)
               m_MaxChanging = True
         End Select
         Me.BackColor = Color.LightSlateGray
         Me.Text = String.Empty
         Me.Focus()
      End Sub

#End Region

   End Class

End Namespace
