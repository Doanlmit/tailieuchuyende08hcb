' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Collections
Imports System.Windows.Forms
Imports System.Data

Imports DateBoxControl.YaoDurant.Gui
Imports TaskStatusControl.YaoDurant.Gui

Namespace TestControls

   Public Class FormMain
      Inherits System.Windows.Forms.Form

      Private dboxTest As DateBoxControl.YaoDurant.Gui.DateBox

      Friend WithEvents cmdTest As Button
      Friend WithEvents tskdatOne As TaskStatus
      Friend WithEvents MainMenu1 As MainMenu

#Region " Windows Form Designer generated code "

      Public Sub New()
         MyBase.New()

         'This call is required by the Windows Form Designer.
         InitializeComponent()

         'Add any initialization after the InitializeComponent() call
      End Sub

      'Form overrides dispose to clean up the component list.
      Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
         MyBase.Dispose(disposing)
      End Sub

      'NOTE: The following procedure is required by the Windows Form Designer
      'It can be modified using the Windows Form Designer.  
      'Do not modify it using the code editor.
      Private Sub InitializeComponent()
         Me.MainMenu1 = New System.Windows.Forms.MainMenu
         Me.cmdTest = New System.Windows.Forms.Button
         '
         'cmdTest
         '
         Me.cmdTest.Location = New System.Drawing.Point(72, 208)
         Me.cmdTest.Text = "Test"
         '
         'FormMain
         '
         Me.Controls.Add(Me.cmdTest)
         Me.Menu = Me.MainMenu1
         Me.Text = "FormMain"

      End Sub

#End Region

      Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
         Me.MinimizeBox = False
      End Sub

      Private Sub cmdTest_Click(ByVal sender As System.Object, _
                                ByVal e As System.EventArgs _
                                ) _
                                Handles cmdTest.Click
         dboxTest = New DateBox
         With dboxTest
            .Location = New System.Drawing.Point(72, 108)
            .Parent = Me
         End With
         tskdatOne = New TaskStatus
         With tskdatOne
            .Bounds = New Rectangle(10, 10, 220, 20)
            .Parent = Me
            .dateBegin = DateTime.Today.AddDays(-5)
            .dateEnd = DateTime.Today.AddDays(10)
            .durEstimated = 15
            .durActual = 6
         End With
      End Sub
   End Class

End Namespace
