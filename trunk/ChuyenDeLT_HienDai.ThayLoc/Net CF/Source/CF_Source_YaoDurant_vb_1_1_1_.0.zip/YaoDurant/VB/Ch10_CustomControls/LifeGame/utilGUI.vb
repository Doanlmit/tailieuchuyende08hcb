' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.Windows.Forms

Public Class utilGUI
   ' Symbolic constants for menu selections.
   Public Enum gameSpeed
      gsSlowest = 2046
      gsSlow = 1024
      gsSlower = 512
      gsNormal = 256
      gsFaster = 128
      gsFast = 64
      gsFastest = 32
   End Enum

   Public Enum gameZoom
      gzInnest = 8
      gzIn = 16
      gzInner = 16
      gzNormal = 32
      gzOuter = 64
      gzOut = 64
      gzOutest = 128
   End Enum


   ' Replaces a desktop method that is not
   '     available in Compact Framework.
   Shared Sub SetBounds(ByVal theControl As Control, ByVal x As Integer, ByVal y As Integer, ByVal width As Integer, ByVal height As Integer)
      theControl.Left = x
      theControl.Top = y
      theControl.Width = width
      theControl.Height = height
   End Sub

End Class
