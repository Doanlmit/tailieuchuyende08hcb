' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Collections
Imports System.Drawing
Imports System.Windows.Forms

Namespace MultiThreaded

   Public Class FormMain
      Inherits System.Windows.Forms.Form

      Friend WithEvents cmdGetData As Button
      Private mtbPerson As YaoDurant.Gui.MultiThreadBox

#Region " Windows Form Designer generated code "

      Public Sub New()
         MyBase.New()

         'This call is required by the Windows Form Designer.
         InitializeComponent()

         'Add any initialization after the InitializeComponent() call

      End Sub

      'Form overrides dispose to clean up the component list.
      Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
         MyBase.Dispose(disposing)
      End Sub

      'NOTE: The following procedure is required by the Windows Form Designer
      'It can be modified imports the Windows Form Designer.  
      'Do not modify it imports the code editor.
      Private Sub InitializeComponent()
         Me.cmdGetData = New System.Windows.Forms.Button
         '
         'cmdGetData
         '
         Me.cmdGetData.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
         Me.cmdGetData.Location = New System.Drawing.Point(72, 200)
         Me.cmdGetData.Size = New System.Drawing.Size(104, 32)
         Me.cmdGetData.Text = "Get Data"
         '
         'FormMain
         '
         Me.Controls.Add(Me.cmdGetData)
         Me.Text = "FormMain"

      End Sub

#End Region

      Private Sub FormMain_Load(ByVal sender As Object, _
                                ByVal e As System.EventArgs _
                               ) _
                               Handles MyBase.Load
         mtbPerson = New YaoDurant.Gui.MultiThreadBox
         InitializeTheControl(mtbPerson)
      End Sub

      Private Sub cmdGetData_Click(ByVal sender As Object, _
                                   ByVal e As System.EventArgs _
                                  ) _
                                  Handles cmdGetData.Click
         mtbPerson.RequestData()
      End Sub

      Private Sub InitializeTheControl( _
                                 ByVal mtbPerson As _
                                 YaoDurant.Gui.MultiThreadBox)
         mtbPerson.Size = _
            New Size(mtbPerson.Width * 2, mtbPerson.Height * 2)
         mtbPerson.Location = _
            New Point(Me.Width / 2 - mtbPerson.Width / 2, 20)
         mtbPerson.Font = _
            New Font(mtbPerson.Font.Name, _
                     mtbPerson.Font.Size * 2, _
                     mtbPerson.Font.Style)
         mtbPerson.Parent = Me
         mtbPerson.Text = String.Empty
      End Sub
   End Class

End Namespace

