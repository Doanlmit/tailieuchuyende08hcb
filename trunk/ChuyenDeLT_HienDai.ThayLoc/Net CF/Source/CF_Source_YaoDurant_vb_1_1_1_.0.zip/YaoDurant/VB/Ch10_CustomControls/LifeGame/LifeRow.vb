' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing

Public Class LifeRow
   ' Summary description for LifeRow.
   '   Contains an array of integer cells.  Each cell 
   '      is either alive (1) or dead (0).

#Region "Properties"

   '	Member variables.
   Friend cellsRow(LifeMain.noofCells) As Byte
   Friend noofLive As Integer

   '	Some convenience fields.
   Friend hi, lo, middle As Integer

#End Region

#Region "System Methods"

   'Constructor.
   Friend Sub New()
      '	Set the convenience fields.
      lo = cellsRow.GetLowerBound(0)
      hi = cellsRow.GetUpperBound(0)
      middle = lo + (hi - lo) / 2
   End Sub

#End Region

#Region "Internal Methods"

   Friend Function CalcNextGen(ByVal rowAbove As LifeRow, ByVal rowBelow As LifeRow) As LifeRow
      '	Create an empty row.
      Dim rowNextGen As New LifeRow

      '	If this row and the row above 
      '		and the row below are all
      '		empty, then the next generation
      '		will be an empty row.
      If Me.noofLive = 0 And rowAbove.noofLive = 0 And rowBelow.noofLive = 0 Then
         Return rowNextGen
      End If

      '	For each cell in the row:
      '		(Leave the end cells blank.)
      Dim workSum As Integer
      Dim j As Integer
      For j = lo + 1 To hi - 1
         '	Sum the number of adjacent live cells.
         workSum = cellsRow((j - 1)) + cellsRow((j + 1)) + rowAbove.cellsRow((j - 1)) + rowAbove.cellsRow(j) + rowAbove.cellsRow((j + 1)) + rowBelow.cellsRow((j - 1)) + rowBelow.cellsRow(j) + rowBelow.cellsRow((j + 1))

         '	Any cell with three live neighbors
         '		will become/remain a live cell.  
         '		Any live	cell with two live
         '		neighbors will remain a live cell.
         rowNextGen.cellsRow(j) = _
            CByte(IIf(workSum = 3 Or _
                     (cellsRow(j) = 1 And workSum = 2), 1, 0))

         ' Increment the live cell count,
         '		as appropriate.
         rowNextGen.noofLive += rowNextGen.cellsRow(j)
      Next j
      Return rowNextGen
   End Function


   Friend Sub SetRow(ByVal arrayArgs() As Integer)
      '	Every cell specified by arrayArgs
      '		becomes a live cell.  All other
      '		cells die.
      cellsRow = New Byte(LifeMain.noofCells) {}
      Dim argIn As Integer
      For Each argIn In arrayArgs
         cellsRow(argIn) = 1
         noofLive += 1
      Next argIn
   End Sub


   Friend Sub FlipCell(ByVal ixCell As Integer)
      '	Toggle the cell specified
      '		by ixCell.
      If cellsRow(ixCell) = 0 Then
         cellsRow(ixCell) = 1
         noofLive += 1
      Else
         cellsRow(ixCell) = 0
         noofLive -= 1
      End If
   End Sub


   Friend Sub CopyTo(ByVal rowTarget As LifeRow)
      '	Check for null reference.
      If rowTarget Is Nothing Then
         Return
      End If
      '	Copy the relevant info from row to row.
      Me.cellsRow.CopyTo(rowTarget.cellsRow, 0)
      rowTarget.noofLive = Me.noofLive
   End Sub


   Friend Function CompareTo(ByVal rowTarget As LifeRow) As Integer
      '	CompareTo tradionally returns three
      '		possible values, 0 (==), -1 (<)
      '		and +1 (>); and we wish to 
      '		maintain that convention.  But,
      '		for a row, only "==" and "!=" 
      '		is meaningful.  So the definition
      '		of "<" and ">" is somewhat arbitrary 
      '		here.
      '	The definition of "<" and ">" in
      '		this code sequence is optimized
      '		for performance, given that 
      '		most CompareTo calls will be
      '		comparing the Nth row of one
      '		generation to the Nth row of
      '		an adjacent generation.
      '	"Equal" means identical values in
      '		cells of equal index values for 
      '		all possible index values.
      If rowTarget Is Nothing Then
         Return 1
      End If
      If Me.noofLive = 0 And rowTarget.noofLive = 0 Then
         Return 0
      End If
      If Me.noofLive < rowTarget.noofLive Then
         Return -1
      End If
      If Me.noofLive > rowTarget.noofLive Then
         Return 1
      End If
      Dim j As Integer
      For j = lo To hi
         If cellsRow(j) = rowTarget.cellsRow(j) Then
            GoTo ContinueFor1
         End If
         If cellsRow(j) < rowTarget.cellsRow(j) Then
            Return -1
         End If
         If cellsRow(j) > rowTarget.cellsRow(j) Then
            Return +1
         End If
ContinueFor1:
      Next j
      Return 0
   End Function


   Friend Function CompareTo(ByVal rowTarget As LifeRow, ByVal ixBegin As Integer, ByVal ixEnd As Integer) As Integer
      '	Overloaded version.  Specifies a 
      '		begin and end for the range of
      '		cells to compare.
      If rowTarget Is Nothing Then
         Return 1
      End If
      Dim j As Integer
      For j = ixBegin To ixEnd
         If cellsRow(j) = rowTarget.cellsRow(j) Then
            GoTo ContinueFor1
         End If
         If cellsRow(j) < rowTarget.cellsRow(j) Then
            Return -1
         End If
         If cellsRow(j) > rowTarget.cellsRow(j) Then
            Return +1
         End If
ContinueFor1:
      Next j
      Return 0
   End Function

#End Region

End Class
