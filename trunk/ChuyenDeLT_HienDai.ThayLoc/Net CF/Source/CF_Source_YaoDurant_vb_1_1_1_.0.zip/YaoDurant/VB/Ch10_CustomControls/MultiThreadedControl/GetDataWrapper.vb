' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Windows.Forms
Imports System.Collections
Imports System.Data
Imports System.Threading

Namespace MultiThreaded

   '  GetDataWrapper class.  A wrapper around a thread that
   '     simulates a component, or other service, contacting
   '     a WebService, receiving a DataSet, and delivering 
   '     that DataSet back to the calling Control via a 
   '     callback routine.
   '  Since all Compact Framework delegates must be of type
   '     EventHandler; that is, they must be:
   '        public void XXX (object sender, EventArgs e)
   '     and since EventArgs holds no information, data is 
   '     passed between the calling Control and this object
   '     by placing it within a Queue object that is created
   '     by the calling Control and passed to this object in
   '     this object's overloaded constructor.

   Public Class GetDataWrapper
      ' Data passed in the constructor
      '    by the caller.  Stored here.
      Private formCaller As Control
      Private deleCallback As EventHandler
      Private queueArgs As Queue

      ' The class's thread.
      Private thrdGetData As Thread

      ' The call can request that the thread terminate.
      Dim TerminateRequestReceived As Boolean = False

      ' The only constructor.  Takes three parameters.
      Public Sub New(ByVal formCaller As Control, _
                     ByVal deleCallback As EventHandler, _
                     ByVal queueArgs As Queue)
         ' formCaller =>  Location of delegate.  Could
         '    be a control or a form.

         ' deleCallback =>  The delegate to invoke after the 
         '    data has been gathered.

         ' queueArgs =>  Since EventHandler is the only 
         '    possible delegate type allowed in CF, and since 
         '    it does NOT allow for the passing of parameters
         '    other than "sender" and "EventArg.Empty",the
         '    caller will provide a queue for use by this
         '    class in passing the DataSet back to the caller.

         ' Save the input params.
         Me.formCaller = formCaller
         Me.deleCallback = deleCallback
         Me.queueArgs = queueArgs

         ' Create and start the thread.
         thrdGetData = _
               New Thread(New ThreadStart(AddressOf ThreadProc))
         thrdGetData.Start()
      End Sub


      Private Sub ThreadProc()
         ' Simulate contacting a Web Service and receiving
         '    a returned DataSet object.  In this example,
         '    we'll simply create and load the DataSet here.
         ' The DataSet will contain one DataTable which will
         '    contain one row which will contain a person's
         '    first name and last name.
         Dim dtblPerson As New DataTable("Person")

         dtblPerson.Columns.Add( _
                     "FirstName", Type.GetType("System.String"))
         dtblPerson.Columns.Add( _
                     "LastName", Type.GetType("System.String"))
         dtblPerson.Rows.Add( _
                     New System.String(1) {"Marion", "Shank"})

         Dim dsetPerson As New DataSet("Person")
         dsetPerson.Tables.Add(dtblPerson)

         ' In CompactFramework there is no Thread.Stop, or
         '    comparable, method.  We stop by reaching the
         '    end of the ThreadProc ASAP.  
         If Not TerminateRequestReceived Then
            ' Now that we have our dataset, we need to pass
            '    it back to the caller.  Since we are using
            '    Invoke to communicate with the calling form,
            '    we cannot pass the DataSet in a parameter,
            '    for CompactFramework's Invoke does not allow
            '    parameters.  Instead, the form has provided
            '    us with a System.Collections.Queue object
            '    for us to use.  We'll place the dataset into
            '    a Queue and let the Invoked routine retrieve
            '    it from the queue.
            SyncLock Me.queueArgs.SyncRoot
               Me.queueArgs.Enqueue(dsetPerson)
            End SyncLock
            Me.formCaller.Invoke(Me.deleCallback)
            ' Placing the above line of code inside the
            '    lock loop would ensure that only one 
            '    object was in the queue when the callback
            '    executed, thus making the callback 
            '    routine simplier to write; but it would
            '    result in a lock of greater granularity.
         End If
      End Sub


      Private Sub StopThread()
         TerminateRequestReceived = True
      End Sub

   End Class

End Namespace

