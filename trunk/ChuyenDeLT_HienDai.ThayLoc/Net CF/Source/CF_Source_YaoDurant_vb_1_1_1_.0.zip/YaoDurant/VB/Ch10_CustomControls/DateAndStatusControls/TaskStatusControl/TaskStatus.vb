' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Windows.Forms

Imports DateBoxControl.YaoDurant.Gui

Namespace YaoDurant.Gui

   Public Class TaskStatus
      Inherits System.Windows.Forms.Control

#Region "Properties"

      ' The contained controls.
      Private WithEvents tskdtBegin, tskdtEnd As DateBox
      Private txtEstimated, txtActual As TextBox

      ' Their four values.
      Public Property dateBegin() As DateTime
         Get
            Return tskdtBegin.Date
         End Get
         Set(ByVal Value As DateTime)
            tskdtBegin.Date = Value
         End Set
      End Property

      Public Property dateEnd() As DateTime
         Get
            Return tskdtEnd.Date
         End Get
         Set(ByVal Value As DateTime)
            tskdtEnd.Date = Value
         End Set
      End Property

      Public Property durEstimated() As Integer
         Get
            Return Convert.ToInt32(txtEstimated.Text)
         End Get
         Set(ByVal Value As Integer)
            txtEstimated.Text = Value.ToString()
         End Set
      End Property

      Public Property durActual() As Integer
         Get
            Return Convert.ToInt32(txtActual.Text)
         End Get
         Set(ByVal Value As Integer)
            txtActual.Text = Value.ToString()
         End Set
      End Property

      ' The current display mode:  Text or graphic.
      Private Enum Modes
         modeText
         modeGraphic
      End Enum 'Modes
      Private m_Mode As Modes
      Private Property Mode() As Modes
         Get
            Return m_Mode
         End Get
         Set(ByVal Value As Modes)
            ' Set the Mode.if you have
            m_Mode = Value

            ' Child controls are used only when in modeText.
            Dim cntlX As Control
            For Each cntlX In Me.Controls
               cntlX.Visible = m_Mode = Modes.modeText
            Next cntlX

            ' State has changed; redraw this.
            Me.Invalidate()
         End Set
      End Property

      ' Brushes for filling.
      Private brushRed As New SolidBrush(Color.Red)
      Private brushGray As New SolidBrush(Color.LightSlateGray)
      Private brushGreen As New SolidBrush(Color.Green)
      Private brushBlack As New SolidBrush(Color.Black)

#End Region

#Region "Initialization and Termination"

      Public Sub New()
         ' Set background color to light gray.
         Me.BackColor = Color.LightSlateGray

         ' Create two DateBoxes and two TextBoxes 
         tskdtBegin = New DateBox
         tskdtBegin.Parent = Me
         tskdtEnd = New DateBox
         tskdtEnd.Parent = Me
         txtEstimated = New TextBox
         txtEstimated.Parent = Me
         txtEstimated.Width = tskdtBegin.Width / 2
         txtActual = New TextBox
         txtActual.Parent = Me
         txtActual.Width = tskdtBegin.Width / 2

         ' Position them from left to right to fill this.
         Dim PrevRight As Integer = 0
         Dim cntlX As Control
         For Each cntlX In Me.Controls
            cntlX.Left = PrevRight
            PrevRight += cntlX.Width
            cntlX.Visible = True
         Next cntlX
         Me.Height = tskdtEnd.Height
         Me.Width = PrevRight + Me.Height / 3

         ' Set the Mode.
         Me.m_Mode = Modes.modeText
      End Sub 'New

#End Region

#Region "Overrides"

      Protected Overrides Sub OnClick(ByVal e As EventArgs)
         ' Call base class method.
         MyBase.OnClick(e)

         ' Swap modes.
         Me.Mode = IIf(Me.Mode = Modes.modeText, _
                          Modes.modeGraphic, _
                          Modes.modeText)
      End Sub


      Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
         ' Call base class method.
         MyBase.OnPaint(e)

         Select Case Me.Mode
            Case Modes.modeText
               ' In textMode the contained controls
               '    do all the work.
            Case Modes.modeGraphic
               ' The client rectangle represents the time
               '    from task start to task end.  Draw a
               '    rectangle from the left that represents
               '    the percentage of task completion.  Draw
               '    a small triangle to mark today, relative
               '    to task start / end.
               ' If more time has passed than task has been
               '    completed, the task is behind schedule;
               '    color the rectangle red.  Otherwise color
               '    it green.
               ' Calculate coordinates.
               Dim daysStartToEnd As Integer = _
                  dateEnd.Subtract(Me.dateBegin).Days
               Dim daysStartToNow As Integer = _
                  DateTime.Today.Subtract(Me.dateBegin).Days
               Dim rectX As Rectangle = Me.ClientRectangle
               Dim xposToday As Integer = _
                  rectX.Width * daysStartToNow / daysStartToEnd
               Dim xposComplete As Integer = _
                  rectX.Width * durActual / durEstimated
               Dim yposAll As Integer = Me.Height / 2
               Dim arrptTriangle As Point() = _
                  {New Point(xposToday - yposAll / 2, 0), _
                   New Point(xposToday, yposAll), _
                   New Point(xposToday + yposAll / 2, 0)}

               ' Draw rectangle.
               rectX.Width = xposComplete
               e.Graphics.FillRectangle( _
                  IIf(xposToday <= xposComplete, _
                      brushGreen, _
                      brushRed), _
                  rectX)
               ' Draw triangle.
               e.Graphics.FillPolygon(brushBlack, arrptTriangle)
         End Select
      End Sub
#End Region

#Region "Events"

      Private Sub Dates_Validating( _
                        ByVal sender As Object, _
                        ByVal e As CancelEventArgs _
                        ) _
                        Handles tskdtBegin.Validating, _
                                tskdtEnd.Validating

         '  If the DateBox's validation routine says that
         '     the date is invalid, do not continue to 
         '     validate it.  (There is only "bad", there
         '     is no "badder").
         If e.Cancel = True Then
            Exit Sub
         End If

         '  Convert the two date textboxes' Text 
         '     property values into dates.
         Dim dtBegin As DateTime = _
            CType(tskdtBegin.Text, DateTime)
         Dim dtEnd As DateTime = _
            CType(tskdtEnd.Text, DateTime)

         '  Start date must be prior to end date.
         If Not dtBegin <= dtEnd Then
            MessageBox.Show( _
               "Start date must be prior to end date.", _
               "Error", _
               MessageBoxButtons.OK, _
               MessageBoxIcon.Exclamation, _
               MessageBoxDefaultButton.Button1)
            e.Cancel = True
         End If
      End Sub
#End Region

   End Class

End Namespace


