' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.ComponentModel
Imports System.Drawing
Imports System.Windows.Forms

Imports WaterTempControl.YaoDurant.Types

Namespace YaoDurant.Gui
   Public Class WaterBox
      Inherits TextBox

#Region "Properties"
      ' Temperature.  
      '    The WaterTemp contained and displayed 
      '       in this control.
      Private boolSettingTemperature As Boolean
      Private m_Temperature As WaterTemp
      Public Property Temperature() As WaterTemp
         Get
            Return m_Temperature
         End Get
         Set(ByVal Value As WaterTemp)
            ' Set the private Temperature.
            m_Temperature = Value

            ' Set the Text property
            boolSettingTemperature = True
            Me.Text = m_Temperature.ToString()
            boolSettingTemperature = False

            ' Set the background color to 
            '    indicate ice / water / steam.
            Me.BackColor = Color.White
            If m_Temperature.CompareTo(New WaterTemp("0c")) = -1 Then
               Me.BackColor = Color.LightSteelBlue
            End If
            If m_Temperature.CompareTo(New WaterTemp("100c")) = 1 Then
               Me.BackColor = Color.LightPink
            End If
         End Set
      End Property

      '   Text
      Public Overrides Property [Text]() As String
         Get
            Return MyBase.Text
         End Get
         Set(ByVal Value As String)
            Try
               ' There is no such thing as an "empty" 
               '    Temperature.  No Temperature means 
               '    zero digrees Kelvin.
               If Value = [String].Empty Then
                  Value = "0k"
               End If

               ' To prevent an infinite loop...
               ' If we are being called because the 
               '    Temperature property is being set, 
               '    do not set the Temperature property.  
               '    Else, set the Temperature to keep it 
               '    in synch with the Text property.
               If boolSettingTemperature Then
                  MyBase.Text = Value
               Else
                  Me.Temperature = New WaterTemp(Value)
               End If
            Catch
               ' Unable to convert value to WaterTemp.
               ' (Highly unlikely that "base.Text = value;" 
               '    would cause the exception.)
            Finally
            End Try
         End Set
      End Property
#End Region

#Region "Initialization and Termination"

      Public Sub New()
         ' Initialize Temperature.
         Me.Temperature = New WaterTemp("0k")
      End Sub 'New


      Public Sub New(ByVal strTemp As String)
         ' Initialize Temperature.
         Me.Temperature = New WaterTemp(strTemp)
      End Sub 'New

#End Region

#Region "Base Class Overrides"
      Private Sub WaterBox_Validating( _
                              ByVal sender As Object, _
                              ByVal e As CancelEventArgs _
                              ) _
                              Handles MyBase.Validating

         ' Ensure that the Text property contains a Temperature.
         ' If not, set background color to red and set the 
         '    EventArg's Cancel property to true to indicate 
         '    that validation failed.
         Try
            Me.Text = Me.Text
         Catch
            Me.BackColor = Color.Red
            e.Cancel = True
         Finally
         End Try
      End Sub


#End Region

   End Class
End Namespace