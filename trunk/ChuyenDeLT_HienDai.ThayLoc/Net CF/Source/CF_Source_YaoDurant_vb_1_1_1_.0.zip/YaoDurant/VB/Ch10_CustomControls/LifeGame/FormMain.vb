' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.IO
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Threading

Public Class FormMain
   Inherits System.Windows.Forms.Form
   Friend WithEvents mnuMain As MainMenu

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.mnuMain = New MainMenu
      '
      'FormMain
      '
      Me.Menu = Me.mnuMain
      Me.Text = "Life Game"

   End Sub

#End Region

#Region "Properties"
   '	The LifeMain object.  It contains,
   '		and runs, the Life Game; and it
   '		supplies the control needed to
   '		display the game.
   Private WithEvents refLifeMain As LifeMain

   '	"Game is running" indicator.
   Private boolRun As Boolean = False
#End Region

#Region "Controls"
   Private WithEvents panelCells As Panel
   Private WithEvents btnStartStop As Button
   Private WithEvents facadeLifeGame As LifeGame.LifeControl

   Private WithEvents mnuFile As MenuItem
   Private WithEvents mnuStartStop As MenuItem
   Private WithEvents mnuExit As MenuItem

   Private WithEvents mnuPattern As MenuItem
   Private WithEvents mnuEmpty As MenuItem
   Private WithEvents mnuReset As MenuItem
   Private WithEvents mnuManual As MenuItem

   Private WithEvents mnuCheckers As MenuItem
   Private WithEvents mnuBoard As MenuItem
   Private WithEvents mnuSelfFix As MenuItem
   Private WithEvents mnuSelfDestruct As MenuItem

   Private WithEvents mnuLines As MenuItem
   Private WithEvents mnuDiagonal As MenuItem
   Private WithEvents mnuVertical As MenuItem
   Private WithEvents mnuFlawedVertical As MenuItem

   Private WithEvents mnuGliders As MenuItem
   Private WithEvents mnuGlider As MenuItem
   Private WithEvents mnuGliderMate As MenuItem
   Private WithEvents mnuGliderPump As MenuItem

   Private WithEvents mnuSmalls As MenuItem
   Private WithEvents mnuFiveCell As MenuItem
   Private WithEvents mnuSixCell As MenuItem
   Private WithEvents mnuEightCell As MenuItem
   Private WithEvents mnuTenCell As MenuItem

   Private WithEvents mnuSpeed As MenuItem
   Private WithEvents mnuFastest As MenuItem
   Private WithEvents mnuFast As MenuItem
   Private WithEvents mnuFaster As MenuItem
   Private WithEvents mnuSpeedNormal As MenuItem
   Private WithEvents mnuSlower As MenuItem
   Private WithEvents mnuSlow As MenuItem
   Private WithEvents mnuSlowest As MenuItem

   Private WithEvents mnuZoom As MenuItem
   Private WithEvents mnuInnest As MenuItem
   Private WithEvents mnuIn As MenuItem
   Private WithEvents mnuSizeNormal As MenuItem
   Private WithEvents mnuOut As MenuItem
   Private WithEvents mnuOutest As MenuItem

   Private WithEvents mnuAbout As MenuItem
#End Region

#Region " Initialization "
   Private Sub FormMain_Load(ByVal sender As Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles MyBase.Load
      InitLifeGame()
      InitMenus()
      WindowState = FormWindowState.Maximized
      PositionControls()
   End Sub


   Private Sub InitLifeGame()
      '	Create a new LifeMain object.
      refLifeMain = New LifeMain

      '	Get the display control from the LifeGame 
      '		object.  Make it visible.  Specify a
      '		click event for it.  Add it to the form.
      facadeLifeGame = refLifeMain.refFacade
      facadeLifeGame.Visible = True
      Me.Controls.Add(Me.facadeLifeGame)
   End Sub


   Private Sub PositionControls()
      '	Postion controls on form.
      facadeLifeGame.BackColor = Color.Tan
      utilGUI.SetBounds(facadeLifeGame, ClientRectangle.Left, ClientRectangle.Top, IIf(ClientRectangle.Width < ClientRectangle.Height, ClientRectangle.Width, ClientRectangle.Height), IIf(ClientRectangle.Width < ClientRectangle.Height, ClientRectangle.Width, ClientRectangle.Height))
      '      utilGUI.SetBounds(panelCells, facadeLifeGame.Width, ClientRectangle.Height / 4 * 2, ClientRectangle.Width - facadeLifeGame.Width, ClientRectangle.Height / 4)
      btnStartStop.Enabled = False
      mnuStartStop.Enabled = False
   End Sub

#End Region

#Region "Menu Initialization"
   Private Sub InitMenus()
      Me.btnStartStop = New Button
      Me.mnuFile = New MenuItem
      Me.mnuStartStop = New MenuItem
      Me.mnuExit = New MenuItem
      Me.mnuPattern = New MenuItem
      Me.mnuEmpty = New MenuItem
      Me.mnuReset = New MenuItem
      Me.mnuManual = New MenuItem
      Me.mnuSmalls = New MenuItem
      Me.mnuFiveCell = New MenuItem
      Me.mnuSixCell = New MenuItem
      Me.mnuEightCell = New MenuItem
      Me.mnuTenCell = New MenuItem
      Me.mnuSpeed = New MenuItem
      Me.mnuFastest = New MenuItem
      Me.mnuFast = New MenuItem
      Me.mnuFaster = New MenuItem
      Me.mnuSpeedNormal = New MenuItem
      Me.mnuSlower = New MenuItem
      Me.mnuSlow = New MenuItem
      Me.mnuSlowest = New MenuItem
      Me.mnuZoom = New MenuItem
      Me.mnuInnest = New MenuItem
      Me.mnuIn = New MenuItem
      Me.mnuSizeNormal = New MenuItem
      Me.mnuOut = New MenuItem
      Me.mnuOutest = New MenuItem
      Me.mnuLines = New MenuItem
      Me.mnuDiagonal = New MenuItem
      Me.mnuVertical = New MenuItem
      Me.mnuFlawedVertical = New MenuItem
      Me.mnuCheckers = New MenuItem
      Me.mnuBoard = New MenuItem
      Me.mnuSelfFix = New MenuItem
      Me.mnuSelfDestruct = New MenuItem
      Me.mnuGliders = New MenuItem
      Me.mnuGlider = New MenuItem
      Me.mnuGliderMate = New MenuItem
      Me.mnuGliderPump = New MenuItem
      Me.mnuAbout = New MenuItem
      ' 
      ' mnuMain
      ' 
      Me.mnuMain.MenuItems.Add(Me.mnuFile)
      Me.mnuMain.MenuItems.Add(Me.mnuPattern)
      Me.mnuMain.MenuItems.Add(Me.mnuSpeed)
      Me.mnuMain.MenuItems.Add(Me.mnuZoom)
      ' 
      ' mnuFile
      ' 
      Me.mnuFile.MenuItems.Add(Me.mnuStartStop)
      Me.mnuFile.MenuItems.Add(Me.mnuExit)
      Me.mnuFile.Text = "File"
      ' 
      ' mnuStartStop
      ' 
      Me.mnuStartStop.Text = "S&tart"
      ' 
      ' mnuExit
      ' 
      Me.mnuExit.Text = "E&xit"
      ' 
      ' mnuPattern
      ' 
      Me.mnuPattern.MenuItems.Add(Me.mnuEmpty)
      Me.mnuPattern.MenuItems.Add(Me.mnuReset)
      Me.mnuPattern.MenuItems.Add(Me.mnuManual)
      Me.mnuPattern.MenuItems.Add(Me.mnuSmalls)
      Me.mnuPattern.MenuItems.Add(Me.mnuLines)
      Me.mnuPattern.MenuItems.Add(Me.mnuCheckers)
      Me.mnuPattern.MenuItems.Add(Me.mnuGliders)
      Me.mnuPattern.Text = "Pattern"
      ' 
      ' mnuEmpty
      ' 
      Me.mnuEmpty.Text = "Empty"
      ' 
      ' mnuReset
      ' 
      Me.mnuReset.Text = "Reset"
      ' 
      ' mnuManual
      ' 
      Me.mnuManual.Text = "Manual"
      ' 
      ' mnuSmalls
      ' 
      Me.mnuSmalls.MenuItems.Add(Me.mnuFiveCell)
      Me.mnuSmalls.MenuItems.Add(Me.mnuSixCell)
      Me.mnuSmalls.MenuItems.Add(Me.mnuEightCell)
      Me.mnuSmalls.MenuItems.Add(Me.mnuTenCell)
      Me.mnuSmalls.Text = "Smalls"
      ' 
      ' mnuFiveCell
      ' 
      Me.mnuFiveCell.Text = "Five Cell"
      ' 
      ' mnuSixCell
      ' 
      Me.mnuSixCell.Text = "Six Cell"
      ' 
      ' mnuEightCell
      ' 
      Me.mnuEightCell.Text = "Eight Cell"
      ' 
      ' mnuTenCell
      ' 
      Me.mnuTenCell.Text = "Ten Cell"
      ' 
      ' mnuSpeed
      ' 
      Me.mnuSpeed.MenuItems.Add(Me.mnuFastest)
      Me.mnuSpeed.MenuItems.Add(Me.mnuFast)
      Me.mnuSpeed.MenuItems.Add(Me.mnuFaster)
      Me.mnuSpeed.MenuItems.Add(Me.mnuSpeedNormal)
      Me.mnuSpeed.MenuItems.Add(Me.mnuSlower)
      Me.mnuSpeed.MenuItems.Add(Me.mnuSlow)
      Me.mnuSpeed.MenuItems.Add(Me.mnuSlowest)
      Me.mnuSpeed.Text = "Speed"
      ' 
      ' mnuFastest
      ' 
      Me.mnuFastest.Text = "Fastest"
      ' 
      ' mnuFast
      ' 
      Me.mnuFast.Text = "Fast"
      ' 
      ' mnuFaster
      ' 
      Me.mnuFaster.Text = "Faster"
      ' 
      ' mnuSpeedNormal
      ' 
      Me.mnuSpeedNormal.Text = "Normal"
      ' 
      ' mnuSlower
      ' 
      Me.mnuSlower.Text = "Slower"
      ' 
      ' mnuSlow
      ' 
      Me.mnuSlow.Text = "Slow"
      ' 
      ' mnuSlowest
      ' 
      Me.mnuSlowest.Text = "Slowest"
      ' 
      ' mnuZoom
      ' 
      Me.mnuZoom.MenuItems.Add(Me.mnuInnest)
      Me.mnuZoom.MenuItems.Add(Me.mnuIn)
      Me.mnuZoom.MenuItems.Add(Me.mnuSizeNormal)
      Me.mnuZoom.MenuItems.Add(Me.mnuOut)
      Me.mnuZoom.MenuItems.Add(Me.mnuOutest)
      Me.mnuZoom.Text = "Zoom"
      ' 
      ' mnuInnest
      ' 
      Me.mnuInnest.Text = "Innest"
      ' 
      ' mnuIn
      ' 
      Me.mnuIn.Text = "In"
      ' 
      ' mnuSizeNormal
      ' 
      Me.mnuSizeNormal.Text = "Normal"
      ' 
      ' mnuOut
      ' 
      Me.mnuOut.Text = "Out"
      ' 
      ' mnuOutest
      ' 
      Me.mnuOutest.Text = "Outest"
      ' 
      ' mnuLines
      ' 
      Me.mnuLines.MenuItems.Add(Me.mnuDiagonal)
      Me.mnuLines.MenuItems.Add(Me.mnuVertical)
      Me.mnuLines.MenuItems.Add(Me.mnuFlawedVertical)
      Me.mnuLines.Text = "Lines"
      ' 
      ' mnuDiagonal
      ' 
      Me.mnuDiagonal.Text = "Diagonal"
      ' 
      ' mnuVertical
      ' 
      Me.mnuVertical.Text = "Vertical"
      ' 
      ' mnuFlawedVertical
      ' 
      Me.mnuFlawedVertical.Text = "FlawedVertical"
      ' 
      ' mnuCheckers
      ' 
      Me.mnuCheckers.MenuItems.Add(Me.mnuBoard)
      Me.mnuCheckers.MenuItems.Add(Me.mnuSelfFix)
      Me.mnuCheckers.MenuItems.Add(Me.mnuSelfDestruct)
      Me.mnuCheckers.Text = "Checkers"
      ' 
      ' mnuBoard
      ' 
      Me.mnuBoard.Text = "Board"
      ' 
      ' mnuSelfFix
      ' 
      Me.mnuSelfFix.Text = "Self Fixing"
      ' 
      ' mnuSelfDestruct
      ' 
      Me.mnuSelfDestruct.Text = "Self Destructive"
      ' 
      ' mnuGliders
      ' 
      Me.mnuGliders.MenuItems.Add(Me.mnuGlider)
      Me.mnuGliders.MenuItems.Add(Me.mnuGliderMate)
      Me.mnuGliders.MenuItems.Add(Me.mnuGliderPump)
      Me.mnuGliders.Text = "Gliders"
      ' 
      ' mnuGlider
      ' 
      Me.mnuGlider.Text = "Single"
      ' 
      ' mnuGliderMate
      ' 
      Me.mnuGliderMate.Text = "Mate"
      ' 
      ' mnuGliderPump
      ' 
      Me.mnuGliderPump.Text = "Pump"
      ' 
      ' mnuAbout
      ' 
      Me.mnuAbout.Text = "&Help"

      ' Starting selections
      'Me.mnuSpeed_Click(Me.mnuSpeedNormal, EventArgs.Empty)
      'Me.mnuZoom_Click(Me.mnuSizeNormal, EventArgs.Empty)
   End Sub
#End Region

#Region "Utitlities"
   Private Function LittlePowerOfTwo(ByVal exponent As Integer) As Integer
      '	Don't laugh.  It is not in the CLR 
      '		(except for SQL non-integer types).
      Select Case exponent
         Case 0
            Return 1
         Case 1
            Return 2
         Case 2
            Return 4
         Case 3
            Return 8
         Case 4
            Return 16
         Case 5
            Return 32
         Case 6
            Return 64
         Case 7
            Return 128
         Case 8
            Return 256
         Case 9
            Return 512
         Case 10
            Return 1024
         Case Else
            Return 1024
      End Select
   End Function 'LittlePowerOfTwo
#End Region

#Region "Menu Processing"

   Private Sub mnuStartStop_Click(ByVal sender As Object, _
                                  ByVal e As System.EventArgs _
                                  ) _
                                  Handles mnuStartStop.Click

      '	The Start/Stop button is a toggle.
      boolRun = Not boolRun

      '	If requested to run.
      If boolRun Then
         '	Do not allow the user to do certain
         '		things while the game is running.
         btnStartStop.Text = "S&top"
         mnuStartStop.Text = "S&top"
         mnuExit.Enabled = False

         '	Notify the object to start the game.
         refLifeMain.StartGame()
         '	If requested to stop.
      Else
         refLifeMain.StopGame()
         btnStartStop.Text = "S&tart"
         mnuStartStop.Text = "S&tart"
         mnuExit.Enabled = True
      End If
   End Sub 'mnuStartStop_Click


   Private Sub mnuExit_Click(ByVal sender As Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles mnuExit.Click
      Application.Exit()
   End Sub 'mnuExit_Click


   Private Sub mnuPatterns_Click(ByVal sender As Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles mnuBoard.Click, _
                                      mnuDiagonal.Click, _
                                      mnuEightCell.Click, _
                                      mnuEmpty.Click, _
                                      mnuFiveCell.Click, _
                                      mnuFlawedVertical.Click, _
                                      mnuGlider.Click, _
                                      mnuGliderMate.Click, _
                                      mnuGliderPump.Click, _
                                      mnuSelfDestruct.Click, _
                                      mnuSelfFix.Click, _
                                      mnuSixCell.Click, _
                                      mnuTenCell.Click, _
                                      mnuVertical.Click
      '	Some pattern work best at certain sizes.
      '         if( sender == mnuTenCell ) tbarSize.Value = 7;
      '         if( sender == mnuFlawedVertical ) tbarSize.Value = 7;
      '	Inform the LifeMain object of the 
      '		requested pattern.
      If sender Is mnuEmpty Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpEmpty)
      End If
      If sender Is mnuFiveCell Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpFiveCell)
      End If
      If sender Is mnuSixCell Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpSixCell)
      End If
      If sender Is mnuEightCell Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpEightCell)
      End If
      If sender Is mnuTenCell Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpTenCell)
      End If
      If sender Is mnuVertical Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpVertical)
      End If
      If sender Is mnuFlawedVertical Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpFlawedVertical)
      End If
      If sender Is mnuDiagonal Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpDiagonal)
      End If
      If sender Is mnuBoard Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpBoard)
      End If
      If sender Is mnuSelfFix Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpSelfFix)
      End If
      If sender Is mnuSelfDestruct Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpSelfDestruct)
      End If
      If sender Is mnuGlider Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpGlider)
      End If
      If sender Is mnuGliderMate Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpGliderMate)
      End If
      If sender Is mnuGliderPump Then
         refLifeMain.SetPattern(LifeMain.lgpPattern.lgpGliderPump)
      End If
      '	If there is a pattern in the window,
      '		enable the start button and give
      '		it the focus.
      btnStartStop.Enabled = Not (sender Is mnuEmpty)
      mnuStartStop.Enabled = Not (sender Is mnuEmpty)
      If btnStartStop.Enabled Then
         btnStartStop.Focus()
      End If
      '	Prepare to draw the patterns.
      facadeLifeGame.Invalidate()
   End Sub 'mnuPatterns_Click


   Private Sub mnuReset_Click(ByVal sender As Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles mnuReset.Click
      refLifeMain.Reset()
      facadeLifeGame.Invalidate()
   End Sub 'mnuReset_Click


   Private Sub mnuManual_Click(ByVal sender As Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles mnuManual.Click
      MessageBox.Show("Click in the window to create or alter a pattern")
   End Sub 'mnuManual_Click


   Private Sub mnuSpeed_Click(ByVal sender As Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles mnuFast.Click, _
                                      mnuFaster.Click, _
                                      mnuFastest.Click, _
                                      mnuSpeedNormal.Click, _
                                      mnuSlow.Click, _
                                      mnuSlower.Click, _
                                      mnuSlowest.Click
      If refLifeMain Is Nothing Then
         Return
      End If
      Select Case CType(sender, MenuItem).Text
         Case "Fastest"
            refLifeMain.ChangeRunSpeed(CInt(utilGUI.gameSpeed.gsFastest))
         Case "Fast"
            refLifeMain.ChangeRunSpeed(CInt(utilGUI.gameSpeed.gsFast))
         Case "Faster"
            refLifeMain.ChangeRunSpeed(CInt(utilGUI.gameSpeed.gsFaster))
         Case "Normal"
            refLifeMain.ChangeRunSpeed(CInt(utilGUI.gameSpeed.gsNormal))
         Case "Slower"
            refLifeMain.ChangeRunSpeed(CInt(utilGUI.gameSpeed.gsSlower))
         Case "Slow"
            refLifeMain.ChangeRunSpeed(CInt(utilGUI.gameSpeed.gsSlow))
         Case "Slowest"
            refLifeMain.ChangeRunSpeed(CInt(utilGUI.gameSpeed.gsSlowest))
      End Select
   End Sub 'mnuSpeed_Click


   Private Sub mnuZoom_Click(ByVal sender As Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles mnuIn.Click, _
                                      mnuInnest.Click, _
                                      mnuOut.Click, _
                                      mnuOutest.Click, _
                                      mnuSizeNormal.Click
      If refLifeMain Is Nothing Then
         Return
      End If
      Select Case CType(sender, MenuItem).Text
         Case "Innest"
            refLifeMain.ChangeDisplaySize(CInt(utilGUI.gameZoom.gzInnest))
         Case "In"
            refLifeMain.ChangeDisplaySize(CInt(utilGUI.gameZoom.gzIn))
         Case "Normal"
            refLifeMain.ChangeDisplaySize(CInt(utilGUI.gameZoom.gzNormal))
         Case "Out"
            refLifeMain.ChangeDisplaySize(CInt(utilGUI.gameZoom.gzOut))
         Case "Outest"
            refLifeMain.ChangeDisplaySize(CInt(utilGUI.gameZoom.gzOutest))
      End Select
   End Sub 'mnuZoom_Click

#End Region

#Region "Event Handlers"

   Private Sub facadeLifeGame_MouseUp(ByVal sender As Object, _
                              ByVal e As MouseEventArgs _
                              ) _
                              Handles facadeLifeGame.MouseUp
      '	The user is entering a pattern,
      '		enable Run.
      btnStartStop.Enabled = (mnuStartStop.Enabled = True)
   End Sub 'facadeLifeGame_MouseUp


   Private Sub LifeMain_NextGenReady(ByVal sender As Object, _
                              ByVal e As EventArgs _
                              ) _
                              Handles refLifeMain.NextGenReady
      ' Place a reference to the current and previous
      '    generation into properties of the control.
      '    Then have the control draw the current 
      '    generation.
      Me.facadeLifeGame.refCurr = refLifeMain.genCurr
      Me.facadeLifeGame.refPrev = refLifeMain.genPrev
      Me.facadeLifeGame.Invalidate()
      Application.DoEvents()
   End Sub 'LifeMain_NextGenReady


   Private Sub LifeMain_StableStateReached(ByVal sender As Object, _
                              ByVal e As EventArgs _
                              ) _
                              Handles refLifeMain.StableStateReached
      '	Delegate routine.  Called by LifeMain
      '		when the pattern is now static.
      mnuStartStop_Click(Me, EventArgs.Empty)
      Application.DoEvents()
      MessageBox.Show("Steady State")
   End Sub 'LifeMain_StableStateReached
#End Region

#Region "Termination"
   Private Sub FormMain_Closing(ByVal sender As Object, _
                              ByVal e As CancelEventArgs _
                              ) _
                              Handles MyBase.Closing
      '	If the form is closing, STOP THE GAME.	
      If Not (refLifeMain Is Nothing) Then
         refLifeMain.StopGame()
      End If
   End Sub 'FormMain_Closing

#End Region
End Class
