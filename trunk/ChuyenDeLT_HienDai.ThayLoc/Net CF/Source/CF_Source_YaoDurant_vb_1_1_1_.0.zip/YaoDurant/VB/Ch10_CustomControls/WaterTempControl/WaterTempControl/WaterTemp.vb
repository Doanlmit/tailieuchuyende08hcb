' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Text

Namespace YaoDurant.Types
   ' Summary description for WaterTemp.
   '   Consists of integer Temperature and a one character
   '      long Unit of Measure; K, F, or C (Kelvin, Farhenheit,
   '      Celsius).
   '   Has an overloaded constructor that accepts a string.
   '   Has ToString, CompareTo, Clone and Convert methods.
   Public Class WaterTemp

#Region "Properties"

      Private strError As String
      Private strerrFormat As String = _
         "Argument is not a valid water temperature.  Must " + _
         "be a positive integer followed by 'C', 'F', or 'K'."
      Private strerrUofM As String = _
         "Argument is not a valid unit of measure.  " + _
         "Must be 'C', 'F', or 'K'."
      Private strerrTemp As String = _
         "Temperature must be greater than absolute 0."

      Private m_Temperature As Integer
      Public ReadOnly Property Temperature() As Integer
         Get
            Return m_Temperature
         End Get
      End Property

      Private m_UnitOfMeasure As String
      Public ReadOnly Property UnitOfMeasure() As String
         Get
            Return m_UnitOfMeasure
         End Get
      End Property
#End Region

#Region "Constructors"

      Public Sub New()
         InitializeWaterTemp(String.Empty)
      End Sub
      Public Sub New(ByVal strTemp As String)
         InitializeWaterTemp(strTemp)
      End Sub

      Public Sub InitializeWaterTemp(ByVal strTemp As String)
         ' Convert a string, eg. " -44 c ", to a
         '    temperature and a unit of measure.
         ' An empty string produces a cold WaterTemp.!
         If strTemp = String.Empty Then
            strTemp = "0k"
         End If

         ' The last character, optional, is the Unit of
         '    Measure.  Everything else is the Temperature.
         strError = strerrFormat
         Try
            ' Split the input string on 'K', 'C', or 'F'.
            Dim strarrTemp() As String
            strTemp = strTemp.Trim().ToUpper()
            strarrTemp = strTemp.Split("KCF".ToCharArray())

            ' Store the temperature portion.  (If any letter
            '    other than K/C/F was specified as the UofM,
            '    it will be in strarrTemp[0] and will cause
            '    an exception here.)
            Me.m_Temperature = System.Convert.ToInt32(strarrTemp(0))

            ' The UofM, if any, is the last character.
            ' The default UofM is 'K' (Kelvin).
            Me.m_UnitOfMeasure = _
               IIf(strarrTemp.Length = 2, _
                  strTemp.Substring(strTemp.Length - 1, 1), _
                  "K")

            ' Temperature cannot be below 0 Kelvin.
            ' (Do not use Convert here.  Farhenheit prescision
            '    will be lost when converting to/from Kelvin.)
            strError = "Temperature cannot be below 0 Kelvin."
            If m_UnitOfMeasure = "K" And m_Temperature < 0 _
            Or (m_UnitOfMeasure = "C" And m_Temperature < -273) _
            Or (m_UnitOfMeasure = "F" And m_Temperature < -460) Then
               Throw New ArgumentException(strError)
            End If
         Catch
         Finally
         End Try
      End Sub
#End Region

#Region "Methods"

      Public Function Convert(ByVal strUofM As String) As WaterTemp '
         strUofM = strUofM.ToUpper()
         Dim intTemp As Integer = m_Temperature

         Select Case strUofM
            Case "K"
               Select Case m_UnitOfMeasure
                  Case "F"
                     intTemp = (intTemp + 40) * 5 / 9 - 40
                     intTemp += 273
                  Case "C"
                     intTemp += 273
               End Select
            Case "C"
               Select Case m_UnitOfMeasure
                  Case "K"
                     intTemp -= 273
                  Case "F"
                     intTemp = (intTemp + 40) * 5 / 9 - 40
               End Select
            Case "F"
               Select Case m_UnitOfMeasure
                  Case "K"
                     intTemp -= 273
                     intTemp = (intTemp + 40) * 9 / 5 - 40
                  Case "C"
                     intTemp = (intTemp + 40) * 9 / 5 - 40
               End Select
            Case Else
               Throw New ArgumentException(strerrUofM)
         End Select

         Return New WaterTemp(intTemp.ToString() + strUofM)
      End Function

      Public Function CompareTo(ByVal wtTarget As WaterTemp) As Integer
         ' If you and the target are the 
         '    same UofM, compare temperatures.
         ' Otherwise, convert yourself to the
         '    other's UofM and compare temperatures.  
         If Me.UnitOfMeasure = wtTarget.UnitOfMeasure Then
            Return m_Temperature.CompareTo(wtTarget.Temperature)
         Else
            Return m_Temperature.CompareTo( _
               wtTarget.Convert(m_UnitOfMeasure).Temperature)
         End If
      End Function

      Public Overrides Function ToString() As String
         Return m_Temperature.ToString() + m_UnitOfMeasure
      End Function

      Public Function Clone() As WaterTemp
         Return New WaterTemp(Me.ToString())
      End Function
#End Region

   End Class
End Namespace
