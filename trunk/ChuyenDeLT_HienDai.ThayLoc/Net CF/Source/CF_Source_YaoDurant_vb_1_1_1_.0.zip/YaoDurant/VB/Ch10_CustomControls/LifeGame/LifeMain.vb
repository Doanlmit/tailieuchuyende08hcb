' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.IO
Imports System.Threading

Public Class LifeMain
   ' Summary description for LifeMain.
   '	The main object.  It controls the game.
   '	It creates one LifeGeneration object for
   '	each generation.  Each generation object
   '	creates a LifeRow object for each of the
   '	512-1 rows that make up a generation.

#Region "Predefined Patterns"
   '	The list of pre-defined patterns.
   Public Enum lgpPattern
      lgpEmpty
      lgpDiagonal
      lgpVertical
      lgpFlawedVertical
      lgpFiveCell
      lgpSixCell
      lgpSevenCell
      lgpEightCell
      lgpTenCell
      lgpBoard
      lgpSelfFix
      lgpSelfDestruct
      lgpGlider
      lgpGliderMate
      lgpGliderPump
   End Enum 'lgpPattern
#End Region

#Region "Properties"
   '	Reference to the LifeControl that will
   '		display the generations.
   Public refFacade As LifeControl


   '	Event definition for NextGenReady.
   Delegate Sub deleNextGenReady(ByVal sender As Object, ByVal e As EventArgs)

   '	Event definition for StableStateReached.
   Delegate Sub deleStableStateReached(ByVal sender As Object, ByVal e As EventArgs)

   '	The size of the grid.  That is,
   '		each generation will contain 
   '		noofCells * noofCells cells.
   Friend Const noofCells As Integer = 512 - 1
   '	The display size.  That is
   '		the display will contain 
   '		noofDisplay * noofDisplay cells.
   Friend Shared noofDisplay As Integer = 64 - 1

   '	A set of generations.
   '		Zero => The starting pattern.
   '		Next => The next generation.
   '		Curr => The current generation.
   '		Prev => The previous generation.
   '		Grand => The grandfather generation.
   '		Four => The great grandfather generation.
   Friend genZero As New LifeGeneration
   Friend genNext As New LifeGeneration
   Friend genCurr As New LifeGeneration
   Friend genPrev As New LifeGeneration
   Friend genGrand As New LifeGeneration
   Friend genFour As New LifeGeneration

   ' Run speed.  No of milleseconds 
   '		between generations.
   Private m_RunSpeed As Integer = 1024

   Public Property RunSpeed() As Integer
      Get
         Return m_RunSpeed
      End Get
      Set(ByVal Value As Integer)
         m_RunSpeed = value
      End Set
   End Property

   ' Number of live cells.  In
   '		actuality, the number 
   '		of live cells in the
   '		current generation.
   '	Updates the Peak number
   '		as necessary.

   Public ReadOnly Property noofLive() As Integer
      Get
         Dim temp As Integer = genCurr.noofLive
         If temp > m_noofLivePeak Then
            m_noofLivePeak = temp
         End If
         Return temp
      End Get
   End Property

   ' Peak number of live cells.
   Private m_noofLivePeak As Integer = 0
   Public ReadOnly Property noofLivePeak() As Integer
      Get
         Return m_noofLivePeak
      End Get
   End Property

   '	Number of generations.  In
   '		actuality, the generation 
   '		number of the current 
   '		generation.

   Public ReadOnly Property noofGeneration() As Integer
      Get
         Return genCurr.countGeneration
      End Get
   End Property

   '	Lapsed time, in seconds.
   Private dtStart As DateTime = DateTime.Now

   Public ReadOnly Property secondsLapsed() As Integer
      Get
         Return DateTime.Now.Subtract(dtStart).Minutes * 60 + DateTime.Now.Subtract(dtStart).Seconds
      End Get
   End Property

   ' Indicator that client is now
   '		iteratively calculating
   '		generations; that is, the
   '		client is in "run" mode.
   Friend Shared boolRun As Boolean

   '	Indication that the entire pattern
   '		needs to be repainted.  When
   '		turned off, only cells that have
   '		changed are repainted.
   Friend Shared boolPaintAll As Boolean
#End Region

#Region "System Methods"
   ' Constructor.
   Public Sub New()
      '	Set the current pattern to empty.
      genCurr.Clear()
      boolPaintAll = True

      ' Create an instance of the display control.
      refFacade = New LifeGame.LifeControl
   End Sub
#End Region

#Region "Public Methods"
   Public Sub StartGame()
      '	Start the generation
      '		calculation loop.
      ' Remove the menu.  Must be done here because
      '    this control is responsible for erasing
      '    its own background.
      Redraw()

      '	Save the current pattern, for
      '		"reset" purposes.
      genCurr.CopyTo(genZero)

      '	Clear all previous patterns.
      genPrev.SetPattern(lgpPattern.lgpEmpty)
      genGrand.SetPattern(lgpPattern.lgpEmpty)
      genFour.SetPattern(lgpPattern.lgpEmpty)

      '	Init some properties.
      dtStart = DateTime.Now

      '	Start calcuating generations
      boolRun = True
      While boolRun
         CalcNextGen()
         boolPaintAll = False
         OnNextGenReady()
         boolPaintAll = True
         Thread.Sleep(CInt(RunSpeed))
      End While
   End Sub


   Public Sub StopGame()
      '	Halt the generation
      '		calculation loop.
      ' Remove the menu.  Must be done here because
      '    this control is responsible for erasing
      '    its own background.
      Redraw()

      ' Halt.
      boolRun = False
   End Sub


   Public Sub CalcNextGen()
      '	Have the current generation calculate
      '		the next generation.
      genNext = genCurr.CalcNextGen()

      '	Check to see if a static state has been
      '		has been reached.
      If genNext.countGeneration >= 4 And genNext.CompareTo(genFour) = 0 Then
         OnStableStateReached()
      End If
      '	Age the generations
      genFour = genGrand
      genGrand = genPrev
      genPrev = genCurr
      genCurr = genNext
   End Sub


   Public Sub ChangeDisplaySize(ByVal gsZoom As Integer)
      noofDisplay = gsZoom
      Redraw()
   End Sub


   Public Sub ChangeRunSpeed(ByVal gsSpeed As Integer)
      RunSpeed = gsSpeed
      Redraw()
   End Sub


   Public Sub SetPattern(ByVal Pattern As lgpPattern)
      '	Have the current generation do it.
      genCurr.SetPattern(Pattern)
      Redraw()
   End Sub


   Public Sub SetRow(ByVal ixRow As Integer, ByVal arrayArgs() As Integer)
      '	Have the current generation do it.
      genCurr.SetRow(ixRow, arrayArgs)
      Redraw()
   End Sub


   Public Sub Reset()
      '	Restore the current pattern.
      genZero.CopyTo(genCurr)

      '	Clear all previous patterns.
      genPrev.SetPattern(lgpPattern.lgpEmpty)
      genGrand.SetPattern(lgpPattern.lgpEmpty)
      genFour.SetPattern(lgpPattern.lgpEmpty)
      Redraw()
   End Sub

#End Region

#Region "Private Methods"

   Private Sub Redraw()
      '	Do a complete repaint of
      '		the current generation.
      boolPaintAll = True
      OnNextGenReady()
   End Sub


   Private Function LittlePowerOfTwo(ByVal exponent As Integer) As Integer
      '	Don't laugh.  It is not in the CLR 
      '		(except for SQL non-integer types).
      Select Case exponent
         Case 0
            Return 1
         Case 1
            Return 2
         Case 2
            Return 4
         Case 3
            Return 8
         Case 4
            Return 16
         Case 5
            Return 32
         Case 6
            Return 64
         Case 7
            Return 128
         Case 8
            Return 256
         Case 9
            Return 512
         Case 10
            Return 1024
         Case Else
            Return 1024
      End Select
   End Function
#End Region

#Region "Event Raisers"
   '	Event raisers.
   '		This object raises two events, the "next generation
   '		has been calculated" event and the "game has reached
   '    a stable state" event.  Both events pass no 
   '    additional information when raised.
   Event NextGenReady As deleNextGenReady
   Protected Overridable Sub OnNextGenReady()
      RaiseEvent NextGenReady(Me, EventArgs.Empty)
   End Sub

   Public Event StableStateReached As deleStableStateReached
   Protected Overridable Sub OnStableStateReached()
      RaiseEvent StableStateReached(Me, EventArgs.Empty)
   End Sub
#End Region

End Class
