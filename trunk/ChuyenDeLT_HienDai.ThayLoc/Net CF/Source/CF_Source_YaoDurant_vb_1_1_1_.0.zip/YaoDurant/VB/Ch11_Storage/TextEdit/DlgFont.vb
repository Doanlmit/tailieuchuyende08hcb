' DlgFont.vb - Edit Font dialog box.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System.Runtime.InteropServices

Namespace DialogBoxes
   Public Class DlgFont
      Inherits System.Windows.Forms.Form
         Friend WithEvents label2 As System.Windows.Forms.Label
         Friend WithEvents comboFont As System.Windows.Forms.ComboBox
         Friend WithEvents label3 As System.Windows.Forms.Label
         Friend WithEvents comboSize As System.Windows.Forms.ComboBox
         Friend WithEvents chkBold As System.Windows.Forms.CheckBox
         Friend WithEvents chkItalic As System.Windows.Forms.CheckBox
         Friend WithEvents chkUnderline As System.Windows.Forms.CheckBox

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.label2 = New System.Windows.Forms.Label
Me.comboFont = New System.Windows.Forms.ComboBox
Me.label3 = New System.Windows.Forms.Label
Me.comboSize = New System.Windows.Forms.ComboBox
Me.chkBold = New System.Windows.Forms.CheckBox
Me.chkItalic = New System.Windows.Forms.CheckBox
Me.chkUnderline = New System.Windows.Forms.CheckBox
'
'label2
'
Me.label2.Location = New System.Drawing.Point(8, 32)
Me.label2.Size = New System.Drawing.Size(48, 20)
Me.label2.Text = "Font:"
'
'comboFont
'
Me.comboFont.Location = New System.Drawing.Point(8, 48)
Me.comboFont.Size = New System.Drawing.Size(120, 22)
'
'label3
'
Me.label3.Location = New System.Drawing.Point(152, 32)
Me.label3.Size = New System.Drawing.Size(56, 20)
Me.label3.Text = "Size:"
'
'comboSize
'
Me.comboSize.Items.Add("8")
Me.comboSize.Items.Add("9")
Me.comboSize.Items.Add("10")
Me.comboSize.Items.Add("11")
Me.comboSize.Items.Add("12")
Me.comboSize.Items.Add("14")
Me.comboSize.Items.Add("16")
Me.comboSize.Items.Add("20")
Me.comboSize.Items.Add("24")
Me.comboSize.Items.Add("28")
Me.comboSize.Items.Add("36")
Me.comboSize.Location = New System.Drawing.Point(152, 48)
Me.comboSize.Size = New System.Drawing.Size(56, 22)
'
'chkBold
'
Me.chkBold.Location = New System.Drawing.Point(32, 88)
Me.chkBold.Text = "Bold"
'
'chkItalic
'
Me.chkItalic.Location = New System.Drawing.Point(32, 112)
Me.chkItalic.Text = "Italic"
'
'chkUnderline
'
Me.chkUnderline.Location = New System.Drawing.Point(32, 136)
Me.chkUnderline.Text = "Underline"
'
'DlgFont
'
Me.Controls.Add(Me.chkUnderline)
Me.Controls.Add(Me.chkItalic)
Me.Controls.Add(Me.chkBold)
Me.Controls.Add(Me.comboSize)
Me.Controls.Add(Me.label3)
Me.Controls.Add(Me.comboFont)
Me.Controls.Add(Me.label2)
Me.Text = "TextEdit"

    End Sub

#End Region

      ' Our private data.
      Private m_formParent As Control       ' Main form
      Private bClosing As Boolean = False   ' Shutdown flag

      ' Public fields
      Public strFontName As String
      Public cemFontSize As Single
      Public bBold As Boolean
      Public bItalic As Boolean
      Public bUnderline As Boolean

      Sub New(ByVal ctrlParent As Control)
         '
         ' Required for Windows Form Designer support
         '
         InitializeComponent()

         ' Remember parent to help later in cleanup
         m_formParent = ctrlParent

         ' Default values for public fields
         strFontName = String.Empty
         cemFontSize = 10
         bBold = False
         bItalic = False
         bUnderline = False
      End Sub

      ' Dialog startup & shutdown events
      ' The startup and shutdown for a dialog involves the same
      ' events and in the same order as for a form, in the 
      ' simplest case:
      ' 1) Activated
      ' 2) Load
      ' 3) Closed
      ' 4) Deactivate
      ' 
      ' More complicated cases occur due to context switches to
      ' another application, or when a message box appears.
      ' These cases add pairs of Deactivate/Activated events
      ' between the 'Load' and the 'Closed' events.

      ' DlgFont_Activated - Activation event.
      Private Sub DlgFont_Activated( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.Activated

      End Sub

      ' DlgFont_Load - Initialize dialog box controls.
      Private Sub DlgFont_Load( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.Load

         ' Add font face names to comboFont combo box
         Dim fonts As YaoDurant.Drawing.FontCollection
         Dim iCurrent As Integer = -1
         Try
            ' Create managed code font collection.
            fonts = New YaoDurant.Drawing.FontCollection

            ' Loop through collection, adding all items to combo box
            Dim i As Integer
            For i = 0 To fonts.Count - 1 Step i + 1
               comboFont.Items.Add(fonts(i))
               If strFontName = fonts(i) Then
                  iCurrent = i
               End If
            Next

            fonts.Dispose()
            fonts = Nothing

            ' Set current face name.
            comboFont.SelectedIndex = iCurrent

            ' Set font size.
            Dim strFontSize As String = cemFontSize.ToString()
            comboSize.SelectedItem = strFontSize

            ' Set font styles.
            chkBold.Checked = bBold
            chkItalic.Checked = bItalic
            chkUnderline.Checked = bUnderline
         Catch
            Dim str As String
            str = "Error: cannot create FontCollection" + _
               " -- make sure fontlist.dll is installed"
            MessageBox.Show(str, "DialogBox")

            DialogResult = DialogResult.Cancel
            Close()
         End Try

      End Sub

      <DllImport("coredll.dll")> _
      Public Shared Function SetForegroundWindow( _
      ByVal hwnd As IntPtr) As Integer
      End Function
      <DllImport("coredll.dll")> _
      Public Shared Function GetFocus() As IntPtr
      End Function

      ' DlgFont_Closed - Copy values from dialog controls to
      ' associated public fields.
      Private Sub DlgFont_Closed( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.Closed

         If (DialogResult = DialogResult.Cancel) Then
            Return
         End If

         ' Package up return values
         strFontName = comboFont.SelectedItem.ToString()
         Dim sinTemp As Single
         Try
            Dim str As String
            str = comboSize.SelectedItem.ToString()
            sinTemp = Single.Parse(str)
         Catch
            sinTemp = 10
         End Try
         cemFontSize = sinTemp

         bBold = chkBold.Checked
         bItalic = chkItalic.Checked
         bUnderline = chkUnderline.Checked

         ' Set cleanup flags.
         bClosing = True
         m_formParent.Visible = True

         ' Force main window to top.
         m_formParent.Focus()
         SetForegroundWindow(GetFocus())
      End Sub

      ' DlgFont_Deactivate - Handle Deactive message for
      ' dialog. When dialog is not closing, hide parent
      ' form to avoid too many items in task list.
      Private Sub DlgFont_Deactivate( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.Deactivate

         ' Hide parent when switching between apps
         ' and we are not closing
         If (Not bClosing) Then
            m_formParent.Visible = False
         End If
      End Sub

      ' DlgFont_Paint - Handle Paint event for dialog, which
      ' means draw a line and post name of dialog
      Private Sub DlgFont_Paint( _
      ByVal sender As Object, _
      ByVal e As System.Windows.Forms.PaintEventArgs) _
      Handles MyBase.Paint

         Dim g As Graphics = e.Graphics

         Dim brText As Brush
         brText = New SolidBrush(SystemColors.ActiveCaption)
         g.DrawString("Font", Font, brText, 5, 5)

         Dim penBlack As Pen = New Pen(Color.Black)
         g.DrawLine(penBlack, 0, 25, 240, 25)
      End Sub
   End Class
End Namespace
