' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Runtime.InteropServices    '  SizeOf
Imports System.Text                       '  StringBuilder
Imports YaoDurant.Win32                   '  Registry access

'  UtilRegistry:  
'     A utility class for reading and writing data to the
'        HKEY.HKEY_LOCAL_MACHINE\SOFTWARE\YaoDurant hive
'        of the registry.

Public Class UtilRegistry
   Private hkeyHive As New _
      IntPtr(WinRegCE.HKEY.HKEY_LOCAL_MACHINE)
   Private strYDKey As String = "SOFTWARE\YaoDurant"
   Private iType As WinRegCE.REGTYPE
   Private hkeyCurrent As IntPtr
   Private intReturn, cbData As Integer
   Private regdispResult As WinRegCE.REGDISP
   Private Const cbMAX As Integer = 255

   '  Delete a registry key.
   Public Function DeleteKey(ByVal strKeyName As String _
                            ) _
                            As Boolean

      intReturn = WinRegCE.RegDeleteKey( _
                   hkeyHive, _
                   strYDKey + "\" + strKeyName _
                   )
      If intReturn <> 0 Then Return False

      Return True
   End Function

   '  Read a System.String from the registry.
   Public Function GetValue(ByVal strKeyName As String, _
                            ByVal strValueName As String, _
                            ByRef strValue As String _
                            ) _
                            As Boolean

      '  Open HKEY_LOCAL_MACHINE\SOFTWARE\YaoDurant\... 
      intReturn = WinRegCE.RegCreateKeyEx( _
                     hkeyHive, strYDKey + "\" + strKeyName, _
                     0, String.Empty, 0, 0, IntPtr.Zero, _
                     hkeyCurrent, _
                     regdispResult)
      If intReturn <> 0 Then Return False

      '  Create fields to hold the output.
      Dim sbValue As New StringBuilder(cbMAX)
      Dim cbValue As Integer = cbMAX

      '  Pead the value from the registry into sbValue
      intReturn = WinRegCE.RegQueryValueEx( _
                     hkeyCurrent, strValueName, _
                     0, 0, _
                     sbValue, cbValue)
      If intReturn <> 0 Then Return False

      '  Close the key.
      intReturn = WinRegCE.RegCloseKey(hkeyCurrent)
      If intReturn <> 0 Then Return False

      '  Set the string into the output parameter.
      strValue = sbValue.ToString()

      Return True
   End Function

   '  Read a System.Integer from the registry.
   Public Function GetValue(ByVal strKeyName As String, _
                            ByVal strValueName As String, _
                            ByRef intValue As Integer _
                            ) _
                            As Boolean

      '  Open HKEY_LOCAL_MACHINE\SOFTWARE\YaoDurant\... 
      intReturn = WinRegCE.RegCreateKeyEx( _
                     hkeyHive, strYDKey + "\" + strKeyName, _
                     0, String.Empty, 0, 0, IntPtr.Zero, _
                     hkeyCurrent, _
                     regdispResult)
      If intReturn <> 0 Then Return False

      '  Pull the value into intValue.  For platform 
      '     independence, use Marshal.SizeOf(intValue),
      '     not "4", to specify the size in bytes of
      '     a System.Integer.
      Dim cbValue As Integer = Marshal.SizeOf(intValue)
      intReturn = WinRegCE.RegQueryValueEx( _
                     hkeyCurrent, strValueName, _
                     0, 0, _
                     intValue, cbValue)
      If intReturn <> 0 Then Return False

      '  Close the key.
      intReturn = WinRegCE.RegCloseKey(hkeyCurrent)
      If intReturn <> 0 Then Return False

      Return True
   End Function

   '  Read a System.Boolean from the registry.
   Public Function GetValue(ByVal strKeyName As String, _
                            ByVal strValueName As String, _
                            ByRef boolValue As Boolean _
                            ) _
                            As Boolean

      '  Use the integer version of GetValue to get the value 
      '     from the registry, then convert it to a boolean.
      Dim intValue As Integer
      Dim boolReturn As Boolean = _
         GetValue(strKeyName, strValueName, intValue)
      If boolReturn Then _
         boolValue = Convert.ToBoolean(intValue)
      Return boolReturn
   End Function

   '  Write a System.String to the registry.
   Public Function SetValue(ByVal strKeyName As String, _
                            ByVal strValueName As String, _
                            ByVal strValue As String _
                            ) _
                            As Boolean

      '  Open HKEY_LOCAL_MACHINE\SOFTWARE\YaoDurant\... 
      intReturn = WinRegCE.RegCreateKeyEx( _
                     hkeyHive, strYDKey + "\" + strKeyName, _
                     0, String.Empty, 0, 0, IntPtr.Zero, _
                     hkeyCurrent, _
                     regdispResult)
      If intReturn <> 0 Then Return False

      '  Store strValue under the name strValueName.
      intReturn = WinRegCE.RegSetValueEx( _
                     hkeyCurrent, strValueName, _
                     0, WinRegCE.REGTYPE.REG_SZ, _
                     strValue, strValue.Length * 2 + 1)
      If intReturn <> 0 Then Return False

      '  Close the key.
      intReturn = WinRegCE.RegCloseKey(hkeyCurrent)
      If intReturn <> 0 Then Return False

      Return True
   End Function

   '  Write a System.Integer to the registry.
   Public Function SetValue(ByVal strKeyName As String, _
                            ByVal strValueName As String, _
                            ByVal intValue As Integer _
                            ) _
                            As Boolean

      '  Open HKEY_LOCAL_MACHINE\SOFTWARE\YaoDurant\... 
      intReturn = WinRegCE.RegCreateKeyEx( _
                     hkeyHive, strYDKey + "\" + strKeyName, _
                     0, String.Empty, 0, 0, IntPtr.Zero, _
                     hkeyCurrent, _
                     regdispResult)
      If intReturn <> 0 Then Return False

      '  Store intValue under the name strValueName.  For
      '  platform independence, use Marshal.SizeOf(intValue),
      '     not "4", to specify the size in bytes of
      '     a System.Integer.
      intReturn = WinRegCE.RegSetValueEx( _
                     hkeyCurrent, strValueName, _
                     0, 0, _
                     intValue, Marshal.SizeOf(intValue))
      If intReturn <> 0 Then Return False

      '  Close the key.
      intReturn = WinRegCE.RegCloseKey(hkeyCurrent)
      If intReturn <> 0 Then Return False

      Return True
   End Function

   '  Write a System.Boolean to the registry.
   Public Function SetValue(ByVal strKeyName As String, _
                            ByVal strValueName As String, _
                            ByVal boolValue As Boolean _
                            ) _
                            As Boolean

      '  Cast the value as a boolean, then use the integer 
      '     version of SetValue to set the value into the
      '     registry.

      '  There is no Convert.ToInteger method.  For platform
      '     independence, we cast to the smallest integer, 
      '     which will always implicitly and successfully cast
      '     to Integer.
      Return SetValue(strKeyName, _
                      strValueName, _
                      Convert.ToInt16(boolValue))

   End Function
End Class
