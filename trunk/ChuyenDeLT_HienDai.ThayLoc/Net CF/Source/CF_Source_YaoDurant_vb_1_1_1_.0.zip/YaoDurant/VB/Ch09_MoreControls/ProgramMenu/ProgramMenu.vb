Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents menuEmpty As System.Windows.Forms.MainMenu
      Friend WithEvents cmdHideMenus As System.Windows.Forms.Button
      Friend WithEvents cmdEmptyMenu As System.Windows.Forms.Button
      Friend WithEvents cmdShowStartupMenu As System.Windows.Forms.Button
      Friend WithEvents cmdShowEditMenu As System.Windows.Forms.Button
      Friend WithEvents menuStartup As System.Windows.Forms.MainMenu
      Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemNewDocument As System.Windows.Forms.MenuItem
      Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemNewCheckServer As System.Windows.Forms.MenuItem

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents menuEdit As System.Windows.Forms.MainMenu
   Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem7 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem13 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem15 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem17 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem23 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem26 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem28 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem34 As System.Windows.Forms.MenuItem
   Friend WithEvents menuItem36 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemNewHTML As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditUndo As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditRedo As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditCut As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditCopy As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditPaste As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditClear As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditSelectAll As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditFill As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditRename As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewToolbar As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewHorzScroll As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewVertScroll As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewStat As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewHeadings As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewSplit As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewFreeze As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewFullScreen As System.Windows.Forms.MenuItem
   Friend WithEvents mitemZoom50 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemZoom75 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemZoom100 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemZoom125 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemZoom150 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemFormatCells As System.Windows.Forms.MenuItem
   Friend WithEvents mitemInsertCells As System.Windows.Forms.MenuItem
   Friend WithEvents mitemDeleteCells As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
Me.menuEmpty = New System.Windows.Forms.MainMenu
Me.cmdHideMenus = New System.Windows.Forms.Button
Me.cmdEmptyMenu = New System.Windows.Forms.Button
Me.cmdShowStartupMenu = New System.Windows.Forms.Button
Me.cmdShowEditMenu = New System.Windows.Forms.Button
Me.menuStartup = New System.Windows.Forms.MainMenu
Me.menuItem1 = New System.Windows.Forms.MenuItem
Me.mitemNewDocument = New System.Windows.Forms.MenuItem
Me.mitemNewHTML = New System.Windows.Forms.MenuItem
Me.menuItem5 = New System.Windows.Forms.MenuItem
Me.mitemNewCheckServer = New System.Windows.Forms.MenuItem
Me.menuEdit = New System.Windows.Forms.MainMenu
Me.menuItem2 = New System.Windows.Forms.MenuItem
Me.mitemEditUndo = New System.Windows.Forms.MenuItem
Me.mitemEditRedo = New System.Windows.Forms.MenuItem
Me.menuItem7 = New System.Windows.Forms.MenuItem
Me.mitemEditCut = New System.Windows.Forms.MenuItem
Me.mitemEditCopy = New System.Windows.Forms.MenuItem
Me.mitemEditPaste = New System.Windows.Forms.MenuItem
Me.mitemEditClear = New System.Windows.Forms.MenuItem
Me.mitemEditSelectAll = New System.Windows.Forms.MenuItem
Me.menuItem13 = New System.Windows.Forms.MenuItem
Me.mitemEditFill = New System.Windows.Forms.MenuItem
Me.menuItem15 = New System.Windows.Forms.MenuItem
Me.mitemEditRename = New System.Windows.Forms.MenuItem
Me.menuItem17 = New System.Windows.Forms.MenuItem
Me.mitemViewToolbar = New System.Windows.Forms.MenuItem
Me.mitemViewHorzScroll = New System.Windows.Forms.MenuItem
Me.mitemViewVertScroll = New System.Windows.Forms.MenuItem
Me.mitemViewStat = New System.Windows.Forms.MenuItem
Me.mitemViewHeadings = New System.Windows.Forms.MenuItem
Me.menuItem23 = New System.Windows.Forms.MenuItem
Me.mitemViewSplit = New System.Windows.Forms.MenuItem
Me.mitemViewFreeze = New System.Windows.Forms.MenuItem
Me.menuItem26 = New System.Windows.Forms.MenuItem
Me.mitemViewFullScreen = New System.Windows.Forms.MenuItem
Me.menuItem28 = New System.Windows.Forms.MenuItem
Me.mitemZoom50 = New System.Windows.Forms.MenuItem
Me.mitemZoom75 = New System.Windows.Forms.MenuItem
Me.mitemZoom100 = New System.Windows.Forms.MenuItem
Me.mitemZoom125 = New System.Windows.Forms.MenuItem
Me.mitemZoom150 = New System.Windows.Forms.MenuItem
Me.menuItem34 = New System.Windows.Forms.MenuItem
Me.mitemFormatCells = New System.Windows.Forms.MenuItem
Me.menuItem36 = New System.Windows.Forms.MenuItem
Me.mitemInsertCells = New System.Windows.Forms.MenuItem
Me.mitemDeleteCells = New System.Windows.Forms.MenuItem
'
'cmdHideMenus
'
Me.cmdHideMenus.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdHideMenus.Location = New System.Drawing.Point(32, 32)
Me.cmdHideMenus.Size = New System.Drawing.Size(184, 24)
Me.cmdHideMenus.Text = "Hide Menus"
'
'cmdEmptyMenu
'
Me.cmdEmptyMenu.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdEmptyMenu.Location = New System.Drawing.Point(32, 72)
Me.cmdEmptyMenu.Size = New System.Drawing.Size(184, 24)
Me.cmdEmptyMenu.Text = "Show Empty Menu (for SIP)"
'
'cmdShowStartupMenu
'
Me.cmdShowStartupMenu.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdShowStartupMenu.Location = New System.Drawing.Point(32, 112)
Me.cmdShowStartupMenu.Size = New System.Drawing.Size(184, 24)
Me.cmdShowStartupMenu.Text = "Show Startup Menu"
'
'cmdShowEditMenu
'
Me.cmdShowEditMenu.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdShowEditMenu.Location = New System.Drawing.Point(32, 160)
Me.cmdShowEditMenu.Size = New System.Drawing.Size(184, 24)
Me.cmdShowEditMenu.Text = "Show Editing Menu"
'
'menuStartup
'
Me.menuStartup.MenuItems.Add(Me.menuItem1)
'
'menuItem1
'
Me.menuItem1.MenuItems.Add(Me.mitemNewDocument)
Me.menuItem1.MenuItems.Add(Me.mitemNewHTML)
Me.menuItem1.MenuItems.Add(Me.menuItem5)
Me.menuItem1.MenuItems.Add(Me.mitemNewCheckServer)
Me.menuItem1.Text = "New"
'
'mitemNewDocument
'
Me.mitemNewDocument.Text = "Document"
'
'mitemNewHTML
'
Me.mitemNewHTML.Enabled = False
Me.mitemNewHTML.Text = "HTML Page"
'
'menuItem5
'
Me.menuItem5.Text = "-"
'
'mitemNewCheckServer
'
Me.mitemNewCheckServer.Text = "Check server"
'
'menuEdit
'
Me.menuEdit.MenuItems.Add(Me.menuItem2)
Me.menuEdit.MenuItems.Add(Me.menuItem17)
Me.menuEdit.MenuItems.Add(Me.menuItem34)
'
'menuItem2
'
Me.menuItem2.MenuItems.Add(Me.mitemEditUndo)
Me.menuItem2.MenuItems.Add(Me.mitemEditRedo)
Me.menuItem2.MenuItems.Add(Me.menuItem7)
Me.menuItem2.MenuItems.Add(Me.mitemEditCut)
Me.menuItem2.MenuItems.Add(Me.mitemEditCopy)
Me.menuItem2.MenuItems.Add(Me.mitemEditPaste)
Me.menuItem2.MenuItems.Add(Me.mitemEditClear)
Me.menuItem2.MenuItems.Add(Me.mitemEditSelectAll)
Me.menuItem2.MenuItems.Add(Me.menuItem13)
Me.menuItem2.MenuItems.Add(Me.mitemEditFill)
Me.menuItem2.MenuItems.Add(Me.menuItem15)
Me.menuItem2.MenuItems.Add(Me.mitemEditRename)
Me.menuItem2.Text = "Edit"
'
'mitemEditUndo
'
Me.mitemEditUndo.Text = "Undo"
'
'mitemEditRedo
'
Me.mitemEditRedo.Text = "Redo"
'
'menuItem7
'
Me.menuItem7.Text = "-"
'
'mitemEditCut
'
Me.mitemEditCut.Text = "Cut"
'
'mitemEditCopy
'
Me.mitemEditCopy.Text = "Copy"
'
'mitemEditPaste
'
Me.mitemEditPaste.Text = "Paste"
'
'mitemEditClear
'
Me.mitemEditClear.Text = "Clear"
'
'mitemEditSelectAll
'
Me.mitemEditSelectAll.Text = "Select All"
'
'menuItem13
'
Me.menuItem13.Text = "-"
'
'mitemEditFill
'
Me.mitemEditFill.Text = "Fill..."
'
'menuItem15
'
Me.menuItem15.Text = "-"
'
'mitemEditRename
'
Me.mitemEditRename.Text = "Rename/Move..."
'
'menuItem17
'
Me.menuItem17.MenuItems.Add(Me.mitemViewToolbar)
Me.menuItem17.MenuItems.Add(Me.mitemViewHorzScroll)
Me.menuItem17.MenuItems.Add(Me.mitemViewVertScroll)
Me.menuItem17.MenuItems.Add(Me.mitemViewStat)
Me.menuItem17.MenuItems.Add(Me.mitemViewHeadings)
Me.menuItem17.MenuItems.Add(Me.menuItem23)
Me.menuItem17.MenuItems.Add(Me.mitemViewSplit)
Me.menuItem17.MenuItems.Add(Me.mitemViewFreeze)
Me.menuItem17.MenuItems.Add(Me.menuItem26)
Me.menuItem17.MenuItems.Add(Me.mitemViewFullScreen)
Me.menuItem17.MenuItems.Add(Me.menuItem28)
Me.menuItem17.Text = "View"
'
'mitemViewToolbar
'
Me.mitemViewToolbar.Text = "Toolbar"
'
'mitemViewHorzScroll
'
Me.mitemViewHorzScroll.Text = "Horizontal Scroll Bar"
'
'mitemViewVertScroll
'
Me.mitemViewVertScroll.Text = "Vertical Scroll Bar"
'
'mitemViewStat
'
Me.mitemViewStat.Text = "Status Bar"
'
'mitemViewHeadings
'
Me.mitemViewHeadings.Text = "Row/Column Headings"
'
'menuItem23
'
Me.menuItem23.Text = "-"
'
'mitemViewSplit
'
Me.mitemViewSplit.Text = "Split"
'
'mitemViewFreeze
'
Me.mitemViewFreeze.Text = "Freeze Panes"
'
'menuItem26
'
Me.menuItem26.Text = "-"
'
'mitemViewFullScreen
'
Me.mitemViewFullScreen.Text = "Full Screen"
'
'menuItem28
'
Me.menuItem28.MenuItems.Add(Me.mitemZoom50)
Me.menuItem28.MenuItems.Add(Me.mitemZoom75)
Me.menuItem28.MenuItems.Add(Me.mitemZoom100)
Me.menuItem28.MenuItems.Add(Me.mitemZoom125)
Me.menuItem28.MenuItems.Add(Me.mitemZoom150)
Me.menuItem28.Text = "Zoom"
'
'mitemZoom50
'
Me.mitemZoom50.Text = "50%"
'
'mitemZoom75
'
Me.mitemZoom75.Text = "75%"
'
'mitemZoom100
'
Me.mitemZoom100.Text = "100%"
'
'mitemZoom125
'
Me.mitemZoom125.Text = "125%"
'
'mitemZoom150
'
Me.mitemZoom150.Text = "150%"
'
'menuItem34
'
Me.menuItem34.MenuItems.Add(Me.mitemFormatCells)
Me.menuItem34.MenuItems.Add(Me.menuItem36)
Me.menuItem34.MenuItems.Add(Me.mitemInsertCells)
Me.menuItem34.MenuItems.Add(Me.mitemDeleteCells)
Me.menuItem34.Text = "Format"
'
'mitemFormatCells
'
Me.mitemFormatCells.Text = "Cells..."
'
'menuItem36
'
Me.menuItem36.Text = "-"
'
'mitemInsertCells
'
Me.mitemInsertCells.Text = "Insert Cells..."
'
'mitemDeleteCells
'
Me.mitemDeleteCells.Text = "Delete Cells..."
'
'FormMain
'
Me.Controls.Add(Me.cmdShowEditMenu)
Me.Controls.Add(Me.cmdShowStartupMenu)
Me.Controls.Add(Me.cmdEmptyMenu)
Me.Controls.Add(Me.cmdHideMenus)
Me.Menu = Me.menuEdit
Me.MinimizeBox = False
Me.Text = "Program Menu"

    End Sub

#End Region

   Private Sub cmdHideMenus_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdHideMenus.Click
      Me.Menu = Nothing
   End Sub

   Private Sub cmdEmptyMenu_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdEmptyMenu.Click
      Me.Menu = menuEmpty
   End Sub

   Private Sub cmdShowStartupMenu_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdShowStartupMenu.Click
      Me.Menu = menuStartup
   End Sub

   Private Sub cmdShowEditMenu_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdShowEditMenu.Click
      Me.Menu = menuEdit
   End Sub
End Class
