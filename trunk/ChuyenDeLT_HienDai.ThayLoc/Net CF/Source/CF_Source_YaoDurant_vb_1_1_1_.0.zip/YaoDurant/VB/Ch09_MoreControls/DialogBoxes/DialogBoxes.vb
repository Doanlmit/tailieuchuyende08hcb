' DialogBoxes.vb - Main form for DialogBoxes sample.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Namespace DialogBoxes
Public Class FormMain
   Inherits System.Windows.Forms.Form
   Friend WithEvents textInput As System.Windows.Forms.TextBox
   Friend WithEvents cmenuMain As System.Windows.Forms.ContextMenu
   Friend WithEvents mitemProgramMenu As System.Windows.Forms.MenuItem
   Friend WithEvents mitemToolbar As System.Windows.Forms.MenuItem
   Friend WithEvents ilistCommands As System.Windows.Forms.ImageList
   Friend WithEvents menuMain As System.Windows.Forms.MainMenu
   Friend WithEvents mitemEditPopup As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEditFont As System.Windows.Forms.MenuItem
   Friend WithEvents mitemToolsPopup As System.Windows.Forms.MenuItem
   Friend WithEvents mitemToolsOptions As System.Windows.Forms.MenuItem
   Friend WithEvents tbarCommands As System.Windows.Forms.ToolBar
   Friend WithEvents tbbEditFormat As System.Windows.Forms.ToolBarButton
   Friend WithEvents tbbViewOptions As System.Windows.Forms.ToolBarButton

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Private Sub InitializeComponent()
Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FormMain))
Me.textInput = New System.Windows.Forms.TextBox
Me.cmenuMain = New System.Windows.Forms.ContextMenu
Me.mitemProgramMenu = New System.Windows.Forms.MenuItem
Me.mitemToolbar = New System.Windows.Forms.MenuItem
Me.ilistCommands = New System.Windows.Forms.ImageList
Me.menuMain = New System.Windows.Forms.MainMenu
Me.mitemEditPopup = New System.Windows.Forms.MenuItem
Me.mitemEditFont = New System.Windows.Forms.MenuItem
Me.mitemToolsPopup = New System.Windows.Forms.MenuItem
Me.mitemToolsOptions = New System.Windows.Forms.MenuItem
Me.tbarCommands = New System.Windows.Forms.ToolBar
Me.tbbEditFormat = New System.Windows.Forms.ToolBarButton
Me.tbbViewOptions = New System.Windows.Forms.ToolBarButton
'
'textInput
'
Me.textInput.Location = New System.Drawing.Point(32, 32)
Me.textInput.Multiline = True
Me.textInput.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.textInput.Size = New System.Drawing.Size(160, 136)
Me.textInput.Text = "Some text inside a textbox."
'
'cmenuMain
'
Me.cmenuMain.MenuItems.Add(Me.mitemProgramMenu)
Me.cmenuMain.MenuItems.Add(Me.mitemToolbar)
'
'mitemProgramMenu
'
Me.mitemProgramMenu.Text = "Program Menu"
'
'mitemToolbar
'
Me.mitemToolbar.Text = "Toolbar"
'
'ilistCommands
'
Me.ilistCommands.Images.Add(CType(resources.GetObject("resource"), System.Drawing.Image))
Me.ilistCommands.Images.Add(CType(resources.GetObject("resource1"), System.Drawing.Image))
Me.ilistCommands.ImageSize = New System.Drawing.Size(16, 16)
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.mitemEditPopup)
Me.menuMain.MenuItems.Add(Me.mitemToolsPopup)
'
'mitemEditPopup
'
Me.mitemEditPopup.MenuItems.Add(Me.mitemEditFont)
Me.mitemEditPopup.Text = "Edit"
'
'mitemEditFont
'
Me.mitemEditFont.Text = "Font..."
'
'mitemToolsPopup
'
Me.mitemToolsPopup.MenuItems.Add(Me.mitemToolsOptions)
Me.mitemToolsPopup.Text = "Tools"
'
'mitemToolsOptions
'
Me.mitemToolsOptions.Text = "Options..."
'
'tbarCommands
'
Me.tbarCommands.Buttons.Add(Me.tbbEditFormat)
Me.tbarCommands.Buttons.Add(Me.tbbViewOptions)
Me.tbarCommands.ImageList = Me.ilistCommands
'
'tbbEditFormat
'
Me.tbbEditFormat.ImageIndex = 0
'
'tbbViewOptions
'
Me.tbbViewOptions.ImageIndex = 1
'
'FormMain
'
Me.ContextMenu = Me.cmenuMain
Me.Controls.Add(Me.textInput)
Me.Controls.Add(Me.tbarCommands)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "DialogBoxes"

   End Sub

#End Region

   ' mitemEditFont - Respond to menu selection Edit->Font...
   Private Sub mitemEditFont_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemEditFont.Click

      Dim dlg As DlgFont = New DlgFont(Me)

      ' Initialize input values to dialog.
      dlg.strFontName = textInput.Font.Name
      dlg.cemFontSize = textInput.Font.Size
      Dim fsTemp As FontStyle = textInput.Font.Style
      dlg.bBold = ((fsTemp And FontStyle.Bold) <> 0)
      dlg.bItalic = ((fsTemp And FontStyle.Italic) <> 0)
      dlg.bUnderline = ((fsTemp And FontStyle.Underline) <> 0)

      ' Summon dialog box.
      If (dlg.ShowDialog() <> DialogResult.OK) Then
         Return
      End If

      ' Modify settings based on user input.
      Dim fontOld As Font = textInput.Font
      fsTemp = 0
      If (dlg.bBold) Then
         fsTemp = fsTemp Or FontStyle.Bold
      End If
      If (dlg.bItalic) Then
         fsTemp = fsTemp Or FontStyle.Italic
      End If
      If (dlg.bUnderline) Then
         fsTemp = fsTemp Or FontStyle.Underline
      End If
      textInput.Font = New Font(dlg.strFontName, _
         dlg.cemFontSize, fsTemp)
      fontOld.Dispose()

   End Sub

   ' mitemToolsOptions -- Respond to menu selection
   ' Tools->Options...
   Private Sub mitemToolsOptions_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemToolsOptions.Click

      Dim dlg As DlgToolsOptions = New DlgToolsOptions(Me)

      ' Get flag for whether toolbar is being displayed
      Dim bHasTB As Boolean = Me.Controls.Contains(tbarCommands)

      ' Initialize input values to dialog.
      dlg.sbScrollBars = textInput.ScrollBars
      dlg.bProgramMenu = Not (Me.Menu Is Nothing)
      dlg.bToolbar = bHasTB
      dlg.haTextAlign = textInput.TextAlign
      dlg.bWordWrap = textInput.WordWrap

      ' Summon dialog box.
      If dlg.ShowDialog() <> DialogResult.OK Then
         Return
      End If

      ' Hide textbox to minimize redrawing time.
      textInput.Visible = False

      ' Modify settings based on user input.
      textInput.ScrollBars = dlg.sbScrollBars
      Me.Menu = IIf((dlg.bProgramMenu), menuMain, Nothing)

      ' Do we need to add toolbar?
      ' (adding a toolbar twice causes an
      '  exception, so we have to be careful)
      If dlg.bToolbar And (Not bHasTB) Then
         Me.Controls.Add(tbarCommands)
      End If

      ' Do we need to remove toolbar?
      ' (okay to remove a toolbar twice -- we
      '  do the following to parallel the add code)
      If bHasTB And (Not dlg.bToolbar) Then
         Me.Controls.Remove(tbarCommands)
      End If

      ' Update text alignment.
      textInput.TextAlign = dlg.haTextAlign

      ' Update word-wrap setting.
      textInput.WordWrap = dlg.bWordWrap

      ' Make textbox visible again.
      textInput.Visible = True

   End Sub

   ' tbarCommands_ButtonClick - Respond to ButtonClick
   ' event for toolbar tbarCommands
   Private Sub tbarCommands_ButtonClick( _
   ByVal sender As System.Object, _
   ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) _
   Handles tbarCommands.ButtonClick

      If (e.Button Is tbbEditFormat) Then
         mitemEditFont_Click(sender, e)
      Else
         mitemToolsOptions_Click(sender, e)
      End If
   End Sub

   ' cmenuMain_Popup -- Handle Popup event for
   ' context menu. Set/clear check-mark on context
   ' menu items.
   Private Sub cmenuMain_Popup(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmenuMain.Popup

      Dim bMenu As Boolean = Not (Me.Menu Is Nothing)
      mitemProgramMenu.Checked = bMenu

      Dim bTB As Boolean = Me.Controls.Contains(tbarCommands)
      mitemToolbar.Checked = bTB
   End Sub

   Private Sub mitemProgramMenu_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemProgramMenu.Click

      If (Me.Menu Is Nothing) Then
         Me.Menu = menuMain
      Else
         Me.Menu = Nothing
      End If
   End Sub

   Private Sub mitemToolbar_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemToolbar.Click

      If (mitemToolbar.Checked) Then
         Me.Controls.Remove(tbarCommands)
      Else
         Me.Controls.Add(tbarCommands)
      End If

   End Sub
End Class
End Namespace
