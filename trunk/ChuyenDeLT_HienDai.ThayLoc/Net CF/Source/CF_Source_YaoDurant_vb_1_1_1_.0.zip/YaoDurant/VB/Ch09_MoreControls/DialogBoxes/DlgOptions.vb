' DlgOptions.vb - Options dialog box.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Namespace DialogBoxes
Public Class DlgToolsOptions
    Inherits System.Windows.Forms.Form
      Friend WithEvents chkProgMenu As System.Windows.Forms.CheckBox
      Friend WithEvents chkToolbar As System.Windows.Forms.CheckBox
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents optBothScroll As System.Windows.Forms.RadioButton
      Friend WithEvents optHorzScroll As System.Windows.Forms.RadioButton
      Friend WithEvents optVertScroll As System.Windows.Forms.RadioButton
      Friend WithEvents optNoScroll As System.Windows.Forms.RadioButton
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents comboTextAlign As System.Windows.Forms.ComboBox
      Friend WithEvents chkWordWrap As System.Windows.Forms.CheckBox

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.chkProgMenu = New System.Windows.Forms.CheckBox
Me.chkToolbar = New System.Windows.Forms.CheckBox
Me.label3 = New System.Windows.Forms.Label
Me.label1 = New System.Windows.Forms.Label
Me.optBothScroll = New System.Windows.Forms.RadioButton
Me.optHorzScroll = New System.Windows.Forms.RadioButton
Me.optVertScroll = New System.Windows.Forms.RadioButton
Me.optNoScroll = New System.Windows.Forms.RadioButton
Me.label2 = New System.Windows.Forms.Label
Me.comboTextAlign = New System.Windows.Forms.ComboBox
Me.chkWordWrap = New System.Windows.Forms.CheckBox
'
'chkProgMenu
'
Me.chkProgMenu.Location = New System.Drawing.Point(24, 56)
Me.chkProgMenu.Text = "Program Menu"
'
'chkToolbar
'
Me.chkToolbar.Location = New System.Drawing.Point(144, 56)
Me.chkToolbar.Size = New System.Drawing.Size(72, 20)
Me.chkToolbar.Text = "Toolbar"
'
'label3
'
Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Underline)
Me.label3.Location = New System.Drawing.Point(0, 96)
Me.label3.Size = New System.Drawing.Size(232, 20)
Me.label3.Text = "Text Box Settings__________________"
'
'label1
'
Me.label1.Location = New System.Drawing.Point(24, 120)
Me.label1.Text = "Scroll Bars"
'
'optBothScroll
'
Me.optBothScroll.Location = New System.Drawing.Point(32, 136)
Me.optBothScroll.Size = New System.Drawing.Size(64, 20)
Me.optBothScroll.Text = "Both"
'
'optHorzScroll
'
Me.optHorzScroll.Location = New System.Drawing.Point(32, 160)
Me.optHorzScroll.Size = New System.Drawing.Size(112, 20)
Me.optHorzScroll.Text = "Only horizontal"
'
'optVertScroll
'
Me.optVertScroll.Location = New System.Drawing.Point(32, 184)
Me.optVertScroll.Text = "Only vertical"
'
'optNoScroll
'
Me.optNoScroll.Location = New System.Drawing.Point(32, 208)
Me.optNoScroll.Size = New System.Drawing.Size(56, 20)
Me.optNoScroll.Text = "None"
'
'label2
'
Me.label2.Location = New System.Drawing.Point(152, 120)
Me.label2.Size = New System.Drawing.Size(72, 20)
Me.label2.Text = "Text Align:"
'
'comboTextAlign
'
Me.comboTextAlign.Items.Add("Left")
Me.comboTextAlign.Items.Add("Center")
Me.comboTextAlign.Items.Add("Right")
Me.comboTextAlign.Location = New System.Drawing.Point(152, 136)
Me.comboTextAlign.Size = New System.Drawing.Size(72, 22)
'
'chkWordWrap
'
Me.chkWordWrap.Location = New System.Drawing.Point(144, 208)
Me.chkWordWrap.Size = New System.Drawing.Size(80, 20)
Me.chkWordWrap.Text = "Word wrap"
'
'DlgToolsOptions
'
Me.Controls.Add(Me.chkWordWrap)
Me.Controls.Add(Me.comboTextAlign)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.optNoScroll)
Me.Controls.Add(Me.optVertScroll)
Me.Controls.Add(Me.optHorzScroll)
Me.Controls.Add(Me.optBothScroll)
Me.Controls.Add(Me.label1)
Me.Controls.Add(Me.label3)
Me.Controls.Add(Me.chkToolbar)
Me.Controls.Add(Me.chkProgMenu)
Me.Text = "DialogBoxes"

    End Sub

#End Region

      ' Our private data.
      Private m_formParent As Control       ' Main form

      ' Public fields for initial & updated values.
      Public sbScrollBars As ScrollBars
      Public bProgramMenu As Boolean
      Public bToolbar As Boolean
      Public haTextAlign As HorizontalAlignment
      Public bWordWrap As Boolean

      Enum Align
         Left = 0
         Center
         Right
      End Enum

      Sub New(ByVal ctrlParent As Control)
         '
         ' Required for Windows Form Designer support
         '
         InitializeComponent()

         ' Remember parent to help later in cleanup
         m_formParent = ctrlParent

         ' Set default values.
         sbScrollBars = ScrollBars.None
         bProgramMenu = True
         bToolbar = True
         haTextAlign = HorizontalAlignment.Left
         bWordWrap = False
      End Sub

      ' DlgToolsOptions_Load - Initialize dialog box controls.
      Private Sub DlgToolsOptions_Load( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.Load

         ' Hide parent -- to keep it off system list.
         m_formParent.Visible = False

         ' Initialize scroll bar settings.
         Select Case sbScrollBars
            Case ScrollBars.Both
               optBothScroll.Checked = True
            Case ScrollBars.Horizontal
               optHorzScroll.Checked = True
            Case ScrollBars.Vertical
               optVertScroll.Checked = True
            Case ScrollBars.None
               optNoScroll.Checked = True
         End Select

         ' Initilaize program menu & toolbar settings.
         chkProgMenu.Checked = bProgramMenu
         chkToolbar.Checked = bToolbar

         ' Set text alignment
         If haTextAlign = HorizontalAlignment.Left Then
            comboTextAlign.SelectedIndex = CInt(Align.Left)
         ElseIf haTextAlign = HorizontalAlignment.Center Then
            comboTextAlign.SelectedIndex = CInt(Align.Center)
         Else
            comboTextAlign.SelectedIndex = CInt(Align.Right)
         End If

         ' Set word wrap
         chkWordWrap.Checked = bWordWrap

         ' Initialize constraints
         UpdateTextAlignConstraints()
         UpdateWordWrapConstraints()
      End Sub

      ' DlgToolsOptions_Closed - Copy values from dialog
      ' controls to associated public fields.
      Private Sub DlgToolsOptions_Closed( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.Closed

         ' Restore parent visibility.
         m_formParent.Visible = True

         ' Update scrollbar setting.      
         If (optBothScroll.Checked) Then
            sbScrollBars = ScrollBars.Both
         ElseIf (optVertScroll.Checked) Then
            sbScrollBars = ScrollBars.Vertical
         ElseIf (optHorzScroll.Checked) Then
            sbScrollBars = ScrollBars.Horizontal
         Else
            sbScrollBars = ScrollBars.None
         End If

         ' Update program menu & toolbar settings.
         bProgramMenu = chkProgMenu.Checked
         bToolbar = chkToolbar.Checked

         ' Update text alignment setting.
         Dim iSel As Align
         iSel = CType(comboTextAlign.SelectedIndex, Align)
         If iSel = Align.Left Then
            haTextAlign = HorizontalAlignment.Left
         ElseIf iSel = Align.Center Then
            haTextAlign = HorizontalAlignment.Center
         Else
            haTextAlign = HorizontalAlignment.Right
         End If

         ' Update word wrap ssetting.
         bWordWrap = chkWordWrap.Checked
      End Sub

      ' DlgToolsOptions_Paint - Handle Paint event for dialog,
      ' which means draw a line and post name of dialog
      Private Sub DlgToolsOptions_Paint( _
      ByVal sender As Object, _
      ByVal e As System.Windows.Forms.PaintEventArgs) _
      Handles MyBase.Paint

         Dim g As Graphics = e.Graphics

         Dim brText As Brush
         brText = New SolidBrush(SystemColors.ActiveCaption)
         g.DrawString("Options", Font, brText, 5, 5)

         Dim penBlack As Pen = New Pen(Color.Black)
         g.DrawLine(penBlack, 0, 25, 240, 25)
      End Sub

      ' UpdateTextAlignConstraints -- When text alignment
      ' changes, update word wrap setting to reflect
      ' behavior of actual text box.
      Private Sub UpdateTextAlignConstraints()

         ' Alignment center or right --
         ' turn wordwrap *on* and disable.
         If (comboTextAlign.SelectedIndex <> Align.Left) Then
            chkWordWrap.Checked = True
            chkWordWrap.Enabled = False
         Else
            ' Alignment left --
            ' enable wordwrap
            chkWordWrap.Enabled = True
         End If
      End Sub

      ' UpdateWordWrapConstraints -- when word wrap
      ' changes, update scroll bar settings to reflect
      ' actual behavior of text box.
      Private Sub UpdateWordWrapConstraints()

         If (chkWordWrap.Checked) Then
            If (optBothScroll.Checked) Then
               optBothScroll.Checked = False
               optVertScroll.Checked = True
            ElseIf (optHorzScroll.Checked) Then
               optHorzScroll.Checked = False
               optNoScroll.Checked = True
            End If
            optBothScroll.Enabled = False
            optHorzScroll.Enabled = False
         Else
            optBothScroll.Enabled = True
            optHorzScroll.Enabled = True
         End If
      End Sub

      ' comboTextAlign_SelectedIndexChanged - Handle change to
      ' text alignment value
      Private Sub comboTextAlign_SelectedIndexChanged( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles comboTextAlign.SelectedIndexChanged

         UpdateTextAlignConstraints()
      End Sub

      ' chkWordWrap_CheckStateChanged - Handle change to
      ' wordwrap checkbox
      Private Sub chkWordWrap_CheckStateChanged( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) _
      Handles chkWordWrap.CheckStateChanged

         UpdateWordWrapConstraints()
      End Sub

   End Class
End Namespace
