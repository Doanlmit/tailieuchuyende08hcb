' YaoDurant.Controls.EventGrabber.vb - Wrapper class for
' control event grabber support provided by 
' YaoDurantControls.dll
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports Microsoft.WindowsCE.Forms

Namespace YaoDurant.Controls
   ' <summary>
   ' EventGrabber - managed code wrapper around a generic
   ' event grabber for Compact Framework programs. Note
   ' that this requires an unmanaged code DLL to work
   ' correctly: YaoDurant.Controls.dll.
   ' </summary>
   Public Class EventGrabber
    Implements IDisposable

     Dim m_hwndTarget As IntPtr

      ' hwndCtrl is Window handle of control
      ' mw is a MessageWindow-derived object
      ' fEvents indicates which events to trap
      Public Sub New( _
         ByVal hwndCtrl As IntPtr, _
         ByVal mw As MessageWindow, _
         ByVal fEvents As Integer)

        MyBase.New()  ' Call constructor for base class

         ' We keep a private copy of the window handle.
         m_hwndTarget = hwndCtrl

         CreateEventGrabber(hwndCtrl, mw.Hwnd)
         SetEventFlags(hwndCtrl, fEvents)
      End Sub

      Protected Overrides Sub Finalize()
         Dispose(False)
      End Sub

      Public Overridable Sub Dispose() _
      Implements IDisposable.Dispose
         Dispose(True)
         GC.SuppressFinalize(Me)
      End Sub

      Protected Sub Dispose( _
      ByVal bExplicit As Boolean)

         ' Explicit call to Dispose from program?
         If (bExplicit) Then

            ' Unhook handler from our program.
            DisposeEventGrabber(m_hwndTarget)
         End If

      End Sub

      '--------------------------------------------------------
      ' Methods implemented in YaoDurantControls.dll
      '--------------------------------------------------------
      <DllImport("YaoDurantControls.dll")> _
      Shared Function CreateEventGrabber( _
         ByVal hwndControl As IntPtr, _
         ByVal hwndDispatch As IntPtr) As Integer
      End Function

      <DllImport("YaoDurantControls.dll")> _
      Shared Function DisposeEventGrabber( _
         ByVal hwndControl As IntPtr) As Integer
      End Function
      <DllImport("YaoDurantControls.dll")> _
      Shared Function SetEventFlags( _
         ByVal hwndControl As IntPtr, _
         ByVal flags As Integer) As Integer
      End Function
      <DllImport("YaoDurantControls.dll")> _
      Shared Function GetEventFlags( _
         ByVal hwndControl As IntPtr) As Integer
      End Function
   End Class
End Namespace
