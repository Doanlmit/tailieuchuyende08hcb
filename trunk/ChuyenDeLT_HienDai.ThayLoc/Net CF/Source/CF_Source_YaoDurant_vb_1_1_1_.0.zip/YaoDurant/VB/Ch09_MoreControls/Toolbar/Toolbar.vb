Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents cmdAdd1 As System.Windows.Forms.Button
      Friend WithEvents cmdRemove1 As System.Windows.Forms.Button
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents cmdAdd2 As System.Windows.Forms.Button
      Friend WithEvents cmdRemove2 As System.Windows.Forms.Button
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents cmdShowMenu As System.Windows.Forms.Button
      Friend WithEvents cmdHideMenu As System.Windows.Forms.Button
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents mitemFile As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileNew As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileOpen As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileSave As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileSaveAs As System.Windows.Forms.MenuItem
      Friend WithEvents mitemSep1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFilePrint As System.Windows.Forms.MenuItem
      Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileExit As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEdit As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditCut As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditCopy As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditPaste As System.Windows.Forms.MenuItem
      Friend WithEvents mitemSep2 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditUndo As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditClear As System.Windows.Forms.MenuItem
      Friend WithEvents menuSizePopup As System.Windows.Forms.MenuItem
      Friend WithEvents mitem12x12 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem16x16 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem18x18 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem20x20 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem24x24 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem32x32 As System.Windows.Forms.MenuItem
      Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem12x20 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem14x20 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem16x20 As System.Windows.Forms.MenuItem
      Friend WithEvents mitem18x20 As System.Windows.Forms.MenuItem
      Friend WithEvents ilistFile As System.Windows.Forms.ImageList
      Friend WithEvents ilistEdit As System.Windows.Forms.ImageList
      Friend WithEvents tbarFile As System.Windows.Forms.ToolBar
      Friend WithEvents tbbNew As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbbOpen As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbbSave As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbbPrint As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbarEdit As System.Windows.Forms.ToolBar
      Friend WithEvents tbbCut As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbbCopy As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbbPaste As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbbUndo As System.Windows.Forms.ToolBarButton
      Friend WithEvents tbbClear As System.Windows.Forms.ToolBarButton

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents mitem14x14 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FormMain))
Me.label1 = New System.Windows.Forms.Label
Me.cmdAdd1 = New System.Windows.Forms.Button
Me.cmdRemove1 = New System.Windows.Forms.Button
Me.label2 = New System.Windows.Forms.Label
Me.cmdAdd2 = New System.Windows.Forms.Button
Me.cmdRemove2 = New System.Windows.Forms.Button
Me.label3 = New System.Windows.Forms.Label
Me.cmdShowMenu = New System.Windows.Forms.Button
Me.cmdHideMenu = New System.Windows.Forms.Button
Me.menuMain = New System.Windows.Forms.MainMenu
Me.mitemFile = New System.Windows.Forms.MenuItem
Me.mitemFileNew = New System.Windows.Forms.MenuItem
Me.mitemFileOpen = New System.Windows.Forms.MenuItem
Me.mitemFileSave = New System.Windows.Forms.MenuItem
Me.mitemFileSaveAs = New System.Windows.Forms.MenuItem
Me.mitemSep1 = New System.Windows.Forms.MenuItem
Me.mitemFilePrint = New System.Windows.Forms.MenuItem
Me.menuItem2 = New System.Windows.Forms.MenuItem
Me.mitemFileExit = New System.Windows.Forms.MenuItem
Me.mitemEdit = New System.Windows.Forms.MenuItem
Me.mitemEditCut = New System.Windows.Forms.MenuItem
Me.mitemEditCopy = New System.Windows.Forms.MenuItem
Me.mitemEditPaste = New System.Windows.Forms.MenuItem
Me.mitemSep2 = New System.Windows.Forms.MenuItem
Me.mitemEditUndo = New System.Windows.Forms.MenuItem
Me.mitemEditClear = New System.Windows.Forms.MenuItem
Me.menuSizePopup = New System.Windows.Forms.MenuItem
Me.mitem12x12 = New System.Windows.Forms.MenuItem
Me.mitem12x20 = New System.Windows.Forms.MenuItem
Me.mitem14x14 = New System.Windows.Forms.MenuItem
Me.mitem14x20 = New System.Windows.Forms.MenuItem
Me.menuItem5 = New System.Windows.Forms.MenuItem
Me.mitem16x16 = New System.Windows.Forms.MenuItem
Me.mitem16x20 = New System.Windows.Forms.MenuItem
Me.mitem18x18 = New System.Windows.Forms.MenuItem
Me.mitem18x20 = New System.Windows.Forms.MenuItem
Me.mitem20x20 = New System.Windows.Forms.MenuItem
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitem24x24 = New System.Windows.Forms.MenuItem
Me.mitem32x32 = New System.Windows.Forms.MenuItem
Me.ilistFile = New System.Windows.Forms.ImageList
Me.ilistEdit = New System.Windows.Forms.ImageList
Me.tbarFile = New System.Windows.Forms.ToolBar
Me.tbbNew = New System.Windows.Forms.ToolBarButton
Me.tbbOpen = New System.Windows.Forms.ToolBarButton
Me.tbbSave = New System.Windows.Forms.ToolBarButton
Me.tbbPrint = New System.Windows.Forms.ToolBarButton
Me.tbarEdit = New System.Windows.Forms.ToolBar
Me.tbbCut = New System.Windows.Forms.ToolBarButton
Me.tbbCopy = New System.Windows.Forms.ToolBarButton
Me.tbbPaste = New System.Windows.Forms.ToolBarButton
Me.tbbUndo = New System.Windows.Forms.ToolBarButton
Me.tbbClear = New System.Windows.Forms.ToolBarButton
'
'label1
'
Me.label1.Location = New System.Drawing.Point(16, 40)
Me.label1.Size = New System.Drawing.Size(64, 40)
Me.label1.Text = "File Toolbar:"
Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'cmdAdd1
'
Me.cmdAdd1.Location = New System.Drawing.Point(96, 48)
Me.cmdAdd1.Size = New System.Drawing.Size(64, 20)
Me.cmdAdd1.Text = "Add"
'
'cmdRemove1
'
Me.cmdRemove1.Location = New System.Drawing.Point(168, 48)
Me.cmdRemove1.Size = New System.Drawing.Size(64, 20)
Me.cmdRemove1.Text = "Remove"
'
'label2
'
Me.label2.Location = New System.Drawing.Point(16, 88)
Me.label2.Size = New System.Drawing.Size(64, 32)
Me.label2.Text = "Edit Toolbar:"
Me.label2.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'cmdAdd2
'
Me.cmdAdd2.Location = New System.Drawing.Point(96, 96)
Me.cmdAdd2.Size = New System.Drawing.Size(64, 20)
Me.cmdAdd2.Text = "Add"
'
'cmdRemove2
'
Me.cmdRemove2.Location = New System.Drawing.Point(168, 96)
Me.cmdRemove2.Size = New System.Drawing.Size(64, 20)
Me.cmdRemove2.Text = "Remove"
'
'label3
'
Me.label3.Location = New System.Drawing.Point(24, 136)
Me.label3.Size = New System.Drawing.Size(56, 32)
Me.label3.Text = "Program Menu:"
Me.label3.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'cmdShowMenu
'
Me.cmdShowMenu.Location = New System.Drawing.Point(96, 144)
Me.cmdShowMenu.Size = New System.Drawing.Size(64, 20)
Me.cmdShowMenu.Text = "Show"
'
'cmdHideMenu
'
Me.cmdHideMenu.Location = New System.Drawing.Point(168, 144)
Me.cmdHideMenu.Size = New System.Drawing.Size(64, 20)
Me.cmdHideMenu.Text = "Hide"
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.mitemFile)
Me.menuMain.MenuItems.Add(Me.mitemEdit)
Me.menuMain.MenuItems.Add(Me.menuSizePopup)
'
'mitemFile
'
Me.mitemFile.MenuItems.Add(Me.mitemFileNew)
Me.mitemFile.MenuItems.Add(Me.mitemFileOpen)
Me.mitemFile.MenuItems.Add(Me.mitemFileSave)
Me.mitemFile.MenuItems.Add(Me.mitemFileSaveAs)
Me.mitemFile.MenuItems.Add(Me.mitemSep1)
Me.mitemFile.MenuItems.Add(Me.mitemFilePrint)
Me.mitemFile.MenuItems.Add(Me.menuItem2)
Me.mitemFile.MenuItems.Add(Me.mitemFileExit)
Me.mitemFile.Text = "File"
'
'mitemFileNew
'
Me.mitemFileNew.Text = "New"
'
'mitemFileOpen
'
Me.mitemFileOpen.Text = "Open..."
'
'mitemFileSave
'
Me.mitemFileSave.Text = "Save"
'
'mitemFileSaveAs
'
Me.mitemFileSaveAs.Text = "Save As..."
'
'mitemSep1
'
Me.mitemSep1.Text = "-"
'
'mitemFilePrint
'
Me.mitemFilePrint.Text = "Print"
'
'menuItem2
'
Me.menuItem2.Text = "-"
'
'mitemFileExit
'
Me.mitemFileExit.Text = "Exit"
'
'mitemEdit
'
Me.mitemEdit.MenuItems.Add(Me.mitemEditCut)
Me.mitemEdit.MenuItems.Add(Me.mitemEditCopy)
Me.mitemEdit.MenuItems.Add(Me.mitemEditPaste)
Me.mitemEdit.MenuItems.Add(Me.mitemSep2)
Me.mitemEdit.MenuItems.Add(Me.mitemEditUndo)
Me.mitemEdit.MenuItems.Add(Me.mitemEditClear)
Me.mitemEdit.Text = "Edit"
'
'mitemEditCut
'
Me.mitemEditCut.Text = "Cut"
'
'mitemEditCopy
'
Me.mitemEditCopy.Text = "Copy"
'
'mitemEditPaste
'
Me.mitemEditPaste.Text = "Paste"
'
'mitemSep2
'
Me.mitemSep2.Text = "-"
'
'mitemEditUndo
'
Me.mitemEditUndo.Text = "Undo"
'
'mitemEditClear
'
Me.mitemEditClear.Text = "Clear"
'
'menuSizePopup
'
Me.menuSizePopup.MenuItems.Add(Me.mitem12x12)
Me.menuSizePopup.MenuItems.Add(Me.mitem12x20)
Me.menuSizePopup.MenuItems.Add(Me.mitem14x14)
Me.menuSizePopup.MenuItems.Add(Me.mitem14x20)
Me.menuSizePopup.MenuItems.Add(Me.menuItem5)
Me.menuSizePopup.MenuItems.Add(Me.mitem16x16)
Me.menuSizePopup.MenuItems.Add(Me.mitem16x20)
Me.menuSizePopup.MenuItems.Add(Me.mitem18x18)
Me.menuSizePopup.MenuItems.Add(Me.mitem18x20)
Me.menuSizePopup.MenuItems.Add(Me.mitem20x20)
Me.menuSizePopup.MenuItems.Add(Me.MenuItem1)
Me.menuSizePopup.MenuItems.Add(Me.mitem24x24)
Me.menuSizePopup.MenuItems.Add(Me.mitem32x32)
Me.menuSizePopup.Text = "Size"
'
'mitem12x12
'
Me.mitem12x12.Text = "12x12"
'
'mitem12x20
'
Me.mitem12x20.Text = "12x20"
'
'mitem14x14
'
Me.mitem14x14.Text = "14x14"
'
'mitem14x20
'
Me.mitem14x20.Text = "14x20"
'
'menuItem5
'
Me.menuItem5.Text = "-"
'
'mitem16x16
'
Me.mitem16x16.Text = "16x16"
'
'mitem16x20
'
Me.mitem16x20.Text = "16x20"
'
'mitem18x18
'
Me.mitem18x18.Text = "18x18"
'
'mitem18x20
'
Me.mitem18x20.Text = "18x20"
'
'mitem20x20
'
Me.mitem20x20.Text = "20x20"
'
'MenuItem1
'
Me.MenuItem1.Text = "-"
'
'mitem24x24
'
Me.mitem24x24.Text = "24x24"
'
'mitem32x32
'
Me.mitem32x32.Text = "32x32"
'
'ilistFile
'
Me.ilistFile.Images.Add(CType(resources.GetObject("resource"), System.Drawing.Image))
Me.ilistFile.Images.Add(CType(resources.GetObject("resource1"), System.Drawing.Image))
Me.ilistFile.Images.Add(CType(resources.GetObject("resource2"), System.Drawing.Image))
Me.ilistFile.Images.Add(CType(resources.GetObject("resource3"), System.Drawing.Image))
Me.ilistFile.ImageSize = New System.Drawing.Size(16, 16)
'
'ilistEdit
'
Me.ilistEdit.Images.Add(CType(resources.GetObject("resource4"), System.Drawing.Image))
Me.ilistEdit.Images.Add(CType(resources.GetObject("resource5"), System.Drawing.Image))
Me.ilistEdit.Images.Add(CType(resources.GetObject("resource6"), System.Drawing.Image))
Me.ilistEdit.Images.Add(CType(resources.GetObject("resource7"), System.Drawing.Image))
Me.ilistEdit.Images.Add(CType(resources.GetObject("resource8"), System.Drawing.Image))
Me.ilistEdit.ImageSize = New System.Drawing.Size(16, 16)
'
'tbarFile
'
Me.tbarFile.Buttons.Add(Me.tbbNew)
Me.tbarFile.Buttons.Add(Me.tbbOpen)
Me.tbarFile.Buttons.Add(Me.tbbSave)
Me.tbarFile.Buttons.Add(Me.tbbPrint)
Me.tbarFile.ImageList = Me.ilistFile
'
'tbbNew
'
Me.tbbNew.ImageIndex = 0
'
'tbbOpen
'
Me.tbbOpen.ImageIndex = 1
'
'tbbSave
'
Me.tbbSave.ImageIndex = 2
'
'tbbPrint
'
Me.tbbPrint.ImageIndex = 3
'
'tbarEdit
'
Me.tbarEdit.Buttons.Add(Me.tbbCut)
Me.tbarEdit.Buttons.Add(Me.tbbCopy)
Me.tbarEdit.Buttons.Add(Me.tbbPaste)
Me.tbarEdit.Buttons.Add(Me.tbbUndo)
Me.tbarEdit.Buttons.Add(Me.tbbClear)
Me.tbarEdit.ImageList = Me.ilistEdit
'
'tbbCut
'
Me.tbbCut.ImageIndex = 0
'
'tbbCopy
'
Me.tbbCopy.ImageIndex = 1
'
'tbbPaste
'
Me.tbbPaste.ImageIndex = 2
'
'tbbUndo
'
Me.tbbUndo.ImageIndex = 3
'
'tbbClear
'
Me.tbbClear.ImageIndex = 4
'
'FormMain
'
Me.Controls.Add(Me.cmdHideMenu)
Me.Controls.Add(Me.cmdShowMenu)
Me.Controls.Add(Me.label3)
Me.Controls.Add(Me.cmdRemove2)
Me.Controls.Add(Me.cmdAdd2)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.cmdRemove1)
Me.Controls.Add(Me.cmdAdd1)
Me.Controls.Add(Me.label1)
Me.Controls.Add(Me.tbarFile)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "ToolBar"

    End Sub

#End Region

   ' Remember currently-selected toolbar
   Private m_tbarCurrent As System.Windows.Forms.ToolBar

   Private Sub FormMain_Load( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Load
      ' Disconnect both toolbars, so we always know which
      ' toolbar we start with (can change this inadvertently
      ' in forms designer.
      Me.Controls.Remove(tbarEdit)
      Me.Controls.Remove(tbarFile)

      m_tbarCurrent = tbarFile
      Me.Controls.Add(m_tbarCurrent)
   End Sub

   Private Sub cmdAdd1_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdAdd1.Click
      Controls.Add(tbarFile)
      m_tbarCurrent = tbarFile
   End Sub

   Private Sub cmdRemove1_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdRemove1.Click
      Controls.Remove(tbarFile)
      If (m_tbarCurrent Is tbarFile) Then
         m_tbarCurrent = Nothing
      End If
   End Sub

   Private Sub cmdAdd2_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdAdd2.Click
      Controls.Add(tbarEdit)
      m_tbarCurrent = tbarEdit
   End Sub

   Private Sub cmdRemove2_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdRemove2.Click
      Controls.Remove(tbarEdit)
      If (m_tbarCurrent Is tbarEdit) Then
         m_tbarCurrent = Nothing
      End If
   End Sub

   Private Sub cmdShowMenu_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdShowMenu.Click
      Me.Menu = menuMain
   End Sub

   Private Sub cmdHideMenu_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdHideMenu.Click
      Me.Menu = Nothing
   End Sub

   Private Sub ResetImageListSize( _
   ByVal cxWidth As Integer, _
   ByVal cyHeight As Integer)
      Me.ilistEdit.ImageSize = _
         New System.Drawing.Size(cxWidth, cyHeight)
      Me.ilistFile.ImageSize = _
         New System.Drawing.Size(cxWidth, cyHeight)
      If Not m_tbarCurrent Is Nothing Then
         Me.Controls.Remove(m_tbarCurrent)
         Me.Controls.Add(m_tbarCurrent)
      End If
   End Sub

   Private Sub ToggleMenuCheckMark( _
   ByVal mitemSender As MenuItem)
      ' Clear check mark from all other menu items.
      Dim citems As Integer = menuSizePopup.MenuItems.Count
      Dim i As Integer
      For i = 0 To citems - 1 Step i + 1
         menuSizePopup.MenuItems(i).Checked = False
      Next

      ' Set check mark on requested menu item.
      mitemSender.Checked = True
   End Sub

   Private Sub mitem12x12_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem12x12.Click
      ResetImageListSize(12, 12)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem12x20_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem12x20.Click
      ResetImageListSize(12, 20)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem14x14_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem14x14.Click
      ResetImageListSize(14, 14)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem14x20_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem14x20.Click
      ResetImageListSize(14, 20)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem16x16_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem16x16.Click
      ResetImageListSize(16, 16)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem16x20_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem16x20.Click
      ResetImageListSize(16, 20)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem18x18_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem18x18.Click
      ResetImageListSize(18, 18)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem18x20_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem18x20.Click
      ResetImageListSize(18, 20)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem20x20_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem20x20.Click
      ResetImageListSize(20, 20)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem24x24_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem24x24.Click
      ResetImageListSize(24, 24)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub mitem32x32_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitem32x32.Click
      ResetImageListSize(32, 32)
      ToggleMenuCheckMark(CType(sender, MenuItem))
   End Sub

   Private Sub tbarEdit_ButtonClick( _
   ByVal sender As System.Object, _
   ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) _
   Handles tbarEdit.ButtonClick
      Dim strButtonName As String = String.Empty
      If e.Button Is tbbCut Then
         strButtonName = "tbbCut"
      ElseIf e.Button Is tbbCopy Then
         strButtonName = "tbbCopy"
      ElseIf e.Button Is tbbPaste Then
         strButtonName = "tbbPaste"
      ElseIf e.Button Is tbbUndo Then
         strButtonName = "tbbUndo"
      ElseIf e.Button Is tbbClear Then
         strButtonName = "tbbClear"
      End If

      MessageBox.Show("User clicked " + strButtonName + _
         " tool bar button.")

   End Sub

   Private Sub tbarFile_ButtonClick( _
   ByVal sender As System.Object, _
   ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) _
   Handles tbarFile.ButtonClick

      Dim strButtonName As String = String.Empty
      If e.Button Is tbbNew Then
         strButtonName = "tbbNew"
      ElseIf e.Button Is tbbOpen Then
         strButtonName = "tbbOpen"
      ElseIf e.Button Is tbbSave Then
         strButtonName = "tbbSave"
      ElseIf e.Button Is tbbPrint Then
         strButtonName = "tbbPrint"
      End If

      MessageBox.Show("User clicked " + strButtonName + _
      " tool bar button.")
   End Sub
End Class
