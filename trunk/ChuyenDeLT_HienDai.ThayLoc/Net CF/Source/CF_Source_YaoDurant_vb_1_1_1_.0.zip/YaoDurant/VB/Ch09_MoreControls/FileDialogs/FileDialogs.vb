Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents textFileName As System.Windows.Forms.TextBox
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents textFilter As System.Windows.Forms.TextBox
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents nudFilterIndex As System.Windows.Forms.NumericUpDown
      Friend WithEvents label4 As System.Windows.Forms.Label
      Friend WithEvents textInitialDir As System.Windows.Forms.TextBox
      Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileNew As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileOpen As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileSave As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFileSaveAs As System.Windows.Forms.MenuItem
      Friend WithEvents dlgFileOpen As System.Windows.Forms.OpenFileDialog
      Friend WithEvents dlgFileSave As System.Windows.Forms.SaveFileDialog

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.menuMain = New System.Windows.Forms.MainMenu
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitemFileNew = New System.Windows.Forms.MenuItem
Me.mitemFileOpen = New System.Windows.Forms.MenuItem
Me.mitemFileSave = New System.Windows.Forms.MenuItem
Me.mitemFileSaveAs = New System.Windows.Forms.MenuItem
Me.label1 = New System.Windows.Forms.Label
Me.textFileName = New System.Windows.Forms.TextBox
Me.label2 = New System.Windows.Forms.Label
Me.textFilter = New System.Windows.Forms.TextBox
Me.label3 = New System.Windows.Forms.Label
Me.nudFilterIndex = New System.Windows.Forms.NumericUpDown
Me.label4 = New System.Windows.Forms.Label
Me.textInitialDir = New System.Windows.Forms.TextBox
Me.dlgFileOpen = New System.Windows.Forms.OpenFileDialog
Me.dlgFileSave = New System.Windows.Forms.SaveFileDialog
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.MenuItem1)
'
'MenuItem1
'
Me.MenuItem1.MenuItems.Add(Me.mitemFileNew)
Me.MenuItem1.MenuItems.Add(Me.mitemFileOpen)
Me.MenuItem1.MenuItems.Add(Me.mitemFileSave)
Me.MenuItem1.MenuItems.Add(Me.mitemFileSaveAs)
Me.MenuItem1.Text = "File"
'
'mitemFileNew
'
Me.mitemFileNew.Text = "New"
'
'mitemFileOpen
'
Me.mitemFileOpen.Text = "Open..."
'
'mitemFileSave
'
Me.mitemFileSave.Text = "Save"
'
'mitemFileSaveAs
'
Me.mitemFileSaveAs.Text = "Save As..."
'
'label1
'
Me.label1.Location = New System.Drawing.Point(0, 16)
Me.label1.Size = New System.Drawing.Size(64, 20)
Me.label1.Text = "File Name:"
Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'textFileName
'
Me.textFileName.Location = New System.Drawing.Point(72, 16)
Me.textFileName.Size = New System.Drawing.Size(160, 22)
Me.textFileName.Text = "NewDoc"
'
'label2
'
Me.label2.Location = New System.Drawing.Point(16, 48)
Me.label2.Size = New System.Drawing.Size(48, 20)
Me.label2.Text = "Filter:"
Me.label2.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'textFilter
'
Me.textFilter.Location = New System.Drawing.Point(72, 48)
Me.textFilter.Multiline = True
Me.textFilter.Size = New System.Drawing.Size(160, 88)
Me.textFilter.Text = "Pocket Word (*.psw)|*.psw|Pocket Excel (*.pxt)|*.pxt|Text Files (*.txt)|*.txt|All" & _
" Files (*.*)|*.*"
'
'label3
'
Me.label3.Location = New System.Drawing.Point(8, 152)
Me.label3.Size = New System.Drawing.Size(56, 32)
Me.label3.Text = "Filter  Index:"
Me.label3.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'nudFilterIndex
'
Me.nudFilterIndex.Location = New System.Drawing.Point(72, 152)
Me.nudFilterIndex.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
Me.nudFilterIndex.Size = New System.Drawing.Size(48, 20)
Me.nudFilterIndex.Value = New Decimal(New Integer() {1, 0, 0, 0})
'
'label4
'
Me.label4.Location = New System.Drawing.Point(0, 192)
Me.label4.Size = New System.Drawing.Size(56, 32)
Me.label4.Text = "Initial Directory:"
Me.label4.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'textInitialDir
'
Me.textInitialDir.Location = New System.Drawing.Point(72, 192)
Me.textInitialDir.Size = New System.Drawing.Size(152, 22)
Me.textInitialDir.Text = "\My Documents"
'
'dlgFileSave
'
Me.dlgFileSave.FileName = "doc1"
'
'FormMain
'
Me.Controls.Add(Me.textInitialDir)
Me.Controls.Add(Me.label4)
Me.Controls.Add(Me.nudFilterIndex)
Me.Controls.Add(Me.label3)
Me.Controls.Add(Me.textFilter)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.textFileName)
Me.Controls.Add(Me.label1)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "FileDialogs"

    End Sub

#End Region

   Private m_strAppName As String = "FileDialogs"

   ' mitemFileNew_Click - Handler for File->New menu item.
   Private Sub mitemFileNew_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemFileNew.Click

      textFileName.Text = "NewDoc"
      textFilter.Text = "Pocket Word (*.psw)|*.psw|" + _
         "Pocket Excel (*.pxt)|*.pxt|" + _
         "Text Files (*.txt)|*.txt|" + _
         "All Files (*.*)|*.*"
      nudFilterIndex.Value = 1
      textInitialDir.Text = "\My Documents"

      MessageBox.Show("Resetting fields.", m_strAppName)
   End Sub

   ' mitemFileOpen_Click - Handler for File->Open menu item.
   Private Sub mitemFileOpen_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemFileOpen.Click

      ' Read current settings from controls.
      dlgFileOpen.FileName = textFileName.Text
      dlgFileOpen.Filter = textFilter.Text
      Dim i As Integer = CInt(nudFilterIndex.Value)
      dlgFileOpen.FilterIndex = i
      dlgFileOpen.InitialDirectory = textInitialDir.Text

      Dim strResult As String

      Dim dlgres As DialogResult = _
      dlgFileOpen.ShowDialog()
      If (dlgres = DialogResult.OK) Then
         strResult = "User clicked Ok." + vbCrLf + _
            "Filename: " + dlgFileOpen.FileName

         ' Copy file name to our file name control.
         textFileName.Text = dlgFileOpen.FileName
      Else
         strResult = "User clicked Cancel."
      End If

      MessageBox.Show(strResult, m_strAppName)
   End Sub

   ' mitemFileSave_Click - Handler for File->Save menu item
   Private Sub mitemFileSave_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemFileSave.Click

      MessageBox.Show("File saved.", m_strAppName)
   End Sub

   ' mitemFileSaveAs_Click - Handler for File->Save As... menu
   Private Sub mitemFileSaveAs_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemFileSaveAs.Click

      ' Read current settings from controls.
      dlgFileSave.FileName = textFileName.Text
      dlgFileSave.Filter = textFilter.Text
      Dim i As Integer = CInt(nudFilterIndex.Value)
      dlgFileSave.FilterIndex = i
      dlgFileSave.InitialDirectory = textInitialDir.Text

      Dim strResult As String

      Dim dlgres As DialogResult = _
      dlgFileSave.ShowDialog()
      If (dlgres = DialogResult.OK) Then
         strResult = "User clicked Ok." + vbCrLf + _
            "Filename:" + dlgFileSave.FileName

         ' Copy file name to our file name control.
         textFileName.Text = dlgFileSave.FileName
      Else
         strResult = "User clicked Cancel."
      End If

      MessageBox.Show(strResult, m_strAppName)
   End Sub

End Class
