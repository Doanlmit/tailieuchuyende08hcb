' YaoDurant.Drawing.FontCollection.vb - Font enumeration 
' wrapper class for FONTLIST.DLL.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Collections
Imports System.Runtime.InteropServices

Namespace YaoDurant.Drawing

   Public Class FontCollection
      Public Sub New()
         Dim hFontList As IntPtr = FontList_Create()
         Dim count As Integer = FontList_GetCount(hFontList)
         Dim i As Integer
         Dim strFace As String
         Dim ip As IntPtr
         For i = 0 To count - 1 Step i + 1
            ip = FontList_GetFace(hFontList, i)
            strFace = Marshal.PtrToStringUni(ip)
            m_alFaceNames.Add(strFace)
         Next

         FontList_Destroy(hFontList)

      End Sub
      Public Sub Dispose()
         m_alFaceNames.Clear()
      End Sub

      ' P/Invoke declarations for fontlist.dll
      <DllImport("fontlist.DLL")> _
      Public Shared Function FontList_Create() As IntPtr
      End Function

      <DllImport("fontlist.DLL")> _
      Public Shared Function FontList_GetCount( _
      ByVal hFontList As IntPtr) As Integer
      End Function

      <DllImport("fontlist.DLL")> _
      Public Shared Function FontList_GetFace( _
      ByVal hFontList As IntPtr, _
      ByVal iFace As Integer) As IntPtr
      End Function

      <DllImport("fontlist.DLL")> _
      Public Shared Function FontList_Destroy( _
      ByVal hFontList As IntPtr) As Integer
      End Function

      ' Count of available face names.
      Public ReadOnly Property Count() As Integer
         Get
             Return m_alFaceNames.Count
         End Get
      End Property

      Private m_alFaceNames As ArrayList = New ArrayList

      Default Public ReadOnly Property FontCollection( _
      ByVal index As Integer) As String
         Get
            If index < 0 Or index >= m_alFaceNames.Count Then
               Return String.Empty
            Else
               Return CType(m_alFaceNames(index), String)
            End If
         End Get
      End Property

   End Class
End Namespace

