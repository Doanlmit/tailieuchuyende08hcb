' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Runtime.InteropServices
Imports YaoDurant.Controls
Imports Microsoft.WindowsCE.Forms

Namespace TextBoxClipboard

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents textEditor As System.Windows.Forms.TextBox
      Friend WithEvents sipMain As Microsoft.WindowsCE.Forms.InputPanel
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditCut As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditCopy As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditPaste As System.Windows.Forms.MenuItem
      Friend WithEvents menuItem6 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditClear As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditUndo As System.Windows.Forms.MenuItem

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
      Friend WithEvents cmenuClipboard As System.Windows.Forms.ContextMenu
      Friend WithEvents mitemCut As System.Windows.Forms.MenuItem
      Friend WithEvents mitemCopy As System.Windows.Forms.MenuItem
      Friend WithEvents mitemPaste As System.Windows.Forms.MenuItem
      Friend WithEvents mitemClear As System.Windows.Forms.MenuItem
      Friend WithEvents mitemUndo As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
Me.textEditor = New System.Windows.Forms.TextBox
Me.sipMain = New Microsoft.WindowsCE.Forms.InputPanel
Me.menuMain = New System.Windows.Forms.MainMenu
Me.menuItem2 = New System.Windows.Forms.MenuItem
Me.mitemEditCut = New System.Windows.Forms.MenuItem
Me.mitemEditCopy = New System.Windows.Forms.MenuItem
Me.mitemEditPaste = New System.Windows.Forms.MenuItem
Me.menuItem6 = New System.Windows.Forms.MenuItem
Me.mitemEditClear = New System.Windows.Forms.MenuItem
Me.mitemEditUndo = New System.Windows.Forms.MenuItem
Me.cmenuClipboard = New System.Windows.Forms.ContextMenu
Me.mitemCut = New System.Windows.Forms.MenuItem
Me.mitemCopy = New System.Windows.Forms.MenuItem
Me.mitemPaste = New System.Windows.Forms.MenuItem
Me.mitemClear = New System.Windows.Forms.MenuItem
Me.mitemUndo = New System.Windows.Forms.MenuItem
'
'textEditor
'
Me.textEditor.AcceptsReturn = True
Me.textEditor.ContextMenu = Me.cmenuClipboard
Me.textEditor.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular)
Me.textEditor.Location = New System.Drawing.Point(-1, -1)
Me.textEditor.Multiline = True
Me.textEditor.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
Me.textEditor.Size = New System.Drawing.Size(100, 100)
Me.textEditor.Text = ""
'
'sipMain
'
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.menuItem2)
'
'menuItem2
'
Me.menuItem2.MenuItems.Add(Me.mitemEditCut)
Me.menuItem2.MenuItems.Add(Me.mitemEditCopy)
Me.menuItem2.MenuItems.Add(Me.mitemEditPaste)
Me.menuItem2.MenuItems.Add(Me.menuItem6)
Me.menuItem2.MenuItems.Add(Me.mitemEditClear)
Me.menuItem2.MenuItems.Add(Me.mitemEditUndo)
Me.menuItem2.Text = "Edit"
'
'mitemEditCut
'
Me.mitemEditCut.Text = "Cut"
'
'mitemEditCopy
'
Me.mitemEditCopy.Text = "Copy"
'
'mitemEditPaste
'
Me.mitemEditPaste.Text = "Paste"
'
'menuItem6
'
Me.menuItem6.Text = "-"
'
'mitemEditClear
'
Me.mitemEditClear.Text = "Clear"
'
'mitemEditUndo
'
Me.mitemEditUndo.Text = "Undo"
'
'cmenuClipboard
'
Me.cmenuClipboard.MenuItems.Add(Me.mitemCut)
Me.cmenuClipboard.MenuItems.Add(Me.mitemCopy)
Me.cmenuClipboard.MenuItems.Add(Me.mitemPaste)
Me.cmenuClipboard.MenuItems.Add(Me.mitemClear)
Me.cmenuClipboard.MenuItems.Add(Me.mitemUndo)
'
'mitemCut
'
Me.mitemCut.Text = "Cut"
'
'mitemCopy
'
Me.mitemCopy.Text = "Copy"
'
'mitemPaste
'
Me.mitemPaste.Text = "Paste"
'
'mitemClear
'
Me.mitemClear.Text = "Clear"
'
'mitemUndo
'
Me.mitemUndo.Text = "Undo"
'
'FormMain
'
Me.Controls.Add(Me.textEditor)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "TextBoxClipboard"

    End Sub

#End Region

   '--------------------------------------------------------
   Dim m_emw As EventGrabberWindow
   Dim m_eg As YaoDurant.Controls.EventGrabber
   Dim m_msg As Microsoft.WindowsCE.Forms.Message

   ' Event grabber flags
   Public Const EVENT_KEYDOWN As Integer = &H1
   Public Const EVENT_KEYPRESS As Integer = &H2
   Public Const EVENT_KEYUP As Integer = &H4
   Public Const EVENT_MOUSEDOWN As Integer = &H8
   Public Const EVENT_MOUSEMOVE As Integer = &H10
   Public Const EVENT_MOUSEUP As Integer = &H20

   ' Clipboard messages
   Public Const WM_CUT As Integer = &H300
   Public Const WM_COPY As Integer = &H301
   Public Const WM_PASTE As Integer = &H302
   Public Const WM_CLEAR As Integer = &H303
   Public Const WM_UNDO As Integer = &H304

   ' P/Invoke declaration
   <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
   Public Shared Function GetFocus() As IntPtr
   End Function

   Private Sub FormMain_Load( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Load
      ' Textbox origin is (-1,-1)
      ' Adjust textbox size to available screen space.
      ' Add *two* to hide right and bottom borders.
      textEditor.Width = Me.Width + 2
      SetEditorHeight()

      ' Set focus to text box window.
      textEditor.Focus()

      ' Fetch window handle of text box.
      Dim hwndEditor As IntPtr = GetFocus()

      ' Create message structure for sending Win32 messages
      m_msg = Message.Create(hwndEditor, 0, IntPtr.Zero, _
         IntPtr.Zero)

      ' MessageWindow-derived object receives MouseDown
      m_emw = New EventGrabberWindow(textEditor, hwndEditor)

      ' Event grabber sends MouseDown event
      m_eg = New EventGrabber(hwndEditor, m_emw, _
         EVENT_MOUSEDOWN)
   End Sub

   Private Sub FormMain_Closed( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Closed
      ' Clean up event grabber.
      m_eg.Dispose()
   End Sub

   Private Sub SetEditorHeight()

      If (sipMain.Enabled) Then
         textEditor.Height = sipMain.VisibleDesktop.Height + 2
      Else
         textEditor.Height = Me.Height + 2
      End If
   End Sub

   Private Sub sipMain_EnabledChanged( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles sipMain.EnabledChanged

      SetEditorHeight()
   End Sub

   Private Sub mitemCut_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemEditCut.Click, mitemCut.Click

      ' WM_CUT does not work...
      ' m_msg.Msg = WM_CUT 
      ' MessageWindow.SendMessage(m_msg)

      ' ...and yet Copy & Clear work, so we do that instead
      m_msg.Msg = WM_COPY
      MessageWindow.SendMessage(m_msg)
      m_msg.Msg = WM_CLEAR
      MessageWindow.SendMessage(m_msg)
   End Sub

   Private Sub mitemCopy_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemEditCopy.Click, mitemCopy.Click

      m_msg.Msg = WM_COPY
      MessageWindow.SendMessage(m_msg)

   End Sub

   Private Sub mitemPaste_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemEditPaste.Click, mitemPaste.Click

      m_msg.Msg = WM_PASTE
      MessageWindow.SendMessage(m_msg)
   End Sub

   Private Sub mitemClear_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemEditClear.Click, mitemClear.Click

      m_msg.Msg = WM_CLEAR
      MessageWindow.SendMessage(m_msg)
   End Sub

   Private Sub mitemUndo_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemEditUndo.Click, mitemUndo.Click

      m_msg.Msg = WM_UNDO
      MessageWindow.SendMessage(m_msg)
   End Sub

End Class

Class EventGrabberWindow
    Inherits MessageWindow

   Private m_ctrlTarget As Control
   Private m_hwndTarget As IntPtr

   Public Sub New( _
      ByVal ctrlTarget As Control, _
      ByVal hwndTarget As IntPtr)

      m_ctrlTarget = ctrlTarget
      m_hwndTarget = hwndTarget
   End Sub

   ' Message values
   Public Const WM_MOUSEMOVE As Integer = &H200
   Public Const WM_LBUTTONDOWN As Integer = &H201
   Public Const WM_LBUTTONUP As Integer = &H202
   Public Const WM_KEYDOWN As Integer = &H100
   Public Const WM_KEYUP As Integer = &H101
   Public Const WM_CHAR As Integer = &H102

   ' Start -- SHRecognizeGesture declarations.
   <DllImport("AygShell.dll", CharSet:=CharSet.Unicode)> _
   Shared Function SHRecognizeGesture( _
      ByRef shrg As SHRGINFO) As Integer
   End Function

   Public Structure SHRGINFO
      Public cbSize As Integer
      Public hwndClient As IntPtr
      Public ptDown As System.Drawing.Point
      Public dwFlags As Integer
   End Structure

   Public Const GN_CONTEXTMENU As Integer = 1000
   Public Const SHRG_RETURNCMD As Integer = &H1

   Protected Overrides Sub WndProc( _
   ByRef msg As Microsoft.WindowsCE.Forms.Message)

      Select Case msg.Msg
         Case WM_LBUTTONDOWN
            Dim xyBundle As Integer
            xyBundle = CInt(msg.LParam.ToInt32())
            Dim x As Integer = xyBundle And &HFFFF
            Dim y As Integer = (xyBundle >> 16)

            Dim shinfo As SHRGINFO
            shinfo = New SHRGINFO
            shinfo.cbSize = Marshal.SizeOf(shinfo)
            shinfo.hwndClient = m_hwndTarget
            shinfo.ptDown.X = x
            shinfo.ptDown.Y = y
            shinfo.dwFlags = SHRG_RETURNCMD

            If SHRecognizeGesture(shinfo) = GN_CONTEXTMENU Then
               Dim pt As Point = New Point(x, y)
               Dim pt2 As Point = m_ctrlTarget.PointToScreen(pt)
               m_ctrlTarget.ContextMenu.Show(m_ctrlTarget, pt2)

               ' We handle event.
               ' Do not pass to original wndproc
               msg.Result = IntPtr.Zero
            Else
               ' Tell handler to send to original wndproc
               msg.Result = New IntPtr(1)
            End If
         Case WM_MOUSEMOVE
         Case WM_LBUTTONUP
         Case WM_KEYDOWN
         Case WM_CHAR
         Case WM_KEYUP
      End Select
   End Sub

End Class

End Namespace
