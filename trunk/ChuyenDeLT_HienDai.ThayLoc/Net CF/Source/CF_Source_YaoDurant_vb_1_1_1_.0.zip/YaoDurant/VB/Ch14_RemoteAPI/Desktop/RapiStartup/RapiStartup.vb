' RapiStartup.vb - Simple thread-free RAPI startup
' with all P/Invoke declarations included.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Threading
Imports System.Windows.Forms
Imports System.Runtime.InteropServices

Namespace RapiStartup
   Public Class RapiStartup
      Const m_strAppName As String = "RapiStartup"

      Public Sub New()
      End Sub

      ' -------------------------------------------------------
      ' RAPI.DLL Definitions
      ' -------------------------------------------------------
      Public Structure RAPIINIT
         Public cbSize As Integer
         Public heRapiInit As IntPtr
         Public hrRapiInit As Integer
      End Structure


      <DllImport("rapi.DLL", CharSet:=CharSet.Unicode)> _
      Public Shared Function _
      CeRapiInitEx(ByRef p As RAPIINIT) As Integer
      End Function

      <DllImport("rapi.DLL", CharSet:=CharSet.Unicode)> _
      Public Shared Function CeRapiUninit() As Integer
      End Function

      Const S_OK As Integer = 0

      ' -------------------------------------------------------
      ' Main -- Program entry point
      ' -------------------------------------------------------
      Public Shared Sub Main()
         ' Allocate structure for call to CeRapiInitEx
         Dim ri As RAPIINIT = New RAPIINIT
         ri.cbSize = Marshal.SizeOf(ri)

         ' Call init function
         Dim hr As Integer = CeRapiInitEx(ri)

         ' Wrap event handle in corresponding .NET object
         Dim mrev As ManualResetEvent = New ManualResetEvent(False)
         mrev.Handle = ri.heRapiInit

         ' Wait five seconds, then fail.
         If mrev.WaitOne(5000, False) And ri.hrRapiInit = S_OK Then
            ' Connection established.
            MessageBox.Show("Connection Established", m_strAppName)
         Else
            ' On failure, disconnect from RAPI.
            CeRapiUninit()

            MessageBox.Show("Timeout - No Device", m_strAppName)
            Return
         End If

         ' If we get here, we have established a RAPI connection

         ' ToDo: Put your RAPI calls here...

         ' Cleanup.
         CeRapiUninit()
      End Sub

   End Class ' RapiStartup
End Namespace  '  RapiStartup
