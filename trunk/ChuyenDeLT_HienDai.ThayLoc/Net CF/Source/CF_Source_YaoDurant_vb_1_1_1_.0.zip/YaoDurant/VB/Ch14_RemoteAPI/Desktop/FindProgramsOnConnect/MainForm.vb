' FormMain.vb - main user-interface for this program
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Collections
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports System.Diagnostics
Imports System.Threading
Imports YaoDurant.Win32.Rapi


Namespace FindPrograms
    _
   '/ <summary>
   '/ Summary description for FormMain.
   '/ </summary>
   Public Class FormMain
      Inherits System.Windows.Forms.Form

      ' Startup thread definitions
      Private m_thrdStartup As StartupThread = Nothing
      Private m_deleStartup As EventHandler
      Private m_bRapiConnected As Boolean = False

      ' Find Files thread definitions
      Private m_thrdFindFiles As FindFilesThread = Nothing
      Private m_deleFindFiles As EventHandler

      ' Connect detect definitions
      Private m_rapicd As RapiConnectDetect = Nothing
      Private m_deleConnect As EventHandler

      Public Sub New()
         '
         ' Required for Windows Form Designer support
         '
         InitializeComponent()

         '
         ' TODO: Add any constructor code after 
         ' InitializeComponent call
         '
         sbarMain.Text = "Ready"
         Trace.WriteLine("FindProgramsOnConnect: Starting..." + ControlChars.Cr + ControlChars.Lf)

         ' Setup inter-thread delegates.
         m_deleStartup = New EventHandler(AddressOf StartupCallback)
         m_deleFindFiles = New EventHandler(AddressOf FindFilesCallback)

         m_deleConnect = New EventHandler(AddressOf DetectCallback)

         ' Create detect connect object
         m_rapicd = New RapiConnectDetect(Me, m_deleConnect)
         m_rapicd.Init()
         m_rapicd.Enable(True)
      End Sub 'New

      '/ <summary>
      '/ Clean up any resources being used.
      '/ </summary>
      Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
         If disposing Then
            If Not (components Is Nothing) Then
               components.Dispose()
            End If
         End If
         MyBase.Dispose(disposing)
      End Sub 'Dispose

#Region " Windows Form Designer generated code "
      Friend WithEvents cmdConnect As System.Windows.Forms.Button
      Friend WithEvents cmdDisconnect As System.Windows.Forms.Button
      Friend WithEvents cmdFind As System.Windows.Forms.Button
      Friend WithEvents cmdRun As System.Windows.Forms.Button
      Friend WithEvents cmdAbout As System.Windows.Forms.Button

      '/ <summary>
      '/ Required designer variable.
      '/ </summary>
      Private components As System.ComponentModel.Container = Nothing
      Private sbarMain As System.Windows.Forms.StatusBar
      Private label1 As System.Windows.Forms.Label
      Private txtStartDir As System.Windows.Forms.TextBox
      Private chkSubs As System.Windows.Forms.CheckBox
      Private lboxPrograms As System.Windows.Forms.ListBox
      Private m_strAppName As String = "FindProgramsOnConnect"

      '/ <summary>
      '/ Required method for Designer support - do not modify
      '/ the contents of this method with the code editor.
      '/ </summary>
      Private Sub InitializeComponent()
         Me.cmdConnect = New System.Windows.Forms.Button
         Me.cmdDisconnect = New System.Windows.Forms.Button
         Me.cmdFind = New System.Windows.Forms.Button
         Me.cmdRun = New System.Windows.Forms.Button
         Me.lboxPrograms = New System.Windows.Forms.ListBox
         Me.cmdAbout = New System.Windows.Forms.Button
         Me.sbarMain = New System.Windows.Forms.StatusBar
         Me.label1 = New System.Windows.Forms.Label
         Me.txtStartDir = New System.Windows.Forms.TextBox
         Me.chkSubs = New System.Windows.Forms.CheckBox
         Me.SuspendLayout()
         ' 
         ' cmdConnect
         ' 
         Me.cmdConnect.Location = New System.Drawing.Point(448, 32)
         Me.cmdConnect.Name = "cmdConnect"
         Me.cmdConnect.Size = New System.Drawing.Size(96, 23)
         Me.cmdConnect.TabIndex = 0
         Me.cmdConnect.Text = "Connect"
         ' 
         ' cmdDisconnect
         ' 
         Me.cmdDisconnect.Enabled = False
         Me.cmdDisconnect.Location = New System.Drawing.Point(448, 72)
         Me.cmdDisconnect.Name = "cmdDisconnect"
         Me.cmdDisconnect.Size = New System.Drawing.Size(96, 23)
         Me.cmdDisconnect.TabIndex = 1
         Me.cmdDisconnect.Text = "Disconnect"
         ' 
         ' cmdFind
         ' 
         Me.cmdFind.Enabled = False
         Me.cmdFind.Location = New System.Drawing.Point(448, 112)
         Me.cmdFind.Name = "cmdFind"
         Me.cmdFind.Size = New System.Drawing.Size(96, 23)
         Me.cmdFind.TabIndex = 2
         Me.cmdFind.Text = "Find Programs"
         ' 
         ' cmdRun
         ' 
         Me.cmdRun.Enabled = False
         Me.cmdRun.Location = New System.Drawing.Point(448, 152)
         Me.cmdRun.Name = "cmdRun"
         Me.cmdRun.Size = New System.Drawing.Size(96, 23)
         Me.cmdRun.TabIndex = 3
         Me.cmdRun.Text = "Run"
         ' 
         ' lboxPrograms
         ' 
         Me.lboxPrograms.Location = New System.Drawing.Point(8, 40)
         Me.lboxPrograms.Name = "lboxPrograms"
         Me.lboxPrograms.Size = New System.Drawing.Size(416, 173)
         Me.lboxPrograms.TabIndex = 4
         ' 
         ' cmdAbout
         ' 
         Me.cmdAbout.Location = New System.Drawing.Point(448, 192)
         Me.cmdAbout.Name = "cmdAbout"
         Me.cmdAbout.Size = New System.Drawing.Size(96, 23)
         Me.cmdAbout.TabIndex = 5
         Me.cmdAbout.Text = "About"
         ' 
         ' sbarMain
         ' 
         Me.sbarMain.Location = New System.Drawing.Point(0, 229)
         Me.sbarMain.Name = "sbarMain"
         Me.sbarMain.Size = New System.Drawing.Size(560, 22)
         Me.sbarMain.TabIndex = 6
         ' 
         ' label1
         ' 
         Me.label1.Location = New System.Drawing.Point(8, 8)
         Me.label1.Name = "label1"
         Me.label1.Size = New System.Drawing.Size(100, 16)
         Me.label1.TabIndex = 7
         Me.label1.Text = "Starting Directory:"
         ' 
         ' txtStartDir
         ' 
         Me.txtStartDir.Location = New System.Drawing.Point(112, 8)
         Me.txtStartDir.Name = "txtStartDir"
         Me.txtStartDir.Size = New System.Drawing.Size(312, 20)
         Me.txtStartDir.TabIndex = 8
         Me.txtStartDir.Text = ""
         ' 
         ' chkSubs
         ' 
         Me.chkSubs.Location = New System.Drawing.Point(440, 8)
         Me.chkSubs.Name = "chkSubs"
         Me.chkSubs.Size = New System.Drawing.Size(104, 16)
         Me.chkSubs.TabIndex = 9
         Me.chkSubs.Text = "Sub-directories"
         ' 
         ' FormMain
         ' 
         Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
         Me.ClientSize = New System.Drawing.Size(560, 251)
         Me.Controls.Add(chkSubs)
         Me.Controls.Add(txtStartDir)
         Me.Controls.Add(label1)
         Me.Controls.Add(sbarMain)
         Me.Controls.Add(cmdAbout)
         Me.Controls.Add(lboxPrograms)
         Me.Controls.Add(cmdRun)
         Me.Controls.Add(cmdFind)
         Me.Controls.Add(cmdDisconnect)
         Me.Controls.Add(cmdConnect)
         Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
         Me.Name = "FormMain"
         Me.Text = "RAPI - FindProgramsOnConnect"
         Me.ResumeLayout(False)
      End Sub 'InitializeComponent
#End Region

      Shared Sub Main()
          Application.Run(New FormMain)
      End Sub
      Private Sub FormMain_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
         ' If threads are running, trigger shutdown.
         If Not (Me.m_thrdStartup Is Nothing) Then
            Me.m_thrdStartup.bThreadContinue = False
         End If
         If Not (Me.m_thrdFindFiles Is Nothing) Then
            Me.m_thrdFindFiles.bThreadContinue = False
         End If
         If m_bRapiConnected Then
            Rapi.CeRapiUninit()
            m_bRapiConnected = False
         End If
      End Sub 'FormMain_Closed


      Private Sub cmdAbout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAbout.Click
         MessageBox.Show("(c) Copyright 2002-2003 " + "Paul Yao and David Durant" + ControlChars.Lf + ControlChars.Lf + "FindProgramsOnConnect - RAPI Sample for " + ControlChars.Lf + "Programming the .NET Compact Framework with C#," + ControlChars.Lf + "& Programming the .NET Compact Framework with VB.", m_strAppName)
      End Sub 'cmdAbout_Click


      Private Sub cmdConnect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdConnect.Click
         ' Update UI.
         sbarMain.Text = "Connecting..."
         Me.cmdConnect.Enabled = False

         ' Create thread to connect to RAPI.
         m_thrdStartup = New StartupThread(Me, m_deleStartup)
         If Not m_thrdStartup.Run() Then
            m_thrdStartup = Nothing
         End If
         ' Clear out prvevious contents of file listbox.
         lboxPrograms.Items.Clear()
      End Sub 'cmdConnect_Click


      Private Sub cmdDisconnect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDisconnect.Click
         sbarMain.Text = "Disconnecting..."

         ' Trigger thread to stop running.
         If Not (m_thrdFindFiles Is Nothing) Then
            m_thrdFindFiles.bThreadContinue = False
         End If
         ' Disconnect from RAPI.
         Rapi.CeRapiUninit()

         ResetUI()

         ' Clear out previous contents of file listbox.
         lboxPrograms.Items.Clear()

         m_bRapiConnected = False
      End Sub 'cmdDisconnect_Click


      Private Sub cmdRun_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRun.Click
         sbarMain.Text = "Attempting to run program..."

         Dim iItem As Integer = lboxPrograms.SelectedIndex
         Dim strProg As String = lboxPrograms.Items(iItem).ToString()

         If strProg.Length > 0 Then
            Dim pi As New Rapi.PROCESS_INFORMATION
            Rapi.CeCreateProcess(strProg, 0, 0, 0, 0, 0, 0, 0, 0, pi)

            Rapi.CeCloseHandle(pi.hProcess)
            Rapi.CeCloseHandle(pi.hThread)
         End If

         sbarMain.Text = "Ready"
      End Sub 'cmdRun_Click


      Private Sub cmdFind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdFind.Click
         ' Disable Find button.
         Me.cmdFind.Enabled = False

         ' Clear out previous contents of file listbox.
         lboxPrograms.Items.Clear()

         m_thrdFindFiles = New FindFilesThread(Me, m_deleFindFiles)
         If Not m_thrdFindFiles.Run(Me.chkSubs.Checked) Then
            m_thrdFindFiles = Nothing
         End If
      End Sub 'cmdFind_Click

      '/ <summary>
      '/ StartupCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub StartupCallback(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim it As INVOKE_STARTUP = Me.m_thrdStartup.itReason
         Select Case it
            Case INVOKE_STARTUP.STARTUP_SUCCESS
               m_bRapiConnected = True
               EnableUI()
            Case INVOKE_STARTUP.STARTUP_FAILED
               ResetUI()
            Case INVOKE_STARTUP.STATUS_MESSAGE
               sbarMain.Text = m_thrdStartup.strBuffer
         End Select
      End Sub 'StartupCallback


      '/ <summary>
      '/ FindFilesCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub FindFilesCallback(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim it As INVOKE_FINDFILES = Me.m_thrdFindFiles.itReason
         Select Case it
            Case INVOKE_FINDFILES.FINDFILE_QUERYSTARTPATH
               Dim strStart As String = txtStartDir.Text
               If strStart.EndsWith("\") = False Then
                  strStart = strStart + "\"
               End If
               m_thrdFindFiles.strBuffer = strStart
            Case INVOKE_FINDFILES.FINDFILE_NEWFILE
               lboxPrograms.Items.Add(m_thrdFindFiles.strBuffer)
            Case INVOKE_FINDFILES.FINDFILE_COMPLETE
               Me.cmdFind.Enabled = True
            Case INVOKE_FINDFILES.STATUS_MESSAGE
               sbarMain.Text = m_thrdFindFiles.strBuffer
         End Select
      End Sub 'FindFilesCallback

      '/ <summary>
      '/ DetectCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub DetectCallback(ByVal sender As Object, ByVal e As System.EventArgs)
          Dim it As INVOKE_CONNECT = Me.m_rapicd.itReason
          Select Case it
              Case INVOKE_CONNECT.START
                 cmdConnect_Click(Me, New EventArgs)
                 Me.txtStartDir.Text = "\"
                 Me.chkSubs.Checked = True
                 cmdFind.Enabled = True
                 Me.cmdFind_Click(Me, New EventArgs)
              Case INVOKE_CONNECT.STOP
                 Me.cmdDisconnect_Click(Me, New EventArgs)
          End Select
      End Sub


      '/ <summary>
      '/ EnableUI - Connection established.
      '/ </summary>
      Private Sub EnableUI()
         Me.cmdDisconnect.Enabled = True
         Me.cmdFind.Enabled = True
         Me.cmdRun.Enabled = True
         Me.cmdConnect.Enabled = False
         sbarMain.Text = "Connected"
      End Sub 'EnableUI


      '/ <summary>
      '/ ResetUI - Connection terminated.
      '/ </summary>
      Private Sub ResetUI()
         Me.cmdDisconnect.Enabled = False
         Me.cmdFind.Enabled = False
         Me.cmdRun.Enabled = False
         Me.cmdConnect.Enabled = True
         sbarMain.Text = "Ready"
      End Sub 'ResetUI
   End Class 'FormMain 
End Namespace 'FindPrograms
