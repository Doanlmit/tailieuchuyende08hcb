' RapiFindFilesThread.vb - Creates a background 
' thread to retrieve file names from the device.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System
Imports System.Threading
Imports System.Collections
Imports System.Windows.Forms
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports YaoDurant.Win32.Rapi


Namespace FindPrograms
    _
   ' Reasons our thread invokes user-interface thread.
   Public Enum INVOKE_FINDFILES
      FINDFILE_QUERYSTARTPATH
      FINDFILE_NEWFILE
      FINDFILE_COMPLETE
      STATUS_MESSAGE
   End Enum 'INVOKE_FINDFILES
    _
   
   '/ <summary>
   '/ FindFilesThread wraps a thread that supports
   '/ RAPI search of device directory.
   '/ </summary>
   Public Class FindFilesThread
      Public strBuffer As String ' Inter-thread buffer
      Public itReason As INVOKE_FINDFILES ' Inter-thread reason
      Private m_thrd As Thread = Nothing ' The contained thread
      Private m_ctlInvokeTarget As Control ' Inter-thread control
      Private m_deleCallback As EventHandler ' Inter-thread delegate
      Private m_bContinue As Boolean ' Continue flag.
      Private m_bIncludeSubDirs As Boolean = False ' Search sub-dirs
      Private m_cFiles As Integer = 0 ' Find-File counter.
      
      Public Property bThreadContinue() As Boolean ' Continue property.
         Get
            Return m_bContinue
         End Get
         Set
            m_bContinue = value
         End Set
      End Property
       
      '/ <summary>
      '/ FindFilesThread - Constructor.
      '/ </summary>
      '/ <param name="ctl">Owner control</param>
      '/ <param name="dele">Delegate to invoke</param>
      Public Sub New(ctl As Control, dele As EventHandler)
         bThreadContinue = True
         m_ctlInvokeTarget = ctl ' Who to call.
         m_deleCallback = dele ' How to call.
      End Sub 'New
      
      
      '/ <summary>
      '/ Run - Init function for find-files thread.
      '/ </summary>
      '/ <param name="bSubDirs"></param>
      '/ <returns></returns>
      Public Function Run(bSubDirs As Boolean) As Boolean
         Dim ts As ThreadStart = Nothing
         ts = New ThreadStart(AddressOf ThreadMainFindFiles)
         If ts Is Nothing Then
            Return False
         End If 
         m_bIncludeSubDirs = bSubDirs
         
         m_thrd = New Thread(ts)
         m_thrd.Start()
         Return True
      End Function 'Run
      
      
      '/ <summary>
      '/ ThreadMainFindFiles - Main thread for file find thread
      '/ </summary>
      Private Sub ThreadMainFindFiles()
         Dim cTicks As Integer = Environment.TickCount
         
         itReason = INVOKE_FINDFILES.FINDFILE_QUERYSTARTPATH
         m_ctlInvokeTarget.Invoke(m_deleCallback)
         Dim strPath As String = strBuffer
         AddProgramsInDirectory(strPath)
         
         Dim cSeconds As Integer = _
            (Environment.TickCount - cTicks + 500) / 1000
         If bThreadContinue Then
            ' Send message for search time.
            strBuffer = "Ready - " + m_cFiles.ToString() + _
               " programs found in " + cSeconds.ToString() + _
               " seconds."
            itReason = INVOKE_FINDFILES.STATUS_MESSAGE
            m_ctlInvokeTarget.Invoke(m_deleCallback)
            
            ' Trigger that search is done.
            itReason = INVOKE_FINDFILES.FINDFILE_COMPLETE
            m_ctlInvokeTarget.Invoke(m_deleCallback)
         End If
      End Sub 'ThreadMainFindFiles
      
      
      '/ <summary>
      '/ AddProgramsInDirectory - Recursive function to search
      '/ into directory tree.
      '/ </summary>
      '/ <param name="strDir">Starting directory</param>
      '/ <returns></returns>
      Private Function AddProgramsInDirectory(strDir As String) As Boolean

         ' Update status bar through delegate function.
         strBuffer = "Searching in " + strDir + "..."
         itReason = INVOKE_FINDFILES.STATUS_MESSAGE
         m_ctlInvokeTarget.Invoke(m_deleCallback)
         
         ' As we add programs, store directory names.
         Dim alDirectories As New ArrayList()

         ' Start our search.
         Dim strSearch As String = strDir + "*.*"
         Dim pfdAllFiles As IntPtr = IntPtr.Zero ' Return pointer.
         Dim cFound As Integer = 0 ' Return count of files.
         ' Call looking for all files in current directory.
         Rapi.CeFindAllFiles(strSearch, _
            Rapi.FAF.FAF_ATTRIBUTES Or _
            Rapi.FAF.FAF_NAME, _
            cFound, _
            pfdAllFiles)

         ' Loop through all files found.
         Dim pfd As IntPtr = pfdAllFiles
         While cFound > 0
            '
            ' Here is the secret sauce. This function uses a
            ' Win32 pointer to create a .NET object
            '
            Dim fd As Rapi.CE_FIND_DATA = _
               CType( _
                  Marshal.PtrToStructure( _
                     pfd, _
                     GetType(Rapi.CE_FIND_DATA)), _
                  Rapi.CE_FIND_DATA)

               Dim strFileName As String = fd.cFileName
               Dim iFlag As Integer = _
                  Rapi.FILE_ATTRIBUTE.FILE_ATTRIBUTE_DIRECTORY
               If (fd.dwFileAttributes And iFlag) = iFlag Then
                  alDirectories.Add((strDir + fd.cFileName))
               Else
                  If strFileName.EndsWith(".EXE") Or _
                     strFileName.EndsWith(".exe") Then
                     m_cFiles += 1

                     strBuffer = strDir + fd.cFileName
                     itReason = INVOKE_FINDFILES.FINDFILE_NEWFILE
                     m_ctlInvokeTarget.Invoke(m_deleCallback)
                  End If
               End If
            ' Get ready for next loop.
            pfd = IntPtr.op_Explicit(pfd.ToInt32() + _
               Marshal.SizeOf(fd))
            cFound -= 1
         End While

         ' Free memory returned by CeFindAllFiles.
         Rapi.CeRapiFreeBuffer(pfdAllFiles)

            If bThreadContinue And m_bIncludeSubDirs Then
               Dim str As String
               For Each str In alDirectories
                  AddProgramsInDirectory((str + "\"))
               Next str
            End If

         Return True
      End Function 'AddProgramsInDirectory
      
      
      '/ <summary>
      '/ FetchAndDisplayError - Display error in status bar
      '/ </summary>
      Public Sub FetchAndDisplayError()
         strBuffer = String.Empty
         
         ' Is this a RAPI error?
         Dim err As Integer = Rapi.CeRapiGetError()
         If err <> Rapi.S_OK Then
            strBuffer = "RAPI Error (0x" + err.ToString("x") + ")"
         Else
            ' Check for CE error.
            err = Rapi.CeGetLastError()
            If err <> Rapi.RAPI_ERROR.ERROR_FILE_NOT_FOUND Then
               strBuffer = "CE Error (code = " + err.ToString("x") + ")"
            End If
         End If
         If strBuffer <> String.Empty Then
            itReason = INVOKE_FINDFILES.STATUS_MESSAGE
            m_ctlInvokeTarget.Invoke(m_deleCallback)
         End If
         
         ' Trigger that thread has ended.
         m_thrd = Nothing
      End Sub 'FetchAndDisplayError
   End Class 'FindFilesThread
End Namespace 'FindPrograms