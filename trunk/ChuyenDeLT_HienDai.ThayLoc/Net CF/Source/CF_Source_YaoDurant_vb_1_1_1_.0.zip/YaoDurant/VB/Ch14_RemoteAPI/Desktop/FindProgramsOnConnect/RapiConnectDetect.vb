' RapiConnectDetect.vb - Creates a RAPI COM
' object of type IDccMan and an Advise Sink of type IDccManSink
' to detect the start and end of RAPI connections.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System
Imports System.Windows.Forms
Imports System.Runtime.InteropServices


Namespace FindPrograms
    _
   ' Reason we are calling.
   Public Enum INVOKE_CONNECT
      START
      [STOP]
   End Enum 'INVOKE_CONNECT
    _
   
   '/ <summary>
   '/ Provides notifications of RAPI connection
   '/ </summary>
   Public Class RapiConnectDetect
      Implements IDccManSink 'We implement this interface
      Public itReason As INVOKE_CONNECT ' Inter-thread reason
      Private m_deleCallback As EventHandler ' Callback delegate
      Private m_ctlTarget As Control ' Target for Invoke calls
      Private m_pDccMan As IDccMan = Nothing ' RAPI-provided object
      Private m_Connected As Boolean = False ' Connection state
      Private m_iAdviseSinkContext As Integer = 0  ' Advise sink context

      <DllImport("ole32.dll"), PreserveSig()> _
      Public Shared Function CoCreateInstance( _
      ByRef rclsid As System.Guid, _
      <MarshalAs(UnmanagedType.Interface)> _
      ByVal punkOuter As Object, _
      <MarshalAs(UnmanagedType.I4)> _
      ByVal context As Integer, _
      ByRef iid As System.Guid, _
      ByRef pDccMan As IDccMan _
      ) As Integer
   End Function

   Const CLSCTX_INPROC_SERVER As Integer = 1

   '/ <summary>
   '/ RapiConnectDetect -- class constructor
   '/ </summary>
   '/ <param name="dele"></param>
   Public Sub New(ByVal ctl As Control, ByVal dele As EventHandler)
      m_deleCallback = dele ' Callback for notifications
      m_ctlTarget = ctl ' Control to notify.
   End Sub 'New

   Public Function Init() As Boolean
      Dim IID_IDccMan As New _
         System.Guid("A7B88841-A812-11CF-8011-00A0C90A8F78")
      Dim CLSID_DccMan As New _
         System.Guid("499C0C20-A766-11CF-8011-00A0C90A8F78")

      Dim pTemp As IntPtr

      Dim iErr As Integer 
      iErr = CoCreateInstance(CLSID_DccMan, Nothing, _
         CLSCTX_INPROC_SERVER, IID_IDccMan, m_pDccMan)

      If m_pDccMan Is Nothing Then
         Return False
      End If
      Return True
   End Function 'Init

   '/ <summary>
   '/ Enable - Toggle advise synch operation.
   '/ </summary>
   '/ <param name="bEnable"></param>
   Public Sub Enable(ByVal bEnable As Boolean)
      If bEnable And m_iAdviseSinkContext = 0 Then
         Dim idcc As IDccManSink = CType(Me, IDccManSink)
         m_pDccMan.Advise(idcc, m_iAdviseSinkContext)
      End If

      If Not bEnable And m_iAdviseSinkContext <> 0 Then
         m_pDccMan.Unadvise(m_iAdviseSinkContext)
         m_iAdviseSinkContext = 0
      End If
   End Sub 'Enable

   '
   ' IDccManSink interface functions.
   '
   Public Function OnLogAnswered() As Integer _
      Implements IDccManSink.OnLogAnswered
      Return 0 ' Line detected
   End Function 'OnLogAnswered

   Public Function OnLogActive() As Integer _
      Implements IDccManSink.OnLogActive
      Return 0 ' Line active
   End Function 'OnLogActive

   '/ <summary>
   '/ OnLogIpAddr - First event when it makes sense to
   '/ try to do any real work with target device.
   '/ </summary>
   '/ <param name="dwIpAddr"></param>
   '/ <returns></returns>
   ' Link established.
   Public Function OnLogIpAddr(ByVal dwIpAddr As Integer) As Integer _
      Implements IDccManSink.OnLogIpAddr
      If Not m_Connected Then ' Notify only if not connected.
         Me.itReason = INVOKE_CONNECT.START
         Me.m_ctlTarget.Invoke(Me.m_deleCallback)
         m_Connected = True
      End If
      Return 0
   End Function 'OnLogIpAddr



   '/ <summary>
   '/ OnLogDisconnection - Connection ended.
   '/ </summary>
   '/ <returns></returns>
   Public Function OnLogDisconnection() As Integer _
      Implements IDccManSink.OnLogDisconnection
      If m_Connected Then ' Notify only if connected.
         Me.itReason = INVOKE_CONNECT.STOP
         Me.m_ctlTarget.Invoke(Me.m_deleCallback)
         m_Connected = False
      End If

      Return 0
   End Function 'OnLogDisconnection


   Public Function OnLogListen() As Integer _
      Implements IDccManSink.OnLogListen
      Return 0
   End Function 'OnLogListen

   Public Function OnLogTerminated() As Integer _
      Implements IDccManSink.OnLogTerminated
      Return 0
   End Function 'OnLogTerminated

   Public Function OnLogInactive() As Integer _
      Implements IDccManSink.OnLogInactive
      Return 0
   End Function 'OnLogInactive

   Public Function OnLogError() As Integer _
      Implements IDccManSink.OnLogError
      Return 0
   End Function 'OnLogError

   End Class ' RapiConnectDetect

   '/ <summary>
   '/ IDccMan - interface of COM component provided by RAPI.
   '/ </summary>
   <Guid("a7b88841-a812-11cf-8011-00a0c90a8f78"), _
      InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
   Public Interface IDccMan
      ' RAPI notification interface
      Sub Advise(ByVal pDccSink As IDccManSink, ByRef pdwContext As Integer)
      Sub Unadvise(ByVal dwContext As Integer)
      Sub ShowCommSettings()
      Sub AutoconnectEnable()
      Sub AutoconnectDisable()
      Sub ConnectNow()
      Sub DisconnectNow()
      Sub SetIconDataTransferring()
      Sub SetIconNoDataTransferring()
      Sub SetIconError()
   End Interface 'IDccMan

   '/ <summary>
   '/ IDccManSink - interface we implement to grab notifications
   '/ </summary>
   <InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> _
   Public Interface IDccManSink
      <PreserveSig()> _
      Function OnLogIpAddr(ByVal dwIpAddr As Integer) As Integer
      <PreserveSig()> _
      Function OnLogTerminated() As Integer
      <PreserveSig()> _
      Function OnLogActive() As Integer
      <PreserveSig()> _
      Function OnLogInactive() As Integer
      <PreserveSig()> _
      Function OnLogAnswered() As Integer
      <PreserveSig()> _
      Function OnLogListen() As Integer
      <PreserveSig()> _
      Function OnLogDisconnection() As Integer
      <PreserveSig()> _
      Function OnLogError() As Integer
   End Interface 'IDccManSink

End Namespace 'FindPrograms 
