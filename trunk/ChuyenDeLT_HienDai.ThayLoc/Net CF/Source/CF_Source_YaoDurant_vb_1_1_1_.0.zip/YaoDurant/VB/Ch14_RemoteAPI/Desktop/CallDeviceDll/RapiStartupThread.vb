' RapiStartupThread.vb - Creates a background thread
' for the purpose of starting RAPI.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System
Imports System.Threading
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports System.Diagnostics
Imports YaoDurant.Win32.Rapi


Namespace CallDeviceDll
    _
   ' Table of reasons that WorkerThread calls into the
   ' user-interface thread.
   Public Enum INVOKE_STARTUP
      STARTUP_SUCCESS
      STARTUP_FAILED
      STATUS_MESSAGE
   End Enum 'INVOKE_STARTUP
    _

   '/ <summary>
   '/ StartupThread - Wrapper class that spins a thread
   '/ to initialize RAPI. Calls a delegate to report status.
   '/ </summary>
   Public Class StartupThread
      Public strBuffer As String ' Inter-thread buffer
      Public itReason As INVOKE_STARTUP ' Inter-thread reason
      Private m_thrd As Thread = Nothing ' The contained thread
      Private m_ctlInvokeTarget As Control ' Inter-thread control
      Private m_deleCallback As EventHandler ' Inter-thread delegate
      Private m_bContinue As Boolean ' Continue flag.

      Public Property bThreadContinue() As Boolean ' Continue property.
         Get
            Return m_bContinue
         End Get
         Set(ByVal Value As Boolean)
            m_bContinue = Value
         End Set
      End Property

      '/ <summary>
      '/ StartupThread - Constructor.
      '/ </summary>
      '/ <param name="ctl">Owner control</param>
      '/ <param name="dele">Delegate to invoke</param>
      Public Sub New(ByVal ctl As Control, ByVal dele As EventHandler)
         bThreadContinue = True
         m_ctlInvokeTarget = ctl ' Who to call.
         m_deleCallback = dele ' How to call.
      End Sub 'New


      '/ <summary>
      '/ Run - Init function for startup thread.
      '/ </summary>
      '/ <returns></returns>
      Public Function Run() As Boolean
         Dim ts As ThreadStart = Nothing
         ts = New ThreadStart(AddressOf ThreadMainStartup)
         If ts Is Nothing Then
            Return False
         End If
         m_thrd = New Thread(ts)
         m_thrd.Start()
         Return True
      End Function 'Run


      '/ <summary>
      '/ ThreadMainStartup - Start RAPI connection.
      '/ </summary>
      Private Sub ThreadMainStartup()
         ' Allocate structure for call to CeRapiInitEx
         Dim ri As New Rapi.RAPIINIT
         ri.cbSize = Marshal.SizeOf(ri)

         ' Call init function
         Dim hr As Integer = Rapi.CeRapiInitEx(ri)

         ' Wrap event handle in corresponding .NET object
         Dim mrev As New ManualResetEvent(False)
         mrev.Handle = ri.heRapiInit

         ' Wait five seconds, then fail.
         If mrev.WaitOne(5000, False) And ri.hrRapiInit = Rapi.S_OK Then
            ' Notify caller that connection established.
            itReason = INVOKE_STARTUP.STARTUP_SUCCESS
            m_ctlInvokeTarget.Invoke(m_deleCallback)
         Else
            ' On failure, disconnect from RAPI.
            Rapi.CeRapiUninit()

            strBuffer = "Timeout - no device present."
            itReason = INVOKE_STARTUP.STATUS_MESSAGE
            m_ctlInvokeTarget.Invoke(m_deleCallback)

            ' Notify caller that connection failed.
            itReason = INVOKE_STARTUP.STARTUP_FAILED
            m_ctlInvokeTarget.Invoke(m_deleCallback)
         End If

         ' Trigger that thread has ended.
         m_thrd = Nothing
      End Sub 'ThreadMainStartup
   End Class 'StartupThread
End Namespace 'CallDeviceDll