' MainForm.vb - main user-interface for RegShowStartup program
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Windows.Forms
Imports System.Threading
Imports YaoDurant.Win32.Rapi

Namespace RegShowStartup

Public Class FormMain
    Inherits System.Windows.Forms.Form

   Public m_strAppName As String = "RegShowStartup"

   ' Startup thread definitions
   Private m_thrdStartup As StartupThread = Nothing
   Private m_deleStartup As EventHandler
   Private m_bRapiConnected As Boolean = False

   ' Enumeration thread definitions
   Dim m_thrdRapiRegEnum As RapiEnumRegisTryThread = Nothing
   Private m_deleRegEnum As EventHandler


#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

   End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents cmdConnect As System.Windows.Forms.Button
   Friend WithEvents cmdDisconnect As System.Windows.Forms.Button
   Friend WithEvents cmdFetch As System.Windows.Forms.Button
   Friend WithEvents cmdStop As System.Windows.Forms.Button
   Friend WithEvents cmdAbout As System.Windows.Forms.Button
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents cboList As System.Windows.Forms.ComboBox
   Friend WithEvents lboxStartupItems As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.cmdConnect = New System.Windows.Forms.Button
Me.cmdDisconnect = New System.Windows.Forms.Button
Me.cmdFetch = New System.Windows.Forms.Button
Me.cmdStop = New System.Windows.Forms.Button
Me.cmdAbout = New System.Windows.Forms.Button
Me.Label1 = New System.Windows.Forms.Label
Me.cboList = New System.Windows.Forms.ComboBox
Me.lboxStartupItems = New System.Windows.Forms.ListBox
Me.SuspendLayout()
'
'cmdConnect
'
Me.cmdConnect.Location = New System.Drawing.Point(312, 32)
Me.cmdConnect.Name = "cmdConnect"
Me.cmdConnect.Size = New System.Drawing.Size(88, 24)
Me.cmdConnect.TabIndex = 2
Me.cmdConnect.Text = "Connect"
'
'cmdDisconnect
'
Me.cmdDisconnect.Location = New System.Drawing.Point(312, 80)
Me.cmdDisconnect.Name = "cmdDisconnect"
Me.cmdDisconnect.Size = New System.Drawing.Size(88, 24)
Me.cmdDisconnect.TabIndex = 3
Me.cmdDisconnect.Text = "Disconnect"
'
'cmdFetch
'
Me.cmdFetch.Location = New System.Drawing.Point(312, 128)
Me.cmdFetch.Name = "cmdFetch"
Me.cmdFetch.Size = New System.Drawing.Size(88, 24)
Me.cmdFetch.TabIndex = 4
Me.cmdFetch.Text = "Fetch"
'
'cmdStop
'
Me.cmdStop.Location = New System.Drawing.Point(312, 176)
Me.cmdStop.Name = "cmdStop"
Me.cmdStop.Size = New System.Drawing.Size(88, 24)
Me.cmdStop.TabIndex = 5
Me.cmdStop.Text = "Stop"
'
'cmdAbout
'
Me.cmdAbout.Location = New System.Drawing.Point(312, 224)
Me.cmdAbout.Name = "cmdAbout"
Me.cmdAbout.Size = New System.Drawing.Size(88, 24)
Me.cmdAbout.TabIndex = 6
Me.cmdAbout.Text = "About"
'
'Label1
'
Me.Label1.Location = New System.Drawing.Point(8, 16)
Me.Label1.Name = "Label1"
Me.Label1.Size = New System.Drawing.Size(100, 16)
Me.Label1.TabIndex = 5
Me.Label1.Text = "Select Startup List:"
'
'cboList
'
Me.cboList.Items.AddRange(New Object() {"Startup Programs", "Startup DLLs"})
Me.cboList.Location = New System.Drawing.Point(120, 16)
Me.cboList.Name = "cboList"
Me.cboList.Size = New System.Drawing.Size(168, 21)
Me.cboList.TabIndex = 1
'
'lboxStartupItems
'
Me.lboxStartupItems.Location = New System.Drawing.Point(16, 56)
Me.lboxStartupItems.Name = "lboxStartupItems"
Me.lboxStartupItems.Size = New System.Drawing.Size(272, 212)
Me.lboxStartupItems.TabIndex = 7
'
'FormMain
'
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.ClientSize = New System.Drawing.Size(424, 276)
Me.Controls.Add(Me.lboxStartupItems)
Me.Controls.Add(Me.cboList)
Me.Controls.Add(Me.Label1)
Me.Controls.Add(Me.cmdAbout)
Me.Controls.Add(Me.cmdStop)
Me.Controls.Add(Me.cmdFetch)
Me.Controls.Add(Me.cmdDisconnect)
Me.Controls.Add(Me.cmdConnect)
Me.Name = "FormMain"
Me.Text = "RAPI - RegShowStartup"
Me.ResumeLayout(False)

    End Sub

#End Region

   Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
         ' Init user-interface objects.
         cmdDisconnect.Enabled = False
         cmdFetch.Enabled = False
         cmdConnect.Enabled = True
         cmdStop.Enabled = False

         ' Startup thread setup details
         m_deleStartup = New EventHandler(AddressOf StartupCallback)

         ' Enum thread setup details
         m_deleRegEnum = New EventHandler(AddressOf EnumRegCallback)

   End Sub

   Private Sub FormMain_Closed(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Closed
         ' If threads are running, trigger shutdown.
         If (Not (m_thrdStartup Is Nothing)) Then
            Me.m_thrdStartup.bThreadContinue = False
         End If
         If (Not (Me.m_thrdRapiRegEnum Is Nothing)) Then
            Me.m_thrdRapiRegEnum.bThreadContinue = False
            While Not m_thrdRapiRegEnum.thrd Is Nothing
               Application.DoEvents()
            End While
         End If

         If (m_bRapiConnected) Then
            Rapi.CeRapiUninit()
            m_bRapiConnected = False
         End If

   End Sub

   Private Sub cmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConnect.Click
         ' Create thread to connect to RAPI.
         m_thrdStartup = New StartupThread(Me, m_deleStartup)
         If (Not m_thrdStartup.Run()) Then
            m_thrdStartup = Nothing
         End If

   End Sub

   Private Sub cmdDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDisconnect.Click
         If (m_bRapiConnected) Then
            Rapi.CeRapiUninit()
            m_bRapiConnected = False
         End If

         cmdDisconnect.Enabled = False
         cmdFetch.Enabled = False
         cmdConnect.Enabled = True

   End Sub

   Private Sub cmdFetch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFetch.Click
         If (cboList.SelectedIndex = -1) Then
            MessageBox.Show("Please select a startup item", _
               m_strAppName)
            Return
         End If

         ' Clear previous list.
         Me.lboxStartupItems.Items.Clear()

         Dim strSearch As String = String.Empty
         Dim bKeys As Boolean = False
         If (cboList.Text = "Startup Programs") Then
            strSearch = "Init"
            bKeys = False
         End If
         If (cboList.Text = "Startup DLLs") Then
            strSearch = "Drivers\BuiltIn"
            bKeys = True
         End If

         ' Create background thread object.
         m_thrdRapiRegEnum = _
            New RapiEnumRegistryThread( _
               Me, _
               Me.m_deleRegEnum, _
               bKeys, _
               Rapi.HKEY_LOCAL_MACHINE, _
               strSearch)
         If (m_thrdRapiRegEnum Is Nothing) Then
             MessageBox.Show("Cannot create thread", m_strAppName)
         End If

         ' Start search in background thread.
         If (Not m_thrdRapiRegEnum.Run()) Then
            MessageBox.Show("Cannot run thread", m_strAppName)
         Else
            ' Reset user-interface to prevent other searches,
            ' and to enable stopping current search.
            cmdFetch.Enabled = False
            cmdStop.Enabled = True
         End If

   End Sub

   Private Sub cmdStop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdStop.Click
         ' Stop search
         If (Not Me.m_thrdRapiRegEnum Is Nothing) Then
            Me.m_thrdRapiRegEnum.bThreadContinue = False
         End If

   End Sub

   Private Sub cmdAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAbout.Click
      MessageBox.Show("(c) Copyright 2002-2003 Paul Yao and David Durant\r\n\r\n" + _
         "RegShowStartup - RAPI Sample for the book\r\n" + _
         "Programming the .NET Compact Framework", m_strAppName)

   End Sub

      '/ <summary>
      '/ StartupCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub _
      StartupCallback(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim it As INVOKE_STARTUP = Me.m_thrdStartup.itReason
         Select Case it
            Case INVOKE_STARTUP.STARTUP_SUCCESS
               m_bRapiConnected = True
               cmdDisconnect.Enabled = True
               cmdFetch.Enabled = True
               cmdConnect.Enabled = False
            Case INVOKE_STARTUP.STARTUP_FAILED
               MessageBox.Show("Cannot connect to device", _
                  m_strAppName)
         End Select
      End Sub ' StartupCallback

      '/ <summary>
      '/ EnumRegCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub _
      EnumRegCallback(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim it As INVOKE_ENUMREG = Me.m_thrdRapiRegEnum.itReason
         Dim str As String = m_thrdRapiRegEnum.strBuffer
         Select Case it
            Case INVOKE_ENUMREG.ENUMREG_NEWKEY
               lboxStartupItems.Items.Add(str)
            Case INVOKE_ENUMREG.ENUMREG_NEWVALUE
               lboxStartupItems.Items.Add(str)
            Case INVOKE_ENUMREG.ENUMREG_ENDED
               cmdFetch.Enabled = True
               cmdStop.Enabled = False
            Case INVOKE_ENUMREG.STATUS_MESSAGE
               MessageBox.Show(str, m_strAppName)
         End Select
      End Sub ' EnumRegCallback

End Class
End Namespace
