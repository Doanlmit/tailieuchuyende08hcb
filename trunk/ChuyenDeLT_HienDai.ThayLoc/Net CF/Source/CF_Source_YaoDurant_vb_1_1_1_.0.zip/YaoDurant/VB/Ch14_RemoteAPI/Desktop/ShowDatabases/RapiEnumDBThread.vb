' RapiEnumDBThread.vb - Creates a background 
' thread to names of database volumes and names of databases
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System
Imports System.Threading
Imports System.Collections
Imports System.Windows.Forms
Imports System.Diagnostics
Imports System.Runtime.InteropServices
Imports YaoDurant.Win32.Rapi


Namespace ShowDatabases
    _
   ' Reasons our thread invokes user-interface thread.
   Public Enum INVOKE_ENUMDB
      ENUMDB_NEWVOLUME
      ENUMDB_NEWDATABASE
      ENUMDB_COMPLETE
      STATUS_MESSAGE
   End Enum 'INVOKE_ENUMDB
    _

   '/ <summary>
   '/ Summary description for RapiEnumDBThread.
   '/ </summary>
   Public Class RapiEnumDBThread
      Public strBuffer As String ' Inter-thread buffer
      Public itReason As INVOKE_ENUMDB ' Inter-thread reason
      Private m_thrd As Thread = Nothing ' The contained thread
      Private m_ctlInvokeTarget As Control ' Inter-thread control
      Private m_deleCallback As EventHandler ' Inter-thread delegate
      Private m_bContinue As Boolean ' Continue flag.
      Private m_bVolume As Boolean ' Enum volumes or databases?

      Public Property bThreadContinue() As Boolean ' Continue property.
         Get
            Return m_bContinue
         End Get
         Set(ByVal Value As Boolean)
            m_bContinue = value
         End Set
      End Property

      Public Sub New(ByVal ctl As Control, ByVal dele As EventHandler, ByVal bVolume As Boolean)
         m_bContinue = True
         m_ctlInvokeTarget = ctl ' Who to call.
         m_deleCallback = dele ' How to call.
         m_bVolume = bVolume
      End Sub 'New

      '/ <summary>
      '/ Run - Init function for enum thread.
      '/ </summary>
      '/ <param name="bSubDirs"></param>
      '/ <returns></returns>
      Public Function Run() As Boolean
         Dim ts As ThreadStart = Nothing
         ts = New ThreadStart(AddressOf ThreadMainEnumDB)
         If ts Is Nothing Then
            Return False
         End If
         m_thrd = New Thread(ts)
         m_thrd.Start()
         Return True
      End Function 'Run


      Private Sub ThreadMainEnumDB()
         If m_bVolume Then ' Enumerate volumes.
            Dim guid As New Guid("ffffffffffffffffffffffffffffffff")
            Dim cch As Integer = 32
            Dim str = New [String](ControlChars.NullChar, cch)
            While Rapi.CeEnumDBVolumes(guid, str, cch) = Rapi.RAPI_TRUE And m_bContinue
               strBuffer = str
               itReason = INVOKE_ENUMDB.ENUMDB_NEWVOLUME
               m_ctlInvokeTarget.Invoke(m_deleCallback)
            End While
         ' Enumerate databases.
         Else
            Dim cRecords As Short = 0
            Dim pfdbAll As IntPtr = IntPtr.Zero
            Rapi.CeFindAllDatabases(0, Rapi.FAD.FAD_NAME Or Rapi.FAD.FAD_NUM_RECORDS, cRecords, pfdbAll)

            Dim pfdb As IntPtr = pfdbAll
            While cRecords > 0
               ' Set pointer to next record.
               Dim dbfd As Rapi.CEDB_FIND_DATA = _
                  CType( _
                     Marshal.PtrToStructure( _
                        pfdb, _
                        GetType(Rapi.CEDB_FIND_DATA)), _
                     Rapi.CEDB_FIND_DATA)

               ' Post name to listbox.
               strBuffer = dbfd.DbInfo.szDbaseName + " (" + dbfd.DbInfo.wNumRecords.ToString() + " records)"
               itReason = INVOKE_ENUMDB.ENUMDB_NEWDATABASE
               m_ctlInvokeTarget.Invoke(m_deleCallback)

               ' Get ready for next loop.
               pfdb = IntPtr.op_Explicit(pfdb.ToInt32() + _
               Marshal.SizeOf(dbfd))
               cRecords -= 1
            End While ' while
            ' Free memory returned by CeFindAllDatabases.
            Rapi.CeRapiFreeBuffer(pfdbAll)
         End If ' if
         ' Notify main thread that we are done.
         itReason = INVOKE_ENUMDB.ENUMDB_COMPLETE
         m_ctlInvokeTarget.Invoke(m_deleCallback)

         ' Mark thread as done.
         m_thrd = Nothing
      End Sub 'ThreadMainEnumDB
   End Class 'RapiEnumDBThread 
End Namespace 'ShowDatabases ' RapiEnumDBThread
' ShowDatabases