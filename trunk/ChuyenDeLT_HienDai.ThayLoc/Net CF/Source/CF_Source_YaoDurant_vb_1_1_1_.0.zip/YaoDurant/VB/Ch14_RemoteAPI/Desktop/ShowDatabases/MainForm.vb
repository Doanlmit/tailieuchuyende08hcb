' FormMain.vb - Main form for ShowDatabases sample.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports YaoDurant.Win32.Rapi

Namespace ShowDatabases

Public Class FormMain
   Inherits System.Windows.Forms.Form

   Private m_strAppName As String = "ShowDatabases"

   ' Startup thread definitions
   Private m_thrdStartup As StartupThread = Nothing
   Private m_deleStartup As EventHandler
   Private m_bRapiConnected As Boolean = False

   ' Find Database thread definitions
   Private m_thrdFindDB As RapiEnumDBThread = Nothing
   Private m_deleFindDB As EventHandler

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents lboxDatabases As System.Windows.Forms.ListBox
   Friend WithEvents cmdConnect As System.Windows.Forms.Button
   Friend WithEvents cmdDisconnect As System.Windows.Forms.Button
   Friend WithEvents cmdFindVolumes As System.Windows.Forms.Button
   Friend WithEvents cmdFindDatabases As System.Windows.Forms.Button
   Friend WithEvents cmdAbout As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.lboxDatabases = New System.Windows.Forms.ListBox
Me.cmdConnect = New System.Windows.Forms.Button
Me.cmdDisconnect = New System.Windows.Forms.Button
Me.cmdFindVolumes = New System.Windows.Forms.Button
Me.cmdFindDatabases = New System.Windows.Forms.Button
Me.cmdAbout = New System.Windows.Forms.Button
Me.SuspendLayout()
'
'lboxDatabases
'
Me.lboxDatabases.Location = New System.Drawing.Point(16, 16)
Me.lboxDatabases.Name = "lboxDatabases"
Me.lboxDatabases.Size = New System.Drawing.Size(328, 199)
Me.lboxDatabases.TabIndex = 0
'
'cmdConnect
'
Me.cmdConnect.Location = New System.Drawing.Point(360, 16)
Me.cmdConnect.Name = "cmdConnect"
Me.cmdConnect.Size = New System.Drawing.Size(112, 23)
Me.cmdConnect.TabIndex = 2
Me.cmdConnect.Text = "Connect"
'
'cmdDisconnect
'
Me.cmdDisconnect.Location = New System.Drawing.Point(360, 56)
Me.cmdDisconnect.Name = "cmdDisconnect"
Me.cmdDisconnect.Size = New System.Drawing.Size(112, 23)
Me.cmdDisconnect.TabIndex = 3
Me.cmdDisconnect.Text = "Disconnect"
'
'cmdFindVolumes
'
Me.cmdFindVolumes.Location = New System.Drawing.Point(360, 96)
Me.cmdFindVolumes.Name = "cmdFindVolumes"
Me.cmdFindVolumes.Size = New System.Drawing.Size(112, 23)
Me.cmdFindVolumes.TabIndex = 4
Me.cmdFindVolumes.Text = "Find Volumes"
'
'cmdFindDatabases
'
Me.cmdFindDatabases.Location = New System.Drawing.Point(360, 136)
Me.cmdFindDatabases.Name = "cmdFindDatabases"
Me.cmdFindDatabases.Size = New System.Drawing.Size(112, 23)
Me.cmdFindDatabases.TabIndex = 5
Me.cmdFindDatabases.Text = "Find Databases"
'
'cmdAbout
'
Me.cmdAbout.Location = New System.Drawing.Point(360, 176)
Me.cmdAbout.Name = "cmdAbout"
Me.cmdAbout.Size = New System.Drawing.Size(112, 23)
Me.cmdAbout.TabIndex = 6
Me.cmdAbout.Text = "About"
'
'FormMain
'
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.ClientSize = New System.Drawing.Size(488, 230)
Me.Controls.Add(Me.cmdAbout)
Me.Controls.Add(Me.cmdFindDatabases)
Me.Controls.Add(Me.cmdFindVolumes)
Me.Controls.Add(Me.cmdDisconnect)
Me.Controls.Add(Me.cmdConnect)
Me.Controls.Add(Me.lboxDatabases)
Me.Name = "FormMain"
Me.Text = "RAPI - ShowDatabases"
Me.ResumeLayout(False)

    End Sub

#End Region

      Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
         EnableButtons(False)

         ' Setup inter-thread delegates.
         m_deleStartup = New EventHandler(AddressOf Me.StartupCallback)
         m_deleFindDB = New EventHandler(AddressOf Me.FindDBCallback)

      End Sub

      Private Sub FormMain_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
         ' If threads are running, trigger shutdown.
         If Not (Me.m_thrdStartup Is Nothing) Then
            Me.m_thrdStartup.bThreadContinue = False
         End If
         If Not (Me.m_thrdFindDB Is Nothing) Then
            Me.m_thrdFindDB.bThreadContinue = False
         End If
         If m_bRapiConnected Then
            Rapi.CeRapiUninit()
            m_bRapiConnected = False
         End If
      End Sub 'FormMain_Closed

      Private Sub cmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConnect.Click
         ' Create thread to connect to RAPI.
         m_thrdStartup = New StartupThread(Me, m_deleStartup)
         If Not m_thrdStartup.Run() Then
            m_thrdStartup = Nothing
         End If
         ' Clear out previous contents of listbox.
         Me.lboxDatabases.Items.Clear()
      End Sub

      Private Sub cmdDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDisconnect.Click
         ' Disconnect from RAPI.
         Rapi.CeRapiUninit()

         EnableButtons(False)
         m_bRapiConnected = False

      End Sub

      Private Sub cmdFindVolumes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFindVolumes.Click
         ' Disable Find buttons.
         Me.cmdFindDatabases.Enabled = False
         Me.cmdFindVolumes.Enabled = False

         ' Clear out previous contents of file listbox.
         Me.lboxDatabases.Items.Clear()

         m_thrdFindDB = New RapiEnumDBThread(Me, m_deleFindDB, True)
         If Not m_thrdFindDB.Run() Then
            m_thrdFindDB = Nothing
         End If

      End Sub

      Private Sub cmdFindDatabases_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFindDatabases.Click
         ' Disable Find buttons.
         Me.cmdFindDatabases.Enabled = False
         Me.cmdFindVolumes.Enabled = False

         ' Clear out previous contents of file listbox.
         Me.lboxDatabases.Items.Clear()

         m_thrdFindDB = New RapiEnumDBThread(Me, m_deleFindDB, False)
         If Not m_thrdFindDB.Run() Then
            m_thrdFindDB = Nothing
         End If

      End Sub

      Private Sub cmdAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAbout.Click
         MessageBox.Show(Me, "(c) Copyright 2002-2003 " + _
            "Paul Yao and David Durant" + _
            ControlChars.Lf + _
            ControlChars.Lf + _
            "ShowDatabases - RAPI sample for" + _
            ControlChars.Lf + _
            "Programming the .NET Compact Framework with C#," + _
            ControlChars.Lf + _
            "& Programming the .NET Compact Framework with VB.", _
            m_strAppName)

      End Sub

      Private Sub EnableButtons(ByVal bConnected As Boolean)
         Me.cmdConnect.Enabled = Not bConnected
         Me.cmdDisconnect.Enabled = bConnected
         Me.cmdFindDatabases.Enabled = bConnected
         Me.cmdFindVolumes.Enabled = bConnected
      End Sub 'EnableButtons


      '/ <summary>
      '/ StartupCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub StartupCallback(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim it As INVOKE_STARTUP = Me.m_thrdStartup.itReason
         Select Case it
            Case INVOKE_STARTUP.STARTUP_SUCCESS
               m_bRapiConnected = True
               EnableButtons(True)
            Case INVOKE_STARTUP.STARTUP_FAILED
               EnableButtons(False)
            Case INVOKE_STARTUP.STATUS_MESSAGE
               MessageBox.Show(m_thrdStartup.strBuffer, m_strAppName)
         End Select
      End Sub 'StartupCallback


      '/ <summary>
      '/ FindDBCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub FindDBCallback(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim it As INVOKE_ENUMDB = Me.m_thrdFindDB.itReason
         Dim strIn As String = m_thrdFindDB.strBuffer
         Select Case it
            Case INVOKE_ENUMDB.ENUMDB_NEWVOLUME
               Me.lboxDatabases.Items.Add(strIn)
            Case INVOKE_ENUMDB.ENUMDB_NEWDATABASE
               Me.lboxDatabases.Items.Add(strIn)
            Case INVOKE_ENUMDB.ENUMDB_COMPLETE
               ' Enable Find buttons.
               Me.cmdFindDatabases.Enabled = True
               Me.cmdFindVolumes.Enabled = True
            Case INVOKE_ENUMDB.STATUS_MESSAGE
               MessageBox.Show(strIn, m_strAppName)
         End Select
      End Sub 'FindDBCallback

End Class ' FormMain
End Namespace ' ShowDatabases
