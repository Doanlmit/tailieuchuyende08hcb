' FormMain.vb - main user-interface for this program
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System.Runtime.InteropServices
Imports YaoDurant.Win32.Rapi

Namespace CallDeviceDll

Public Class FormMain
    Inherits System.Windows.Forms.Form

      ' Startup thread definitions
      Private m_thrdStartup As StartupThread = Nothing
      Private m_deleStartup As EventHandler
      Private m_bRapiConnected As Boolean = False

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents textInput As System.Windows.Forms.TextBox
   Friend WithEvents cmdConnect As System.Windows.Forms.Button
   Friend WithEvents cmdInvoke As System.Windows.Forms.Button
   Friend WithEvents cmdDisconnect As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.textInput = New System.Windows.Forms.TextBox
Me.cmdConnect = New System.Windows.Forms.Button
Me.cmdInvoke = New System.Windows.Forms.Button
Me.cmdDisconnect = New System.Windows.Forms.Button
Me.SuspendLayout()
'
'textInput
'
Me.textInput.Location = New System.Drawing.Point(24, 48)
Me.textInput.Name = "textInput"
Me.textInput.Size = New System.Drawing.Size(312, 20)
Me.textInput.TabIndex = 0
Me.textInput.Text = ""
'
'cmdConnect
'
Me.cmdConnect.Location = New System.Drawing.Point(24, 88)
Me.cmdConnect.Name = "cmdConnect"
Me.cmdConnect.TabIndex = 1
Me.cmdConnect.Text = "Connect"
'
'cmdInvoke
'
Me.cmdInvoke.Location = New System.Drawing.Point(136, 88)
Me.cmdInvoke.Name = "cmdInvoke"
Me.cmdInvoke.TabIndex = 2
Me.cmdInvoke.Text = "Invoke"
'
'cmdDisconnect
'
Me.cmdDisconnect.Location = New System.Drawing.Point(256, 88)
Me.cmdDisconnect.Name = "cmdDisconnect"
Me.cmdDisconnect.TabIndex = 3
Me.cmdDisconnect.Text = "Disconnect"
'
'FormMain
'
Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
Me.ClientSize = New System.Drawing.Size(352, 142)
Me.Controls.Add(Me.cmdDisconnect)
Me.Controls.Add(Me.cmdInvoke)
Me.Controls.Add(Me.cmdConnect)
Me.Controls.Add(Me.textInput)
Me.Name = "FormMain"
Me.Text = "Call Device DLL"
Me.ResumeLayout(False)

    End Sub

#End Region

   Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
         cmdInvoke.Enabled = False
         cmdDisconnect.Enabled = False
         textInput.Enabled = False

         ' Setup inter-thread delegates.
         m_deleStartup = New EventHandler(AddressOf StartupCallback)
   End Sub ' FormMain_Load

   Private Sub cmdConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdConnect.Click
         ' Create thread to connect to RAPI.
         m_thrdStartup = New StartupThread(Me, m_deleStartup)
         If (Not m_thrdStartup.Run()) Then
            m_thrdStartup = Nothing
         End If
   End Sub ' cmdConnect_Click

   Private Sub cmdInvoke_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdInvoke.Click
         ' Set up data to send to DLL
         Dim strHello As String = textInput.Text
         Dim cbInput As Integer = (strHello.Length + 1) * 2
         Dim cbOutput As Integer = 0
         Dim ipInput As IntPtr = Marshal.StringToHGlobalUni(strHello)
         Dim ipOutput As IntPtr = IntPtr.Zero

         Try
            ' Call device-side DLL
            Dim strDll As String
            strDll = "\windows\SimpleBlockModeInvoke.dll"
            Dim hr As Integer
            hr = Rapi.CeRapiInvoke(strDll, _
               "UpperCaseInvoke", _
               cbInput, _
               ipInput, _
                cbOutput, _
                ipOutput, _
               0, 0)

            If (hr = Rapi.S_OK) Then
               ' Convert return value to a string.
               Dim strOutput As String = Marshal.PtrToStringUni(ipOutput, cbOutput)

               ' Free memory returned from call to CeRapiInvoke.
               Marshal.FreeHGlobal(ipOutput)

               ' Display resulting string.
               MessageBox.Show(strOutput, "CallDeviceDll")
            Else
               Throw (New System.Exception)
            End If
         Catch
            ' In case of error, free memory we allocated.
            Marshal.FreeHGlobal(ipInput)

            MessageBox.Show("Error in calling device DLL. " + _
               "Download SimpleBlockModeInvoke.dll " + _
               "to the device. Then try again.", _
               "CallDeviceDll")
         End Try

   End Sub ' cmdInvoke_Click

   Private Sub cmdDisconnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDisconnect.Click
         ' Disconnect from RAPI.
         Rapi.CeRapiUninit()

         ' Change UI.
         cmdInvoke.Enabled = False
         cmdDisconnect.Enabled = False
         cmdConnect.Enabled = True
         textInput.Text = String.Empty
         textInput.Enabled = False

         ' Set flag that we are disconnected
         m_bRapiConnected = False

   End Sub ' cmdDisconnect_Click

      '/ <summary>
      '/ StartupCallback - Interthread delegate.
      '/ </summary>
      '/ <param name="sender">unused</param>
      '/ <param name="e">unused</param>
      Private Sub _
      StartupCallback(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim it As INVOKE_STARTUP = Me.m_thrdStartup.itReason
         Select Case it
            Case INVOKE_STARTUP.STARTUP_SUCCESS
               m_bRapiConnected = True
               cmdInvoke.Enabled = True
               cmdDisconnect.Enabled = True
               cmdConnect.Enabled = False
               textInput.Enabled = True
            Case INVOKE_STARTUP.STARTUP_FAILED
               cmdInvoke.Enabled = False
               cmdDisconnect.Enabled = False
               cmdConnect.Enabled = True
               textInput.Enabled = False
         End Select
      End Sub ' StartupCallback

      Private Sub _
      textInput_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs)
         Dim bHasText As Boolean = (textInput.Text.Length > 0)
         cmdInvoke.Enabled = bHasText

      End Sub ' textInput_TextChanged

End Class ' FormMain
End Namespace ' CallDeviceDll
