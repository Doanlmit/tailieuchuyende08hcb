' Program: RegShowStartup.exe
'
' RapiEnumRegistryThread.vb - Create a thread to 
' enumerate both registry keys and registry values.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Threading
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports YaoDurant.Win32.Rapi

Namespace RegShowStartup
   ' Reasons our thread invokes user-interface thread.
   Public Enum INVOKE_ENUMREG
      ENUMREG_NEWKEY
      ENUMREG_NEWVALUE
      ENUMREG_ENDED
      STATUS_MESSAGE
   End Enum

  '/ <summary>
   '/ RapiConnection - Manages RAPI Remote API connections
   '/ </summary>
Public Class RapiEnumRegistryThread
      Public strBuffer As String         ' Inter-thread buffer
      Public itReason As INVOKE_ENUMREG  ' Inter-thread reason

      ' Public thread to allow monitoring by UI thread.
      Public thrd As Thread = Nothing        ' The contained thread
      Private m_ctlInvokeTarget As Control   ' Inter-thread control
      Private m_deleCallback As EventHandler ' Inter-thread delegate

      ' Private data.
      Private m_bContinue As Boolean    ' Continue flag.
      Private m_bKeys As Boolean        ' Enumerate keys or values
      Private m_hkeyRoot As IntPtr      ' Root enumeration key.
      Private m_strRegNode As String    ' Root enumeration node.

      Public Property bThreadContinue() As Boolean ' Continue property.
         Get
             Return m_bContinue
             End Get
         Set(ByVal Value As Boolean)
             m_bContinue = Value
             End Set
       End Property


      Sub New(ByVal ctl As Control, ByVal dele As EventHandler, _
         ByVal bKeys As Boolean, ByVal hkeyRoot As IntPtr, _
         ByVal strRegNode As String)
         ' Make private copies of init data.
         m_ctlInvokeTarget = ctl
         m_deleCallback = dele
         m_bKeys = bKeys
         m_hkeyRoot = hkeyRoot
         m_strRegNode = strRegNode

         bThreadContinue = True
      End Sub

      Public Function Run() As Boolean
         Dim ts As ThreadStart = Nothing
         ts = New ThreadStart(AddressOf ThreadMainEnumReg)
         If ts Is Nothing Then
            Return False
         End If

         thrd = New Thread(ts)
         thrd.Start()

         Return True
      End Function


      '/ <summary>
      '/ ThreadMainEnumReg - Enumerate registry values.
      '/ </summary>
      Private Sub ThreadMainEnumReg()
         ' Open registry key.
         Dim hkeySearchNode As IntPtr = IntPtr.Zero
         Dim iResult As Integer
         iResult = Rapi.CeRegOpenKeyEx(m_hkeyRoot, _
            Me.m_strRegNode, 0, 0, hkeySearchNode)
         If iResult <> Rapi.ERROR_SUCCESS And m_bContinue Then
            ' Send error message.
            itReason = INVOKE_ENUMREG.STATUS_MESSAGE
            strBuffer = "Error accessing registry key"
            Me.m_ctlInvokeTarget.Invoke(m_deleCallback)

            ' Trigger end of enumeration.
            itReason = INVOKE_ENUMREG.ENUMREG_ENDED
            Me.m_ctlInvokeTarget.Invoke(m_deleCallback)

            ' Trigger that shutdown is complete.
            thrd = Nothing
            Return
         End If

         ' Keys or values?
         If Me.m_bKeys Then
            Dim iIndex As Integer = 0
            While iResult = Rapi.ERROR_SUCCESS And m_bContinue
               Dim strKeyName As String = New String(ChrW(0), 32)
               Dim cbLength As Integer = 32
               iResult = Rapi.CeRegEnumKeyEx(hkeySearchNode, _
                  iIndex, strKeyName, cbLength, _
                  0, 0, 0, 0)
               iIndex = iIndex + 1
               If iResult = Rapi.ERROR_SUCCESS And m_bContinue Then
                  itReason = INVOKE_ENUMREG.ENUMREG_NEWKEY
                  strBuffer = strKeyName
                  Me.m_ctlInvokeTarget.Invoke(m_deleCallback)
               End If
            End While
         Else ' Enumerate values. Then 
            Dim iIndex As Integer
            iIndex = 0
            Do While iResult = Rapi.ERROR_SUCCESS And m_bContinue
               Dim cbName As Integer = 32
               Dim strName As String = New String(ChrW(0), 16)
               Dim iType As Rapi.REGTYPE = 0
               Dim cbLength As Integer = 0

               ' Enumerate key names only (not values)
               iResult = Rapi.CeRegEnumValue(hkeySearchNode, _
                  iIndex, strName, cbName, _
                  0, iType, 0, cbLength)

               If iResult = Rapi.ERROR_SUCCESS And m_bContinue Then
                  If iType = Rapi.REGTYPE.REG_SZ Then
                     Dim cbData As Integer = 32
                     Dim str As String = New String(ChrW(0), cbData)
                     Rapi.CeRegQueryValueEx(hkeySearchNode, _
                         strName, 0, iType, str, _
                          cbData)
                     Dim ach(1) As Char
                     ach(0) = ChrW(0)

                     strBuffer = strName.Trim(ach) + " = " + str.Trim(ach)

                  ElseIf iType = Rapi.REGTYPE.REG_BINARY Then
                     ' Fetch binary array of short values
                     Dim ach(1) As Char
                     ach(0) = ChrW(0)

                     strBuffer = strName.Trim(ach) + " = "

                     ' Allocate buffer of short values.
                     Dim sh As Short = 0
                     Dim iptr As IntPtr
                     Dim cbSizeOfShort As Integer = Marshal.SizeOf(sh)
                     Dim cbData As Integer = cbSizeOfShort * 5
                     iptr = Marshal.AllocCoTaskMem(cbData)

                     ' Fetch array of short values.
                     Rapi.CeRegQueryValueEx(hkeySearchNode, _
                        strName, 0, iType, iptr, _
                         cbData)

                     ' Copy array to managed array.
                     Dim cElements As Integer = cbData / cbSizeOfShort
                     Dim ash(cElements) As Short
                     Marshal.Copy(iptr, ash, 0, cElements)
                     Marshal.FreeCoTaskMem(iptr)

                     ' Add values to string for display.
                     For i As Integer = 0 To (cElements - 1)
                        strBuffer = strBuffer + ash(i).ToString("d") + " "
                     Next i
                  Else
                     strBuffer = strName + " not expected type"
                  End If
                  itReason = INVOKE_ENUMREG.ENUMREG_NEWVALUE
                  Me.m_ctlInvokeTarget.Invoke(m_deleCallback)
               End If
            iIndex = iIndex + 1
            Loop
         End If
 
         Rapi.CeRegCloseKey(hkeySearchNode)

         ' Trigger end of enumeration.
         itReason = INVOKE_ENUMREG.ENUMREG_ENDED
         Me.m_ctlInvokeTarget.Invoke(m_deleCallback)

         ' Trigger that shutdown is complete.
         thrd = Nothing
      End Sub

End Class
End Namespace
