' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Runtime.InteropServices

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents textPath As System.Windows.Forms.TextBox
      Friend WithEvents cmdStart As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.label1 = New System.Windows.Forms.Label
Me.textPath = New System.Windows.Forms.TextBox
Me.cmdStart = New System.Windows.Forms.Button
'
'label1
'
Me.label1.Location = New System.Drawing.Point(16, 24)
Me.label1.Text = "Program Path:"
'
'textPath
'
Me.textPath.Location = New System.Drawing.Point(16, 48)
Me.textPath.Size = New System.Drawing.Size(216, 22)
Me.textPath.Text = ""
'
'cmdStart
'
Me.cmdStart.Location = New System.Drawing.Point(56, 96)
Me.cmdStart.Size = New System.Drawing.Size(112, 24)
Me.cmdStart.Text = "Start Program"
'
'FormMain
'
Me.Controls.Add(Me.cmdStart)
Me.Controls.Add(Me.textPath)
Me.Controls.Add(Me.label1)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Start"

    End Sub

#End Region

      Public strAppName As String = "Start"

      <DllImport("coredll.dll")> _
      Public Shared Function _
      CreateProcess(ByVal pszImageName As String, _
         ByVal pszCmdLine As String, _
         ByVal Res1 As Integer, _
         ByVal Res2 As Integer, _
         ByVal Res3 As Integer, _
         ByVal fdwCreate As CREATE_FLAG, _
         ByVal Res4 As Integer, _
         ByVal Res5 As Integer, _
         ByVal Res6 As Integer, _
         ByRef pProcInfo As PROCESS_INFORMATION) As Integer
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function _
      CreateProcess(ByVal pszImageName As String, _
         ByVal pszEmptyPath As Integer, _
         ByVal Res1 As Integer, _
         ByVal Res2 As Integer, _
         ByVal Res3 As Integer, _
         ByVal fdwCreate As CREATE_FLAG, _
         ByVal Res4 As Integer, _
         ByVal Res5 As Integer, _
         ByVal Res6 As Integer, _
         ByRef pProcInfo As PROCESS_INFORMATION) As Integer
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function CloseHandle(ByVal hObject As IntPtr) As Integer
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Sub GetLastError()
      End Sub

      Public Structure PROCESS_INFORMATION
         Public hProcess As IntPtr
         Public hThread As IntPtr
         Public dwProcessId As Integer
         Public dwThreadId As Integer
      End Structure

      Public Enum CREATE_FLAG
         CREATE_SUSPENDED = 4
         CREATE_NEW_CONSOLE = &H10
      End Enum

   Private Sub cmdStart_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdStart.Click
      Dim strPath As String = textPath.Text
      Dim pi As PROCESS_INFORMATION = New PROCESS_INFORMATION
      Dim bOk As Integer
      bOk = CreateProcess(strPath, 0, 0, 0, 0, 0, 0, 0, 0, pi)
      If (bOk > 0) Then
         CloseHandle(pi.hProcess)
         CloseHandle(pi.hThread)
      Else
         MessageBox.Show("CreateProcess Failed", strAppName)
      End If

   End Sub

   Private Sub FormMain_GotFocus( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.GotFocus
      textPath.Focus()
   End Sub
End Class
