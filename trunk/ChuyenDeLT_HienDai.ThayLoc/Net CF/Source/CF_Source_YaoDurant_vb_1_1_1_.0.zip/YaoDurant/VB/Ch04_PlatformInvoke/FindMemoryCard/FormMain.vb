' FormMain.vb - Main form for FindMemoryCard sample.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Namespace FindMemoryCard


   Public Class frmMain
      Inherits System.Windows.Forms.Form
         Friend WithEvents cmdFindFirst As System.Windows.Forms.Button
      Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

      Public Sub New()
         MyBase.New()

         'This call is required by the Windows Form Designer.
         InitializeComponent()

         'Add any initialization after the InitializeComponent() call

      End Sub

      'Form overrides dispose to clean up the component list.
      Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
         MyBase.Dispose(disposing)
      End Sub

      'NOTE: The following procedure is required by the Windows Form Designer
      'It can be modified using the Windows Form Designer.  
      'Do not modify it using the code editor.
      Friend WithEvents cmdFindNext As System.Windows.Forms.Button
      Friend WithEvents cmdFindClose As System.Windows.Forms.Button
      Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.cmdFindFirst = New System.Windows.Forms.Button
Me.cmdFindNext = New System.Windows.Forms.Button
Me.cmdFindClose = New System.Windows.Forms.Button
'
'cmdFindFirst
'
Me.cmdFindFirst.Location = New System.Drawing.Point(32, 48)
Me.cmdFindFirst.Size = New System.Drawing.Size(176, 20)
Me.cmdFindFirst.Text = "FindFirstFlashCard()"
'
'cmdFindNext
'
Me.cmdFindNext.Location = New System.Drawing.Point(32, 104)
Me.cmdFindNext.Size = New System.Drawing.Size(176, 20)
Me.cmdFindNext.Text = "FindNextFlashCard()"
'
'cmdFindClose
'
Me.cmdFindClose.Location = New System.Drawing.Point(32, 160)
Me.cmdFindClose.Size = New System.Drawing.Size(176, 20)
Me.cmdFindClose.Text = "Call FindClose()"
'
'frmMain
'
Me.Controls.Add(Me.cmdFindClose)
Me.Controls.Add(Me.cmdFindNext)
Me.Controls.Add(Me.cmdFindFirst)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "FindMemoryCard"

      End Sub

#End Region

      Dim strAppName As String = "FindMemoryCard"

      Dim hffc As IntPtr = New IntPtr(EnumFlash.INVALID_HANDLE_VALUE)
      Dim wfd As EnumFlash.WIN32_FIND_DATA = New EnumFlash.WIN32_FIND_DATA


      Private Sub cmdFindFirst_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles cmdFindFirst.Click
         hffc = EnumFlash.FindFirstFlashCard(wfd)
         If hffc.ToInt32() = EnumFlash.INVALID_HANDLE_VALUE Then
            MessageBox.Show("Error in FindMemoryCard()", strAppName)
         Else
            MessageBox.Show(wfd.cFileName, strAppName)
         End If
      End Sub

      Private Sub cmdFindNext_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles cmdFindNext.Click
         If hffc.ToInt32() = EnumFlash.INVALID_HANDLE_VALUE Then
            MessageBox.Show("Must first call FindMemoryCard()", strAppName)
         End If
         If EnumFlash.FindNextFlashCard(hffc, wfd) Then
            MessageBox.Show(wfd.cFileName, strAppName)
         Else
            MessageBox.Show("No more flash cards available", strAppName)
         End If
      End Sub

      Private Sub cmdFindClose_Click(ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles cmdFindClose.Click
         If hffc.ToInt32() = EnumFlash.INVALID_HANDLE_VALUE Then
            MessageBox.Show("Must first call FindMemoryCard()", strAppName)
         Else
            EnumFlash.FindClose(hffc)
            hffc = New IntPtr(EnumFlash.INVALID_HANDLE_VALUE)
         End If
      End Sub
   End Class
End Namespace
