' Marshal.vb - Wrappers for several approaches to allocating
' unmanaged memory.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System.Runtime.InteropServices

Namespace YaoDurant.Allocator
   Public Class Marshal

   '------------------------------------------------------------
   ' Allocate / free COM memory
   '------------------------------------------------------------
   <DllImport("ole32.dll")> _
   Public Shared _
   Function CoTaskMemAlloc(ByVal cb As Integer) As IntPtr
   End Function

   <DllImport("ole32.dll")> _
   Public Shared _
   Sub CoTaskMemFree(ByVal pv As IntPtr)
   End Sub
   Public Shared _
   Function AllocCoTaskMem(ByVal cb As Integer) As IntPtr
      Return CoTaskMemAlloc(cb)
   End Function

   Public Shared Sub FreeCoTaskMem(ByVal ptr As IntPtr)
      CoTaskMemFree(ptr)
   End Sub

   '------------------------------------------------------------
   ' Allocate / free regular heap memory
   '------------------------------------------------------------
   <DllImport("COREDLL.DLL")> _
   Public Shared _
   Function LocalAlloc(ByVal fuFlags As Integer, _
      ByVal cbBytes As Integer) As IntPtr
   End Function
   Public Const LMEM_FIXED As Integer = &H0
   Public Const LMEM_ZEROINIT As Integer = &H40

   Public Shared Function AllocHGlobal(ByVal cb As Integer) _
   As IntPtr
      Return LocalAlloc(LMEM_FIXED Or LMEM_ZEROINIT, cb)
   End Function


   Public Shared Function AllocHGlobal(ByVal cb As IntPtr) _
   As IntPtr
      Return AllocHGlobal(cb.ToInt32())
   End Function


   <DllImport("COREDLL.DLL")> _
   Public Shared _
   Function LocalFree(ByVal hMem As IntPtr) As IntPtr
   End Function

   Public Shared Sub FreeHGlobal(ByVal hglobal As IntPtr)
      LocalFree(hglobal)
   End Sub
   End Class
End Namespace
