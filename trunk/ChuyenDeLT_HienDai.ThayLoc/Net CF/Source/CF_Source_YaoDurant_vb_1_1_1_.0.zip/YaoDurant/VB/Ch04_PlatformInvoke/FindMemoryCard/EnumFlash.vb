' EmumFlash.vb - Wrappers for calling flash card enumeration
' functions.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System.Runtime.InteropServices
Namespace FindMemoryCard
   Public Class EnumFlash
      ' Flash-card search functions.
      <DllImport("note_prj.dll", _
      EntryPoint:="FindFirstFlashCard")> _
      Public Shared Function _
      YD_FindFirstFlashCard(ByVal lpFindFlashData As IntPtr) _
      As IntPtr
      End Function
      <DllImport("note_prj.dll", _
      EntryPoint:="FindNextFlashCard")> _
      Public Shared Function _
      YD_FindNextFlashCard(ByVal hFlashCard As IntPtr, _
      ByVal lpFindFlashData As IntPtr) _
      As Integer
      End Function
      <DllImport("coredll.dll", EntryPoint:="FindClose")> _
      Public Shared Function _
      YD_FindClose(ByVal hFindFile As IntPtr) As Integer
      End Function

      Const MAX_PATH As Integer = 260

      Public Structure FILETIME
         Public dwLowDateTime As Integer
         Public dwHighDateTime As Integer
      End Structure 'FILETIME

      Public Structure WIN32_FIND_DATA
         Public dwFileAttributes As Integer
         Public ftCreationTime As FILETIME
         Public ftLastAccessTime As FILETIME
         Public ftLastWriteTime As FILETIME
         Public nFileSizeHigh As Integer
         Public nFileSizeLow As Integer
         Public dwOID As Integer
         Public cFileName As String
      End Structure 'WIN32_FIND_DATA

      ' Memory allocation functions.
      Public Const LMEM_FIXED As Integer = &H0
      <DllImport("COREDLL.DLL")> _
      Public Shared _
      Function LocalAlloc(ByVal fuFlags As Integer, _
         ByVal cbBytes As Integer) As IntPtr
      End Function
      <DllImport("COREDLL.DLL")> _
      Public Shared _
      Function LocalFree(ByVal hMem As IntPtr) As IntPtr
      End Function

      Public Shared INVALID_HANDLE_VALUE As Integer = -1

      '--------------------------------------------------------
      ' Buffer needed for find-flash-card functions
      '--------------------------------------------------------
      Public Shared pFindData As IntPtr = IntPtr.Zero

      '--------------------------------------------------------
      '--------------------------------------------------------
      Private Shared Sub _
      CopyIntPtr_to_WIN32_FIND_DATA( _
      ByVal pIn As IntPtr, ByRef pffd As WIN32_FIND_DATA)
         ' Handy values for incrementing IntPtr pointer.
         Dim i As Integer = 0
         Dim cbInt As Integer = Marshal.SizeOf(i)
         Dim ft As New FILETIME
         Dim cbFT As Integer = Marshal.SizeOf(ft)

         ' int dwFileAttributes
         pffd.dwFileAttributes = Marshal.ReadInt32(pIn)
         pIn = New IntPtr(pIn.ToInt32() + cbInt)

         ' FILETIME ftCreationTime;
         Marshal.PtrToStructure(pIn, pffd.ftCreationTime)
         pIn = New IntPtr(pIn.ToInt32() + cbFT)

         ' FILETIME ftLastAccessTime;
         Marshal.PtrToStructure(pIn, pffd.ftLastAccessTime)
         pIn = New IntPtr(pIn.ToInt32() + cbFT)

         ' FILETIME ftLastWriteTime;
         Marshal.PtrToStructure(pIn, pffd.ftLastWriteTime)
         pIn = New IntPtr(pIn.ToInt32() + cbFT)

         ' int nFileSizeHigh;
         pffd.nFileSizeHigh = Marshal.ReadInt32(pIn)
         pIn = New IntPtr(pIn.ToInt32() + cbInt)

         ' int nFileSizeLow;
         pffd.nFileSizeLow = Marshal.ReadInt32(pIn)
         pIn = New IntPtr(pIn.ToInt32() + cbInt)

         ' int dwOID;
         pffd.dwOID = Marshal.ReadInt32(pIn)
         pIn = New IntPtr(pIn.ToInt32() + cbInt)

         ' String cFileName;
         pffd.cFileName = Marshal.PtrToStringUni(pIn)
      End Sub 'CopyIntPtr_to_WIN32_FIND_DATA

      '--------------------------------------------------------
      '--------------------------------------------------------
      Public Shared Function FindFirstFlashCard(ByRef pffd As WIN32_FIND_DATA) As IntPtr
         Dim hFF As IntPtr = New IntPtr(INVALID_HANDLE_VALUE)

         ' Allocate a block large enough for WIN32_FIND_DATA
         pFindData = LocalAlloc(LMEM_FIXED, 560)
         If pFindData.Equals(IntPtr.Zero) Then
            GoTo ErrorExit
         End If
         hFF = YD_FindFirstFlashCard(pFindData)
         If hFF.ToInt32() <> INVALID_HANDLE_VALUE Then
            CopyIntPtr_to_WIN32_FIND_DATA(pFindData, pffd)
         End If

ErrorExit:
         Return hFF
      End Function 'FindFirstFlashCard

      '--------------------------------------------------------
      '--------------------------------------------------------
      Public Shared Function FindNextFlashCard(ByVal hFlashCard As IntPtr, ByRef pffd As WIN32_FIND_DATA) As Boolean
         Dim bRet As Boolean = False

         If pFindData.Equals(IntPtr.Zero) Then
            GoTo ErrorExit
         End If
         Dim bMore As Integer = YD_FindNextFlashCard(hFlashCard, pFindData)
         If bMore <> 0 Then
            CopyIntPtr_to_WIN32_FIND_DATA(pFindData, pffd)
            bRet = True
         End If

ErrorExit:
         Return bRet
      End Function 'FindNextFlashCard

      '--------------------------------------------------------
      '--------------------------------------------------------
      Public Shared Function FindClose(ByVal hFindFile As IntPtr) As Boolean
         Dim bRet As Boolean = YD_FindClose(hFindFile) <> 0

         ' Free the memory we allocated.
         If pFindData.ToInt32() <> 0 Then
            LocalFree(pFindData)
            pFindData = IntPtr.Zero
         End If

         Return bRet
      End Function 'FindClose
   End Class
End Namespace
