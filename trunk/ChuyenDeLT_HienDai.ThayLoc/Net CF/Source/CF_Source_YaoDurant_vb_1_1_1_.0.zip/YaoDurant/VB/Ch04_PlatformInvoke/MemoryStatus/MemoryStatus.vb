' MemoryStatus.vb - Displays system memory status
' by calling a Win32 function and passing a pointer to a data
' structure.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Windows.Forms

Namespace MemoryStatus
   Class MemoryStatus
      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Sub GlobalMemoryStatus( _
         ByRef lpBuffer As MEMORYSTATUS)
      End Sub

      Public Structure MEMORYSTATUS
         Public dwLength As Integer
         Public dwMemoryLoad As Integer
         Public dwTotalPhys As Integer
         Public dwAvailPhys As Integer
         Public dwTotalPageFile As Integer
         Public dwAvailPageFile As Integer
         Public dwTotalVirtual As Integer
         Public dwAvailVirtual As Integer
      End Structure

      Const CRLF As String = vbCrLf

      Public Shared Sub Main()
         Dim ms As MemoryStatus = New MemoryStatus
         ms.dwLength = Marshal.SizeOf(ms)
         GlobalMemoryStatus(ms)

         Dim strAppName As String = "Memory Status"

         Dim sbMessage As StringBuilder = New StringBuilder
         sbMessage.Append("Memory Load = ")
         sbMessage.Append(ms.dwMemoryLoad.ToString() + "%")
         sbMessage.Append(CRLF)
         sbMessage.Append("Total RAM = ")
         sbMessage.Append(ms.dwTotalPhys.ToString("#,##0"))
         sbMessage.Append(CRLF)
         sbMessage.Append("Avail RAM = ")
         sbMessage.Append(ms.dwAvailPhys.ToString("#,##0"))
         sbMessage.Append(CRLF)
         sbMessage.Append("Total Page = ")
         sbMessage.Append(ms.dwTotalPageFile.ToString("#,##0"))
         sbMessage.Append(CRLF)
         sbMessage.Append("Avail Page = ")
         sbMessage.Append(ms.dwAvailPageFile.ToString("#,##0"))
         sbMessage.Append(CRLF)
         sbMessage.Append("Total Virt = ")
         sbMessage.Append(ms.dwTotalVirtual.ToString("#,##0"))
         sbMessage.Append(CRLF)
         sbMessage.Append("Avail Virt = ")
         sbMessage.Append(ms.dwAvailVirtual.ToString("#,##0"))

         MessageBox.Show(sbMessage.ToString(), strAppName)
      End Sub
   End Class
End Namespace

