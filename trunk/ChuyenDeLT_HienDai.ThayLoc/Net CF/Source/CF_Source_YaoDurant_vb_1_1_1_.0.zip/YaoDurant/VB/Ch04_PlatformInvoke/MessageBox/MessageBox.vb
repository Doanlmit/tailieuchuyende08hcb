' MessageBox.vb - Two ways to call Win32 MessageBox
' function using P/Invoke.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Runtime.InteropServices

Namespace PlatformInvoke

   Class PI_MessageBox
      Public Const strApp As String = "MessageBox"

      <DllImport("coredll.dll")> _
      Public Shared Function MessageBox( _
         ByVal hWnd As IntPtr _
         , ByVal lpText As String _
         , ByVal lpCaption As String _
         , ByVal uType As Integer _
         ) As Integer
      End Function

      Public Const MB_OK As Integer = &H0
      Public Const MB_OKCANCEL As Integer = &H1
      Public Const MB_ABORTRETRYIGNORE As Integer = &H2
      Public Const MB_YESNOCANCEL As Integer = &H3
      Public Const MB_YESNO As Integer = &H4
      Public Const MB_RETRYCANCEL As Integer = &H5
      Public Const MB_ICONHAND As Integer = &H10
      Public Const MB_ICONQUESTION As Integer = &H20
      Public Const MB_ICONEXCLAMATION As Integer = &H30
      Public Const MB_ICONASTERISK As Integer = &H40
      Public Const MB_ICONWARNING As Integer = MB_ICONEXCLAMATION
      Public Const MB_ICONERROR As Integer = MB_ICONHAND
      Public Const MB_ICONINFORMATION As Integer = MB_ICONASTERISK
      Public Const MB_ICONSTOP As Integer = MB_ICONHAND
      Public Const MB_DEFBUTTON1 As Integer = &H0
      Public Const MB_DEFBUTTON2 As Integer = &H100
      Public Const MB_DEFBUTTON3 As Integer = &H200
      Public Const MB_DEFBUTTON4 As Integer = &H300
      Public Const MB_APPLMODAL As Integer = &H0
      Public Const MB_SETFOREGROUND As Integer = &H10000
      Public Const MB_TOPMOST As Integer = &H40000

      <DllImport("coredll.dll")> _
      Public Shared Function MessageBox( _
         ByVal hWnd As IntPtr _
         , ByVal lpText As String _
         , ByVal lpCaption As String _
         , ByVal uType As MB _
         ) As Integer
      End Function

      Public Enum MB
         MB_OK = &H0
         MB_OKCANCEL = &H1
         MB_ABORTRETRYIGNORE = &H2
         MB_YESNOCANCEL = &H3
         MB_YESNO = &H4
         MB_RETRYCANCEL = &H5
         MB_ICONHAND = &H10
         MB_ICONQUESTION = &H20
         MB_ICONEXCLAMATION = &H30
         MB_ICONASTERISK = &H40
         MB_ICONWARNING = MB_ICONEXCLAMATION
         MB_ICONERROR = MB_ICONHAND
         MB_ICONINFORMATION = MB_ICONASTERISK
         MB_ICONSTOP = MB_ICONHAND
         MB_DEFBUTTON1 = &H0
         MB_DEFBUTTON2 = &H100
         MB_DEFBUTTON3 = &H200
         MB_DEFBUTTON4 = &H300
         MB_APPLMODAL = &H0
         MB_SETFOREGROUND = &H10000
         MB_TOPMOST = &H40000
      End Enum

   Public Shared Sub Main()
         ' Flags defined as set of const values.
         MessageBox(IntPtr.Zero, "One way to define flags", _
            strApp, MB_OK Or MB_TOPMOST)

         ' Flags defined as members of enum
         MessageBox(IntPtr.Zero, "Another way to define flags", _
            strApp, MB.MB_OK Or MB.MB_TOPMOST)

   End Sub
   End Class

End Namespace


