' CallWin32.vb - Declarations and functions to call
' Win32 functions in the Win32 library ShowParam.dll.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
'
Imports System.Runtime.InteropServices
Imports System.Text

Namespace CallWin32
Public Class CallWin32

   Public Const DllName As String = "ShowParam.dll"

   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowBooleanByVal( _
      ByVal b As Byte)
   End Sub
   <DllImport("DllName", CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowBooleanByRef( _
      ByRef b As Byte)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowByteByVal( _
      ByVal val As Byte)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowByteByRef( _
      ByRef val As Byte)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowSByteByVal( _
      ByVal val As SByte)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowSByteByRef( _
      ByRef val As SByte)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowInt16ByVal( _
      ByVal val As Short)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowInt16ByRef( _
      ByRef val As Short)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowUInt16ByVal( _
      ByVal val As UInt16)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowUInt16ByRef( _
      ByRef val As UInt16)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowInt32ByVal( _
      ByVal val As Integer)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowInt32ByRef( _
      ByRef val As Integer)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowUInt32ByVal( _
      ByVal val As UInt32)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowUInt32ByRef( _
      ByRef val As UInt32)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowInt64ByVal( _
      ByVal val As Long)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowInt64ByRef( _
      ByRef val As Long)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowUInt64ByVal( _
      ByVal val As UInt64)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowUInt64ByRef( _
      ByRef val As UInt64)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowSingleByVal( _
      ByVal val As Single)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowSingleByRef( _
      ByRef val As Single)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowDoubleByVal( _
      ByVal val As Double)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowDoubleByRef( _
      ByRef val As Double)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowCharByVal( _
      ByVal val As Char)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowCharByRef( _
      ByRef val As Char)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowStringByVal( _
      ByVal val As String)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowStringByRef( _
      ByRef val As String)
   End Sub
   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowStringByVal( _
      ByVal val As StringBuilder)
   End Sub

   <DllImport(DllName, CharSet:=CharSet.Unicode)> _
   Public Shared Sub ShowStringByRef( _
      ByRef val As StringBuilder)
   End Sub


   Public Shared Sub _
   CallWin32Lib(ByVal strVal As String, ByVal strType As String, _
   ByVal bByRef As Boolean)
      '
      ' User selection -- Boolean
      '
      If strType = "Boolean" Then
         Dim b As Boolean
         If strVal = "true" Then
               b = True
         ElseIf strVal = "false" Then
         Else
            MessageBox.Show("Boolean needs true or false", _
               FormMain.strApp)
            Return
         End If
         If bByRef Then
            ShowBooleanByRef(b)
         Else
            ShowBooleanByVal(b)
         End If
      End If
      '
      ' User selection -- Byte
      '
      If strType = "Byte" Then
         Dim bytVal As Byte = Byte.Parse(strVal)
         If bByRef Then
            ShowByteByRef(bytVal)
         Else
            ShowByteByVal(bytVal)
         End If
      End If
         '
         ' User selection -- SByte
         '
         If strType = "SByte" Then
            Dim sbytVal As SByte = SByte.Parse(strVal)
            If bByRef Then
               ShowSByteByRef(sbytVal)
            Else
               ShowSByteByVal(sbytVal)
            End If
         End If
         '
         ' User selection -- Int16
         '
         If strType = "Int16" Then
            Dim shVal As Int16 = Int16.Parse(strVal)
            If bByRef Then
               ShowInt16ByRef(shVal)
            Else
               ShowInt16ByVal(shVal)
            End If
         End If
         '
         ' User selection -- UInt16
         '
         If strType = "UInt16" Then
            Dim ushVal As UInt16 = UInt16.Parse(strVal)
            If bByRef Then
               ShowUInt16ByRef(ushVal)
            Else
               ShowUInt16ByVal(ushVal)
            End If
         End If
         '
         ' User selection -- Int32
         '
         If strType = "Int32" Then
            Dim iVal As Int32 = Int32.Parse(strVal)
            If bByRef Then
               ShowInt32ByRef(iVal)
            Else
               ShowInt32ByVal(iVal)
            End If
         End If
         '
         ' User selection -- UInt32
         '
         If strType = "UInt32" Then
            Dim uiVal As UInt32 = UInt32.Parse(strVal)
            If bByRef Then
               ShowUInt32ByRef(uiVal)
            Else
               ShowUInt32ByVal(uiVal)
            End If
         End If
         '
         ' User selection -- IntPtr
         '
         If strType = "IntPtr" Then
            Dim iVal As Int32 = Int32.Parse(strVal)
            If bByRef Then
               ShowInt32ByRef(iVal)
            Else
               ShowInt32ByVal(iVal)
            End If
         End If
         '
         ' User selection -- Int64
         '
         If strType = "Int64" Then
            Dim lVal As Int64 = Int64.Parse(strVal)
            If bByRef Then
               ShowInt64ByRef(lVal)
            Else
               ShowInt64ByVal(lVal)
            End If
         End If
         '
         ' User selection -- UInt64
         '
         If strType = "UInt64" Then
            Dim ulVal As UInt64 = UInt64.Parse(strVal)
            If bByRef Then
               ShowUInt64ByRef(ulVal)
            Else
               ShowUInt64ByVal(ulVal)
            End If
         End If
         '
         ' User selection -- Single
         '
         If strType = "Single" Then
            Dim sinVal As Single = Single.Parse(strVal)
            If bByRef Then
               ShowSingleByRef(sinVal)
            Else
               ShowSingleByVal(sinVal)
            End If
         End If
         '
         ' User selection -- Double
         '
         If strType = "Double" Then
            Dim dblVal As Double = Single.Parse(strVal)
            If bByRef Then
               ShowDoubleByRef(dblVal)
            Else
               ShowDoubleByVal(dblVal)
            End If
         End If
         '
         ' User selection -- Char
         '
         If strType = "Char" Then
            Dim chVal As Char = strVal.Chars(0)
            If bByRef Then
               ShowCharByRef(chVal)
            Else
               ShowCharByVal(chVal)
            End If
         End If
         '
         ' User selection -- String
         '
         If strType = "String" Then
            Dim strValue As String = strVal
            If bByRef Then
               ShowStringByRef(strValue)
            Else
               ShowStringByVal(strValue)
            End If
         End If
         '
         ' User selection -- StringBuilder
         '
         If strType = "StringBuilder" Then
            Dim sbVal As StringBuilder = New StringBuilder(strVal)
            If bByRef Then
               ShowStringByRef(sbVal)
            Else
               ShowStringByVal(sbVal)
            End If
         End If

   End Sub

End Class
End Namespace
