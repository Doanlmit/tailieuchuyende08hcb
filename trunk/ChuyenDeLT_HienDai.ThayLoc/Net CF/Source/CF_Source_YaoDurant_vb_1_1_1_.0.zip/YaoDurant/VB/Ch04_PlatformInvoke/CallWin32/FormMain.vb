' FormMain.vb - Main form for CallWin32 sample.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Namespace CallWin32
Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents txtValue As System.Windows.Forms.TextBox
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents cboType As System.Windows.Forms.ComboBox
      Friend WithEvents rdoByVal As System.Windows.Forms.RadioButton
      Friend WithEvents rdoByRef As System.Windows.Forms.RadioButton
      Friend WithEvents cmdCall As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.label1 = New System.Windows.Forms.Label
Me.txtValue = New System.Windows.Forms.TextBox
Me.label2 = New System.Windows.Forms.Label
Me.cboType = New System.Windows.Forms.ComboBox
Me.rdoByVal = New System.Windows.Forms.RadioButton
Me.rdoByRef = New System.Windows.Forms.RadioButton
Me.cmdCall = New System.Windows.Forms.Button
'
'label1
'
Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.label1.Location = New System.Drawing.Point(8, 8)
Me.label1.Size = New System.Drawing.Size(56, 20)
Me.label1.Text = "Value:"
'
'txtValue
'
Me.txtValue.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.txtValue.Location = New System.Drawing.Point(64, 8)
Me.txtValue.Size = New System.Drawing.Size(160, 22)
Me.txtValue.Text = ""
'
'label2
'
Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.label2.Location = New System.Drawing.Point(8, 56)
Me.label2.Size = New System.Drawing.Size(48, 20)
Me.label2.Text = "Type:"
'
'cboType
'
Me.cboType.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cboType.Items.Add("Boolean")
Me.cboType.Items.Add("Byte")
Me.cboType.Items.Add("SByte")
Me.cboType.Items.Add("Char")
Me.cboType.Items.Add("Int16")
Me.cboType.Items.Add("UInt16")
Me.cboType.Items.Add("Int32")
Me.cboType.Items.Add("UInt32")
Me.cboType.Items.Add("IntPtr")
Me.cboType.Items.Add("Single")
Me.cboType.Items.Add("Int64")
Me.cboType.Items.Add("UInt64")
Me.cboType.Items.Add("Double")
Me.cboType.Items.Add("String")
Me.cboType.Items.Add("StringBuilder")
Me.cboType.Location = New System.Drawing.Point(64, 48)
Me.cboType.Size = New System.Drawing.Size(160, 22)
'
'rdoByVal
'
Me.rdoByVal.Checked = True
Me.rdoByVal.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.rdoByVal.Location = New System.Drawing.Point(64, 88)
Me.rdoByVal.Text = "By Value"
'
'rdoByRef
'
Me.rdoByRef.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.rdoByRef.Location = New System.Drawing.Point(64, 112)
Me.rdoByRef.Text = "By Reference"
'
'cmdCall
'
Me.cmdCall.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdCall.Location = New System.Drawing.Point(16, 144)
Me.cmdCall.Size = New System.Drawing.Size(208, 32)
Me.cmdCall.Text = "Call Win32 Library"
'
'FormMain
'
Me.BackColor = System.Drawing.Color.Silver
Me.Controls.Add(Me.cmdCall)
Me.Controls.Add(Me.rdoByRef)
Me.Controls.Add(Me.rdoByVal)
Me.Controls.Add(Me.cboType)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.txtValue)
Me.Controls.Add(Me.label1)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "CallWin32"

    End Sub

#End Region

   Public Const strApp As String = "CallWin32"

   Private Sub cmdCall_Click(ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdCall.Click
      If (Me.txtValue.Text.Length = 0) Then
            MessageBox.Show("Please enter a value", strApp)
            Return
      End If

      If (Me.cboType.SelectedIndex = -1) Then
         MessageBox.Show("Please select a Type", strApp)
         Return
      End If

      Dim strType As String = Me.cboType.Text
      Dim strVal As String = Me.txtValue.Text
      Dim bByRef As Boolean = Me.rdoByRef.Checked

      Try
         CallWin32.CallWin32Lib(strVal, strType, bByRef)

      Catch ex As Exception
         MessageBox.Show("Exception: " + ex.Message, strApp)
      End Try

   End Sub
End Class
End Namespace
