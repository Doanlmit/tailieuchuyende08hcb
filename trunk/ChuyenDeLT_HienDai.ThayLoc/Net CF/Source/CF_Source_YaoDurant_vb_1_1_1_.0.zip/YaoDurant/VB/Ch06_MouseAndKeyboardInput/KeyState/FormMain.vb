' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Runtime.InteropServices

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.label1 = New System.Windows.Forms.Label
'
'label1
'
Me.label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold)
Me.label1.Location = New System.Drawing.Point(16, 16)
Me.label1.Size = New System.Drawing.Size(192, 136)
Me.label1.Text = "This program shows how to tell the difference between rocker input and 4-way inpu" & _
"t on a Pocket PC."
'
'FormMain
'
Me.Controls.Add(Me.label1)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Key State"

    End Sub

#End Region

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function GetAsyncKeyState( _
   ByVal vKey As Keys _
   ) As Short
End Function

   Private Sub FormMain_KeyDown(ByVal sender As Object, _
   ByVal e As System.Windows.Forms.KeyEventArgs) _
   Handles MyBase.KeyDown
      ' Detecting the difference between the rocker switch
      ' and the 4-way switch can be done in two different
      ' ways, one appears within the #if block and a second
      ' appears in the #else block.
      ' The #if block responds first to the F20 / F21 key
      ' code, and then calls GetAsyncKeyState to see the
      ' state of the direction key.
      ' The #else block looks for the Up / Down key code,
      ' and then calls GetAsyncKeyState to see the state
      ' of the F20 and F21 keys.
      '
      ' Note: The Pocket PC 2002 emulator echoes F21 for 
      ' both rocker and 4-way switch; you must run this 
      ' code on a smart device to see how rocker and 4-way
      ' are handled differently.
#If True Then
      ' Detecting F20 / F21
      If (e.KeyCode = Keys.F21) Then
         If (GetAsyncKeyState(Keys.Up) < 0) Then
            MessageBox.Show("Four-Way - Up")
         End If

         If (GetAsyncKeyState(Keys.Down) < 0) Then
            MessageBox.Show("Four-Way - Down")
         End If
      End If

      If (e.KeyCode = Keys.F20) Then
         If (GetAsyncKeyState(Keys.Up) < 0) Then
            MessageBox.Show("Rocker - Up")
         End If

         If (GetAsyncKeyState(Keys.Down) < 0) Then
            MessageBox.Show("Rocker - Down")
         End If
      End If
#Else
      ' Detecting Up / Down
      If (e.KeyCode = Keys.Up) Then
         If (GetAsyncKeyState(Keys.F21) < 0) Then
            MessageBox.Show("Four-Way - Up")
         End If
         If (GetAsyncKeyState(Keys.F20) < 0) Then
            MessageBox.Show("Rocker - Up")
         End If
      End If

      If (e.KeyCode = Keys.Down) Then
         If (GetAsyncKeyState(Keys.F21) < 0) Then
            MessageBox.Show("Four-Way - Down")
         End If
         If (GetAsyncKeyState(Keys.F20) < 0) Then
            MessageBox.Show("Rocker - Down")
         End If
      End If


#End If
      ' Detect Action key
      If (e.KeyCode = Keys.F23) Then
         MessageBox.Show("Action key")
      End If

   End Sub
End Class
