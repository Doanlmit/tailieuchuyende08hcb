' FormMain.vb - Main form for DrawRectangles sample.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Namespace DrawRectangles

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem

      Private alRectangles As ArrayList = New ArrayList(50)
      Private rectCurrent As Rectangle = New Rectangle(0, 0, 0, 0)
      Private stretch As StretchRectangle = New StretchRectangle

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents mitemEditClear As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewGrid As System.Windows.Forms.MenuItem
   Friend WithEvents mitemViewCoordinates As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
Me.menuMain = New System.Windows.Forms.MainMenu
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitemEditClear = New System.Windows.Forms.MenuItem
Me.MenuItem2 = New System.Windows.Forms.MenuItem
Me.mitemViewGrid = New System.Windows.Forms.MenuItem
Me.mitemViewCoordinates = New System.Windows.Forms.MenuItem
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.MenuItem1)
Me.menuMain.MenuItems.Add(Me.MenuItem2)
'
'MenuItem1
'
Me.MenuItem1.MenuItems.Add(Me.mitemEditClear)
Me.MenuItem1.Text = "Edit"
'
'mitemEditClear
'
Me.mitemEditClear.Text = "Clear"
'
'MenuItem2
'
Me.MenuItem2.MenuItems.Add(Me.mitemViewGrid)
Me.MenuItem2.MenuItems.Add(Me.mitemViewCoordinates)
Me.MenuItem2.Text = "View"
'
'mitemViewGrid
'
Me.mitemViewGrid.Text = "Grid"
'
'mitemViewCoordinates
'
Me.mitemViewCoordinates.Text = "Coordinates"
'
'FormMain
'
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "DrawRectangles"

    End Sub

#End Region

      Private Sub _
      EchoCoordinates(ByVal x As Integer, ByVal y As Integer)

          Me.Text = "Drawing (" + x.ToString() + _
                      "," + y.ToString() + ")"
      End Sub

   Private Sub FormMain_MouseDown(ByVal sender As System.Object, _
      ByVal e As MouseEventArgs) Handles MyBase.MouseDown
      rectCurrent.X = e.X
      rectCurrent.Y = e.Y

      ' Echo mouse coordinates to caption bar.
      If (mitemViewCoordinates.Checked) Then
         EchoCoordinates(e.X, e.Y)
      End If

      ' Start stretchable rectangle drawing.
      stretch.Init(e.X, e.Y, Me)
   End Sub

   Private Sub FormMain_MouseMove(ByVal sender As System.Object, _
      ByVal e As MouseEventArgs) Handles MyBase.MouseMove
      ' Move stretchable rectangle.
      stretch.Move(e.X, e.Y)

      ' Echo mouse coordinates to caption bar.
      If (mitemViewCoordinates.Checked) Then
         EchoCoordinates(e.X, e.Y)
      End If
   End Sub
   Private Sub FormMain_MouseUp(ByVal sender As System.Object, _
      ByVal e As MouseEventArgs) Handles MyBase.MouseUp
      Dim iTemp As Integer
      Dim x As Integer = e.X
      Dim y As Integer = e.Y

      ' End stretchable rectangle drawing.
      stretch.Done()

      ' Echo mouse coordinates to caption bar.
      If (mitemViewCoordinates.Checked) Then
         EchoCoordinates(e.X, e.Y)
      End If

      If (rectCurrent.X > x) Then
         iTemp = rectCurrent.X
         rectCurrent.X = x
         x = iTemp
      End If

      If (rectCurrent.Y > y) Then
         iTemp = rectCurrent.Y
         rectCurrent.Y = y
         y = iTemp
      End If

      Dim xWidth As Integer = x - rectCurrent.X
      Dim yHeight As Integer = y - rectCurrent.Y

      rectCurrent.Width = xWidth
      rectCurrent.Height = yHeight
      alRectangles.Add(rectCurrent)

      ' Adjust rectangle coordinates & request Paint event.
      rectCurrent.Width = rectCurrent.Width + 1
      rectCurrent.Height += 1
      Invalidate(rectCurrent)

   End Sub

   Private Sub FormMain_Paint(ByVal sender As Object, _
      ByVal e As System.Windows.Forms.PaintEventArgs) _
      Handles MyBase.Paint
         Dim g As Graphics = e.Graphics

         ' Draw grid
         If (mitemViewGrid.Checked) Then
            Dim cxWidth As Integer = Me.Width
            Dim cyHeight As Integer = Me.Height
            Dim penGray As Pen = _
               New Pen(System.Drawing.Color.LightBlue)
            Dim x As Integer
            For x = 0 To cxWidth - 1 Step 10
               g.DrawLine(penGray, x, 0, x, cyHeight)
            Next
            Dim y As Integer
            For y = 0 To cyHeight - 1 Step 10
               g.DrawLine(penGray, 0, y, cxWidth, y)
            Next
         End If

         ' Draw rectangles.
         Dim penBlack As Pen = _
            New Pen(System.Drawing.Color.Black)
         Dim brWhite As Brush = _
            New SolidBrush(System.Drawing.Color.White)
         Dim rect As Rectangle
         For Each rect In alRectangles
            g.FillRectangle(brWhite, rect)
            g.DrawRectangle(penBlack, rect)
         Next
   End Sub
   Private Sub mitemEditClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemEditClear.Click
      alRectangles.Clear()
      Invalidate()
   End Sub

   Private Sub mitemViewGrid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemViewGrid.Click
      ' Toggle checked menu item.
      mitemViewGrid.Checked = (Not mitemViewGrid.Checked)

      ' Redraw.
      Invalidate()

   End Sub

   Private Sub mitemViewCoordinates_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemViewCoordinates.Click
      ' Toggle checked menu item.
      mitemViewCoordinates.Checked = (Not mitemViewCoordinates.Checked)

      If (Not mitemViewCoordinates.Checked) Then
         Me.Text = "Draw Rectangles"
      End If

   End Sub

End Class
End Namespace

