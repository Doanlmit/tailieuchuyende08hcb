' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Runtime.InteropServices
Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents label4 As System.Windows.Forms.Label
      Friend WithEvents textBattery As System.Windows.Forms.TextBox
      Friend WithEvents textExternal As System.Windows.Forms.TextBox
      Friend WithEvents textSnooze As System.Windows.Forms.TextBox
      Friend WithEvents cmdSetBatteryTimeout As System.Windows.Forms.Button
      Friend WithEvents cmdSetSnoozeTimeout As System.Windows.Forms.Button
      Friend WithEvents cmdSleepButton As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents cmdSetExternalTimeout As System.Windows.Forms.Button
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.label1 = New System.Windows.Forms.Label
Me.label2 = New System.Windows.Forms.Label
Me.label3 = New System.Windows.Forms.Label
Me.label4 = New System.Windows.Forms.Label
Me.textBattery = New System.Windows.Forms.TextBox
Me.textExternal = New System.Windows.Forms.TextBox
Me.textSnooze = New System.Windows.Forms.TextBox
Me.cmdSetBatteryTimeout = New System.Windows.Forms.Button
Me.cmdSetExternalTimeout = New System.Windows.Forms.Button
Me.cmdSetSnoozeTimeout = New System.Windows.Forms.Button
Me.cmdSleepButton = New System.Windows.Forms.Button
'
'label1
'
Me.label1.Location = New System.Drawing.Point(72, 24)
Me.label1.Size = New System.Drawing.Size(112, 32)
Me.label1.Text = "Inactivity Timer Settings (in sec.)"
'
'label2
'
Me.label2.Location = New System.Drawing.Point(21, 72)
Me.label2.Size = New System.Drawing.Size(48, 20)
Me.label2.Text = "Battery:"
'
'label3
'
Me.label3.Location = New System.Drawing.Point(16, 112)
Me.label3.Size = New System.Drawing.Size(56, 20)
Me.label3.Text = "External:"
'
'label4
'
Me.label4.Location = New System.Drawing.Point(21, 152)
Me.label4.Size = New System.Drawing.Size(48, 20)
Me.label4.Text = "Snooze:"
'
'textBattery
'
Me.textBattery.Location = New System.Drawing.Point(88, 70)
Me.textBattery.Size = New System.Drawing.Size(64, 22)
Me.textBattery.Text = ""
'
'textExternal
'
Me.textExternal.Location = New System.Drawing.Point(88, 110)
Me.textExternal.Size = New System.Drawing.Size(64, 22)
Me.textExternal.Text = ""
'
'textSnooze
'
Me.textSnooze.Location = New System.Drawing.Point(88, 150)
Me.textSnooze.Size = New System.Drawing.Size(64, 22)
Me.textSnooze.Text = ""
'
'cmdSetBatteryTimeout
'
Me.cmdSetBatteryTimeout.Location = New System.Drawing.Point(168, 70)
Me.cmdSetBatteryTimeout.Size = New System.Drawing.Size(40, 22)
Me.cmdSetBatteryTimeout.Text = "Set"
'
'cmdSetExternalTimeout
'
Me.cmdSetExternalTimeout.Location = New System.Drawing.Point(168, 110)
Me.cmdSetExternalTimeout.Size = New System.Drawing.Size(40, 22)
Me.cmdSetExternalTimeout.Text = "Set"
'
'cmdSetSnoozeTimeout
'
Me.cmdSetSnoozeTimeout.Location = New System.Drawing.Point(168, 150)
Me.cmdSetSnoozeTimeout.Size = New System.Drawing.Size(40, 22)
Me.cmdSetSnoozeTimeout.Text = "Set"
'
'cmdSleepButton
'
Me.cmdSleepButton.Location = New System.Drawing.Point(32, 192)
Me.cmdSleepButton.Size = New System.Drawing.Size(168, 24)
Me.cmdSleepButton.Text = "Push Power Button"
'
'FormMain
'
Me.Controls.Add(Me.cmdSleepButton)
Me.Controls.Add(Me.cmdSetSnoozeTimeout)
Me.Controls.Add(Me.cmdSetExternalTimeout)
Me.Controls.Add(Me.cmdSetBatteryTimeout)
Me.Controls.Add(Me.textSnooze)
Me.Controls.Add(Me.textExternal)
Me.Controls.Add(Me.textBattery)
Me.Controls.Add(Me.label4)
Me.Controls.Add(Me.label3)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.label1)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Sleep"

    End Sub

#End Region

   Dim strAppName As String = "Sleep"

   <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
   Public Shared Sub keybd_event( _
      ByVal bVk As Byte _
      , ByVal bScan As Byte _
      , ByVal dwFlags As Integer _
      , ByVal dwExtraInfo As Integer _
      )
   End Sub

   Public Const VK_OFF As Integer = &HDF

   <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
   Public Shared Function SystemParametersInfo( _
      ByVal uiAction As Integer _
      , ByVal uiParam As Integer _
      , ByVal iReserved As IntPtr _
      , ByVal fWinIni As Integer _
      ) As Integer
   End Function

   <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
   Public Shared Function SystemParametersInfo( _
      ByVal uiAction As Integer _
      , ByVal uiParam As Integer _
      , ByRef iValue As Integer _
      , ByVal fWinIni As Integer _
      ) As Integer
   End Function

   Public Const SPI_SETBATTERYIDLETIMEOUT As Integer = 251
   Public Const SPI_GETBATTERYIDLETIMEOUT As Integer = 252
   Public Const SPI_SETEXTERNALIDLETIMEOUT As Integer = 253
   Public Const SPI_GETEXTERNALIDLETIMEOUT As Integer = 254
   Public Const SPI_SETWAKEUPIDLETIMEOUT As Integer = 255
   Public Const SPI_GETWAKEUPIDLETIMEOUT As Integer = 256
   Public Const SPIF_UPDATEINIFILE As Integer = &H1
   Public Const SPIF_SENDCHANGE As Integer = &H2


   Private Sub FormMain_Load(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Load
      Dim iValue As Integer = 0
      SystemParametersInfo(SPI_GETBATTERYIDLETIMEOUT, 0, iValue, 0)
      textBattery.Text = iValue.ToString()
      SystemParametersInfo(SPI_GETEXTERNALIDLETIMEOUT, 0, iValue, 0)
      textExternal.Text = iValue.ToString()
      SystemParametersInfo(SPI_GETWAKEUPIDLETIMEOUT, 0, iValue, 0)
      textSnooze.Text = iValue.ToString()
   End Sub

   Private Sub cmdSleepButton_Click(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles cmdSleepButton.Click
      keybd_event(VK_OFF, 0, 0, 0)
   End Sub


   Private Sub cmdSetBatteryTimeout_Click(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles cmdSetBatteryTimeout.Click
      Try
         Dim iValue As Integer = Integer.Parse(textBattery.Text)
         If (iValue < 0) Then
            Throw (New Exception)
         End If
         SystemParametersInfo(SPI_SETBATTERYIDLETIMEOUT, iValue, _
            IntPtr.Zero, SPIF_UPDATEINIFILE Or SPIF_SENDCHANGE)
      Catch ex As Exception
         MessageBox.Show("Invalid timeout value entered.", _
            strAppName)
      End Try
   End Sub

   Private Sub cmdSetExternalTimeout_Click(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles cmdSetExternalTimeout.Click
      Try
         Dim iValue As Integer = Integer.Parse(textExternal.Text)
         If (iValue < 0) Then
            Throw (New Exception)
         End If
         SystemParametersInfo(SPI_SETEXTERNALIDLETIMEOUT, iValue, _
            IntPtr.Zero, SPIF_UPDATEINIFILE Or SPIF_SENDCHANGE)

      Catch ex As Exception
         MessageBox.Show("Invalid timeout value entered.", _
            strAppName)
      End Try
   End Sub
End Class
