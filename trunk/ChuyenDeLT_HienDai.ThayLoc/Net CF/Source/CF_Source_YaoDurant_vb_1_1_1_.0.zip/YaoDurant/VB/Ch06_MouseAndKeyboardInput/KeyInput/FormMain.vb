' FormMain.vb - Main form for KeyInput sample.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Namespace KeyInput
Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents textInput As System.Windows.Forms.TextBox
      Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemEditClear As System.Windows.Forms.MenuItem
      Friend WithEvents lviewOutput As System.Windows.Forms.ListView
      Friend WithEvents columnHeader1 As System.Windows.Forms.ColumnHeader
      Friend WithEvents columnHeader2 As System.Windows.Forms.ColumnHeader
      Friend WithEvents columnHeader3 As System.Windows.Forms.ColumnHeader
      Friend WithEvents columnHeader4 As System.Windows.Forms.ColumnHeader
      Friend WithEvents columnHeader5 As System.Windows.Forms.ColumnHeader

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

         ' Delegate to be called back when a new event is available.
         m_deleNewEvent = New EventHandler(AddressOf NewEvent)

         ' Put our text box (TextEventSpy) in place of 
         ' default TextBox
         textspy = New TextEventSpy(Me, m_deleNewEvent)
         textspy.Location = textInput.Location
         textspy.Size = textInput.Size
         textspy.Text = textInput.Text
         Me.Controls.Add(textspy)
         Me.Controls.Remove(textInput)
         textspy.Focus()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents sipMain As Microsoft.WindowsCE.Forms.InputPanel
    Private Sub InitializeComponent()
Me.menuMain = New System.Windows.Forms.MainMenu
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitemEditClear = New System.Windows.Forms.MenuItem
Me.textInput = New System.Windows.Forms.TextBox
Me.lviewOutput = New System.Windows.Forms.ListView
Me.columnHeader1 = New System.Windows.Forms.ColumnHeader
Me.columnHeader2 = New System.Windows.Forms.ColumnHeader
Me.columnHeader3 = New System.Windows.Forms.ColumnHeader
Me.columnHeader4 = New System.Windows.Forms.ColumnHeader
Me.columnHeader5 = New System.Windows.Forms.ColumnHeader
Me.sipMain = New Microsoft.WindowsCE.Forms.InputPanel
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.MenuItem1)
'
'MenuItem1
'
Me.MenuItem1.MenuItems.Add(Me.mitemEditClear)
Me.MenuItem1.Text = "Edit"
'
'mitemEditClear
'
Me.mitemEditClear.Text = "Clear"
'
'textInput
'
Me.textInput.Location = New System.Drawing.Point(8, 8)
Me.textInput.Size = New System.Drawing.Size(224, 22)
Me.textInput.Text = ""
'
'lviewOutput
'
Me.lviewOutput.Columns.Add(Me.columnHeader1)
Me.lviewOutput.Columns.Add(Me.columnHeader2)
Me.lviewOutput.Columns.Add(Me.columnHeader3)
Me.lviewOutput.Columns.Add(Me.columnHeader4)
Me.lviewOutput.Columns.Add(Me.columnHeader5)
Me.lviewOutput.Location = New System.Drawing.Point(0, 48)
Me.lviewOutput.Size = New System.Drawing.Size(240, 222)
Me.lviewOutput.View = System.Windows.Forms.View.Details
'
'columnHeader1
'
Me.columnHeader1.Text = "Event"
Me.columnHeader1.Width = 60
'
'columnHeader2
'
Me.columnHeader2.Text = "Char"
Me.columnHeader2.Width = 40
'
'columnHeader3
'
Me.columnHeader3.Text = "Code"
Me.columnHeader3.Width = 50
'
'columnHeader4
'
Me.columnHeader4.Text = "Val"
Me.columnHeader4.Width = 40
'
'columnHeader5
'
Me.columnHeader5.Text = "Mod"
Me.columnHeader5.Width = 40
'
'sipMain
'
'
'FormMain
'
Me.Controls.Add(Me.lviewOutput)
Me.Controls.Add(Me.textInput)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "Key Input"

    End Sub

#End Region

      ' Our data members
      Private textspy As TextEventSpy
      Private m_deleNewEvent As EventHandler

      Private Sub sipMain_EnabledChanged(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles sipMain.EnabledChanged
              ' SIP is open
         If (sipMain.Enabled) Then
            ' Adjust list view height to make room for SIP.
            lviewOutput.Height = Me.Height - _
               lviewOutput.Top - _
               sipMain.Bounds.Height() _
               + 1
         Else ' SIP is closed
            ' Adjust scroll bar height to form height.
            lviewOutput.Height = Me.Height - _
               lviewOutput.Top() _
               + 1
         End If

      End Sub

      Private Sub NewEvent(ByVal sender As Object, _
      ByVal e As System.EventArgs)
         Dim kei As KeyEventItem = textspy.kei
         Dim strEvent As String = ""
         Dim strChar As String = ""
         Dim strCode As String = ""
         Dim strValue As String = ""
         Dim strMod As String = ""

         ' Fetch event name.
         Select Case kei.etype
            Case EventType.Event_KeyDown
               strEvent = "KeyDown"
            Case EventType.Event_KeyPress
               strEvent = "KeyPress"
            Case EventType.Event_KeyUp
               strEvent = "KeyUp"
            Case EventType.Event_GotFocus
               strEvent = "GotFocus"
            Case EventType.Event_LostFocus
               strEvent = "LostFocus"
         End Select

         ' Fill in event details.
         If (kei.etype = EventType.Event_KeyUp Or _
         kei.etype = EventType.Event_KeyDown) Then
            strCode = kei.eUpDown.KeyCode.ToString()
            strValue = kei.eUpDown.KeyValue.ToString()
            If (kei.eUpDown.Control) Then
               strMod = "C "
            End If
            If (kei.eUpDown.Alt) Then
               strMod.Concat("A ")
            End If
            If (kei.eUpDown.Shift) Then
               strMod.Concat("S")
            End If
         End If

         If kei.etype = EventType.Event_KeyPress Then
            strChar = kei.ePress.KeyChar.ToString()
         End If

         Dim lvi As ListViewItem = New ListViewItem(strEvent)
         lvi.SubItems.Add(strChar)
         lvi.SubItems.Add(strCode)
         lvi.SubItems.Add(strValue)
         lvi.SubItems.Add(strMod)
         lviewOutput.Items.Add(lvi)
         Dim iItem As Integer = lviewOutput.Items.Count - 1
         lviewOutput.EnsureVisible(iItem)
      End Sub

      Private Sub FormMain_GotFocus(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.GotFocus
         ' Set focus to edit control
         ' On error, set focus to textInput
         Try
            textspy.Focus()
         Catch ex As Exception
            textInput.Focus()
         End Try

      End Sub

      Private Sub mitemEditClear_Click(ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles mitemEditClear.Click
         textspy.Text = String.Empty
         lviewOutput.Items.Clear()
         textspy.Focus()
      End Sub
End Class
End Namespace
