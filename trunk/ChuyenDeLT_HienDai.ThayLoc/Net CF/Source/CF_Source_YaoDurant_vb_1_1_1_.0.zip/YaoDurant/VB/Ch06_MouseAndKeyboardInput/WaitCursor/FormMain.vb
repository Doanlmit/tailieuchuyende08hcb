' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Runtime.InteropServices
Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents cmdShow As System.Windows.Forms.Button
      Friend WithEvents CmdHide As System.Windows.Forms.Button
      Friend WithEvents cmdSetCursor As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.cmdShow = New System.Windows.Forms.Button
Me.CmdHide = New System.Windows.Forms.Button
Me.cmdSetCursor = New System.Windows.Forms.Button
'
'cmdShow
'
Me.cmdShow.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdShow.Location = New System.Drawing.Point(48, 48)
Me.cmdShow.Size = New System.Drawing.Size(136, 20)
Me.cmdShow.Text = "Show Wait Cursor"
'
'CmdHide
'
Me.CmdHide.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.CmdHide.Location = New System.Drawing.Point(48, 80)
Me.CmdHide.Size = New System.Drawing.Size(136, 20)
Me.CmdHide.Text = "Hide Wait Cursor"
'
'cmdSetCursor
'
Me.cmdSetCursor.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdSetCursor.Location = New System.Drawing.Point(48, 176)
Me.cmdSetCursor.Size = New System.Drawing.Size(136, 20)
Me.cmdSetCursor.Text = "Call SetCursor"
'
'FormMain
'
Me.Controls.Add(Me.cmdSetCursor)
Me.Controls.Add(Me.CmdHide)
Me.Controls.Add(Me.cmdShow)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Wait Cursor"

    End Sub

#End Region

      Shared Sub Main()
         Application.Run(New FormMain)
      End Sub

   <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
   Public Shared Function LoadCursor( _
      ByVal hInstance As IntPtr _
      , ByVal lpCursorName As Integer _
      ) As IntPtr
   End Function

   <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
   Public Shared Function SetCursor( _
      ByVal hCursor As IntPtr _
      ) As IntPtr
   End Function

   <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
   Public Shared Sub Sleep( _
      ByVal dwMilliseconds As Integer)
   End Sub

   Public Const IDC_WAIT As Integer = 32514
   Public Const IDC_ARROW As Integer = 32512
   Public Const IDC_IBEAM As Integer = 32513
   Public Const IDC_CROSS As Integer = 32515
   Public Const IDC_UPARROW As Integer = 32516
   Public Const IDC_NO As Integer = 32648
   Public Const IDC_HELP As Integer = 32651
   Public Const IDC_HAND As Integer = 32649

   Private Sub cmdShow_Click(ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdShow.Click
      ' Display wait cursor.
      Cursor.Current = Cursors.WaitCursor
   End Sub

   Private Sub CmdHide_Click(ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles CmdHide.Click
      ' Display default cursor (or no cursor for Pocket PC)
      Cursor.Current = Cursors.Default
   End Sub

   Private Sub cmdSetCursor_Click(ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdSetCursor.Click
      ' Get button text.
      Dim strButtonText As String = cmdSetCursor.Text

      ' Create table of cursor IDs and names.
      Dim ht As Hashtable = New Hashtable
      ht.Add(IDC_WAIT, "IDC_WAIT")
      ht.Add(IDC_ARROW, "IDC_ARROW")
      ht.Add(IDC_IBEAM, "IDC_IBEAM")
      ht.Add(IDC_CROSS, "IDC_CROSS")
      ht.Add(IDC_UPARROW, "IDC_UPARROW")
      ht.Add(IDC_NO, "IDC_NO")
      ht.Add(IDC_HELP, "IDC_HELP")
      ht.Add(IDC_HAND, "IDC_HAND")

      For Each oKey As Object In ht.Keys
            Dim iCursor As Integer = oKey
            SetCursor(LoadCursor(IntPtr.Zero, iCursor))
            cmdSetCursor.Text = ht(oKey).ToString()

            ' Pause for one second
            Sleep(1000)
      Next

      ' Display default cursor (no cursor for Pocket PC)
      Cursor.Current = Cursors.Default
      cmdSetCursor.Text = strButtonText

   End Sub
End Class
