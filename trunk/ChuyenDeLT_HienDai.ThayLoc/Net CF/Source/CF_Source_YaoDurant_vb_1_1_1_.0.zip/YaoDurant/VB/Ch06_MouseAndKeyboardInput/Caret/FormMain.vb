' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Runtime.InteropServices

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents Label1 As System.Windows.Forms.Label
      Friend WithEvents Label2 As System.Windows.Forms.Label
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents textWidth As System.Windows.Forms.TextBox
      Friend WithEvents textHeight As System.Windows.Forms.TextBox
      Friend WithEvents textBlinkTime As System.Windows.Forms.TextBox
      Friend WithEvents cmdSetFocus As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.Label1 = New System.Windows.Forms.Label
Me.Label2 = New System.Windows.Forms.Label
Me.label3 = New System.Windows.Forms.Label
Me.textWidth = New System.Windows.Forms.TextBox
Me.textHeight = New System.Windows.Forms.TextBox
Me.textBlinkTime = New System.Windows.Forms.TextBox
Me.cmdSetFocus = New System.Windows.Forms.Button
'
'Label1
'
Me.Label1.Location = New System.Drawing.Point(51, 56)
Me.Label1.Size = New System.Drawing.Size(48, 20)
Me.Label1.Text = "Width:"
'
'Label2
'
Me.Label2.Location = New System.Drawing.Point(48, 88)
Me.Label2.Size = New System.Drawing.Size(48, 20)
Me.Label2.Text = "Height:"
'
'label3
'
Me.label3.Location = New System.Drawing.Point(29, 120)
Me.label3.Size = New System.Drawing.Size(67, 20)
Me.label3.Text = "Blink Time:"
'
'textWidth
'
Me.textWidth.Location = New System.Drawing.Point(104, 54)
Me.textWidth.Size = New System.Drawing.Size(72, 22)
Me.textWidth.Text = "2"
'
'textHeight
'
Me.textHeight.Location = New System.Drawing.Point(104, 86)
Me.textHeight.Size = New System.Drawing.Size(72, 22)
Me.textHeight.Text = "16"
'
'textBlinkTime
'
Me.textBlinkTime.Location = New System.Drawing.Point(104, 118)
Me.textBlinkTime.Size = New System.Drawing.Size(72, 22)
'
'cmdSetFocus
'
Me.cmdSetFocus.Location = New System.Drawing.Point(48, 176)
Me.cmdSetFocus.Size = New System.Drawing.Size(160, 20)
Me.cmdSetFocus.Text = "Set Focus to Form"
'
'FormMain
'
Me.Controls.Add(Me.cmdSetFocus)
Me.Controls.Add(Me.textBlinkTime)
Me.Controls.Add(Me.textHeight)
Me.Controls.Add(Me.textWidth)
Me.Controls.Add(Me.label3)
Me.Controls.Add(Me.Label2)
Me.Controls.Add(Me.Label1)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Caret"

    End Sub

#End Region

   Private Sub cmdSetFocus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSetFocus.Click
      Me.Focus()
   End Sub

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function CreateCaret( _
   ByVal hWnd As IntPtr _
   , ByVal hBitmap As IntPtr _
   , ByVal nWidth As Integer _
   , ByVal nHeight As Integer _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function SetCaretPos( _
   ByVal X As Integer _
   , ByVal Y As Integer _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function ShowCaret( _
   ByVal hWnd As IntPtr _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function HideCaret( _
   ByVal hWnd As IntPtr _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function DestroyCaret( _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function GetCaretPos( _
   ByRef lpPoint As System.Drawing.Point _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function GetCaretBlinkTime( _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function SetCaretBlinkTime( _
   ByVal uMSeconds As Integer _
   ) As Integer
End Function

<DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
Public Shared Function GetFocus( _
   ) As IntPtr
End Function

Private Sub FormMain_GotFocus(ByVal sender As System.Object, _
ByVal e As System.EventArgs) _ Handles MyBase.GotFocus
   Dim cxWidth As Integer
   Dim cyHeight As Integer
   Dim msBlinkTime As Integer

   ' Parse caret width
   Try
      cxWidth = Integer.Parse(textWidth.Text)
   Catch ex As Exception
      cxWidth = 2
      textWidth.Text = "2"
   End Try

   ' Parse caret height
   Try
      cyHeight = Integer.Parse(textHeight.Text)
   Catch ex As Exception
      cyHeight = 20
      textHeight.Text = "20"
   End Try

   ' Parse caret blink time
   Try
      msBlinkTime = Integer.Parse(textBlinkTime.Text)
   Catch ex As Exception
      msBlinkTime = GetCaretBlinkTime()
      textBlinkTime.Text = msBlinkTime.ToString()
   End Try

   Dim hwnd As IntPtr = GetFocus()
   CreateCaret(hwnd, IntPtr.Zero, cxWidth, cyHeight)
   SetCaretPos(10, 10)
   SetCaretBlinkTime(msBlinkTime)
   ShowCaret(hwnd)
End Sub

Private Sub FormMain_LostFocus(ByVal sender As System.Object, _
ByVal e As System.EventArgs) Handles MyBase.LostFocus
   Dim hwnd As IntPtr = GetFocus()
   HideCaret(hwnd)
   DestroyCaret()
End Sub

Private Sub FormMain_MouseDown(ByVal sender As System.Object, _
ByVal e As System.Windows.Forms.MouseEventArgs) _
Handles MyBase.MouseDown
   SetCaretPos(e.X, e.Y)
End Sub

Private Sub FormMain_KeyDown(ByVal sender As System.Object, _
ByVal e As System.Windows.Forms.KeyEventArgs) _
Handles MyBase.KeyDown
   Dim ptCaret As Point = New Point
   GetCaretPos( ptCaret)

   Select Case e.KeyCode
      Case Keys.Left
         ptCaret.X = ptCaret.X - 10
      Case Keys.Right
         ptCaret.X = ptCaret.X + 10
      Case Keys.Up
         ptCaret.Y = ptCaret.Y - 10
      Case Keys.Down
         ptCaret.Y = ptCaret.Y + 10
   End Select

   ' Make sure that caret stays in the window.
   If ptCaret.X < 0 Then
         ptCaret.X = 0
   End If
   If ptCaret.Y < 0 Then
         ptCaret.Y = 0
   End If

   Dim cxCaretWidth As Integer
   Try
      cxCaretWidth = Integer.Parse(textWidth.Text)
   Catch
      cxCaretWidth = 2
      textWidth.Text = cxCaretWidth.ToString()
   End Try
   Dim cyCaretHeight As Integer
   Try
      cyCaretHeight = Integer.Parse(textHeight.Text)
   Catch
      cyCaretHeight = 20
      textHeight.Text = cyCaretHeight.ToString()
   End Try

   If (ptCaret.X + cxCaretWidth) > Me.Width Then
      ptCaret.X = Me.Width - cxCaretWidth
   End If
   If (ptCaret.Y + cyCaretHeight) > Me.Height Then
      ptCaret.Y = Me.Height - cyCaretHeight
   End If

   ' Move caret to new position.
   SetCaretPos(ptCaret.X, ptCaret.Y)
End Sub

End Class
