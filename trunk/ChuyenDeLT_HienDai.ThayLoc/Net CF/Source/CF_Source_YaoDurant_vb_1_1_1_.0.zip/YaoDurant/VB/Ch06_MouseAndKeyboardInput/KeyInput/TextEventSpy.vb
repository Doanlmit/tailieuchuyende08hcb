' TextEventSpy.vb - Custom control which echoes keyboard event
' information.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Namespace KeyInput
   Public Enum EventType
      Event_KeyDown
      Event_KeyPress
      Event_KeyUp
      Event_GotFocus
      Event_LostFocus
   End Enum

   ' Buffer for passing event info to form.
   Public Structure KeyEventItem
      Public etype As EventType
      Public eUpDown As KeyEventArgs
      Public ePress As KeyPressEventArgs
   End Structure

   Public Class TextEventSpy
   Inherits System.Windows.Forms.TextBox

      Private m_kei As KeyEventItem = New KeyEventItem
      ' Inter-thread control
      Private m_ctrlInvokeTarget As Control
      ' Inter-thread delegate
      Private m_deleCallback As EventHandler

      Public ReadOnly Property kei() As KeyEventItem
         Get
               Return m_kei
         End Get
      End Property

      Public Sub New(ByVal ctrl As Control, ByVal dele As EventHandler)
         MyBase.New()

         m_ctrlInvokeTarget = ctrl  ' Who to call.
         m_deleCallback = dele    ' How to call.
      End Sub

      Protected Overrides Sub _
      OnKeyDown(ByVal e As KeyEventArgs)
         ' Add new event info to list.
         m_kei.etype = EventType.Event_KeyDown
         m_kei.eUpDown = e

         ' Trigger "new event" notification
         m_ctrlInvokeTarget.Invoke(m_deleCallback)

         MyBase.OnKeyDown(e)
      End Sub


      Protected Overrides Sub _
      OnKeyPress(ByVal e As KeyPressEventArgs)
         ' Add new event info to list.
         m_kei.etype = EventType.Event_KeyPress
         m_kei.ePress = e

         ' Trigger "new event" notification
         m_ctrlInvokeTarget.Invoke(m_deleCallback)

         MyBase.OnKeyPress(e)
      End Sub

      Protected Overrides Sub _
      OnKeyUp(ByVal e As KeyEventArgs)
         ' Add new event info to list.
         m_kei.etype = EventType.Event_KeyUp
         m_kei.eUpDown = e

         ' Trigger "new event" notification
         m_ctrlInvokeTarget.Invoke(m_deleCallback)

         MyBase.OnKeyUp(e)
      End Sub

      Protected Overrides Sub _
      OnGotFocus(ByVal e As System.EventArgs)
         ' Add new event info to list.
         m_kei.etype = EventType.Event_GotFocus

         ' Trigger "new event" notification
         m_ctrlInvokeTarget.Invoke(m_deleCallback)

         MyBase.OnGotFocus(e)

      End Sub

      Protected Overrides Sub _
      OnLostFocus(ByVal e As System.EventArgs)
         ' Add new event info to list.
         m_kei.etype = EventType.Event_LostFocus

         ' Trigger "new event" notification
         m_ctrlInvokeTarget.Invoke(m_deleCallback)

         MyBase.OnLostFocus(e)

      End Sub
   End Class
End Namespace
