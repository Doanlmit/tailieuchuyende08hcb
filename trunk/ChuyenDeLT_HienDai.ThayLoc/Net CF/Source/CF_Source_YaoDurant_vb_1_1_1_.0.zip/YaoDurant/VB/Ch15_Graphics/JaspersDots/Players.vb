' Players.vb - Structure for player info.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Drawing

Public Class Players
   Public strName1 As String
   Public strName2 As String
   Public bComputerPlaying As Boolean
   Public clr1 As System.Drawing.Color
   Public clr2 As System.Drawing.Color
End Class

