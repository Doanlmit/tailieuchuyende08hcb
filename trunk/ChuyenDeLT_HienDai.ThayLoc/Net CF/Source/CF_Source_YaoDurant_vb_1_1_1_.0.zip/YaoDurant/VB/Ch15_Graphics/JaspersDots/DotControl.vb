' DotControl.vb - Custom control for JaspersDots game.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Drawing
Imports System.Windows.Forms

Public Class DotControl
Inherits System.Windows.Forms.Control
   Private formParent As FormMain
   Private m_brPlayer1 As Brush
   Private m_brPlayer2 As Brush
   Private sq As Squares

   Sub New(ByVal form As FormMain)
      formParent = form

      formParent.Controls.Add(Me)
      Me.Left = 0
      Me.Top = 64
      Me.Width = 240
      Me.Height = 240

      sq = New Squares(Me)
   End Sub

   Public Function SetGridSize( _
   ByVal cxWidth As Integer, _
   ByVal cyHeight As Integer) As Boolean
      Return sq.SetGridSize(cxWidth, cyHeight)
   End Function

   Public Function SetPlayerColors( _
   ByVal clr1 As Color, _
   ByVal clr2 As Color) As Boolean
      m_brPlayer1 = New SolidBrush(clr1)
      m_brPlayer2 = New SolidBrush(clr2)

      Return sq.SetPlayerBrushes(m_brPlayer1, m_brPlayer2)
   End Function


   Private Sub DotControl_MouseDown( _
   ByVal sender As Object, _
   ByVal e As MouseEventArgs) Handles MyBase.MouseDown

      ' Check result.
      Dim iResult As Integer = sq.HitTest(e.X, e.Y, _
         formParent.CurrentPlayer)

      ' Click on available line, no score.
      If iResult = 1 Then
         formParent.NextPlayer()
      End If

      ' Click on available line, score.
      If iResult = 2 Then
         Dim iScore1 As Integer = sq.GetScore(1)
         formParent.DisplayScore(1, iScore1)
         Dim iScore2 As Integer = sq.GetScore(2)
         formParent.DisplayScore(2, iScore2)

         Dim count As Integer = sq.Height * sq.Width
         If iScore1 + iScore2 = count Then
            Dim strResult As String = Nothing

            If iScore1 > iScore2 Then
               strResult = "Player 1 wins!"
            ElseIf iScore1 < iScore2 Then
               strResult = "Player 2 wins!"
            Else
               strResult = "Tie Game!"
            End If

            MessageBox.Show(strResult, "JaspersDots")
         End If
      End If

   End Sub

   Private Sub DotControl_Paint( _
   ByVal sender As Object, _
   ByVal e As PaintEventArgs) Handles MyBase.Paint
      ' Fill squares which players now own.
      sq.FillSquares(e.Graphics)

      ' Draw lines which players have selected.
      sq.DrawLines(e.Graphics)

      ' Draw dots in grid.
      sq.DrawDots(e.Graphics)

   End Sub
End Class
