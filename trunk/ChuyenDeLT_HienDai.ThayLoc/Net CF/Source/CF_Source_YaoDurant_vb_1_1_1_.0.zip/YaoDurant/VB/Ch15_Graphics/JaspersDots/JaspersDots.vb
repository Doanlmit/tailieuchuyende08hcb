' JaspersDots.cs - Main form for JaspersDots game.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.Windows.Forms
Imports System.Data

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents panelCurrPlayer As System.Windows.Forms.Panel
      Friend WithEvents labelCurrPlayer As System.Windows.Forms.Label
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemGameNew As System.Windows.Forms.MenuItem
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents panel1 As System.Windows.Forms.Panel
      Friend WithEvents label_Score1 As System.Windows.Forms.Label
      Friend WithEvents label5 As System.Windows.Forms.Label
      Friend WithEvents label_Name1 As System.Windows.Forms.Label
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents panel2 As System.Windows.Forms.Panel
      Friend WithEvents label_Score2 As System.Windows.Forms.Label
      Friend WithEvents label6 As System.Windows.Forms.Label
      Friend WithEvents label_Name2 As System.Windows.Forms.Label
      Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu


    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
         ' Create dot control.
         m_dot = New DotControl(Me)

         ' Create and display new game dialog.
         dlgGameNew = New GameNewDialog(Me)
         mitemGameNew_Click(Me, New EventArgs)

    End Sub
#Region " Windows Form Designer generated code "

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.panelCurrPlayer = New System.Windows.Forms.Panel
Me.labelCurrPlayer = New System.Windows.Forms.Label
Me.label3 = New System.Windows.Forms.Label
Me.menuItem1 = New System.Windows.Forms.MenuItem
Me.mitemGameNew = New System.Windows.Forms.MenuItem
Me.menuMain = New System.Windows.Forms.MainMenu
Me.panel1 = New System.Windows.Forms.Panel
Me.label_Score1 = New System.Windows.Forms.Label
Me.label5 = New System.Windows.Forms.Label
Me.label_Name1 = New System.Windows.Forms.Label
Me.label1 = New System.Windows.Forms.Label
Me.panel2 = New System.Windows.Forms.Panel
Me.label_Score2 = New System.Windows.Forms.Label
Me.label6 = New System.Windows.Forms.Label
Me.label_Name2 = New System.Windows.Forms.Label
Me.label2 = New System.Windows.Forms.Label
'
'panelCurrPlayer
'
Me.panelCurrPlayer.Controls.Add(Me.labelCurrPlayer)
Me.panelCurrPlayer.Controls.Add(Me.label3)
Me.panelCurrPlayer.Location = New System.Drawing.Point(0, 56)
Me.panelCurrPlayer.Size = New System.Drawing.Size(240, 16)
'
'labelCurrPlayer
'
Me.labelCurrPlayer.Location = New System.Drawing.Point(128, 0)
'
'label3
'
Me.label3.Location = New System.Drawing.Point(40, 0)
Me.label3.Size = New System.Drawing.Size(88, 16)
Me.label3.Text = "Current Player:"
'
'menuItem1
'
Me.menuItem1.MenuItems.Add(Me.mitemGameNew)
Me.menuItem1.Text = "Game"
'
'mitemGameNew
'
Me.mitemGameNew.Text = "New Game"
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.menuItem1)
'
'panel1
'
Me.panel1.Controls.Add(Me.label_Score1)
Me.panel1.Controls.Add(Me.label5)
Me.panel1.Controls.Add(Me.label_Name1)
Me.panel1.Controls.Add(Me.label1)
Me.panel1.Size = New System.Drawing.Size(120, 56)
'
'label_Score1
'
Me.label_Score1.Location = New System.Drawing.Point(80, 32)
Me.label_Score1.Size = New System.Drawing.Size(24, 20)
Me.label_Score1.Text = "0"
'
'label5
'
Me.label5.Font = New System.Drawing.Font("Tahoma", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
Me.label5.Location = New System.Drawing.Point(24, 32)
Me.label5.Size = New System.Drawing.Size(56, 20)
Me.label5.Text = "Score:"
'
'label_Name1
'
Me.label_Name1.Location = New System.Drawing.Point(64, 8)
Me.label_Name1.Size = New System.Drawing.Size(56, 20)
'
'label1
'
Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
Me.label1.Location = New System.Drawing.Point(0, 8)
Me.label1.Size = New System.Drawing.Size(64, 20)
Me.label1.Text = "Player 1:"
'
'panel2
'
Me.panel2.Controls.Add(Me.label_Score2)
Me.panel2.Controls.Add(Me.label6)
Me.panel2.Controls.Add(Me.label_Name2)
Me.panel2.Controls.Add(Me.label2)
Me.panel2.Location = New System.Drawing.Point(120, 0)
Me.panel2.Size = New System.Drawing.Size(120, 56)
'
'label_Score2
'
Me.label_Score2.Location = New System.Drawing.Point(80, 32)
Me.label_Score2.Size = New System.Drawing.Size(24, 20)
Me.label_Score2.Text = "0"
'
'label6
'
Me.label6.Font = New System.Drawing.Font("Tahoma", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
Me.label6.Location = New System.Drawing.Point(24, 32)
Me.label6.Size = New System.Drawing.Size(48, 20)
Me.label6.Text = "Score:"
'
'label_Name2
'
Me.label_Name2.Location = New System.Drawing.Point(64, 8)
Me.label_Name2.Size = New System.Drawing.Size(64, 20)
'
'label2
'
Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
Me.label2.Location = New System.Drawing.Point(0, 8)
Me.label2.Size = New System.Drawing.Size(64, 20)
Me.label2.Text = "Player 2:"
'
'FormMain
'
Me.Controls.Add(Me.panel1)
Me.Controls.Add(Me.panel2)
Me.Controls.Add(Me.panelCurrPlayer)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "Jasper's Dots"

    End Sub

#End Region

   Public players As players
   Private m_dot As DotControl
   Dim dlgGameNew As GameNewDialog
   Dim m_CurrentPlayer As Integer = 1

   Public Property CurrentPlayer() As Integer
      Get
         Return m_CurrentPlayer
      End Get
      Set(ByVal Value As Integer)
         m_CurrentPlayer = Value
         If m_CurrentPlayer = 1 Then
            panelCurrPlayer.BackColor = players.clr1
            labelCurrPlayer.Text = players.strName1
         ElseIf m_CurrentPlayer = 2 Then
            panelCurrPlayer.BackColor = players.clr2
            labelCurrPlayer.Text = players.strName2
         End If
      End Set
   End Property

   Public Function NextPlayer() As Integer
      If CurrentPlayer = 1 Then
         CurrentPlayer = 2
      Else
         CurrentPlayer = 1
      End If

      Return CurrentPlayer
   End Function

   Public Sub DisplayScore( _
   ByVal iPlayer As Integer, _
   ByVal iScore As Integer)
      If iPlayer = 1 Then
         Me.label_Score1.Text = iScore.ToString()
      End If
      If iPlayer = 2 Then
         Me.label_Score2.Text = iScore.ToString()
      End If
   End Sub

   Private Sub mitemGameNew_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemGameNew.Click
      dlgGameNew.ShowDialog()

      Me.Focus()

      ' Initialize display of player info
      label_Name1.Text = players.strName1
      label_Name2.Text = players.strName2
      panel1.BackColor = players.clr1
      panel2.BackColor = players.clr2

      Dim cx As Integer = dlgGameNew.cxWidth
      Dim cy As Integer = dlgGameNew.cyHeight

      ' Initialize dot control.
      m_dot.SetPlayerColors(players.clr1, players.clr2)
      m_dot.SetGridSize(cx, cy)

      ' Set starting player.
      CurrentPlayer = 1
      Me.BackColor = players.clr1

   End Sub
End Class
