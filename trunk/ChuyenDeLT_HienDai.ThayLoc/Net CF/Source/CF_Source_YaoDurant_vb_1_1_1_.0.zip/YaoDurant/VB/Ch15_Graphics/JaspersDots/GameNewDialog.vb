' GameNewDialog.vb - New Game dialog for JaspersDots game.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms

Public Class GameNewDialog
    Inherits System.Windows.Forms.Form
      Public WithEvents textHeight As System.Windows.Forms.TextBox
      Friend WithEvents label6 As System.Windows.Forms.Label
      Public WithEvents textWidth As System.Windows.Forms.TextBox
      Friend WithEvents label5 As System.Windows.Forms.Label
      Friend WithEvents panelE As System.Windows.Forms.Panel
      Friend WithEvents panelD As System.Windows.Forms.Panel
      Friend WithEvents panelC As System.Windows.Forms.Panel
      Friend WithEvents panelB As System.Windows.Forms.Panel
      Friend WithEvents panelA As System.Windows.Forms.Panel
      Friend WithEvents panel5 As System.Windows.Forms.Panel
      Friend WithEvents panel4 As System.Windows.Forms.Panel
      Friend WithEvents panel3 As System.Windows.Forms.Panel
      Friend WithEvents panel2 As System.Windows.Forms.Panel
      Friend WithEvents panel1 As System.Windows.Forms.Panel
      Friend WithEvents label4 As System.Windows.Forms.Label
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents textPlayer2 As System.Windows.Forms.TextBox
      Friend WithEvents textPlayer1 As System.Windows.Forms.TextBox
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents label1 As System.Windows.Forms.Label


    Public Sub New(ByVal form As FormMain)
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        formParent = form

    End Sub

#Region " Windows Form Designer generated code "

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.textHeight = New System.Windows.Forms.TextBox
Me.label6 = New System.Windows.Forms.Label
Me.textWidth = New System.Windows.Forms.TextBox
Me.label5 = New System.Windows.Forms.Label
Me.panelE = New System.Windows.Forms.Panel
Me.panelD = New System.Windows.Forms.Panel
Me.panelC = New System.Windows.Forms.Panel
Me.panelB = New System.Windows.Forms.Panel
Me.panelA = New System.Windows.Forms.Panel
Me.panel5 = New System.Windows.Forms.Panel
Me.panel4 = New System.Windows.Forms.Panel
Me.panel3 = New System.Windows.Forms.Panel
Me.panel2 = New System.Windows.Forms.Panel
Me.panel1 = New System.Windows.Forms.Panel
Me.label4 = New System.Windows.Forms.Label
Me.label3 = New System.Windows.Forms.Label
Me.textPlayer2 = New System.Windows.Forms.TextBox
Me.textPlayer1 = New System.Windows.Forms.TextBox
Me.label2 = New System.Windows.Forms.Label
Me.label1 = New System.Windows.Forms.Label
Me.MainMenu1 = New System.Windows.Forms.MainMenu
'
'textHeight
'
Me.textHeight.Location = New System.Drawing.Point(150, 230)
Me.textHeight.Size = New System.Drawing.Size(24, 26)
Me.textHeight.Text = "8"
'
'label6
'
Me.label6.Location = New System.Drawing.Point(126, 230)
Me.label6.Size = New System.Drawing.Size(24, 20)
Me.label6.Text = "x"
'
'textWidth
'
Me.textWidth.Location = New System.Drawing.Point(94, 230)
Me.textWidth.Size = New System.Drawing.Size(24, 26)
Me.textWidth.Text = "8"
'
'label5
'
Me.label5.Location = New System.Drawing.Point(22, 230)
Me.label5.Size = New System.Drawing.Size(72, 20)
Me.label5.Text = "Grid size:"
'
'panelE
'
Me.panelE.BackColor = System.Drawing.Color.Magenta
Me.panelE.Location = New System.Drawing.Point(190, 190)
Me.panelE.Size = New System.Drawing.Size(24, 24)
'
'panelD
'
Me.panelD.BackColor = System.Drawing.Color.Cyan
Me.panelD.Location = New System.Drawing.Point(150, 190)
Me.panelD.Size = New System.Drawing.Size(24, 24)
'
'panelC
'
Me.panelC.BackColor = System.Drawing.Color.CornflowerBlue
Me.panelC.Location = New System.Drawing.Point(110, 190)
Me.panelC.Size = New System.Drawing.Size(24, 24)
'
'panelB
'
Me.panelB.BackColor = System.Drawing.Color.LawnGreen
Me.panelB.Location = New System.Drawing.Point(70, 190)
Me.panelB.Size = New System.Drawing.Size(24, 24)
'
'panelA
'
Me.panelA.BackColor = System.Drawing.Color.Salmon
Me.panelA.Location = New System.Drawing.Point(30, 190)
Me.panelA.Size = New System.Drawing.Size(24, 24)
'
'panel5
'
Me.panel5.BackColor = System.Drawing.Color.Magenta
Me.panel5.Location = New System.Drawing.Point(190, 78)
Me.panel5.Size = New System.Drawing.Size(24, 24)
'
'panel4
'
Me.panel4.BackColor = System.Drawing.Color.Cyan
Me.panel4.Location = New System.Drawing.Point(150, 78)
Me.panel4.Size = New System.Drawing.Size(24, 24)
'
'panel3
'
Me.panel3.BackColor = System.Drawing.Color.CornflowerBlue
Me.panel3.Location = New System.Drawing.Point(110, 78)
Me.panel3.Size = New System.Drawing.Size(24, 24)
'
'panel2
'
Me.panel2.BackColor = System.Drawing.Color.LawnGreen
Me.panel2.Location = New System.Drawing.Point(70, 78)
Me.panel2.Size = New System.Drawing.Size(24, 24)
'
'panel1
'
Me.panel1.BackColor = System.Drawing.Color.Salmon
Me.panel1.Location = New System.Drawing.Point(30, 78)
Me.panel1.Size = New System.Drawing.Size(24, 24)
'
'label4
'
Me.label4.Location = New System.Drawing.Point(22, 158)
Me.label4.Text = "Pick Color:"
'
'label3
'
Me.label3.Location = New System.Drawing.Point(22, 46)
Me.label3.Text = "Pick Color:"
'
'textPlayer2
'
Me.textPlayer2.Location = New System.Drawing.Point(126, 126)
Me.textPlayer2.Size = New System.Drawing.Size(88, 26)
Me.textPlayer2.Text = "P2"
'
'textPlayer1
'
Me.textPlayer1.Location = New System.Drawing.Point(118, 14)
Me.textPlayer1.Text = "P1"
'
'label2
'
Me.label2.Location = New System.Drawing.Point(22, 126)
Me.label2.Size = New System.Drawing.Size(88, 20)
Me.label2.Text = "Player 2:"
'
'label1
'
Me.label1.Location = New System.Drawing.Point(22, 14)
Me.label1.Size = New System.Drawing.Size(88, 20)
Me.label1.Text = "Player 1:"
'
'GameNewDialog
'
Me.Controls.Add(Me.textHeight)
Me.Controls.Add(Me.label6)
Me.Controls.Add(Me.textWidth)
Me.Controls.Add(Me.label5)
Me.Controls.Add(Me.panelE)
Me.Controls.Add(Me.panelD)
Me.Controls.Add(Me.panelC)
Me.Controls.Add(Me.panelB)
Me.Controls.Add(Me.panelA)
Me.Controls.Add(Me.panel5)
Me.Controls.Add(Me.panel4)
Me.Controls.Add(Me.panel3)
Me.Controls.Add(Me.panel2)
Me.Controls.Add(Me.panel1)
Me.Controls.Add(Me.label4)
Me.Controls.Add(Me.label3)
Me.Controls.Add(Me.textPlayer2)
Me.Controls.Add(Me.textPlayer1)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.label1)
Me.Menu = Me.MainMenu1
Me.Text = "Jasper's Dots"

    End Sub

#End Region

   Private formParent As FormMain
   Private iColor1 As Integer
   Private clr1 As Color
   Private iColor2 As Integer
   Private clr2 As Color
   Public cxWidth As Integer
   Public cyHeight As Integer

   Private Sub GameNewDialog_Load( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Load
      formParent.Visible = False
   End Sub

   Private Sub GameNewDialog_Closed( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Closed
      formParent.Visible = True
   End Sub

   Private Sub GameNewDialog_Closing( _
   ByVal sender As Object, _
   ByVal e As CancelEventArgs) Handles MyBase.Closing
      ' Make sure players each have a different color.
      If iColor1 = iColor2 Then
         MessageBox.Show("Players picked the same color.\n" + _
            "Please pick a unique color for each player.", _
            "JaspersDots")
         e.Cancel = True
      End If

      ' Make sure game board is no larger than 9x11
      Dim cx As Integer
      Dim cy As Integer
      Try
         cx = Integer.Parse(textWidth.Text)
      Catch
         cx = -1
      End Try

      Try
         cy = Integer.Parse(textHeight.Text)
      Catch
         cy = -1
      End Try

      If cx <= 0 Or cy <= 0 Then
         MessageBox.Show("Bad grid size -- switching to 8x8", _
         "JaspersDots")
         cx = 8
         cy = 8
      End If

      If cx > 11 Then
         MessageBox.Show("Max width is 11", "JaspersDots")
         e.Cancel = True
         Return
      End If

      If cy > 9 Then
         MessageBox.Show("Max height is 9", "JaspersDots")
         e.Cancel = True
         Return
      End If

      cxWidth = cx
      cyHeight = cy

      formParent.players = New Players
      formParent.players.clr1 = clr1
      formParent.players.clr2 = clr2
      formParent.players.strName1 = textPlayer1.Text
      formParent.players.strName2 = textPlayer2.Text

   End Sub

   Private Sub panel1_Click( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) _
   Handles panel1.Click, panel2.Click, _
   panel3.Click, panel4.Click, panel5.Click
      If sender Is panel1 Then
         iColor1 = 0
      ElseIf sender Is panel2 Then
         iColor1 = 1
      ElseIf sender Is panel3 Then
         iColor1 = 2
      ElseIf sender Is panel4 Then
         iColor1 = 3
      ElseIf sender Is panel5 Then
         iColor1 = 4
      End If

      ' Redraw window
      Invalidate()

   End Sub

   Private Sub panel2_Click( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) _
   Handles panelA.Click, panelB.Click, _
   panelC.Click, panelD.Click, panelE.Click
      If sender Is panelA Then
         iColor2 = 0
      ElseIf sender Is panelB Then
         iColor2 = 1
      ElseIf sender Is panelC Then
         iColor2 = 2
      ElseIf sender Is panelD Then
         iColor2 = 3
      ElseIf sender Is panelE Then
         iColor2 = 4
      End If

      ' Redraw window
      Invalidate()

   End Sub

   Private Sub GameNewDialog_Paint( _
   ByVal sender As Object, _
   ByVal e As PaintEventArgs) Handles MyBase.Paint
      Dim panel As Panel = panel1

      '
      ' Player 1
      '
      ' What is current player 1 panel?
      Select Case iColor1
         Case 0
            panel = panel1
         Case 1
            panel = panel2
         Case 2
            panel = panel3
         Case 3
            panel = panel4
         Case 4
            panel = panel5
      End Select
      clr1 = panel.BackColor

      ' Draw rectangle around color selected by player 1.
      Dim penBlack As Pen = New Pen(Color.Black)
      Dim rc As Rectangle = New _
            Rectangle(panel.Left - 3, _
            panel.Top - 3, _
            panel.Width + 5, _
            panel.Height + 5)
      e.Graphics.DrawRectangle(penBlack, rc)
      rc.Inflate(1, 1)
      e.Graphics.DrawRectangle(penBlack, rc)
      rc.Inflate(1, 1)
      e.Graphics.DrawRectangle(penBlack, rc)

      '
      ' Player 2
      '
      ' What is current player 2 panel?
      Select Case iColor2
         Case 0
            panel = panelA
         Case 1
            panel = panelB
         Case 2
            panel = panelC
         Case 3
            panel = panelD
         Case 4
            panel = panelE
      End Select
      clr2 = panel.BackColor

      ' Draw rectangle around color selected by player 2.
      rc = New Rectangle(panel.Left - 3, _
            panel.Top - 3, _
            panel.Width + 5, _
            panel.Height + 5)
      e.Graphics.DrawRectangle(penBlack, rc)
      rc.Inflate(1, 1)
      e.Graphics.DrawRectangle(penBlack, rc)
      rc.Inflate(1, 1)
      e.Graphics.DrawRectangle(penBlack, rc)

   End Sub
End Class
