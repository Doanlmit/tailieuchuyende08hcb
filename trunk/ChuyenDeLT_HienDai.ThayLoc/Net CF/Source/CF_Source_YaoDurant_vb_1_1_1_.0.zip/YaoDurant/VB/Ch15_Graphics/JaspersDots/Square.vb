' Square.vb - Elements of a game square.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System.Drawing

Public Structure Square
   ' Coordinate of main rectangle.
   Public rcMain As Rectangle
   Public iOwner As Integer

   ' Hit-rectangles of four edges of main rectangle.
   Public rcTop As Rectangle
   Public bTop As Boolean
   Public rcRight As Rectangle
   Public bRight As Boolean
   Public rcBottom As Rectangle
   Public bBottom As Boolean
   Public rcLeft As Rectangle
   Public bLeft As Boolean
End Structure
