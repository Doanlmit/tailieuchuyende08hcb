Namespace YaoDurant.CFBook.Utilities

   Public Class WaterMath

      '  Constants
      Private Const GALLONS_PER_FOOT As Double = 7.48
      Private Const INCHES_PER_FOOT As Integer = 12

      Public Shared Function _
               GetVolume(ByVal dblSquareFeet As Double _
                         ) _
                         As Integer
         '  This version of GetVolume 
         '     assumes 1 inch of rain.
         Return dblSquareFeet * GALLONS_PER_FOOT _
                              / INCHES_PER_FOOT
      End Function

      Public Shared Function _
               GetVolume(ByVal dblSquareFeet As Double, _
                         ByVal intInches As Integer _
                         ) _
                         As Integer
         '  This version of GetVolume 
         '     accepts both roof size and rainfall.
         Return dblSquareFeet * GALLONS_PER_FOOT * intInches _
                              / INCHES_PER_FOOT
      End Function

   End Class

End Namespace


