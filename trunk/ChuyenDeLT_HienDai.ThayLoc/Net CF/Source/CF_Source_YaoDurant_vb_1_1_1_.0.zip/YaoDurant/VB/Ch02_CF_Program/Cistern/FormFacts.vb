' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Windows.Forms

Public Class FormFacts
   Inherits System.Windows.Forms.Form

   Friend lblHeader As System.Windows.Forms.Label

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.lblHeader = New System.Windows.Forms.Label
      '
      'lblHeader
      '
      Me.lblHeader.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblHeader.Size = New System.Drawing.Size(80, 32)
      Me.lblHeader.Text = "Water Facts"
      '
      'FormFacts
      '
      Me.Controls.Add(Me.lblHeader)
      Me.Text = "FormFacts"

   End Sub

#End Region

   '  An array of information to be displayed in this Form.
   Private strFacts As String() = New String() { _
               "1 cu ft water = 7.48 gal", _
               "1 gal water = 8.34 lbs", _
               "1 cu ft water = 62.38 lbs", _
               "1 in rain on 1000 sqft roof = 623 gal", _
               "Avg annual Seattle rainfall = 35 in", _
               "Est runoff from Seattlite who stands " & _
                     "in rain for 1 year = 22 gal"}

   Private Sub FormFacts_Load( _
                              ByVal sender As System.Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles MyBase.Load
      '  A Bounds variable to hold the position
      '     of the next label to be created.
      Dim bndsNext As Rectangle
      With lblHeader
         bndsNext = New Rectangle(.Width / 4, _
                                  .Height + .Height / 4, _
                                  Me.Width - .Width / 4 * 2, _
                                  .Height)
      End With

      '  A reference to the next label to be created.
      Dim lblWork As Label

      '  Iterate through the facts.
      Dim strFact As String
      '  For each one
      For Each strFact In strFacts
         '  Create a label
         '  Position it
         lblWork = New Label
         With lblWork
            .Text = strFact
            .Bounds = bndsNext
         End With

         '  Add it to the Form.
         Me.Controls.Add(lblWork)

         '  The next label goes below this one.
         With bndsNext
            .Y = .Y + (.Height + (.Height / 4))
         End With
      Next
   End Sub
End Class
