' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.Windows.Forms

Public Class FormMain
   Inherits System.Windows.Forms.Form
   Friend WithEvents lblRoof As System.Windows.Forms.Label
   Friend WithEvents lblRain As System.Windows.Forms.Label
   Friend WithEvents lblAnswer As System.Windows.Forms.Label
   Friend WithEvents lblAnsHeader As System.Windows.Forms.Label
   Friend WithEvents textRoof As System.Windows.Forms.TextBox
   Friend WithEvents textRain As System.Windows.Forms.TextBox
   Friend WithEvents cmdCalc As System.Windows.Forms.Button
   Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents cmdFacts As System.Windows.Forms.Button
   Private Sub InitializeComponent()
      Me.MainMenu1 = New System.Windows.Forms.MainMenu
      Me.lblRoof = New System.Windows.Forms.Label
      Me.lblRain = New System.Windows.Forms.Label
      Me.lblAnswer = New System.Windows.Forms.Label
      Me.textRoof = New System.Windows.Forms.TextBox
      Me.textRain = New System.Windows.Forms.TextBox
      Me.cmdCalc = New System.Windows.Forms.Button
      Me.lblAnsHeader = New System.Windows.Forms.Label
      Me.cmdFacts = New System.Windows.Forms.Button
      '
      'lblRoof
      '
      Me.lblRoof.Location = New System.Drawing.Point(16, 48)
      Me.lblRoof.Size = New System.Drawing.Size(80, 20)
      Me.lblRoof.Text = "Roof (Sq ft)"
      '
      'lblRain
      '
      Me.lblRain.Location = New System.Drawing.Point(144, 48)
      Me.lblRain.Size = New System.Drawing.Size(80, 20)
      Me.lblRain.Text = "Rain (Inches)"
      '
      'lblAnswer
      '
      Me.lblAnswer.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblAnswer.Location = New System.Drawing.Point(88, 144)
      Me.lblAnswer.Size = New System.Drawing.Size(56, 20)
      '
      'textRoof
      '
      Me.textRoof.Location = New System.Drawing.Point(32, 72)
      Me.textRoof.Size = New System.Drawing.Size(48, 22)
      Me.textRoof.Text = ""
      '
      'textRain
      '
      Me.textRain.Location = New System.Drawing.Point(160, 72)
      Me.textRain.Size = New System.Drawing.Size(48, 22)
      Me.textRain.Text = ""
      '
      'cmdCalc
      '
      Me.cmdCalc.Location = New System.Drawing.Point(24, 192)
      Me.cmdCalc.Size = New System.Drawing.Size(64, 24)
      Me.cmdCalc.Text = "Calc"
      '
      'lblAnsHeader
      '
      Me.lblAnsHeader.Location = New System.Drawing.Point(88, 112)
      Me.lblAnsHeader.Size = New System.Drawing.Size(56, 32)
      Me.lblAnsHeader.Text = "Volume (Gallons)"
      '
      'cmdFacts
      '
      Me.cmdFacts.Location = New System.Drawing.Point(144, 192)
      Me.cmdFacts.Size = New System.Drawing.Size(64, 24)
      Me.cmdFacts.Text = "Show"
      '
      'FormMain
      '
      Me.Controls.Add(Me.cmdFacts)
      Me.Controls.Add(Me.lblAnsHeader)
      Me.Controls.Add(Me.cmdCalc)
      Me.Controls.Add(Me.textRain)
      Me.Controls.Add(Me.textRoof)
      Me.Controls.Add(Me.lblAnswer)
      Me.Controls.Add(Me.lblRain)
      Me.Controls.Add(Me.lblRoof)
      Me.Menu = Me.MainMenu1
      Me.Text = "Cistern"

   End Sub

#End Region

   '  Reference to other form.
   Private refFormFacts As Form

   Private Sub cmdCalc_Click(ByVal sender As System.Object, _
                          ByVal e As System.EventArgs _
                          ) _
                          Handles cmdCalc.Click
      '  Use the WaterMath class to calculate the runoff.
      With lblAnswer
         .Text = YaoDurant.CFBook.Utilities. _
                              WaterMath.GetVolume _
                                 (textRoof.Text, textRain.Text)
      End With
   End Sub

   Private Sub cmdFacts_Click(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles cmdFacts.Click
      '  Create an instance of the other form.
      refFormFacts = New Cistern.FormFacts
      '  Then show it.
      With refFormFacts
         .Show()
      End With
   End Sub
End Class

