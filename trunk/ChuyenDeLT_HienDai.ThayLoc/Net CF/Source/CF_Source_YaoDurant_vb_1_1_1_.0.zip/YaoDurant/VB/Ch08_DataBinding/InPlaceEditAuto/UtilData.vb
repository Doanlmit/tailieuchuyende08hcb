' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data

Public Class UtilData
   Inherits System.Object

#Region " Database Structure Simulated "
   Friend Structure Project
      Private m_strIdent As String
      Private m_strName As String
      Private m_dateStart As Date
      Private m_dateEnd As Date
      Private m_ctTasks As Integer
      Private m_strComments As String
      Friend Property strIdent() As String
         Get
            Return m_strIdent
         End Get
         Set(ByVal Value As String)
            m_strIdent = Value
         End Set
      End Property
      Friend Property strName() As String
         Get
            Return m_strName
         End Get
         Set(ByVal Value As String)
            m_strName = Value
         End Set
      End Property
      Friend Property dateStart() As String
         Get
            Return m_dateStart
         End Get
         Set(ByVal Value As String)
            m_dateStart = Value
         End Set
      End Property
      Friend Property dateEnd() As String
         Get
            Return m_dateEnd
         End Get
         Set(ByVal Value As String)
            m_dateEnd = Value
         End Set
      End Property
      Friend Property ctTasks() As Integer
         Get
            Return m_ctTasks
         End Get
         Set(ByVal Value As Integer)
            m_ctTasks = Value
         End Set
      End Property
      Friend Property strComments() As String
         Get
            Return m_strComments
         End Get
         Set(ByVal Value As String)
            m_strComments = Value
         End Set
      End Property
      Public Sub New(ByVal strIdent As String, _
                     ByVal strName As String, _
                     ByVal dateStart As Date, _
                     ByVal dateEnd As Date, _
                     ByVal ctTasks As Integer, _
                     ByVal strComments As String)
         Me.m_strIdent = strIdent
         Me.m_strName = strName
         Me.m_dateStart = dateStart
         Me.m_dateEnd = dateEnd
         Me.m_ctTasks = ctTasks
         Me.m_strComments = strComments
      End Sub
   End Structure

   Friend Structure Task
      Private m_strIdent As String
      Private m_strProjIdent As String
      Private m_strName As String
      Private m_dateStart As Date
      Private m_dateEnd As Date
      Private m_durEstimated As Integer  '  In hours
      Private m_durActual As Integer     '  In hours
      Private m_strComments As String
      Friend Property strIdent() As String
         Get
            Return m_strIdent
         End Get
         Set(ByVal Value As String)
            m_strIdent = Value
         End Set
      End Property
      Friend Property strProjIdent() As String
         Get
            Return m_strProjIdent
         End Get
         Set(ByVal Value As String)
            m_strProjIdent = Value
         End Set
      End Property
      Friend Property strName() As String
         Get
            Return m_strName
         End Get
         Set(ByVal Value As String)
            m_strName = Value
         End Set
      End Property
      Friend Property dateStart() As String
         Get
            Return m_dateStart
         End Get
         Set(ByVal Value As String)
            m_dateStart = Value
         End Set
      End Property
      Friend Property dateEnd() As String
         Get
            Return m_dateEnd
         End Get
         Set(ByVal Value As String)
            m_dateEnd = Value
         End Set
      End Property
      Friend Property durEstimated() As Integer
         Get
            Return durEstimated
         End Get
         Set(ByVal Value As Integer)
            durEstimated = Value
         End Set
      End Property
      Friend Property durActual() As Integer
         Get
            Return durActual
         End Get
         Set(ByVal Value As Integer)
            durActual = Value
         End Set
      End Property
      Friend Property strComments() As String
         Get
            Return m_strComments
         End Get
         Set(ByVal Value As String)
            m_strComments = Value
         End Set
      End Property
      Friend Sub New(ByVal strIdent As String, _
                     ByVal strProjIdent As String, _
                     ByVal strName As String, _
                     ByVal dateStart As Date, _
                     ByVal dateEnd As Date, _
                     ByVal durEstimated As Integer, _
                     ByVal durActual As Integer, _
                     ByVal strComments As String)
         Me.m_strIdent = strIdent
         Me.m_strProjIdent = strProjIdent
         Me.m_strName = strName
         Me.m_dateStart = dateStart
         Me.m_dateEnd = dateEnd
         Me.m_durEstimated = durEstimated
         Me.m_durActual = durActual
         Me.m_strComments = strComments
      End Sub
   End Structure
#End Region

   Private alProjects As ArrayList
   Private alTasks As ArrayList
   Private dsetTimeTracker As DataSet
   Private dtblProjects As DataTable
   Private dtblTasks As DataTable

   Public Sub New()
      LoadData()
   End Sub

   Friend Function GetProjectsAL() As ArrayList
      Return alProjects
   End Function

   Friend Function GetProjectsDT() As DataTable
      Return dsetTimeTracker.Tables("Projects")
   End Function

   Friend Function GetTasksAL() As ArrayList
      Return alTasks
   End Function

   Friend Function GetTasksAL( _
                               ByVal ProjectID As Integer _
                             ) _
                               As ArrayList
   End Function

   Friend Function GetTasksDT() As DataTable
      Return dsetTimeTracker.Tables("Tasks")
   End Function

   Friend Function GetTasksDV( _
                               ByVal ProjectID As Integer _
                             ) _
                               As DataTable
   End Function


#Region " Database Read Simulation "
   Private Sub LoadData()
      '  We want to have both Project and Task data
      '     loaded into ArrayLists, and also have 
      '     the same data loaded into DataTables.

      '  Load an ArrayList with Project data.
      alProjects = New ArrayList
      With alProjects
         .Add(New Project(1, _
                          "Build Ark", _
                          DateTime.Today.AddDays(-17), _
                          DateTime.Today.AddDays(22), _
                          5, _
                          "Must be done in less than 40 days."))
         .Add(New Project(17, _
                          "Develop CF Application", _
                          DateTime.Today.AddDays(-17), _
                          DateTime.Today.AddDays(22), _
                          5, _
                          "To ensure success, " & _
                          "read the Yao-Durant book first."))
         .Add(New Project(9, _
                          "Write CF Book", _
                          DateTime.Today.AddDays(-17), _
                          DateTime.Today.AddDays(22), _
                          5, _
                          "The endless cycle:  " & _
                          "Code, test, write, revise, proof."))
      End With

      '  Load an ArrayList with Project Task data.
      alTasks = New ArrayList
      Dim projWork As Project
      For Each projWork In alProjects
         With alTasks
            .Add(New Task(1, _
                          projWork.strIdent, _
                          "Create Blueprints", _
                          DateTime.Today.AddDays(-17), _
                          DateTime.Today.AddDays(22), _
                          120, 60, ""))
            .Add(New Task(2, _
                          projWork.strIdent, _
                          "Build Franistans", _
                          DateTime.Today.AddDays(-11), _
                          DateTime.Today.AddDays(0), _
                          35, 30, ""))
            .Add(New Task(5, _
                          projWork.strIdent, _
                          "Build Widgets", _
                          DateTime.Today.AddDays(-4), _
                          DateTime.Today.AddDays(44), _
                          400, 45, ""))
            .Add(New Task(3, _
                          projWork.strIdent, _
                          "Assemble Woobletogles", _
                          DateTime.Today.AddDays(-19), _
                          DateTime.Today.AddDays(2), _
                          20, 20, ""))
            .Add(New Task(7, _
                          projWork.strIdent, _
                          "Weld Mainwareing", _
                          DateTime.Today.AddDays(-100), _
                          DateTime.Today.AddDays(50), _
                          20, 6, ""))
         End With
      Next

      '  Create a DataSet
      dsetTimeTracker = New DataSet("TimeTracker")

      '  Create a Projects DataTable.
      Dim dcolWork As DataColumn
      dtblProjects = New DataTable("Projects")
      dcolWork = New DataColumn("strIdent", GetType(String))
      dtblProjects.Columns.Add(dcolWork)
      dcolWork = New DataColumn("strName", GetType(String))
      dtblProjects.Columns.Add(dcolWork)
      dcolWork = New DataColumn("dateStart", GetType(Date))
      dtblProjects.Columns.Add(dcolWork)
      dcolWork = New DataColumn("dateEnd", GetType(Date))
      dtblProjects.Columns.Add(dcolWork)
      dcolWork = New DataColumn("ctTasks", GetType(Integer))
      dtblProjects.Columns.Add(dcolWork)
      dcolWork = New DataColumn("strComments", GetType(String))
      dtblProjects.Columns.Add(dcolWork)

      '  Create a Tasks DataTable.
      dtblTasks = New DataTable("Tasks")
      dcolWork = New DataColumn("strIdent", GetType(String))
      dtblTasks.Columns.Add(dcolWork)
      dcolWork = New DataColumn("strProjIdent", GetType(String))
      dtblTasks.Columns.Add(dcolWork)
      dcolWork = New DataColumn("strName", GetType(String))
      dtblTasks.Columns.Add(dcolWork)
      dcolWork = New DataColumn("dateStart", GetType(Date))
      dtblTasks.Columns.Add(dcolWork)
      dcolWork = New DataColumn("dateEnd", GetType(Date))
      dtblTasks.Columns.Add(dcolWork)
      dcolWork = New DataColumn("durEstimated", GetType(Integer))
      dtblTasks.Columns.Add(dcolWork)
      dcolWork = New DataColumn("durActual", GetType(Integer))
      dtblTasks.Columns.Add(dcolWork)
      dcolWork = New DataColumn("strComments", GetType(String))
      dtblTasks.Columns.Add(dcolWork)

      '  Add the tables to the DataSet.
      dsetTimeTracker.Tables.Add(dtblProjects)
      dsetTimeTracker.Tables.Add(dtblTasks)

      '  Create a DataRelation, showing that Tasks are
      '     subordinate to Projects.  Add it to the 
      '     DataSet.
      dsetTimeTracker.Relations.Add(New DataRelation("ProjectTask", dtblProjects.Columns("strIdent"), dtblTasks.Columns("strProjIdent")))

      '  Load the Projects DataTable from 
      '     the Projects ArrayList.
      For Each projWork In alProjects
         With projWork
            dtblProjects.Rows.Add(New Object() _
                                    {.strIdent, .strName, _
                                     .dateStart, .dateEnd, _
                                     .ctTasks, .strComments})
         End With
      Next

      '  Load the Tasks DataTable from 
      '     the Tasks ArrayList.
      Dim taskWork As Task
      For Each taskWork In alTasks
         With taskWork
            dtblTasks.Rows.Add(New Object() {.strIdent, .strProjIdent, .strName, .dateStart, .dateEnd, .durEstimated, .durActual, .strComments})
         End With
      Next

   End Sub
#End Region

End Class
