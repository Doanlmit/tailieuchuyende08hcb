' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms

Public Class FormMain
   Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents panelBindingData As System.Windows.Forms.Panel
   Friend WithEvents lblHdrType As System.Windows.Forms.Label
   Friend WithEvents lblDatumType As System.Windows.Forms.Label
   Friend WithEvents lblDatumRow As System.Windows.Forms.Label
   Friend WithEvents lblHdrRow As System.Windows.Forms.Label
   Friend WithEvents lblDatumColumn As System.Windows.Forms.Label
   Friend WithEvents lblHdrColumn As System.Windows.Forms.Label
   Friend WithEvents lblDatumName As System.Windows.Forms.Label
   Friend WithEvents lblHdrName As System.Windows.Forms.Label
   Friend WithEvents lblDatumValue As System.Windows.Forms.Label
   Friend WithEvents lblHdrValue As System.Windows.Forms.Label
   Friend WithEvents lblDatumKey As System.Windows.Forms.Label
   Friend WithEvents lblHdrKey As System.Windows.Forms.Label
   Friend WithEvents lblDatumEvent As System.Windows.Forms.Label
   Friend WithEvents panelChoice As System.Windows.Forms.Panel
   Friend WithEvents optCellSelection As System.Windows.Forms.RadioButton
   Friend WithEvents optMouseOver As System.Windows.Forms.RadioButton
   Friend WithEvents dgridProjects As System.Windows.Forms.DataGrid
   Friend WithEvents lblHdrDataType As System.Windows.Forms.Label
   Friend WithEvents lblDatumDataType As System.Windows.Forms.Label
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.dgridProjects = New System.Windows.Forms.DataGrid
      Me.panelBindingData = New System.Windows.Forms.Panel
      Me.lblDatumKey = New System.Windows.Forms.Label
      Me.lblHdrKey = New System.Windows.Forms.Label
      Me.lblDatumValue = New System.Windows.Forms.Label
      Me.lblHdrValue = New System.Windows.Forms.Label
      Me.lblDatumName = New System.Windows.Forms.Label
      Me.lblHdrName = New System.Windows.Forms.Label
      Me.lblDatumColumn = New System.Windows.Forms.Label
      Me.lblHdrColumn = New System.Windows.Forms.Label
      Me.lblDatumRow = New System.Windows.Forms.Label
      Me.lblHdrRow = New System.Windows.Forms.Label
      Me.lblDatumType = New System.Windows.Forms.Label
      Me.lblHdrType = New System.Windows.Forms.Label
      Me.lblDatumEvent = New System.Windows.Forms.Label
      Me.panelChoice = New System.Windows.Forms.Panel
      Me.optMouseOver = New System.Windows.Forms.RadioButton
      Me.optCellSelection = New System.Windows.Forms.RadioButton
      Me.lblDatumDataType = New System.Windows.Forms.Label
      Me.lblHdrDataType = New System.Windows.Forms.Label
      '
      'dgridProjects
      '
      Me.dgridProjects.Location = New System.Drawing.Point(0, 144)
      Me.dgridProjects.Size = New System.Drawing.Size(240, 109)
      '
      'panelBindingData
      '
      Me.panelBindingData.Controls.Add(Me.lblDatumDataType)
      Me.panelBindingData.Controls.Add(Me.lblHdrDataType)
      Me.panelBindingData.Controls.Add(Me.lblDatumKey)
      Me.panelBindingData.Controls.Add(Me.lblHdrKey)
      Me.panelBindingData.Controls.Add(Me.lblDatumValue)
      Me.panelBindingData.Controls.Add(Me.lblHdrValue)
      Me.panelBindingData.Controls.Add(Me.lblDatumName)
      Me.panelBindingData.Controls.Add(Me.lblHdrName)
      Me.panelBindingData.Controls.Add(Me.lblDatumColumn)
      Me.panelBindingData.Controls.Add(Me.lblHdrColumn)
      Me.panelBindingData.Controls.Add(Me.lblDatumRow)
      Me.panelBindingData.Controls.Add(Me.lblHdrRow)
      Me.panelBindingData.Controls.Add(Me.lblDatumType)
      Me.panelBindingData.Controls.Add(Me.lblHdrType)
      Me.panelBindingData.Controls.Add(Me.lblDatumEvent)
      Me.panelBindingData.Location = New System.Drawing.Point(0, 32)
      Me.panelBindingData.Size = New System.Drawing.Size(240, 104)
      '
      'lblDatumKey
      '
      Me.lblDatumKey.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumKey.ForeColor = System.Drawing.Color.Blue
      Me.lblDatumKey.Location = New System.Drawing.Point(72, 88)
      Me.lblDatumKey.Size = New System.Drawing.Size(160, 16)
      '
      'lblHdrKey
      '
      Me.lblHdrKey.Location = New System.Drawing.Point(24, 88)
      Me.lblHdrKey.Size = New System.Drawing.Size(40, 16)
      Me.lblHdrKey.Text = "Key"
      Me.lblHdrKey.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblDatumValue
      '
      Me.lblDatumValue.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumValue.ForeColor = System.Drawing.Color.Blue
      Me.lblDatumValue.Location = New System.Drawing.Point(72, 72)
      Me.lblDatumValue.Size = New System.Drawing.Size(160, 16)
      '
      'lblHdrValue
      '
      Me.lblHdrValue.Location = New System.Drawing.Point(24, 72)
      Me.lblHdrValue.Size = New System.Drawing.Size(40, 16)
      Me.lblHdrValue.Text = "Value"
      Me.lblHdrValue.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblDatumName
      '
      Me.lblDatumName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumName.ForeColor = System.Drawing.Color.Blue
      Me.lblDatumName.Location = New System.Drawing.Point(72, 40)
      Me.lblDatumName.Size = New System.Drawing.Size(160, 16)
      '
      'lblHdrName
      '
      Me.lblHdrName.Location = New System.Drawing.Point(24, 40)
      Me.lblHdrName.Size = New System.Drawing.Size(40, 18)
      Me.lblHdrName.Text = "Name"
      Me.lblHdrName.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblDatumColumn
      '
      Me.lblDatumColumn.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumColumn.ForeColor = System.Drawing.Color.Blue
      Me.lblDatumColumn.Location = New System.Drawing.Point(208, 24)
      Me.lblDatumColumn.Size = New System.Drawing.Size(32, 16)
      '
      'lblHdrColumn
      '
      Me.lblHdrColumn.Location = New System.Drawing.Point(168, 24)
      Me.lblHdrColumn.Size = New System.Drawing.Size(32, 16)
      Me.lblHdrColumn.Text = "Col"
      Me.lblHdrColumn.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblDatumRow
      '
      Me.lblDatumRow.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumRow.ForeColor = System.Drawing.Color.Blue
      Me.lblDatumRow.Location = New System.Drawing.Point(128, 24)
      Me.lblDatumRow.Size = New System.Drawing.Size(32, 16)
      '
      'lblHdrRow
      '
      Me.lblHdrRow.Location = New System.Drawing.Point(88, 24)
      Me.lblHdrRow.Size = New System.Drawing.Size(32, 16)
      Me.lblHdrRow.Text = "Row"
      Me.lblHdrRow.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblDatumType
      '
      Me.lblDatumType.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumType.ForeColor = System.Drawing.Color.Blue
      Me.lblDatumType.Location = New System.Drawing.Point(48, 24)
      Me.lblDatumType.Size = New System.Drawing.Size(32, 16)
      '
      'lblHdrType
      '
      Me.lblHdrType.Location = New System.Drawing.Point(8, 24)
      Me.lblHdrType.Size = New System.Drawing.Size(32, 16)
      Me.lblHdrType.Text = "Type"
      Me.lblHdrType.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblDatumEvent
      '
      Me.lblDatumEvent.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumEvent.Size = New System.Drawing.Size(168, 20)
      '
      'panelChoice
      '
      Me.panelChoice.Controls.Add(Me.optMouseOver)
      Me.panelChoice.Controls.Add(Me.optCellSelection)
      Me.panelChoice.Size = New System.Drawing.Size(240, 24)
      '
      'optMouseOver
      '
      Me.optMouseOver.Location = New System.Drawing.Point(136, 0)
      Me.optMouseOver.Text = "MouseOver"
      '
      'optCellSelection
      '
      Me.optCellSelection.Text = "Cell Selection"
      '
      'lblDatumDataType
      '
      Me.lblDatumDataType.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
      Me.lblDatumDataType.ForeColor = System.Drawing.Color.Blue
      Me.lblDatumDataType.Location = New System.Drawing.Point(72, 56)
      Me.lblDatumDataType.Size = New System.Drawing.Size(160, 16)
      '
      'lblHdrDataType
      '
      Me.lblHdrDataType.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
      Me.lblHdrDataType.Location = New System.Drawing.Point(0, 56)
      Me.lblHdrDataType.Size = New System.Drawing.Size(64, 16)
      Me.lblHdrDataType.Text = "Data Type"
      Me.lblHdrDataType.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'FormMain
      '
      Me.ClientSize = New System.Drawing.Size(240, 295)
      Me.Controls.Add(Me.panelChoice)
      Me.Controls.Add(Me.panelBindingData)
      Me.Controls.Add(Me.dgridProjects)
      Me.Text = "Binding Info"

   End Sub

#End Region

   '  A DataSet that will hold the Projects table
   '     and the Tasks table.
   Private myDataSet As DataSet

   Private Sub FormDataSet_Load( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles MyBase.Load

      '  Create one of our UtilData objects.
      Dim dpProjects As New DisplayBindingInfo.UtilData

      '  Make the Project table the DataSource.
      '  Make the strIdent field of the currently
      '     select row the Text property of the DataGrid
      '     control.
      With dgridProjects
         .DataSource = dpProjects.GetProjectsDT()
         .DataBindings.Clear()
         .DataBindings.Add("Text", .DataSource, "strIdent")
      End With

      '  Use a utility routine to style the 
      '     layout of Projects in the DataGrid.
      UtilGUI.AddCustomDataTableStyle(dgridProjects, "Projects")
   End Sub

   Private Sub Grid_MouseMove _
         ( _
         ByVal sender As System.Object, _
         ByVal e As System.Windows.Forms.MouseEventArgs _
         ) _
         Handles dgridProjects.MouseMove

      '  If the user is not interested in
      '      this event, do not handle it.
      If Not optMouseOver.Checked Then
         Exit Sub
      End If

      '  Tell the user what information they are seeing.
      lblDatumEvent.Text = "Cell Under Mouse"

      '  Store the DataGrid object for early binding.
      Dim dgridSender As DataGrid = sender

      '  Store the DataGrid's DataSource object
      Dim dtabDataSource As DataTable = dgridSender.DataSource

      '  Use the DataSource name to retrieve
      '      and store the current TableStyle.
      Dim dgtsCurrent _
         As System.Windows.Forms.DataGridTableStyle = _
               dgridSender.TableStyles(dtabDataSource.TableName)

      '  Use the DataGrid's HitTest method to get the 
      '     HitTest object for this Click.
      Dim httstInfo As _
         System.Windows.Forms.DataGrid.HitTestInfo
      With dgridSender
         httstInfo = .HitTest(e.X, e.Y)
      End With

      '  Clear the labels that are meaningful only
      '     if the mouse is over a data cell.
      lblDatumName.Text = String.Empty
      lblDatumValue.Text = String.Empty
      lblDatumDataType.Text = String.Empty

      With httstInfo
         '  Display HitTest properties in the labels
         lblDatumType.Text = .Type
         lblDatumRow.Text = .Row
         lblDatumColumn.Text = .Column

         '  If the mouse is positioned over a data column...
         If .Column <> -1 Then
            '  Obtain the DataSource's column name from
            '     the ColumnStyles collection of the
            '     current TableStyle.
            Dim strColumnName As String = _
               dgtsCurrent.GridColumnStyles(.Column).MappingName
            lblDatumName.Text = strColumnName

            '  Obtain the DataSource's column's data type.
            lblDatumDataType.Text = _
               dtabDataSource.Rows(0).Item(strColumnName). _
                  GetType().ToString()

            '  If the mouse is positioned over a data cell...
            If .Row <> -1 Then

               '           ETHER

               '  Obtain and display the cell value from
               '     the underlying data source object.
               lblDatumValue.Text = _
                  dtabDataSource.Rows(.Row).Item(strColumnName)

               '              OR

               '  Obtain and display the cell value from
               '     the DataGrid itself.
               lblDatumValue.Text = _
                  dgridSender.Item(.Row, .Column)
            End If
         End If
      End With
   End Sub

   Private Sub Grid_CurrentCellChanged _
                     ( _
                        ByVal sender As System.Object, _
                        ByVal e As System.EventArgs _
                     ) _
                     Handles dgridProjects.CurrentCellChanged

      '  If the user is not interested in
      '      this event, do not handle it.
      If Not optCellSelection.Checked Then
         Exit Sub
      End If

      '  Since the value of CurrentCell is set before this
      '     event is raised, it can be used to determine
      '     row and column.  Hit testing is not necessary.

      '  Tell the user what information they are seeing.
      lblDatumEvent.Text = "Current Cell"

      '  Store the DataGrid object for early binding.
      Dim dgridSender As DataGrid = sender

      '  Store the DataGrid's DataSource object
      Dim dtabDataSource As DataTable = dgridSender.DataSource

      '  Use the DataSource name to retrieve
      '      and store the current TableStyle.
      Dim dgtsCurrent _
         As System.Windows.Forms.DataGridTableStyle = _
               dgridSender.TableStyles(dtabDataSource.TableName)

      '  Using the CurrentCell, which is always a data cell...
      With dgridSender.CurrentCell
         '  Display HitTest properties in the labels
         lblDatumType.Text = 1
         lblDatumRow.Text = .RowNumber
         lblDatumColumn.Text = .ColumnNumber

         '  Obtain the DataSource's column name from
         '     the ColumnStyles collection of the
         '     current TableStyle.
         Dim strColumnName As String = _
            dgtsCurrent.GridColumnStyles(.ColumnNumber). _
               MappingName
         lblDatumName.Text = strColumnName

         '  Obtain the DataSource's column's data type.
         lblDatumDataType.Text = _
            dtabDataSource.Rows(0).Item(strColumnName). _
               GetType().ToString()

         '           ETHER

         '  Obtain and display the cell value from
         '     the underlying data source object.
         lblDatumValue.Text = _
            dtabDataSource.Rows(.RowNumber).Item(strColumnName)

         '              OR

         '  Obtain and display the cell value from
         '     the DataGrid itself.
         lblDatumValue.Text = _
            dgridSender.Item(.RowNumber, .ColumnNumber)
      End With

      '  Display the primary key of the row; based on
      '     the DataBindings entry that was added 
      '     during the Load event.
      lblDatumKey.Text = dgridSender.Text
   End Sub

   Private Sub optAny_CheckedChanged( _
                     ByVal sender As System.Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles optCellSelection.CheckedChanged, _
                             optMouseOver.CheckedChanged

      '  Clear the Labels
      Me.lblDatumEvent.Text = String.Empty
      Me.lblDatumType.Text = String.Empty
      Me.lblDatumRow.Text = String.Empty
      Me.lblDatumColumn.Text = String.Empty
      Me.lblDatumName.Text = String.Empty
      Me.lblDatumValue.Text = String.Empty
      Me.lblDatumKey.Text = String.Empty
      Me.lblDatumDataType.Text = String.Empty
      Me.lblHdrKey.Visible = optCellSelection.Checked
   End Sub
End Class
