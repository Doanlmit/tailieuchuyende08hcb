' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Object
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms

Public Class FormMain
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents Panel1 As System.Windows.Forms.Panel
   Friend WithEvents dgrdProjects As System.Windows.Forms.DataGrid
   Friend WithEvents cmdCancel As System.Windows.Forms.Button
   Friend WithEvents cmdUpdate As System.Windows.Forms.Button
   Friend WithEvents cmdEdit As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.dgrdProjects = New System.Windows.Forms.DataGrid
      Me.Label1 = New System.Windows.Forms.Label
      Me.Panel1 = New System.Windows.Forms.Panel
      Me.cmdCancel = New System.Windows.Forms.Button
      Me.cmdUpdate = New System.Windows.Forms.Button
      Me.cmdEdit = New System.Windows.Forms.Button
      '
      'dgrdProjects
      '
      Me.dgrdProjects.Location = New System.Drawing.Point(0, 40)
      Me.dgrdProjects.Size = New System.Drawing.Size(240, 109)
      '
      'Label1
      '
      Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.Label1.Location = New System.Drawing.Point(0, 8)
      Me.Label1.Size = New System.Drawing.Size(240, 24)
      '
      'Panel1
      '
      Me.Panel1.Controls.Add(Me.cmdCancel)
      Me.Panel1.Controls.Add(Me.cmdUpdate)
      Me.Panel1.Controls.Add(Me.cmdEdit)
      Me.Panel1.Location = New System.Drawing.Point(0, 160)
      Me.Panel1.Size = New System.Drawing.Size(240, 24)
      '
      'cmdCancel
      '
      Me.cmdCancel.Location = New System.Drawing.Point(184, 0)
      Me.cmdCancel.Size = New System.Drawing.Size(56, 20)
      Me.cmdCancel.Text = "Cancel"
      '
      'cmdUpdate
      '
      Me.cmdUpdate.Location = New System.Drawing.Point(88, 0)
      Me.cmdUpdate.Size = New System.Drawing.Size(56, 20)
      Me.cmdUpdate.Text = "Update"
      '
      'cmdEdit
      '
      Me.cmdEdit.Size = New System.Drawing.Size(56, 20)
      Me.cmdEdit.Text = "Edit"
      '
      'FormMain
      '
      Me.ClientSize = New System.Drawing.Size(240, 295)
      Me.Controls.Add(Me.Panel1)
      Me.Controls.Add(Me.Label1)
      Me.Controls.Add(Me.dgrdProjects)
      Me.Text = "Binding Info"

   End Sub

#End Region

   '  A TextBox control to be used for InPlace editing.
   Dim WithEvents textEdit As TextBox

   Private Sub FormDataSet_Load( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles MyBase.Load

      '  Make the Project table the DataSource.
      Dim utilData As New InPlaceEditing.UtilData
      With dgrdProjects
         .DataSource = utilData.GetProjectsDT()
      End With

      '  Use a utility routine to style the 
      '     layout of Projects in the DataGrid.
      UtilGUI.AddCustomDataTableStyle(dgrdProjects, "Projects")

      '  Create the TextBox to be used with InPlace editing
      '     and add it to the DataGrid control.
      textEdit = New TextBox
      With textEdit
         .Visible = False
      End With
      Me.dgrdProjects.Controls.Add(textEdit)

      '  Set Form GUI state to "Not Editing".
      Me.SetEditingState(False)
   End Sub

   Private Sub cmdEdit_Click(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles cmdEdit.Click

      With dgrdProjects.CurrentCell
         '  Check the DataSource's column's name
         '     If it is "ctTasks", do not update.
         If dgrdProjects.TableStyles("Projects"). _
                           GridColumnStyles(.ColumnNumber). _
                              MappingName = "ctTasks" Then
            MessageBox.Show( _
               "Count of tasks only changes as the " & _
               "result of adding / removing a task.")
            Exit Sub
         End If

         '  Position textEdit for in-place editing.
         textEdit.Bounds = dgrdProjects.GetCellBounds _
                                 (.RowNumber, .ColumnNumber)
         '  Load the CurrentCell's value into textEdit.
         textEdit.Text = dgrdProjects.Item _
                                 (.RowNumber, .ColumnNumber)
         '  Highlight the text.
         textEdit.SelectAll()
         '  Show textEdit and set the focus to it.
         textEdit.Visible = True
         textEdit.Focus()
      End With

      '  Set Form GUI state to "Editing".
      Me.SetEditingState(True)
   End Sub

   Private Sub cmdUpdate_Click(ByVal sender As System.Object, _
                               ByVal e As System.EventArgs _
                               ) _
                               Handles cmdUpdate.Click

      '  Move the contents of textEdit
      '     into the CurrentCell
      With dgrdProjects
         .Item(.CurrentCell.RowNumber, _
               .CurrentCell.ColumnNumber) = textEdit.Text
      End With

      '  Set Form GUI state to "Not Editing".
      Me.SetEditingState(False)
   End Sub

   Private Sub cmdCancel_Click(ByVal sender As System.Object, _
                               ByVal e As System.EventArgs _
                               ) _
                               Handles cmdCancel.Click
      '  Set Form GUI state to "Not Editing".
      Me.SetEditingState(False)
   End Sub

   Private Sub SetEditingState(ByVal boolInProcess As Boolean)
      textEdit.Visible = boolInProcess
      cmdEdit.Enabled = Not boolInProcess
      cmdCancel.Enabled = boolInProcess
      cmdUpdate.Enabled = boolInProcess
   End Sub
End Class

