' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data

Namespace YaoDurant.Data

   Public Class UtilData
      Inherits System.Object

#Region " Database Structure Simulated "
      Friend Structure Project
         Private m_strIdent As String
         Private m_strName As String
         Private m_dateStart As Date
         Private m_dateEnd As Date
         Private m_ctTasks As Integer
         Private m_strComments As String
         Friend Property strIdent() As String
            Get
               Return m_strIdent
            End Get
            Set(ByVal Value As String)
               m_strIdent = Value
            End Set
         End Property
         Friend Property strName() As String
            Get
               Return m_strName
            End Get
            Set(ByVal Value As String)
               m_strName = Value
            End Set
         End Property
         Friend Property dateStart() As String
            Get
               Return m_dateStart
            End Get
            Set(ByVal Value As String)
               m_dateStart = Value
            End Set
         End Property
         Friend Property dateEnd() As String
            Get
               Return m_dateEnd
            End Get
            Set(ByVal Value As String)
               m_dateEnd = Value
            End Set
         End Property
         Friend Property ctTasks() As String
            Get
               Return m_ctTasks
            End Get
            Set(ByVal Value As String)
               m_ctTasks = Value
            End Set
         End Property
         Friend Property strComments() As String
            Get
               Return m_strComments
            End Get
            Set(ByVal Value As String)
               m_strComments = Value
            End Set
         End Property
         Public Sub New(ByVal strIdent As String, _
                        ByVal strName As String, _
                        ByVal dateStart As Date, _
                        ByVal dateEnd As Date, _
                        ByVal ctTasks As Integer, _
                        ByVal strComments As String)
            Me.m_strIdent = strIdent
            Me.m_strName = strName
            Me.m_dateStart = dateStart
            Me.m_dateEnd = dateEnd
            Me.m_ctTasks = ctTasks
            Me.m_strComments = strComments
         End Sub
      End Structure
#End Region

      '  All objects listed here will be loaded with
      '     data whenever an instance of this claas
      '     is created.

      '  The projects, stored in an ArrayList
      Private alProjects As ArrayList

      '  The projects, stored in a DataTable
      Private dtblProjects As DataTable
      '  A DataSet to hold the DataTable.
      Private dsetTimeTracker As DataSet

      Public Sub New()
         LoadData()
      End Sub

      Friend Function GetProjectsAL() As ArrayList
         Return alProjects
      End Function

      Friend Function GetProjectsDT() As DataTable
         Return dsetTimeTracker.Tables("Projects")
      End Function

#Region " Database Read Simulation "

      Private Sub LoadData()
         '  Simulate having retrieved project data
         '     from a database.  Use the Project 
         '     and Task data structures to hold 
         '     the data.
         alProjects = New ArrayList
         With alProjects
            .Add(New Project(1, _
                             "Build Ark", _
                             DateTime.Today.AddDays(-17), _
                             DateTime.Today.AddDays(22), _
                             5, _
                             "Must be done in less than 40 days."))
            .Add(New Project(17, _
                             "Develop CF Application", _
                             DateTime.Today.AddDays(-17), _
                             DateTime.Today.AddDays(22), _
                             5, _
                             "To ensure success, read the Yao-Durant book first."))
            .Add(New Project(9, _
                             "Write CF Book", _
                             DateTime.Today.AddDays(-17), _
                             DateTime.Today.AddDays(22), _
                             5, _
                             "The endless cycle:  Code, test, write, revise, proof."))
         End With

         dsetTimeTracker = New DataSet("TimeTracker")
         Dim dcolWork As DataColumn

         dtblProjects = New DataTable("Projects")

         dcolWork = New DataColumn("strIdent", GetType(String))
         dtblProjects.Columns.Add(dcolWork)
         dcolWork = New DataColumn("strName", GetType(String))
         dtblProjects.Columns.Add(dcolWork)
         dcolWork = New DataColumn("dateStart", GetType(Date))
         dtblProjects.Columns.Add(dcolWork)
         dcolWork = New DataColumn("dateEnd", GetType(Date))
         dtblProjects.Columns.Add(dcolWork)
         dcolWork = New DataColumn("ctTasks", GetType(Integer))
         dtblProjects.Columns.Add(dcolWork)
         dcolWork = New DataColumn("strComments", GetType(String))
         dtblProjects.Columns.Add(dcolWork)

         ' Add the table to the DataSet.
         dsetTimeTracker.Tables.Add(dtblProjects)

         '  Load the Projects DataTable from 
         '     the Projects ArrayList.
         Dim projWork As Project
         For Each projWork In alProjects
            With projWork
               dtblProjects.Rows.Add(New Object() {.strIdent, .strName, .dateStart, .dateEnd, .ctTasks, .strComments})
            End With
         Next
      End Sub
#End Region

   End Class

End Namespace
