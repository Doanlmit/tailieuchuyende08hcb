' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms
Imports System.ComponentModel
Imports Microsoft.WindowsCE.Forms

Public Class FormMain
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents dgrdProjects As System.Windows.Forms.DataGrid
   Friend WithEvents cmenuEdit As System.Windows.Forms.ContextMenu
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.dgrdProjects = New System.Windows.Forms.DataGrid
      Me.cmenuEdit = New System.Windows.Forms.ContextMenu
      '
      'dgrdProjects
      '
      Me.dgrdProjects.Location = New System.Drawing.Point(0, 40)
      Me.dgrdProjects.Size = New System.Drawing.Size(240, 109)
      Me.dgrdProjects.Text = "DataGrid1"
      '
      'FormMain
      '
      Me.ClientSize = New System.Drawing.Size(240, 295)
      Me.Controls.Add(Me.dgrdProjects)
      Me.Text = "Inplace Edit"

   End Sub

#End Region

   '  TextBox control to be used for InPlace editing.
   Private WithEvents textEdit As TextBox

   '  Two ContextMenu items.
   Private WithEvents mitemUpdate As New MenuItem
   Private WithEvents mitemCancel As New MenuItem

   '  The DataGrad's CurrentCell.  We must save it 
   '     because a new CurrentCell may be assigned
   '     before we are finished with the old one.
   Private CurrentCell As DataGridCell

   '  These fields are used to determine when
   '     in-place editing should begin.
   Private boolMouseDriven As Boolean
   Private boolDoEdit As Boolean

   '  This field is to track whether the update
   '     should be completed or cancelled.
   Private boolCancelUpdate As Boolean

   Private Sub FormDataSet_Load( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles MyBase.Load

      '  Make the Project table the DataSource.
      Dim utilData As New InPlaceEditAuto.UtilData
      With dgrdProjects
         .DataSource = utilData.GetProjectsDT()
      End With

      '  Use a utility routine to style the 
      '     layout of Projects in the DataGrid.
      UtilGUI.AddCustomDataTableStyle(dgrdProjects, "Projects")

      '  Create the TextBox to be used with InPlace
      '     editing and add it to the DataGrid control.
      textEdit = New TextBox
      With textEdit
         .Visible = False
      End With
      Me.dgrdProjects.Controls.Add(textEdit)

      '  Initialize the Update/Cancel context menu
      Me.InitContextMenu()

      '  The default is:  Do the update.
      Me.boolCancelUpdate = False
   End Sub


   Private Sub dgrdProjects_MouseDown( _
                     ByVal sender As Object, _
                     ByVal e As MouseEventArgs _
                     ) _
                     Handles dgrdProjects.MouseDown

      '  If editing is in progress
      If textEdit.Visible And e.Button = MouseButtons.Right Then
         '  If the user tapped in the row header of the row
         '     being edited, display the Update/Cancel context 
         '     menu to the user.
         With dgrdProjects
            If .HitTest(e.X, e.Y).Type = .HitTestType.RowHeader _
            And .HitTest(e.X, e.Y).Row = .CurrentRowIndex Then
               cmenuEdit.Show(textEdit, New Point(0, 0))
            End If
         End With
      Else
      End If

      '  When the user taps on a data cell or a row
      '     header, the current cell will change.  
      '     Our CurrentCellChanged event will need to
      '     know that this was caused by a mouse tap,
      '     rather than by a Tab or programatically.
      With dgrdProjects
         boolMouseDriven = (.HitTest(e.X, e.Y).Type = _
               .HitTestType.Cell Or .HitTestType.RowHeader)
      End With
   End Sub


   Private Sub dgrdProjects_CurrentCellChanged( _
                        ByVal sender As Object, _
                        ByVal e As System.EventArgs _
                        ) _
                        Handles dgrdProjects.CurrentCellChanged
      '  If this is a mouse caused event, we must wait for the
      '     Click and MouseUp events to complete before
      '     displaying the Edit TextBox.  If not mouse caused, 
      '     we can display the Edit TextBox after this message 
      '     has completed processing.
      If boolMouseDriven Then
         boolDoEdit = True
      Else
         Me.InitEdit()
      End If
      boolMouseDriven = False
   End Sub


   Private Sub dgrdProjects_MouseUp( _
                     ByVal sender As Object, _
                     ByVal e As MouseEventArgs _
                     ) _
                     Handles dgrdProjects.MouseUp

      '  If editing has been requested, we need 
      '     to display textEdit to the user.
      If boolDoEdit Then
         Me.InitEdit()
      End If
   End Sub


   Private Sub MenuItem_Click( _
                     ByVal sender As Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles mitemUpdate.Click, _
                             mitemCancel.Click

      '  Note which was requested.
      '  Hide the edit TextBox.
      Me.boolCancelUpdate = (sender Is mitemCancel)
      textEdit.Visible = False
   End Sub


   Private Sub textEdit_KeyUp( _
                     ByVal sender As Object, _
                     ByVal e As KeyEventArgs _
                     ) _
                     Handles textEdit.KeyUp
      '  Check to see if the keystroke was Enter or Escape
      Select Case e.KeyCode
         Case Keys.Enter, Keys.Escape
            '  If so,
            '     note which was requested,
            '     hide the edit TextBox.
            Me.boolCancelUpdate = (e.KeyCode = Keys.Escape)
            textEdit.Visible = False
         Case Else
      End Select
   End Sub


   Private Sub textEdit_Validating( _
                     ByVal sender As Object, _
                     ByVal e As CancelEventArgs _
                     ) _
                     Handles textEdit.Validating

      '  To cancel or not to cancel, 
      '     that is the question.
      e.Cancel = boolCancelUpdate
      boolCancelUpdate = False
   End Sub


   Private Sub textEdit_Validated( _
                     ByVal sender As Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles textEdit.Validated

      '  Do the update.
      '  Two issues must be addressed here.  The cell 
      '     we need to update might no longer be
      '     the CurrentCell; and modifying the contents 
      '     a cell makes it the CurrentCell.  Therefore,
      '     we need to save the identity of the CurrentCell 
      '     at the start, update the cell whose identity 
      '     was saved during InitEdit, then restore the 
      '     identity of the CurrentCell.
      With dgrdProjects
         '  Save identity of CurrentCell.
         Dim CurrentCell As DataGridCell = .CurrentCell

         '  Move the contents of textEdit into the 
         '     "correct" CurrentCell.
         .Item(Me.CurrentCell.RowNumber, _
               Me.CurrentCell.ColumnNumber) = textEdit.Text

         '  Restore the identity of the CurrentCell.
         .CurrentCell = CurrentCell
      End With
   End Sub


   Friend Sub InitEdit()
      '  Position textEdit for in-place editing
      With dgrdProjects.CurrentCell
         textEdit.Bounds = dgrdProjects.GetCellBounds _
                                 (.RowNumber, .ColumnNumber)
         textEdit.Text = dgrdProjects.Item _
                                 (.RowNumber, .ColumnNumber)
         textEdit.SelectAll()
         textEdit.Visible = True
         textEdit.Focus()
      End With

      '  Save the CurrentCell.  We must save it because,
      '     if the user terminates the edit by tapping on
      '     a different cell, a new CurrentCell will be
      '     assigned before we are finished with the old one.
      Me.CurrentCell = dgrdProjects.CurrentCell

      '  Set Form GUI state to "Editing".
      boolDoEdit = False
   End Sub


   Private Sub InitContextMenu()
      '  Add "Update" and "Cancel" entries
      '     to the context menu.
      mitemUpdate.Text = "Update"
      mitemCancel.Text = "Cancel"
      With cmenuEdit.MenuItems
         .Clear()
         .Add(mitemUpdate)
         .Add(mitemCancel)
      End With
   End Sub

End Class
