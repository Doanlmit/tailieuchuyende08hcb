' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.Windows.Forms

Public Class UtilGUI
   Friend Shared Sub AddCustomDataTableStyle( _
                     ByVal dgridTarget As DataGrid, _
                     ByVal strTable As String _
                     )
      Dim dgtsStyle As DataGridTableStyle
      Dim dgtsColumn As DataGridTextBoxColumn

      Select Case strTable
         Case "Projects"
            '  Define a Style for the "Projects" 
            '     DataTable or ArrayList to be used by
            '     the DataGrid when displaying projects.
            dgtsStyle = New DataGridTableStyle
            '  Specify that it is to be applied whenever
            '     a data object named Projects is assigned
            '     to the DataGrid's DataSource property.
            With dgtsStyle
               .MappingName = "Projects"
            End With

            '  Add columns.
            '  Specify:
            '     Column/field name
            '     Column header
            '     Column width in pixels.

            dgtsColumn = New DataGridTextBoxColumn
            With dgtsColumn
               .MappingName = "strName"
               .HeaderText = "Name"
               .Width = 100
            End With
            dgtsStyle.GridColumnStyles.Add(dgtsColumn)

            dgtsColumn = New DataGridTextBoxColumn
            With dgtsColumn
               .MappingName = "dateStart"
               .HeaderText = "Start"
               .Width = 50
            End With
            dgtsStyle.GridColumnStyles.Add(dgtsColumn)

            dgtsColumn = New DataGridTextBoxColumn
            With dgtsColumn
               .MappingName = "dateEnd"
               .HeaderText = "End"
               .Width = 50
            End With
            dgtsStyle.GridColumnStyles.Add(dgtsColumn)

            dgtsColumn = New DataGridTextBoxColumn
            With dgtsColumn
               .MappingName = "ctTasks"
               .HeaderText = "Tasks"
               .Width = 50
            End With
            dgtsStyle.GridColumnStyles.Add(dgtsColumn)

            '  Add the style to the DataGrid.
            dgridTarget.TableStyles.Add(dgtsStyle)

         Case "Tasks"
         Case Else
      End Select
   End Sub

End Class
