' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Windows.Forms.DataGrid


Public Class FormMain
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents dgridDisplay As System.Windows.Forms.DataGrid
   Friend WithEvents lblProjectName As System.Windows.Forms.Label
   Friend WithEvents cmenuDrill As System.Windows.Forms.ContextMenu
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.dgridDisplay = New System.Windows.Forms.DataGrid
      Me.cmenuDrill = New System.Windows.Forms.ContextMenu
      Me.lblProjectName = New System.Windows.Forms.Label
      '
      'dgridDisplay
      '
      Me.dgridDisplay.ContextMenu = Me.cmenuDrill
      Me.dgridDisplay.Location = New System.Drawing.Point(0, 40)
      Me.dgridDisplay.Size = New System.Drawing.Size(240, 109)
      '
      'cmenuDrill
      '
      '
      'lblProjectName
      '
      Me.lblProjectName.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblProjectName.Location = New System.Drawing.Point(0, 8)
      Me.lblProjectName.Size = New System.Drawing.Size(240, 24)
      '
      'FormMain
      '
      Me.ClientSize = New System.Drawing.Size(240, 295)
      Me.Controls.Add(Me.lblProjectName)
      Me.Controls.Add(Me.dgridDisplay)
      Me.Text = "Binding Info"

   End Sub

#End Region

   '  A reference to the DataSet
   Private dsetTimeTracker As DataSet
   '  A reference to the Projects DataTable
   Private dtabProjects As DataTable
   '  A reference to the Tasks DataTable
   Private dtabTasks As DataTable

   '  Two ContextMenu items.
   Private WithEvents mitemDrillDown As New MenuItem
   Private WithEvents mitemDrillUp As New MenuItem


   Private Sub FormDataSet_Load( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles MyBase.Load

      '  Set references to data objects.
      Dim utilData As New YaoDurant.Data.UtilData
      dsetTimeTracker = utilData.GetProjectsDataSet()
      dtabProjects = dsetTimeTracker.Tables("Projects")
      dtabTasks = dsetTimeTracker.Tables("Tasks")

      With dgridDisplay
         '  Make the Project table the DataSource.
         .DataSource = dtabProjects

         '  Bind the "strIdent" column of the current 
         '     row to the Text property.
         .DataBindings.Clear()
         .DataBindings.Add("Text", .DataSource, "strIdent")
      End With

      '  Style the layout of the Projects in the DataGrid.
      YaoDurant.GUI.UtilGUI. _
         AddCustomDataTableStyle(dgridDisplay, "Projects")

      '  Initialize the ContectMenu
      InitContextMenu()
   End Sub


   Private Sub dgridDisplay_MouseUp( _
                  ByVal sender As Object, _
                  ByVal e As MouseEventArgs _
                  ) _
                  Handles dgridDisplay.MouseUp

      '  If the user has clicked in a row header,
      '     display the context menu.
      With dgridDisplay
         If .HitTest(e.X, e.Y).Type = HitTestType.RowHeader Then
            .ContextMenu.Show(dgridDisplay, New Point(e.X, e.Y))
         End If
      End With
   End Sub


   Private Sub cmenuDrill_Popup( _
                     ByVal sender As Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles cmenuDrill.Popup
      '  If the user is "Up", they can only go "Down"; 
      '     and vice versa.
      With mitemDrillDown
         If dgridDisplay.DataSource Is dtabProjects Then
            .Enabled = True
            .Checked = False
         Else
            .Enabled = False
            .Checked = True
         End If
         mitemDrillUp.Enabled = Not .Enabled
         mitemDrillUp.Checked = Not .Checked
      End With
   End Sub

   Private Sub mitemDrillDown_Click( _
                     ByVal sender As Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles mitemDrillDown.Click
      '  The Text property of the DataGrid has been bound
      '     to the strIdent column of the DataSource row.
      '     So, the identity of the selected Project will
      '     be in the Text property.
      DrillDown(dgridDisplay.Text)
   End Sub


   Private Sub mitemDrillUp_Click( _
                     ByVal sender As Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles mitemDrillUp.Click
      DrillUp()
   End Sub


   Private Sub DrillDown(ByVal strProjIdent As String)
      '  Note which project is being displayed.
      With lblProjectName
         .Text = dtabProjects.Rows _
            (dgridDisplay.CurrentCell.RowNumber).Item("strName")
      End With

      '  Create a view of the Tasks table.
      Dim dviewProjectTasks As New DataView(dtabTasks)

      '  Set it to display only "strProjIdent" tasks.
      With dviewProjectTasks
         .RowFilter = "strProjIdent = '" & strProjIdent & "'"
      End With

      '  Bind it to the DataGrid control.
      With dgridDisplay
         .DataSource = dviewProjectTasks
      End With
   End Sub


   Private Sub DrillUp()
      '  Bind the Projects DataTable to the DataGrid control.
      With dgridDisplay
         .DataSource = dtabProjects
      End With

      '  Clear the project name display.
      With lblProjectName
         .Text = String.Empty
      End With
   End Sub


   Private Sub InitContextMenu()
      '  Add "drill down" and "drill up" entries
      '     to the context menu.
      cmenuDrill.MenuItems.Clear()

      mitemDrillDown.Text = "Drill Down"
      cmenuDrill.MenuItems.Add(mitemDrillDown)

      mitemDrillUp.Text = "Drill Up"
      cmenuDrill.MenuItems.Add(mitemDrillUp)
   End Sub

End Class

