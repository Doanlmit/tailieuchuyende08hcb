Public Class FormMain
    Inherits System.Windows.Forms.Form
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
'
'FormMain
'
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Named Fonts"

    End Sub

#End Region

   Private Sub FormMain_Paint( _
   ByVal sender As Object, _
   ByVal e As System.Windows.Forms.PaintEventArgs) _
   Handles MyBase.Paint
      Dim g As Graphics = e.Graphics
      Dim x As Single = 10
      Dim y As Single = 10

      Dim font1 As Font = _
         New Font("Tahoma", 14, FontStyle.Regular)
      Dim font2 As Font = _
         New Font("Courier New", 10, FontStyle.Regular)
      Dim font3 As Font = _
         New Font("Bookdings", 12, FontStyle.Regular)

      Dim brText As Brush = _
         New SolidBrush(SystemColors.WindowText)

      g.DrawString("14 Point Tahoma", font1, brText, x, y)
      Dim sizeX As SizeF = g.MeasureString("X", font1)
      y += sizeX.Height

      g.DrawString("10 Point Courier New", font2, brText, x, y)
      sizeX = g.MeasureString("X", font2)
      y += sizeX.Height

      g.DrawString("12 Point Bookdings", font3, brText, x, y)

      ' Cleanup
      font1.Dispose()
      font2.Dispose()
      font3.Dispose()
      brText.Dispose()

   End Sub
End Class
