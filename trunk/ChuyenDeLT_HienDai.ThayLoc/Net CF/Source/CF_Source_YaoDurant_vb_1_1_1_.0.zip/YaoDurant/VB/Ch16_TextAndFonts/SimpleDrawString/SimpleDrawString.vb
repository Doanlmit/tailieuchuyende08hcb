' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Drawing

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents sbarMain As System.Windows.Forms.StatusBar
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.sbarMain = New System.Windows.Forms.StatusBar
'
'sbarMain
'
Me.sbarMain.Location = New System.Drawing.Point(0, 248)
Me.sbarMain.Size = New System.Drawing.Size(240, 22)
Me.sbarMain.Text = "Tap to set text location  -  (10,10)"
'
'FormMain
'
Me.Controls.Add(Me.sbarMain)
Me.Menu = Me.MainMenu1
Me.Text = "SimpleDrawString"

    End Sub

#End Region

Private xDraw As Single = 10
Private yDraw As Single = 10

Private Sub FormMain_Paint( _
   ByVal sender As Object, _
   ByVal e As System.Windows.Forms.PaintEventArgs) _
   Handles MyBase.Paint

   Dim brText As Brush = New SolidBrush(SystemColors.WindowText)
   e.Graphics.DrawString("Simple Draw String", Font, brText, _
   xDraw, yDraw)

   ' Highlight origin.
   Dim X As Integer = CInt(xDraw)
   Dim y As Integer = CInt(yDraw)
   Dim penBlack As Pen = New Pen(Color.Black)
   e.Graphics.DrawLine(penBlack, X, y, X - 8, y)
   e.Graphics.DrawLine(penBlack, X, y, X, y - 8)

   ' Cleanup
   brText.Dispose()
   penBlack.Dispose()

End Sub

Private Sub FormMain_MouseDown( _
   ByVal sender As Object, _
   ByVal e As System.Windows.Forms.MouseEventArgs) _
   Handles MyBase.MouseDown

   sbarMain.Text = "Tap to set text location  -  (" + _
      e.X.ToString() + "," + e.Y.ToString() + ")"
   xDraw = e.X
   yDraw = e.Y
   Invalidate()
End Sub
End Class
