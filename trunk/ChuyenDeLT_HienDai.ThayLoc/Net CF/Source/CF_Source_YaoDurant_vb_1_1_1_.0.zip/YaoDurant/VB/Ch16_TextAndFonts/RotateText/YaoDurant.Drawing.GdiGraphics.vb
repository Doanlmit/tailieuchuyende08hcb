' YaoDurant.Drawing.DC.vb - Wrapper for various Win32 functions
' which deal with a DC.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Windows.Forms
Imports System.Runtime.InteropServices

'
' VB namespace note: VB programs have a default root namespace
' which is the same as the project name. To establish a separate
' namespace that is not part of the root namespace, like the
' YaoDurant.Drawing namespace here, remove the definition of
' the namespace in the project properties dialog box.
Namespace YaoDurant.Drawing
Public Class GdiGraphics
   <DllImport("coredll.dll")> _
   Public Shared Function GetDeviceCaps( _
   ByVal hdc As IntPtr, ByVal iIndex As Integer) As Integer
   End Function

   Public Const LOGPIXELSY As Integer = 90

   <DllImport("coredll.dll")> _
   Public Shared Function GetDC(ByVal hWnd As IntPtr) As IntPtr
   End Function
   <DllImport("coredll.dll")> _
   Public Shared Function ReleaseDC(ByVal hWnd As IntPtr, _
   ByVal hDC As IntPtr) As IntPtr
   End Function
   <DllImport("coredll.dll", EntryPoint:="ExtTextOutW")> _
   Public Shared Function Real_ExtTextOut(ByVal hDC As IntPtr, _
   ByVal X As Integer, ByVal Y As Integer, _
   ByVal fuOptions As Integer, ByVal lprc As IntPtr, _
   ByVal lpString As String, ByVal cbCount As Integer, _
   ByVal lpDx As IntPtr) As IntPtr
   End Function
   <DllImport("coredll.dll")> _
   Public Shared Function DeleteObject( _
   ByVal hObject As IntPtr) As IntPtr
   End Function
   <DllImport("coredll.dll")> _
   Public Shared Function SelectObject( _
   ByVal hDC As IntPtr, ByVal hgdiobj As IntPtr) As IntPtr
   End Function
   <DllImport("coredll.dll")> _
   Public Shared Function SetBkMode(ByVal hDC As IntPtr, _
   ByVal iBkMode As Integer) As Integer
   End Function

   Public Const TRANSPARENT As Integer = 1


   Public Shared Function ExtTextOut(ByVal hdc As IntPtr, _
   ByVal X As Integer, ByVal Y As Integer, _
   ByVal fuOptions As Integer, ByVal lprc As IntPtr, _
   ByVal lpString As String, ByVal cbCount As Integer, _
   ByVal lpDx As IntPtr) As IntPtr
      ' Set drawing mode to "transparent" (only touch
      ' foreground pixels.)
      SetBkMode(hdc, TRANSPARENT)

      Return Real_ExtTextOut(hdc, X, Y, fuOptions, lprc, _
        lpString, cbCount, lpDx)
   End Function

End Class

End Namespace
