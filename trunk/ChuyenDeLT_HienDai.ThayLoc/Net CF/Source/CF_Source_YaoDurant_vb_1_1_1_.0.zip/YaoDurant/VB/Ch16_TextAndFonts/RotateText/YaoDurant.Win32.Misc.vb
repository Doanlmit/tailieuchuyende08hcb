' YaoDurant.Win32.Misc.vb - Wrapper for various Win32 functions.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System.Runtime.InteropServices

Namespace YaoDurant.Win32

Public Class WinFocus
   <DllImport("coredll.dll")> _
   Public Shared Function GetFocus() As IntPtr
   End Function
   <DllImport("coredll.dll")> _
   Public Shared Function SetFocus(ByVal hWnd As IntPtr) As IntPtr
   End Function

End Class

Public Class NativeHeap
   '
   ' Memory allocation functions & definitions.
   '
   <DllImport("coredll.dll")> _
   Public Shared Function LocalAlloc( _
   ByVal uFlags As Integer, ByVal uBytes As Integer) As IntPtr
   End Function
   <DllImport("coredll.dll")> _
   Public Shared Function LocalFree( _
   ByVal hMem As IntPtr) As IntPtr
   End Function
   Public Const LPTR As Integer = &H40

End Class

End Namespace

