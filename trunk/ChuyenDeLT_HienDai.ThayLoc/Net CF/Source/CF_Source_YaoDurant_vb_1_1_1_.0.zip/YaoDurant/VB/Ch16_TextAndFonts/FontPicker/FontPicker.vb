' FontPicker.vb - Enumerates fonts and allows user to pick
' font name, size, and style.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents cboxFont As System.Windows.Forms.ComboBox
      Friend WithEvents cboxSize As System.Windows.Forms.ComboBox
      Friend WithEvents cboxStyle As System.Windows.Forms.ComboBox
      Friend WithEvents textSample As System.Windows.Forms.TextBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.cboxFont = New System.Windows.Forms.ComboBox
Me.cboxSize = New System.Windows.Forms.ComboBox
Me.cboxStyle = New System.Windows.Forms.ComboBox
Me.textSample = New System.Windows.Forms.TextBox
'
'cboxFont
'
Me.cboxFont.Size = New System.Drawing.Size(128, 22)
'
'cboxSize
'
Me.cboxSize.Items.Add("8")
Me.cboxSize.Items.Add("10")
Me.cboxSize.Items.Add("12")
Me.cboxSize.Items.Add("14")
Me.cboxSize.Items.Add("16")
Me.cboxSize.Items.Add("18")
Me.cboxSize.Items.Add("20")
Me.cboxSize.Items.Add("24")
Me.cboxSize.Items.Add("28")
Me.cboxSize.Items.Add("36")
Me.cboxSize.Items.Add("72")
Me.cboxSize.Location = New System.Drawing.Point(128, 0)
Me.cboxSize.Size = New System.Drawing.Size(40, 22)
'
'cboxStyle
'
Me.cboxStyle.Items.Add("Regular")
Me.cboxStyle.Items.Add("Bold")
Me.cboxStyle.Items.Add("Italic")
Me.cboxStyle.Items.Add("Strikeout")
Me.cboxStyle.Items.Add("Underline")
Me.cboxStyle.Location = New System.Drawing.Point(168, 0)
Me.cboxStyle.Size = New System.Drawing.Size(72, 22)
'
'textSample
'
Me.textSample.Location = New System.Drawing.Point(16, 40)
Me.textSample.Multiline = True
Me.textSample.Size = New System.Drawing.Size(208, 216)
Me.textSample.Text = "Sample Text"
'
'FormMain
'
Me.Controls.Add(Me.textSample)
Me.Controls.Add(Me.cboxStyle)
Me.Controls.Add(Me.cboxSize)
Me.Controls.Add(Me.cboxFont)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "FontPicker"

    End Sub

#End Region

   Private fonts As YaoDurant.Drawing.FontCollection

   Private Sub FormMain_Load(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Load
      ' Add font face names to cboxFont combo box
      Try
         ' Create managed code font collection.
         fonts = New YaoDurant.Drawing.FontCollection

         ' Loop through collection, adding all items to combo box
         Dim i As Integer
         For i = 0 To fonts.Count - 1 Step i + 1
            cboxFont.Items.Add(fonts(i))
         Next

         fonts.Dispose()
         fonts = Nothing
      Catch
         Dim str As String = "Error: cannot create FontCollection" + _
            " -- make sure fontlist.dll is installed"
         MessageBox.Show(Str, "FontPicker")
      End Try

      ' Set initial font name, size, and style.
      cboxFont.SelectedIndex = 0
      cboxSize.SelectedIndex = 0
      cboxStyle.SelectedIndex = 0

   End Sub

   Private Sub SetFont()
      Dim iFont As Integer = cboxFont.SelectedIndex
      Dim iSize As Integer = cboxSize.SelectedIndex
      Dim iStyle As Integer = cboxStyle.SelectedIndex
      If iFont <> -1 And iSize <> -1 And iStyle <> -1 Then
         Dim strFont As String = CType(cboxFont.Items(iFont), String)
         Dim strSize As String = CType(cboxSize.Items(iSize), String)
         iSize = Integer.Parse(strSize)

         Dim fs As FontStyle
         If iStyle = 0 Then
            fs = FontStyle.Regular
         ElseIf iStyle = 1 Then
            fs = FontStyle.Bold
         ElseIf iStyle = 2 Then
            fs = FontStyle.Italic
         ElseIf iStyle = 3 Then
            fs = FontStyle.Strikeout
         Else
            fs = FontStyle.Underline
         End If

         ' Create a new font.
         Dim font As Font = New Font(strFont, CSng(iSize), fs)

         ' Connect font to textbox
         textSample.Font = Font

         ' Clean up font.
         Font.Dispose()
      End If
   End Sub


   Private Sub cboxFont_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboxFont.SelectedIndexChanged
      SetFont()
   End Sub

   Private Sub cboxSize_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboxSize.SelectedIndexChanged
      SetFont()
   End Sub

   Private Sub cboxStyle_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboxStyle.SelectedIndexChanged
      SetFont()
   End Sub

End Class
