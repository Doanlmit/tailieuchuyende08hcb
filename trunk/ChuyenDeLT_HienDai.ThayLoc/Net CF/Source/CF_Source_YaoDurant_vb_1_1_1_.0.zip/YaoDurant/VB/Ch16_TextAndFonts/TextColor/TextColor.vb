Imports YaoDurant.Drawing

Namespace TextColor

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents label3 As System.Windows.Forms.Label
      Friend WithEvents label4 As System.Windows.Forms.Label
      Friend WithEvents label5 As System.Windows.Forms.Label
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents lblTextR As System.Windows.Forms.Label
      Friend WithEvents lblTextG As System.Windows.Forms.Label
      Friend WithEvents lblTextB As System.Windows.Forms.Label
      Friend WithEvents lblBackR As System.Windows.Forms.Label
      Friend WithEvents lblBackG As System.Windows.Forms.Label
      Friend WithEvents lblBackB As System.Windows.Forms.Label
      Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextSetColor As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextControlText As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextGrayText As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextHighlightText As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextInfoText As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextMenuText As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextWindowText As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextAliceBlue As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextBeige As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextCoral As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextDeepPink As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextFireBrick As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextGainsboro As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextHoneyDew As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem18 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackSetColor As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem20 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackControl As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackHighlight As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackInfo As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackMenu As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackWindow As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem26 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackIndigo As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackKhaki As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackLavendar As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackMagenta As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackNavy As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackOlive As System.Windows.Forms.MenuItem
      Friend WithEvents mitemBackPlum As System.Windows.Forms.MenuItem

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.menuMain = New System.Windows.Forms.MainMenu
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitemTextSetColor = New System.Windows.Forms.MenuItem
Me.MenuItem3 = New System.Windows.Forms.MenuItem
Me.mitemTextControlText = New System.Windows.Forms.MenuItem
Me.mitemTextGrayText = New System.Windows.Forms.MenuItem
Me.mitemTextHighlightText = New System.Windows.Forms.MenuItem
Me.mitemTextInfoText = New System.Windows.Forms.MenuItem
Me.mitemTextMenuText = New System.Windows.Forms.MenuItem
Me.mitemTextWindowText = New System.Windows.Forms.MenuItem
Me.MenuItem10 = New System.Windows.Forms.MenuItem
Me.mitemTextAliceBlue = New System.Windows.Forms.MenuItem
Me.mitemTextBeige = New System.Windows.Forms.MenuItem
Me.mitemTextCoral = New System.Windows.Forms.MenuItem
Me.mitemTextDeepPink = New System.Windows.Forms.MenuItem
Me.mitemTextFireBrick = New System.Windows.Forms.MenuItem
Me.mitemTextGainsboro = New System.Windows.Forms.MenuItem
Me.mitemTextHoneyDew = New System.Windows.Forms.MenuItem
Me.MenuItem18 = New System.Windows.Forms.MenuItem
Me.mitemBackSetColor = New System.Windows.Forms.MenuItem
Me.MenuItem20 = New System.Windows.Forms.MenuItem
Me.mitemBackControl = New System.Windows.Forms.MenuItem
Me.mitemBackHighlight = New System.Windows.Forms.MenuItem
Me.mitemBackInfo = New System.Windows.Forms.MenuItem
Me.mitemBackMenu = New System.Windows.Forms.MenuItem
Me.mitemBackWindow = New System.Windows.Forms.MenuItem
Me.MenuItem26 = New System.Windows.Forms.MenuItem
Me.mitemBackIndigo = New System.Windows.Forms.MenuItem
Me.mitemBackKhaki = New System.Windows.Forms.MenuItem
Me.mitemBackLavendar = New System.Windows.Forms.MenuItem
Me.mitemBackMagenta = New System.Windows.Forms.MenuItem
Me.mitemBackNavy = New System.Windows.Forms.MenuItem
Me.mitemBackOlive = New System.Windows.Forms.MenuItem
Me.mitemBackPlum = New System.Windows.Forms.MenuItem
Me.label3 = New System.Windows.Forms.Label
Me.label4 = New System.Windows.Forms.Label
Me.label5 = New System.Windows.Forms.Label
Me.label1 = New System.Windows.Forms.Label
Me.label2 = New System.Windows.Forms.Label
Me.lblTextR = New System.Windows.Forms.Label
Me.lblTextG = New System.Windows.Forms.Label
Me.lblTextB = New System.Windows.Forms.Label
Me.lblBackR = New System.Windows.Forms.Label
Me.lblBackG = New System.Windows.Forms.Label
Me.lblBackB = New System.Windows.Forms.Label
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.MenuItem1)
Me.menuMain.MenuItems.Add(Me.MenuItem18)
'
'MenuItem1
'
Me.MenuItem1.MenuItems.Add(Me.mitemTextSetColor)
Me.MenuItem1.MenuItems.Add(Me.MenuItem3)
Me.MenuItem1.MenuItems.Add(Me.MenuItem10)
Me.MenuItem1.Text = "Text"
'
'mitemTextSetColor
'
Me.mitemTextSetColor.Text = "Set Color..."
'
'MenuItem3
'
Me.MenuItem3.MenuItems.Add(Me.mitemTextControlText)
Me.MenuItem3.MenuItems.Add(Me.mitemTextGrayText)
Me.MenuItem3.MenuItems.Add(Me.mitemTextHighlightText)
Me.MenuItem3.MenuItems.Add(Me.mitemTextInfoText)
Me.MenuItem3.MenuItems.Add(Me.mitemTextMenuText)
Me.MenuItem3.MenuItems.Add(Me.mitemTextWindowText)
Me.MenuItem3.Text = "System Colors"
'
'mitemTextControlText
'
Me.mitemTextControlText.Text = "ControlText"
'
'mitemTextGrayText
'
Me.mitemTextGrayText.Text = "GrayText"
'
'mitemTextHighlightText
'
Me.mitemTextHighlightText.Text = "HighlightText"
'
'mitemTextInfoText
'
Me.mitemTextInfoText.Text = "InfoText"
'
'mitemTextMenuText
'
Me.mitemTextMenuText.Text = "MenuText"
'
'mitemTextWindowText
'
Me.mitemTextWindowText.Text = "WindowText"
'
'MenuItem10
'
Me.MenuItem10.MenuItems.Add(Me.mitemTextAliceBlue)
Me.MenuItem10.MenuItems.Add(Me.mitemTextBeige)
Me.MenuItem10.MenuItems.Add(Me.mitemTextCoral)
Me.MenuItem10.MenuItems.Add(Me.mitemTextDeepPink)
Me.MenuItem10.MenuItems.Add(Me.mitemTextFireBrick)
Me.MenuItem10.MenuItems.Add(Me.mitemTextGainsboro)
Me.MenuItem10.MenuItems.Add(Me.mitemTextHoneyDew)
Me.MenuItem10.Text = "Named Colors"
'
'mitemTextAliceBlue
'
Me.mitemTextAliceBlue.Text = "AliceBlue"
'
'mitemTextBeige
'
Me.mitemTextBeige.Text = "Beige"
'
'mitemTextCoral
'
Me.mitemTextCoral.Text = "Coral"
'
'mitemTextDeepPink
'
Me.mitemTextDeepPink.Text = "DeepPink"
'
'mitemTextFireBrick
'
Me.mitemTextFireBrick.Text = "FireBrick"
'
'mitemTextGainsboro
'
Me.mitemTextGainsboro.Text = "Gainsboro"
'
'mitemTextHoneyDew
'
Me.mitemTextHoneyDew.Text = "HoneyDew"
'
'MenuItem18
'
Me.MenuItem18.MenuItems.Add(Me.mitemBackSetColor)
Me.MenuItem18.MenuItems.Add(Me.MenuItem20)
Me.MenuItem18.MenuItems.Add(Me.MenuItem26)
Me.MenuItem18.Text = "Background"
'
'mitemBackSetColor
'
Me.mitemBackSetColor.Text = "Set Color..."
'
'MenuItem20
'
Me.MenuItem20.MenuItems.Add(Me.mitemBackControl)
Me.MenuItem20.MenuItems.Add(Me.mitemBackHighlight)
Me.MenuItem20.MenuItems.Add(Me.mitemBackInfo)
Me.MenuItem20.MenuItems.Add(Me.mitemBackMenu)
Me.MenuItem20.MenuItems.Add(Me.mitemBackWindow)
Me.MenuItem20.Text = "System Colors"
'
'mitemBackControl
'
Me.mitemBackControl.Text = "Control"
'
'mitemBackHighlight
'
Me.mitemBackHighlight.Text = "Highlight"
'
'mitemBackInfo
'
Me.mitemBackInfo.Text = "Info"
'
'mitemBackMenu
'
Me.mitemBackMenu.Text = "Menu"
'
'mitemBackWindow
'
Me.mitemBackWindow.Text = "Window"
'
'MenuItem26
'
Me.MenuItem26.MenuItems.Add(Me.mitemBackIndigo)
Me.MenuItem26.MenuItems.Add(Me.mitemBackKhaki)
Me.MenuItem26.MenuItems.Add(Me.mitemBackLavendar)
Me.MenuItem26.MenuItems.Add(Me.mitemBackMagenta)
Me.MenuItem26.MenuItems.Add(Me.mitemBackNavy)
Me.MenuItem26.MenuItems.Add(Me.mitemBackOlive)
Me.MenuItem26.MenuItems.Add(Me.mitemBackPlum)
Me.MenuItem26.Text = "Named Colors"
'
'mitemBackIndigo
'
Me.mitemBackIndigo.Text = "Indigo"
'
'mitemBackKhaki
'
Me.mitemBackKhaki.Text = "Khaki"
'
'mitemBackLavendar
'
Me.mitemBackLavendar.Text = "Lavender"
'
'mitemBackMagenta
'
Me.mitemBackMagenta.Text = "Magenta"
'
'mitemBackNavy
'
Me.mitemBackNavy.Text = "Navy"
'
'mitemBackOlive
'
Me.mitemBackOlive.Text = "Olive"
'
'mitemBackPlum
'
Me.mitemBackPlum.Text = "Plum"
'
'label3
'
Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
Me.label3.Location = New System.Drawing.Point(88, 128)
Me.label3.Size = New System.Drawing.Size(40, 20)
Me.label3.Text = "Red"
'
'label4
'
Me.label4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
Me.label4.Location = New System.Drawing.Point(120, 128)
Me.label4.Size = New System.Drawing.Size(48, 20)
Me.label4.Text = "Green"
'
'label5
'
Me.label5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
Me.label5.Location = New System.Drawing.Point(168, 128)
Me.label5.Size = New System.Drawing.Size(40, 20)
Me.label5.Text = "Blue"
'
'label1
'
Me.label1.Location = New System.Drawing.Point(36, 152)
Me.label1.Size = New System.Drawing.Size(40, 20)
Me.label1.Text = "Text:"
Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'label2
'
Me.label2.Location = New System.Drawing.Point(0, 176)
Me.label2.Size = New System.Drawing.Size(80, 20)
Me.label2.Text = "Background:"
Me.label2.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'lblTextR
'
Me.lblTextR.Location = New System.Drawing.Point(88, 152)
Me.lblTextR.Size = New System.Drawing.Size(40, 20)
'
'lblTextG
'
Me.lblTextG.Location = New System.Drawing.Point(128, 152)
Me.lblTextG.Size = New System.Drawing.Size(40, 20)
'
'lblTextB
'
Me.lblTextB.Location = New System.Drawing.Point(168, 152)
Me.lblTextB.Size = New System.Drawing.Size(40, 20)
'
'lblBackR
'
Me.lblBackR.Location = New System.Drawing.Point(88, 176)
Me.lblBackR.Size = New System.Drawing.Size(40, 20)
'
'lblBackG
'
Me.lblBackG.Location = New System.Drawing.Point(128, 176)
Me.lblBackG.Size = New System.Drawing.Size(40, 20)
'
'lblBackB
'
Me.lblBackB.Location = New System.Drawing.Point(168, 176)
Me.lblBackB.Size = New System.Drawing.Size(40, 20)
'
'FormMain
'
Me.Controls.Add(Me.lblBackB)
Me.Controls.Add(Me.lblBackG)
Me.Controls.Add(Me.lblBackR)
Me.Controls.Add(Me.lblTextB)
Me.Controls.Add(Me.lblTextG)
Me.Controls.Add(Me.lblTextR)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.label1)
Me.Controls.Add(Me.label5)
Me.Controls.Add(Me.label4)
Me.Controls.Add(Me.label3)
Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "TextColor"

    End Sub

#End Region

   Private Sub FormMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
      DisplayRGBComponents()
   End Sub

   '
   ' Display color picker dialog -- foreground color
   '
   Private Sub mitemTextSetColor_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemTextSetColor.Click
      Dim ccdlg As ChooseColorDlg = New ChooseColorDlg
      ccdlg.Init(Me)
      If ccdlg.ShowDialog(m_clrText) Then
         Invalidate()
         DisplayRGBComponents()
      End If
   End Sub

   '
   ' Display color picker dialog -- background color
   '
   Private Sub mitemBackSetColor_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemBackSetColor.Click
      Dim ccdlg As ChooseColorDlg = New ChooseColorDlg
      ccdlg.Init(Me)
      If ccdlg.ShowDialog(m_clrBack) Then
         Invalidate()
         DisplayRGBComponents()
      End If
   End Sub

   ' Private data
   Dim m_clrBack As Color = SystemColors.Window
   Dim m_clrText As Color = SystemColors.WindowText

   Private Sub FormMain_Paint(ByVal sender As Object, _
   ByVal e As System.Windows.Forms.PaintEventArgs) _
   Handles MyBase.Paint
      Dim g As Graphics = e.Graphics

      ' The string to draw.
      Dim strDraw As String = "Text Color"

      ' String location -- in floating point.
      Dim sinX As Single = 10.0F
      Dim sinY As Single = 10.0F

      ' Location as integers.
      Dim x As Integer = CType(sinX, Integer)
      Dim y As Integer = CType(sinY, Integer)

      ' Draw background if needed
      If (Not m_clrBack.Equals(SystemColors.Window)) Then
         ' Calculate size of string bounding box.
         Dim size As SizeF = g.MeasureString(strDraw, Font)
         Dim cx As Integer = CType(size.Width, Integer)
         Dim cy As Integer = CType(size.Height, Integer)

         ' Draw text bounding box.
         Dim rc As Rectangle = New Rectangle(x, y, cx, cy)

         Dim brBack As Brush = New SolidBrush(m_clrBack)
         g.FillRectangle(brBack, rc)
         brBack.Dispose()
      End If

      Dim brText As Brush = New SolidBrush(m_clrText)
      g.DrawString(strDraw, Font, brText, sinX, sinY)
      brText.Dispose()
   End Sub

   Private Sub DisplayRGBComponents()
      Dim byt As Byte = m_clrText.R
      lblTextR.Text = byt.ToString("000")
      byt = m_clrText.G
      lblTextG.Text = byt.ToString("000")
      byt = m_clrText.B
      lblTextB.Text = byt.ToString("000")

      byt = m_clrBack.R
      lblBackR.Text = byt.ToString("000")
      byt = m_clrBack.G
      lblBackG.Text = byt.ToString("000")
      byt = m_clrBack.B
      lblBackB.Text = byt.ToString("000")
   End Sub

   Private Sub SetTextColor(ByVal clr As Color)
      m_clrText = clr
      Invalidate()
      DisplayRGBComponents()
   End Sub

   Private Sub SetBackColor(ByVal clr As Color)
      m_clrBack = clr
      Invalidate()
      DisplayRGBComponents()
   End Sub

   Private Sub mitemTextControlText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextControlText.Click
      SetTextColor(SystemColors.ControlText)
   End Sub

   Private Sub mitemTextGrayText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextGrayText.Click
      SetTextColor(SystemColors.GrayText)
   End Sub

   Private Sub mitemTextHighlightText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextHighlightText.Click
      SetTextColor(SystemColors.HighlightText)
   End Sub

   Private Sub mitemTextInfoText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextInfoText.Click
      SetTextColor(SystemColors.InfoText)
   End Sub

   Private Sub mitemTextMenuText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextMenuText.Click
      SetTextColor(SystemColors.MenuText)
   End Sub

   Private Sub mitemTextWindowText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextWindowText.Click
      SetTextColor(SystemColors.WindowText)
   End Sub

   Private Sub mitemTextAliceBlue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextAliceBlue.Click
      SetTextColor(Color.AliceBlue)
   End Sub

   Private Sub mitemTextBeige_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextBeige.Click
      SetTextColor(Color.Beige)
   End Sub

   Private Sub mitemTextCoral_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextCoral.Click
      SetTextColor(Color.Coral)
   End Sub

   Private Sub mitemTextDeepPink_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextDeepPink.Click
      SetTextColor(Color.DeepPink)
   End Sub

   Private Sub mitemTextFireBrick_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextFireBrick.Click
      SetTextColor(Color.Firebrick)
   End Sub

   Private Sub mitemTextGainsboro_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextGainsboro.Click
      SetTextColor(Color.Gainsboro)
   End Sub

   Private Sub mitemTextHoneyDew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextHoneyDew.Click
      SetTextColor(Color.Honeydew)
   End Sub

   Private Sub mitemBackControl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackControl.Click
      SetBackColor(SystemColors.Control)
   End Sub

   Private Sub mitemBackHighlight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackHighlight.Click
      SetBackColor(SystemColors.Highlight)
   End Sub

   Private Sub mitemBackInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackInfo.Click
      SetBackColor(SystemColors.Info)
   End Sub

   Private Sub mitemBackMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackMenu.Click
      SetBackColor(SystemColors.Menu)
   End Sub

   Private Sub mitemBackWindow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackWindow.Click
      SetBackColor(SystemColors.Window)
   End Sub

   Private Sub mitemBackIndigo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackIndigo.Click
      SetBackColor(Color.Indigo)
   End Sub

   Private Sub mitemBackKhaki_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackKhaki.Click
      SetBackColor(Color.Khaki)
   End Sub

   Private Sub mitemBackLavendar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackLavendar.Click
      SetBackColor(Color.Lavender)
   End Sub

   Private Sub mitemBackMagenta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackMagenta.Click
      SetBackColor(Color.Magenta)
   End Sub

   Private Sub mitemBackNavy_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackNavy.Click
      SetBackColor(Color.Navy)
   End Sub

   Private Sub mitemBackOlive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackOlive.Click
      SetBackColor(Color.Olive)
   End Sub

   Private Sub mitemBackPlum_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemBackPlum.Click
      SetBackColor(Color.Plum)
   End Sub

End Class
End Namespace
