' RotateText.vb - Show various effects which are possible by
' creating a rotated Win32 font.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System.Runtime.InteropServices
Imports YaoDurant.Drawing
Imports YaoDurant.Win32

'
' VB namespace note: VB programs have a default root namespace
' which is the same as the project name. To establish a separate
' namespace that is not part of the root namespace, like the
' YaoDurant.Drawing in this project, we define an explicit
' namespace in our code (RotateText, below) and then remove the 
' default root namespace definition from the project properties 
' dialog box.
Namespace RotateText

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents textAngle As System.Windows.Forms.TextBox
      Friend WithEvents cmdClear As System.Windows.Forms.Button
      Friend WithEvents cmdRedraw As System.Windows.Forms.Button
      Friend WithEvents cmdFanBlade As System.Windows.Forms.Button
      Friend WithEvents cmdAnimate As System.Windows.Forms.Button
      Friend WithEvents sbarMain As System.Windows.Forms.StatusBar
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.label1 = New System.Windows.Forms.Label
Me.textAngle = New System.Windows.Forms.TextBox
Me.cmdClear = New System.Windows.Forms.Button
Me.cmdRedraw = New System.Windows.Forms.Button
Me.cmdFanBlade = New System.Windows.Forms.Button
Me.cmdAnimate = New System.Windows.Forms.Button
Me.sbarMain = New System.Windows.Forms.StatusBar
'
'label1
'
Me.label1.Location = New System.Drawing.Point(0, 11)
Me.label1.Size = New System.Drawing.Size(104, 16)
Me.label1.Text = "Angle of rotation:"
'
'textAngle
'
Me.textAngle.Location = New System.Drawing.Point(104, 8)
Me.textAngle.Size = New System.Drawing.Size(32, 22)
Me.textAngle.Text = "45"
'
'cmdClear
'
Me.cmdClear.Location = New System.Drawing.Point(160, 8)
Me.cmdClear.Text = "Clear"
'
'cmdRedraw
'
Me.cmdRedraw.Location = New System.Drawing.Point(8, 40)
Me.cmdRedraw.Size = New System.Drawing.Size(64, 20)
Me.cmdRedraw.Text = "Redraw"
'
'cmdFanBlade
'
Me.cmdFanBlade.Location = New System.Drawing.Point(80, 40)
Me.cmdFanBlade.Text = "Fan Blade"
'
'cmdAnimate
'
Me.cmdAnimate.Location = New System.Drawing.Point(160, 40)
Me.cmdAnimate.Text = "Animate"
'
'sbarMain
'
Me.sbarMain.Location = New System.Drawing.Point(0, 248)
Me.sbarMain.Size = New System.Drawing.Size(240, 22)
Me.sbarMain.Text = "Click to set text origin"
'
'FormMain
'
Me.Controls.Add(Me.sbarMain)
Me.Controls.Add(Me.cmdAnimate)
Me.Controls.Add(Me.cmdFanBlade)
Me.Controls.Add(Me.cmdRedraw)
Me.Controls.Add(Me.cmdClear)
Me.Controls.Add(Me.textAngle)
Me.Controls.Add(Me.label1)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "RotateText"

    End Sub

#End Region

      Private m_xText As Integer
      Private m_yText As Integer
      Private m_degRotate As Integer = 0
      Private m_hwndForm As IntPtr

      Public ReadOnly Property degRotate() As Integer
         Get
            Dim strRotate As String = textAngle.Text
            m_degRotate = 0
            Try
               m_degRotate = Integer.Parse(strRotate)
            Catch
            End Try
            Return m_degRotate
         End Get
      End Property

   Private Sub FormMain_Load( _
   ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Load
      m_xText = Width / 2
      m_yText = Height / 2
   End Sub

   Private Sub FormMain_GotFocus( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles MyBase.GotFocus
      m_hwndForm = WinFocus.GetFocus()
   End Sub

   Private Sub FormMain_Paint( _
   ByVal sender As Object, _
   ByVal e As System.Windows.Forms.PaintEventArgs) _
   Handles MyBase.Paint
      ' Fetch a Win32 DC.
      Dim hdc As IntPtr = GdiGraphics.GetDC(m_hwndForm)

      ' Create a Win32 font.
      Dim hfont As IntPtr
      hfont = GdiFont.Create(hdc, "Tahoma", 12, m_degRotate)

      ' Select font into DC.
      Dim hfontOld As IntPtr = GdiGraphics.SelectObject(hdc, hfont)

      ' Draw using Win32 text drawing function.
      GdiGraphics.ExtTextOut(hdc, m_xText, m_yText, _
         0, IntPtr.Zero, "Rotated Text", 12, IntPtr.Zero)

      ' Disconnect font from DC -- *Critical* because....
      GdiGraphics.SelectObject(hdc, hfontOld)

      ' ... clean up of Win32 font object requires font to
      ' be disconnected from any and all DCs.
      GdiGraphics.DeleteObject(hfont)

      ' Disconnect from Win32 DC.
      GdiGraphics.ReleaseDC(m_hwndForm, hdc)

   End Sub

   Private Sub FormMain_MouseDown( _
   ByVal sender As Object, _
   ByVal e As System.Windows.Forms.MouseEventArgs) _
   Handles MyBase.MouseDown
      m_xText = e.X
      m_yText = e.Y
      Invalidate()
   End Sub

   Private Sub cmdRedraw_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdRedraw.Click
      m_degRotate = degRotate
      Invalidate()
   End Sub

   Private Sub cmdFanBlade_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdFanBlade.Click
      Dim cIncrement As Integer = degRotate
      If cIncrement = 0 Then
         cIncrement = 45
      End If

      Dim hdc As IntPtr = GdiGraphics.GetDC(m_hwndForm)

      Dim i As Integer
      For i = 0 To 360 - 1 Step cIncrement
         Dim hfont As IntPtr = GdiFont.Create(hdc, "Tahoma", 12, i)
         Dim hfontOld As IntPtr = _
            GdiGraphics.SelectObject(hdc, hfont)
         GdiGraphics.ExtTextOut(hdc, m_xText, m_yText, 0, IntPtr.Zero, _
            "Rotated Text", 12, IntPtr.Zero)
         GdiGraphics.SelectObject(hdc, hfontOld)
         GdiGraphics.DeleteObject(hfont)
      Next

      GdiGraphics.ReleaseDC(m_hwndForm, hdc)
   End Sub

   Private Sub cmdClear_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdClear.Click
      Dim g As Graphics = Me.CreateGraphics()
      g.Clear(SystemColors.Window)
   End Sub

   Private Sub cmdAnimate_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles cmdAnimate.Click
      ' Use degrees as rotational increment.
      Dim cIncrement As Integer = degRotate
      If cIncrement = 0 Then
         cIncrement = 45
      End If

      Dim i As Integer
      For i = 0 To 360 - 1 Step cIncrement
         m_degRotate = i
         Invalidate()
         Update()
      Next

      m_degRotate = 0
      Invalidate()
      Update()
   End Sub

End Class
End Namespace
