Imports YaoDurant.Drawing.DrawRectangles
Namespace WordWrap
Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu
      Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextRed As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextBlue As System.Windows.Forms.MenuItem
      Friend WithEvents mitemTextDefault As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemRectangleYellow As System.Windows.Forms.MenuItem
      Friend WithEvents mitemRectangleAqua As System.Windows.Forms.MenuItem
      Friend WithEvents mitemRectangleDefault As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemRectangleBorder As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemWindowGreen As System.Windows.Forms.MenuItem
      Friend WithEvents mitemWindowBlack As System.Windows.Forms.MenuItem
      Friend WithEvents mitemWindowDefault As System.Windows.Forms.MenuItem

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.menuMain = New System.Windows.Forms.MainMenu
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitemTextRed = New System.Windows.Forms.MenuItem
Me.mitemTextBlue = New System.Windows.Forms.MenuItem
Me.mitemTextDefault = New System.Windows.Forms.MenuItem
Me.MenuItem5 = New System.Windows.Forms.MenuItem
Me.mitemRectangleYellow = New System.Windows.Forms.MenuItem
Me.mitemRectangleAqua = New System.Windows.Forms.MenuItem
Me.mitemRectangleDefault = New System.Windows.Forms.MenuItem
Me.MenuItem9 = New System.Windows.Forms.MenuItem
Me.mitemRectangleBorder = New System.Windows.Forms.MenuItem
Me.MenuItem11 = New System.Windows.Forms.MenuItem
Me.mitemWindowGreen = New System.Windows.Forms.MenuItem
Me.mitemWindowBlack = New System.Windows.Forms.MenuItem
Me.mitemWindowDefault = New System.Windows.Forms.MenuItem
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.MenuItem1)
Me.menuMain.MenuItems.Add(Me.MenuItem5)
Me.menuMain.MenuItems.Add(Me.MenuItem11)
'
'MenuItem1
'
Me.MenuItem1.MenuItems.Add(Me.mitemTextRed)
Me.MenuItem1.MenuItems.Add(Me.mitemTextBlue)
Me.MenuItem1.MenuItems.Add(Me.mitemTextDefault)
Me.MenuItem1.Text = "Text"
'
'mitemTextRed
'
Me.mitemTextRed.Text = "Red"
'
'mitemTextBlue
'
Me.mitemTextBlue.Text = "Blue"
'
'mitemTextDefault
'
Me.mitemTextDefault.Checked = True
Me.mitemTextDefault.Text = "Default"
'
'MenuItem5
'
Me.MenuItem5.MenuItems.Add(Me.mitemRectangleYellow)
Me.MenuItem5.MenuItems.Add(Me.mitemRectangleAqua)
Me.MenuItem5.MenuItems.Add(Me.mitemRectangleDefault)
Me.MenuItem5.MenuItems.Add(Me.MenuItem9)
Me.MenuItem5.MenuItems.Add(Me.mitemRectangleBorder)
Me.MenuItem5.Text = "Rectangle"
'
'mitemRectangleYellow
'
Me.mitemRectangleYellow.Text = "Yellow"
'
'mitemRectangleAqua
'
Me.mitemRectangleAqua.Text = "Aqua"
'
'mitemRectangleDefault
'
Me.mitemRectangleDefault.Checked = True
Me.mitemRectangleDefault.Text = "Default"
'
'MenuItem9
'
Me.MenuItem9.Text = "-"
'
'mitemRectangleBorder
'
Me.mitemRectangleBorder.Checked = True
Me.mitemRectangleBorder.Text = "Border"
'
'MenuItem11
'
Me.MenuItem11.MenuItems.Add(Me.mitemWindowGreen)
Me.MenuItem11.MenuItems.Add(Me.mitemWindowBlack)
Me.MenuItem11.MenuItems.Add(Me.mitemWindowDefault)
Me.MenuItem11.Text = "Window"
'
'mitemWindowGreen
'
Me.mitemWindowGreen.Text = "Green"
'
'mitemWindowBlack
'
Me.mitemWindowBlack.Text = "Black"
'
'mitemWindowDefault
'
Me.mitemWindowDefault.Checked = True
Me.mitemWindowDefault.Text = "Default"
'
'FormMain
'
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "WordWrap"

    End Sub

#End Region

   Private rcDraw As RectangleF = New RectangleF(16, 16, 208, 160)
   Private stretch As StretchRectangle = New StretchRectangle

   Private Sub FormMain_Paint( _
   ByVal sender As Object, _
   ByVal e As System.Windows.Forms.PaintEventArgs) _
   Handles MyBase.Paint
      Dim str As String
      str = "Font: " + Font.Name + "\n" + _
         "Font Size: " + Font.Size.ToString() + "\n" + _
         "Font Style: " + Font.Style.ToString() + "\n" + _
         "Window Rect: (" + _
            Bounds.X.ToString() + "," + _
            Bounds.Y.ToString() + "," + _
            Bounds.Right.ToString() + "," + _
            Bounds.Bottom.ToString() + ")\n" + _
         "Draw Rect: (" + _
            rcDraw.X.ToString() + "," + _
            rcDraw.Y.ToString() + "," + _
            rcDraw.Right.ToString() + "," + _
            rcDraw.Bottom.ToString() + ")\n\n" + _
         "This is a long string " + _
         "that may need to be word wrapped." + _
         " And that is why we pass a rectangle " + _
         "in the call to DrawString."

      ' Set the text color.
      Dim brText As Brush
      If (mitemTextDefault.Checked) Then
         brText = New SolidBrush(SystemColors.WindowText)
      ElseIf (mitemTextRed.Checked) Then
         brText = New SolidBrush(Color.Red)
      Else
         brText = New SolidBrush(Color.Blue)
      End If

      ' Set the background color.
      Dim brRect As Brush
      If (mitemRectangleDefault.Checked) Then
         brRect = New SolidBrush(SystemColors.Window)
      ElseIf (mitemRectangleAqua.Checked) Then
         brRect = New SolidBrush(Color.Aqua)
      Else
         brRect = New SolidBrush(Color.Yellow)
      End If

      ' Create an integer rectangle (for vector calls)
      Dim rc As Rectangle = Rectangle.Round(rcDraw)

      ' Fetch background color.
      Dim clrClear As Color
      If (mitemWindowBlack.Checked) Then
         clrClear = Color.Black
      ElseIf (mitemWindowGreen.Checked) Then
         clrClear = Color.Green
      Else
         clrClear = SystemColors.Window
      End If

      ' Erase background.
      e.Graphics.Clear(clrClear)

      ' Draw background rectangle.
      e.Graphics.FillRectangle(brRect, rc)

      ' Draw text
      e.Graphics.DrawString(str, Me.Font, brText, rcDraw)

      If (mitemRectangleBorder.Checked) Then
         e.Graphics.DrawRectangle(New Pen(Color.Black), rc)
      End If

   End Sub

   Private Sub FormMain_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
      ' Start stretchable rectangle drawing.
      stretch.Init(e.X, e.Y, CType(Me, Control))
      rcDraw = New RectangleF(e.X, e.Y, 0, 0)
   End Sub

   Private Sub FormMain_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
      ' Move stretchable rectangle.
      stretch.Move(e.X, e.Y)
      rcDraw.Width = e.X - rcDraw.X
      rcDraw.Height = e.Y - rcDraw.Y
   End Sub

   Private Sub FormMain_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
      ' End stretchable rectangle drawing.
      stretch.Done()
      rcDraw.Width = e.X - rcDraw.X
      rcDraw.Height = e.Y - rcDraw.Y

      ' Reverse coordinates for negative values.
      If rcDraw.Width < 0 Then
         rcDraw.X = rcDraw.X + rcDraw.Width
         rcDraw.Width = (-1) * rcDraw.Width
      End If
      If rcDraw.Height < 0 Then
         rcDraw.Y = rcDraw.Y + rcDraw.Height
         rcDraw.Height = (-1) * rcDraw.Height
      End If
      Invalidate()
   End Sub

   Private Sub mitemTextDefault_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextDefault.Click
   End Sub

   Private Sub mitemTextBlue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextBlue.Click
      If Not mitemTextBlue.Checked Then
         mitemTextBlue.Checked = True
         mitemTextRed.Checked = False
         mitemTextDefault.Checked = False
         Invalidate()
      End If
   End Sub

   Private Sub mitemTextRed_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemTextRed.Click
      If Not mitemTextRed.Checked Then
         mitemTextBlue.Checked = False
         mitemTextRed.Checked = True
         mitemTextDefault.Checked = False
         Invalidate()
      End If
   End Sub

   Private Sub mitemRectangleBorder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemRectangleBorder.Click
      mitemRectangleBorder.Checked = Not mitemRectangleBorder.Checked
      Invalidate()
   End Sub

   Private Sub mitemRectangleDefault_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemRectangleDefault.Click
      If Not mitemRectangleDefault.Checked Then
         mitemRectangleYellow.Checked = True
         mitemRectangleAqua.Checked = False
         mitemRectangleDefault.Checked = True
         Invalidate()
      End If
   End Sub

   Private Sub mitemRectangleAqua_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemRectangleAqua.Click
      If Not mitemRectangleAqua.Checked Then
         mitemRectangleYellow.Checked = False
         mitemRectangleAqua.Checked = True
         mitemRectangleDefault.Checked = False
         Invalidate()
      End If
   End Sub

   Private Sub mitemRectangleYellow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemRectangleYellow.Click
      If Not mitemRectangleYellow.Checked Then
         mitemRectangleYellow.Checked = True
         mitemRectangleAqua.Checked = False
         mitemRectangleDefault.Checked = False
         Invalidate()
      End If
   End Sub

   Private Sub mitemWindowDefault_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemWindowDefault.Click
      If Not mitemWindowDefault.Checked Then
         mitemWindowGreen.Checked = False
         mitemWindowBlack.Checked = False
         mitemWindowDefault.Checked = True
         Invalidate()
      End If
   End Sub

   Private Sub mitemWindowBlack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemWindowBlack.Click
      If Not mitemWindowBlack.Checked Then
         mitemWindowGreen.Checked = False
         mitemWindowBlack.Checked = True
         mitemWindowDefault.Checked = False
         Invalidate()
      End If
   End Sub

   Private Sub mitemWindowGreen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemWindowGreen.Click
      If Not mitemWindowGreen.Checked Then
         mitemWindowGreen.Checked = True
         mitemWindowBlack.Checked = False
         mitemWindowDefault.Checked = False
         Invalidate()
      End If
   End Sub

End Class
End Namespace
