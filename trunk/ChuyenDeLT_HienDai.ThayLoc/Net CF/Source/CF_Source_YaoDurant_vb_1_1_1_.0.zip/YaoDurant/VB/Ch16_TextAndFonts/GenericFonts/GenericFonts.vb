' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Drawing

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents menuMain As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents mitemSize8 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSize10 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSize12 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSize14 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSize16 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSize18 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSize24 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemFontMono As System.Windows.Forms.MenuItem
   Friend WithEvents mitemFontSans As System.Windows.Forms.MenuItem
   Friend WithEvents mitemFontSerif As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSizePopup As System.Windows.Forms.MenuItem
   Friend WithEvents mitemFontPopup As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
Me.menuMain = New System.Windows.Forms.MainMenu
Me.mitemSizePopup = New System.Windows.Forms.MenuItem
Me.mitemSize8 = New System.Windows.Forms.MenuItem
Me.mitemSize10 = New System.Windows.Forms.MenuItem
Me.mitemSize12 = New System.Windows.Forms.MenuItem
Me.mitemSize14 = New System.Windows.Forms.MenuItem
Me.mitemSize16 = New System.Windows.Forms.MenuItem
Me.mitemSize18 = New System.Windows.Forms.MenuItem
Me.mitemSize24 = New System.Windows.Forms.MenuItem
Me.mitemFontPopup = New System.Windows.Forms.MenuItem
Me.mitemFontMono = New System.Windows.Forms.MenuItem
Me.mitemFontSans = New System.Windows.Forms.MenuItem
Me.mitemFontSerif = New System.Windows.Forms.MenuItem
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.mitemSizePopup)
Me.menuMain.MenuItems.Add(Me.mitemFontPopup)
'
'mitemSizePopup
'
Me.mitemSizePopup.MenuItems.Add(Me.mitemSize8)
Me.mitemSizePopup.MenuItems.Add(Me.mitemSize10)
Me.mitemSizePopup.MenuItems.Add(Me.mitemSize12)
Me.mitemSizePopup.MenuItems.Add(Me.mitemSize14)
Me.mitemSizePopup.MenuItems.Add(Me.mitemSize16)
Me.mitemSizePopup.MenuItems.Add(Me.mitemSize18)
Me.mitemSizePopup.MenuItems.Add(Me.mitemSize24)
Me.mitemSizePopup.Text = "Size"
'
'mitemSize8
'
Me.mitemSize8.Text = "8 Point"
'
'mitemSize10
'
Me.mitemSize10.Checked = True
Me.mitemSize10.Text = "10 Point"
'
'mitemSize12
'
Me.mitemSize12.Text = "12 Point"
'
'mitemSize14
'
Me.mitemSize14.Text = "14 Point"
'
'mitemSize16
'
Me.mitemSize16.Text = "16 Point"
'
'mitemSize18
'
Me.mitemSize18.Text = "18 Point"
'
'mitemSize24
'
Me.mitemSize24.Text = "24 Point"
'
'mitemFontPopup
'
Me.mitemFontPopup.MenuItems.Add(Me.mitemFontMono)
Me.mitemFontPopup.MenuItems.Add(Me.mitemFontSans)
Me.mitemFontPopup.MenuItems.Add(Me.mitemFontSerif)
Me.mitemFontPopup.Text = "Font"
'
'mitemFontMono
'
Me.mitemFontMono.Checked = True
Me.mitemFontMono.Text = "MonoSpace"
'
'mitemFontSans
'
Me.mitemFontSans.Checked = True
Me.mitemFontSans.Text = "Sans Serif"
'
'mitemFontSerif
'
Me.mitemFontSerif.Checked = True
Me.mitemFontSerif.Text = "Serif"
'
'FormMain
'
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "Generic Fonts"

    End Sub

#End Region

   'Our private class data.
   Private m_ptSize As Integer = 10

   Private Sub DisplayMonoFont( _
   ByVal g As Graphics, _
   ByRef x As Single, _
   ByRef y As Single)
      ' Create brush for standard text color.
      Dim brText As Brush = New SolidBrush( _
         SystemColors.WindowText)

      ' Create monospace regular m_ptSize pt font.
      Dim font As Font = New Font( _
         FontFamily.GenericMonospace, _
         m_ptSize, _
         FontStyle.Regular)
      Dim str As String = "Mono: "
      g.DrawString(str, Font, brText, x, y)
      Dim sizeString As SizeF = g.MeasureString(str, Font)
      x += sizeString.Width

      ' Draw with monospace bold m_ptSize pt font.
      str = "Regular (" + Font.Name + ")"
      g.DrawString(str, Font, brText, x, y)
      sizeString = g.MeasureString(str, Font)
      y += sizeString.Height
      font.Dispose()

      ' Create monospace italic m_ptSize pt font.
      font = New Font(FontFamily.GenericMonospace, m_ptSize, _
         FontStyle.Italic)
      str = "Italic"
      g.DrawString(str, Font, brText, x, y)
      sizeString = g.MeasureString(str, Font)
      y += sizeString.Height
      font.Dispose()

      ' Create monospace bold m_ptSize pt font.
      font = New Font(FontFamily.GenericMonospace, m_ptSize, _
         FontStyle.Bold)
      str = "Bold"
      g.DrawString(str, Font, brText, x, y)
      sizeString = g.MeasureString(str, Font)
      y += sizeString.Height
      font.Dispose()

      ' Create monospace strikeout m_ptSize pt font.
      font = New Font(FontFamily.GenericMonospace, m_ptSize, _
         FontStyle.Strikeout)
      str = "Strikeout"
      g.DrawString(str, Font, brText, x, y)
      sizeString = g.MeasureString(str, Font)
      y += sizeString.Height
      font.Dispose()

      ' Create monospace underline m_ptSize pt font.
      font = New Font(FontFamily.GenericMonospace, m_ptSize, _
         FontStyle.Underline)
      str = "Underline"
      g.DrawString(str, Font, brText, x, y)
      sizeString = g.MeasureString(str, Font)
      y += sizeString.Height
      font.Dispose()

      ' Add spacing between text blocks.
      y += sizeString.Height / 2
   End Sub

   Private Sub DisplaySansSerifFont( _
   ByVal g As Graphics, _
   ByRef x As Single, _
   ByRef y As Single)
      ' Create brush for standard text color.
      Dim brText As Brush = New SolidBrush( _
         SystemColors.WindowText)

      ' Create Sans Serif regular m_ptSize pt font.
      Dim font As Font = New Font( _
         FontFamily.GenericSansSerif, _
         m_ptSize, _
         FontStyle.Regular)
      Dim str As String = "SansSerif: "
      x = 10

      g.DrawString(str, font, brText, x, y)
      Dim sizeString As SizeF = g.MeasureString(str, font)
      x += sizeString.Width

      ' Draw with Sans Serif bold m_ptSize pt font.
      str = "Regular (" + font.Name + ")"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Sans Serif italic m_ptSize pt font.
      font = New Font(FontFamily.GenericSansSerif, m_ptSize, _
         FontStyle.Italic)
      str = "Italic"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Sans Serif bold m_ptSize pt font.
      font = New Font(FontFamily.GenericSansSerif, m_ptSize, _
         FontStyle.Bold)
      str = "Bold"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Sans Serif strikeout m_ptSize pt font.
      font = New Font(FontFamily.GenericSansSerif, m_ptSize, _
         FontStyle.Strikeout)
      str = "Strikeout"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Sans Serif underline m_ptSize pt font.
      font = New Font(FontFamily.GenericSansSerif, m_ptSize, _
         FontStyle.Underline)
      str = "Underline"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Add spacing between text blocks.
      y += sizeString.Height / 2
   End Sub

   Private Sub DisplaySerifFont( _
   ByVal g As Graphics, _
   ByRef x As Single, _
   ByRef y As Single)
      ' Create brush for standard text color.
      Dim brText As Brush = New SolidBrush( _
         SystemColors.WindowText)

      ' Create Serif regular m_ptSize pt font.
      Dim font As Font = New Font( _
         FontFamily.GenericSerif, _
         m_ptSize, _
         FontStyle.Regular)
      Dim str As String = "Serif: "
      x = 10

      g.DrawString(str, font, brText, x, y)
      Dim sizeString As SizeF = g.MeasureString(str, font)
      x += sizeString.Width

      ' Draw with Serif bold m_ptSize pt font.
      str = "Regular (" + font.Name + ")"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Serif italic m_ptSize pt font.
      font = New Font(FontFamily.GenericSerif, m_ptSize, _
         FontStyle.Italic)
      str = "Italic"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Serif bold m_ptSize pt font.
      font = New Font(FontFamily.GenericSerif, m_ptSize, _
         FontStyle.Bold)
      str = "Bold"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Serif strikeout m_ptSize pt font.
      font = New Font(FontFamily.GenericSerif, m_ptSize, _
         FontStyle.Strikeout)
      str = "Strikeout"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Create Serif underline m_ptSize pt font.
      font = New Font(FontFamily.GenericSerif, m_ptSize, _
         FontStyle.Underline)
      str = "Underline"
      g.DrawString(str, font, brText, x, y)
      sizeString = g.MeasureString(str, font)
      y += sizeString.Height
      font.Dispose()

      ' Add spacing between text blocks.
      y += sizeString.Height / 2
   End Sub

   Private Sub FormMain_Paint( _
   ByVal sender As Object, _
   ByVal e As System.Windows.Forms.PaintEventArgs) _
   Handles MyBase.Paint
      Dim g As Graphics = e.Graphics
      Dim x As Single = 10
      Dim y As Single = 10

      '
      '  GenericMonospace Font Styles
      '
      If (mitemFontMono.Checked) Then
         DisplayMonoFont(g, x, y)
      End If

      '
      '  GenericSansSerif Font Styles
      '
      If (mitemFontSans.Checked) Then
         DisplaySansSerifFont(g, x, y)
      End If

      '
      '  GenericSerif Font Styles
      '
      If (mitemFontSerif.Checked) Then
         DisplaySerifFont(g, x, y)
      End If

   End Sub

   Private Sub UncheckAllSizes()
      mitemSize8.Checked = False
      mitemSize10.Checked = False
      mitemSize12.Checked = False
      mitemSize14.Checked = False
      mitemSize16.Checked = False
      mitemSize18.Checked = False
      mitemSize24.Checked = False
   End Sub

   Private Sub mitemSize8_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemSize8.Click
      UncheckAllSizes()
      mitemSize8.Checked = True
      Text = "GenericFonts - 8 pt."
      m_ptSize = 8
      Invalidate()
   End Sub

   Private Sub mitemSize10_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemSize10.Click
      UncheckAllSizes()
      mitemSize10.Checked = True
      Text = "GenericFonts - 10 pt."
      m_ptSize = 10
      Invalidate()
   End Sub

   Private Sub mitemSize12_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemSize12.Click
      UncheckAllSizes()
      mitemSize12.Checked = True
      Text = "GenericFonts - 12 pt."
      m_ptSize = 12
      Invalidate()
   End Sub

   Private Sub mitemSize14_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemSize14.Click
      UncheckAllSizes()
      mitemSize14.Checked = True
      Text = "GenericFonts - 14 pt."
      m_ptSize = 14
      Invalidate()
   End Sub

   Private Sub mitemSize16_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemSize16.Click
      UncheckAllSizes()
      mitemSize16.Checked = True
      Text = "GenericFonts - 16 pt."
      m_ptSize = 16
      Invalidate()
   End Sub

   Private Sub mitemSize18_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemSize18.Click
      UncheckAllSizes()
      mitemSize18.Checked = True
      Text = "GenericFonts - 18 pt."
      m_ptSize = 18
      Invalidate()
   End Sub

   Private Sub mitemSize24_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemSize24.Click
      UncheckAllSizes()
      mitemSize24.Checked = True
      Text = "GenericFonts - 24 pt."
      m_ptSize = 24
      Invalidate()
   End Sub

   Private Sub mitemFontMono_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemFontMono.Click
      mitemFontMono.Checked = Not mitemFontMono.Checked
      Invalidate()
   End Sub

   Private Sub mitemFontSans_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemFontSans.Click
      mitemFontSans.Checked = Not mitemFontSans.Checked
      Invalidate()
   End Sub

   Private Sub mitemFontSerif_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) Handles mitemFontSerif.Click
      mitemFontSerif.Checked = Not mitemFontSerif.Checked
      Invalidate()
   End Sub

End Class
