Imports System.Drawing

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents cmdRewind As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
   Friend WithEvents cmdBack As System.Windows.Forms.Button
   Friend WithEvents cmdPause As System.Windows.Forms.Button
   Friend WithEvents cmdNext As System.Windows.Forms.Button
   Friend WithEvents cmdForward As System.Windows.Forms.Button
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.cmdRewind = New System.Windows.Forms.Button
Me.cmdBack = New System.Windows.Forms.Button
Me.cmdPause = New System.Windows.Forms.Button
Me.cmdNext = New System.Windows.Forms.Button
Me.cmdForward = New System.Windows.Forms.Button
'
'cmdRewind
'
Me.cmdRewind.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular)
Me.cmdRewind.Location = New System.Drawing.Point(8, 240)
Me.cmdRewind.Size = New System.Drawing.Size(24, 20)
Me.cmdRewind.Text = "2"
'
'cmdBack
'
Me.cmdBack.Location = New System.Drawing.Point(56, 240)
Me.cmdBack.Size = New System.Drawing.Size(24, 20)
Me.cmdBack.Text = "3"
'
'cmdPause
'
Me.cmdPause.Location = New System.Drawing.Point(104, 240)
Me.cmdPause.Size = New System.Drawing.Size(24, 20)
Me.cmdPause.Text = "0"
'
'cmdNext
'
Me.cmdNext.Location = New System.Drawing.Point(152, 240)
Me.cmdNext.Size = New System.Drawing.Size(24, 20)
Me.cmdNext.Text = "4"
'
'cmdForward
'
Me.cmdForward.Location = New System.Drawing.Point(200, 240)
Me.cmdForward.Size = New System.Drawing.Size(24, 20)
Me.cmdForward.Text = "7"
'
'FormMain
'
Me.Controls.Add(Me.cmdForward)
Me.Controls.Add(Me.cmdNext)
Me.Controls.Add(Me.cmdPause)
Me.Controls.Add(Me.cmdBack)
Me.Controls.Add(Me.cmdRewind)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Bookdings Fonts"

    End Sub

#End Region


   Private Sub FormMain_Load(ByVal sender As Object, _
   ByVal e As System.EventArgs) Handles MyBase.Load
      Dim fontBookDings As Font
      fontBookDings = New Font("BookDings", 14, FontStyle.Bold)

      ' [ << ] button
      cmdRewind.Font = fontBookDings
      cmdRewind.Text = "2"

      ' [ <  ] button
      cmdBack.Font = fontBookDings
      cmdBack.Text = "3"

      ' [ || ] button
      cmdPause.Font = fontBookDings
      cmdPause.Text = "0"

      ' [ >  ] button
      cmdNext.Font = fontBookDings
      cmdNext.Text = "4"

      ' [ >> ] button
      cmdForward.Font = fontBookDings
      cmdForward.Text = "7"

      fontBookDings.Dispose()
   End Sub

End Class
