' TextAlign.vb - Shows twelve alignments of text.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports YaoDurant.Drawing
Imports YaoDurant.Win32

Namespace TextAlign

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents lblVert As System.Windows.Forms.Label
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents lblHorz As System.Windows.Forms.Label
      Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemVerticalTop As System.Windows.Forms.MenuItem
      Friend WithEvents mitemVerticalMiddle As System.Windows.Forms.MenuItem
      Friend WithEvents mitemVerticalBaseline As System.Windows.Forms.MenuItem
      Friend WithEvents mitemVerticalBottom As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemHorizontalLeft As System.Windows.Forms.MenuItem
      Friend WithEvents mitemHorizontalCenter As System.Windows.Forms.MenuItem
      Friend WithEvents mitemHorizontalRight As System.Windows.Forms.MenuItem
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitemVerticalTop = New System.Windows.Forms.MenuItem
Me.mitemVerticalMiddle = New System.Windows.Forms.MenuItem
Me.mitemVerticalBaseline = New System.Windows.Forms.MenuItem
Me.mitemVerticalBottom = New System.Windows.Forms.MenuItem
Me.MenuItem6 = New System.Windows.Forms.MenuItem
Me.mitemHorizontalLeft = New System.Windows.Forms.MenuItem
Me.mitemHorizontalCenter = New System.Windows.Forms.MenuItem
Me.mitemHorizontalRight = New System.Windows.Forms.MenuItem
Me.label1 = New System.Windows.Forms.Label
Me.lblVert = New System.Windows.Forms.Label
Me.label2 = New System.Windows.Forms.Label
Me.lblHorz = New System.Windows.Forms.Label
'
'MainMenu1
'
Me.MainMenu1.MenuItems.Add(Me.MenuItem1)
Me.MainMenu1.MenuItems.Add(Me.MenuItem6)
'
'MenuItem1
'
Me.MenuItem1.MenuItems.Add(Me.mitemVerticalTop)
Me.MenuItem1.MenuItems.Add(Me.mitemVerticalMiddle)
Me.MenuItem1.MenuItems.Add(Me.mitemVerticalBaseline)
Me.MenuItem1.MenuItems.Add(Me.mitemVerticalBottom)
Me.MenuItem1.Text = "Vertical"
'
'mitemVerticalTop
'
Me.mitemVerticalTop.Checked = True
Me.mitemVerticalTop.Text = "Top"
'
'mitemVerticalMiddle
'
Me.mitemVerticalMiddle.Text = "Middle"
'
'mitemVerticalBaseline
'
Me.mitemVerticalBaseline.Text = "Baseline"
'
'mitemVerticalBottom
'
Me.mitemVerticalBottom.Text = "Bottom"
'
'MenuItem6
'
Me.MenuItem6.MenuItems.Add(Me.mitemHorizontalLeft)
Me.MenuItem6.MenuItems.Add(Me.mitemHorizontalCenter)
Me.MenuItem6.MenuItems.Add(Me.mitemHorizontalRight)
Me.MenuItem6.Text = "Horizontal"
'
'mitemHorizontalLeft
'
Me.mitemHorizontalLeft.Checked = True
Me.mitemHorizontalLeft.Text = "Left"
'
'mitemHorizontalCenter
'
Me.mitemHorizontalCenter.Text = "Center"
'
'mitemHorizontalRight
'
Me.mitemHorizontalRight.Text = "Right"
'
'label1
'
Me.label1.Location = New System.Drawing.Point(8, 0)
Me.label1.Size = New System.Drawing.Size(128, 20)
Me.label1.Text = "Vertical Alignment:"
Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'lblVert
'
Me.lblVert.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
Me.lblVert.Location = New System.Drawing.Point(144, 0)
Me.lblVert.Size = New System.Drawing.Size(88, 20)
Me.lblVert.Text = "Top"
'
'label2
'
Me.label2.Location = New System.Drawing.Point(8, 16)
Me.label2.Size = New System.Drawing.Size(128, 20)
Me.label2.Text = "Horizontal Alignment:"
Me.label2.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'lblHorz
'
Me.lblHorz.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold)
Me.lblHorz.Location = New System.Drawing.Point(144, 16)
Me.lblHorz.Text = "Left"
'
'FormMain
'
Me.Controls.Add(Me.lblHorz)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.lblVert)
Me.Controls.Add(Me.label1)
Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "TextAlign"

    End Sub

#End Region

   Private m_cxAdjust As Integer = 0
   Private m_cyAdjust As Integer = 0
   Private strDisplay As String = "Text"
   Private m_hwndForm As IntPtr

   Public Enum Alignment
      V_TOP
      V_MIDDLE
      V_BASELINE
      V_BOTTOM
      H_LEFT
      H_CENTER
      H_RIGHT
   End Enum

   '
   ' Handlers for menu item selections
   '

   Private Sub mitemVerticalTop_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemVerticalTop.Click
      SetVerticalAlignment(Alignment.V_TOP)
   End Sub

   Private Sub mitemVerticalMiddle_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemVerticalMiddle.Click
      SetVerticalAlignment(Alignment.V_MIDDLE)
   End Sub

   Private Sub mitemVerticalBaseline_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemVerticalBaseline.Click
      SetVerticalAlignment(Alignment.V_BASELINE)
   End Sub

   Private Sub mitemVerticalBottom_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemVerticalBottom.Click
      SetVerticalAlignment(Alignment.V_BOTTOM)
   End Sub

   Private Sub mitemHorizontalLeft_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemHorizontalLeft.Click
      SetHorizontalAlignment(Alignment.H_LEFT)
   End Sub

   Private Sub mitemHorizontalCenter_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemHorizontalCenter.Click
      SetHorizontalAlignment(Alignment.H_CENTER)
   End Sub

   Private Sub mitemHorizontalRight_Click( _
   ByVal sender As System.Object, _
   ByVal e As System.EventArgs) _
   Handles mitemHorizontalRight.Click
      SetHorizontalAlignment(Alignment.H_RIGHT)
   End Sub

   '
   ' Calculate offset for vertical alignment.
   '
   Private Sub SetVerticalAlignment(ByVal align As Alignment)
      ' Remove check mark from all menu items.
      mitemVerticalTop.Checked = False
      mitemVerticalMiddle.Checked = False
      mitemVerticalBaseline.Checked = False
      mitemVerticalBottom.Checked = False

      ' Calculate size of string bounding box.
      Dim g As Graphics = CreateGraphics()
      Dim size As SizeF = g.MeasureString(strDisplay, Font)
      g.Dispose()

      ' Update based on selected alignment.
      Select Case align
         Case Alignment.V_TOP
            mitemVerticalTop.Checked = True
            m_cyAdjust = 0
            lblVert.Text = "Top"
            Exit Select
         Case Alignment.V_MIDDLE
            mitemVerticalMiddle.Checked = True
            m_cyAdjust = CType((size.Height / 2), Integer)
            lblVert.Text = "Middle"
            Exit Select
         Case Alignment.V_BASELINE
            mitemVerticalBaseline.Checked = True
            m_cyAdjust = GetFontBaseline(Font.Name, _
               CType(Font.Size, Integer))
            lblVert.Text = "Baseline"
            Exit Select
         Case Alignment.V_BOTTOM
            mitemVerticalBottom.Checked = True
            m_cyAdjust = CType(size.Height, Integer)
            lblVert.Text = "Bottom"
            Exit Select
      End Select
      ' Redraw
      Invalidate()
   End Sub ' SetVerticalAlignment

   '
   ' Calculate offset for horizontal alignment
   '
   Public Sub SetHorizontalAlignment(ByVal align As Alignment)
      ' Remove check mark from all menu items.
      mitemHorizontalLeft.Checked = False
      mitemHorizontalCenter.Checked = False
      mitemHorizontalRight.Checked = False

      ' Calculate size of string bounding box.
      Dim g As Graphics = CreateGraphics()
      Dim size As SizeF = g.MeasureString(strDisplay, Font)
      g.Dispose()

      ' Update based on selected alignment.
      Select Case align
         Case Alignment.H_LEFT
            mitemHorizontalLeft.Checked = True
            m_cxAdjust = 0
            lblHorz.Text = "Left"
            Exit Select
         Case Alignment.H_CENTER
            mitemHorizontalCenter.Checked = True
            m_cxAdjust = CType((size.Width / 2), Integer)
            lblHorz.Text = "Center"
            Exit Select
         Case Alignment.H_RIGHT
            mitemHorizontalRight.Checked = True
            m_cxAdjust = CType(size.Width, Integer)
            lblHorz.Text = "Right"
            Exit Select
      End Select
      ' Redraw
      Invalidate()
   End Sub ' SetHorizontalAlignment

   '
   ' Calculate font baseline for baseline alignment.
   '
   Private Function GetFontBaseline( _
   ByVal strFont As String, _
   ByVal cptHeight As Integer) As Integer
      Dim cyReturn As Integer

      ' Fetch a Win32 DC.
      Dim hdc As IntPtr = GdiGraphics.GetDC(m_hwndForm)

      ' Create a Win32 font.
      Dim hfont As IntPtr
      hfont = GdiFont.Create(hdc, strFont, cptHeight, 0)

      ' Select font into DC.
      Dim hfontOld As IntPtr = GdiGraphics.SelectObject(hdc, hfont)

      ' Allocate font metric structure.
      Dim tm As GdiFont.TEXTMETRIC
      tm = New GdiFont.TEXTMETRIC

      ' Fetch font metrics.
      GdiFont.GetTextMetrics(hdc, tm)

      ' Fetch return value.
      cyReturn = tm.tmAscent

      ' Disconnect font from DC -- *Critical* because....
      GdiGraphics.SelectObject(hdc, hfontOld)

      ' ... clean up of Win32 font object requires font to
      ' be disconnected from any and all DCs.
      GdiGraphics.DeleteObject(hfont)

      ' Disconnect from Win32 DC.
      GdiGraphics.ReleaseDC(m_hwndForm, hdc)

      Return cyReturn
   End Function ' GetFontBaseline

   Private Sub FormMain_GotFocus( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles MyBase.GotFocus
      m_hwndForm = WinFocus.GetFocus()
   End Sub

   Private Sub FormMain_Paint(ByVal sender As Object, _
   ByVal e As PaintEventArgs) _
   Handles MyBase.Paint
      Dim g As Graphics = e.Graphics

      Dim x As Integer = Me.Width / 2
      Dim y As Integer = Me.Height / 2

      ' Adjust values to accommodate alignment request.
      Dim sinTextX As Single = CType((x - m_cxAdjust), Single)
      Dim sinTextY As Single = CType((y - m_cyAdjust), Single)

      ' Calculate size of string bounding box.
      Dim size As SizeF = g.MeasureString(strDisplay, Font)
      Dim cxWidth As Integer = CType(size.Width, Integer)
      Dim cyHeight As Integer = CType(size.Height, Integer)

      ' Draw text bounding box.
      Dim hbrFill As Brush = New SolidBrush(Color.Gray)
      Dim rc As Rectangle
      rc = New Rectangle( _
         CInt(sinTextX), CInt(sinTextY), _
         cxWidth, cyHeight)
      g.FillRectangle(hbrFill, rc)

      ' Draw string.
      Dim brText As Brush
      brText = New SolidBrush(SystemColors.WindowText)
      g.DrawString(strDisplay, Font, brText, sinTextX, sinTextY)

      ' Draw reference cross-hairs.
      Dim penBlack As Pen = New Pen(SystemColors.WindowText)
      g.DrawLine(penBlack, x, 0, x, Me.Height)
      g.DrawLine(penBlack, 0, y, Me.Width, y)
      penBlack.Dispose()
   End Sub

End Class
End Namespace

