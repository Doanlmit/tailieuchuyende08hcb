' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.IO
Imports System.Data
Imports System.Data.Common
Imports System.Data.SqlServerCe
Imports System.Windows.Forms

Public Class FormMain
   Inherits System.Windows.Forms.Form
   Friend WithEvents MenuMain As System.Windows.Forms.MainMenu
   Friend WithEvents mitemFile As System.Windows.Forms.MenuItem
   Friend WithEvents mitemExit As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemRecreate As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemCreateSubscription As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSynchronize As System.Windows.Forms.MenuItem

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents mitemLocalUpdate As System.Windows.Forms.MenuItem
   Friend WithEvents dgridOutput As System.Windows.Forms.DataGrid
   Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemConstraints As System.Windows.Forms.MenuItem
   Friend WithEvents mitemObjects As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemEmployees As System.Windows.Forms.MenuItem
   Friend WithEvents mitemCustomers As System.Windows.Forms.MenuItem
   Friend WithEvents mitemProducts As System.Windows.Forms.MenuItem
   Friend WithEvents mitemOrders As System.Windows.Forms.MenuItem
   Friend WithEvents mitemOrderDetails As System.Windows.Forms.MenuItem
   Private Sub InitializeComponent()
      Me.MenuMain = New System.Windows.Forms.MainMenu
      Me.mitemFile = New System.Windows.Forms.MenuItem
      Me.mitemExit = New System.Windows.Forms.MenuItem
      Me.MenuItem3 = New System.Windows.Forms.MenuItem
      Me.mitemRecreate = New System.Windows.Forms.MenuItem
      Me.MenuItem2 = New System.Windows.Forms.MenuItem
      Me.mitemCreateSubscription = New System.Windows.Forms.MenuItem
      Me.mitemSynchronize = New System.Windows.Forms.MenuItem
      Me.mitemLocalUpdate = New System.Windows.Forms.MenuItem
      Me.MenuItem1 = New System.Windows.Forms.MenuItem
      Me.mitemObjects = New System.Windows.Forms.MenuItem
      Me.mitemConstraints = New System.Windows.Forms.MenuItem
      Me.MenuItem4 = New System.Windows.Forms.MenuItem
      Me.mitemEmployees = New System.Windows.Forms.MenuItem
      Me.mitemCustomers = New System.Windows.Forms.MenuItem
      Me.mitemProducts = New System.Windows.Forms.MenuItem
      Me.mitemOrders = New System.Windows.Forms.MenuItem
      Me.mitemOrderDetails = New System.Windows.Forms.MenuItem
      Me.dgridOutput = New System.Windows.Forms.DataGrid
      '
      'MenuMain
      '
      Me.MenuMain.MenuItems.Add(Me.mitemFile)
      Me.MenuMain.MenuItems.Add(Me.MenuItem3)
      Me.MenuMain.MenuItems.Add(Me.MenuItem2)
      Me.MenuMain.MenuItems.Add(Me.MenuItem1)
      '
      'mitemFile
      '
      Me.mitemFile.MenuItems.Add(Me.mitemExit)
      Me.mitemFile.Text = "File"
      '
      'mitemExit
      '
      Me.mitemExit.Text = "Exit"
      '
      'MenuItem3
      '
      Me.MenuItem3.MenuItems.Add(Me.mitemRecreate)
      Me.MenuItem3.Text = "DataBase"
      '
      'mitemRecreate
      '
      Me.mitemRecreate.Text = "Re-create"
      '
      'MenuItem2
      '
      Me.MenuItem2.MenuItems.Add(Me.mitemCreateSubscription)
      Me.MenuItem2.MenuItems.Add(Me.mitemSynchronize)
      Me.MenuItem2.MenuItems.Add(Me.mitemLocalUpdate)
      Me.MenuItem2.Text = "Repl"
      '
      'mitemCreateSubscription
      '
      Me.mitemCreateSubscription.Text = "Create Subscription"
      '
      'mitemSynchronize
      '
      Me.mitemSynchronize.Text = "Synchronize"
      '
      'mitemLocalUpdate
      '
      Me.mitemLocalUpdate.Text = "Do Local Update"
      '
      'MenuItem1
      '
      Me.MenuItem1.MenuItems.Add(Me.mitemObjects)
      Me.MenuItem1.MenuItems.Add(Me.mitemConstraints)
      Me.MenuItem1.MenuItems.Add(Me.MenuItem4)
      Me.MenuItem1.Text = "View"
      '
      'mitemObjects
      '
      Me.mitemObjects.Text = "Objects"
      '
      'mitemConstraints
      '
      Me.mitemConstraints.Text = "Contraints"
      '
      'MenuItem4
      '
      Me.MenuItem4.MenuItems.Add(Me.mitemEmployees)
      Me.MenuItem4.MenuItems.Add(Me.mitemCustomers)
      Me.MenuItem4.MenuItems.Add(Me.mitemProducts)
      Me.MenuItem4.MenuItems.Add(Me.mitemOrders)
      Me.MenuItem4.MenuItems.Add(Me.mitemOrderDetails)
      Me.MenuItem4.Text = "Tables"
      '
      'mitemEmployees
      '
      Me.mitemEmployees.Text = "Employees"
      '
      'mitemCustomers
      '
      Me.mitemCustomers.Text = "Customers"
      '
      'mitemProducts
      '
      Me.mitemProducts.Text = "Products"
      '
      'mitemOrders
      '
      Me.mitemOrders.Text = "Orders"
      '
      'mitemOrderDetails
      '
      Me.mitemOrderDetails.Text = """Order Details"""
      '
      'dgridOutput
      '
      Me.dgridOutput.Size = New System.Drawing.Size(240, 248)
      '
      'FormMain
      '
      Me.Controls.Add(Me.dgridOutput)
      Me.Menu = Me.MenuMain
      Me.Text = "FormMain"

   End Sub

#End Region

   '  The database file.
   Private strDBFile As String = _
                           "My Documents\Northwind.sdf"

   '  The local connection string.
   Private strConnLocal As String = "Data Source=" + _
                           "My Documents\Northwind.sdf"

   '  The remote connection string.
   'Private strConnRemote As String = _
   '                        "Provider=sqloledb; " + _
   '                        "Data Source=Snowden; " + _
   '                        "Initial Catalog=Northwind; " + _
   '                        "user id=Davolio;pwd=Nancy; "

   '  The URL
   Private strURL As String = _
                  "http://207.202.168.30/YaoDurantRDA/sscesa20.dll"


   Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      '      mitemRecreate_Click(mitemRecreate, e.Empty)
      '      mitemCreateSubscription_Click(mitemCreateSubscription, e.Empty)
      '      mitemSynchronize_Click(mitemSynchronize, e.Empty)
      Me.MinimizeBox = False
   End Sub


   Private Sub mitemRecreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemRecreate.Click
      If File.Exists(strDBFile) Then File.Delete(strDBFile)
   End Sub


   Private Sub mitemCreateSubscription_Click( _
                        ByVal sender As Object, _
                        ByVal e As EventArgs _
                        ) _
                        Handles mitemCreateSubscription.Click
      Dim replNW As New _
            SqlCeReplication
      Try
         With replNW
            .ExchangeType = ExchangeType.BiDirectional
            .InternetUrl = strURL
            .InternetLogin = ""
            .InternetPassword = ""
            .Publisher = "SNOWDEN"
            .PublisherDatabase = "Northwind"
            .Publication = "EmployeeOrderInfo"
            .PublisherSecurityMode = _
               SecurityType.DBAuthentication
            .PublisherLogin = "Davolio"
            .PublisherPassword = "Nancy"
            .Subscriber = "YaoDurant"
            .SubscriberConnectionString = strConnLocal

            .AddSubscription(AddOption.CreateDatabase)
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         replNW.Dispose()
      End Try
   End Sub

   Private Sub mitemSynchronize_Click( _
                                 ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles mitemSynchronize.Click
      Dim replNW As New _
         SqlCeReplication
      Try
         With replNW
            .ExchangeType = ExchangeType.BiDirectional
            .InternetUrl = strURL
            .InternetLogin = ""
            .InternetPassword = ""
            .Publisher = "SNOWDEN"
            .PublisherDatabase = "Northwind"
            .Publication = "EmployeeOrderInfo"
            .PublisherSecurityMode = _
               SecurityType.DBAuthentication
            .PublisherLogin = "Davolio"
            .PublisherPassword = "Nancy"
            .Subscriber = "YaoDurant"
            .SubscriberConnectionString = strConnLocal

            .Synchronize()
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         replNW.Dispose()
      End Try
   End Sub

   Private Sub mitemLocalUpdate_Click( _
                                 ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles mitemLocalUpdate.Click
      Dim connLocal As New SqlCeConnection(strConnLocal)
      connLocal.Open()

      Dim cmndLocal As New SqlCeCommand
      Try
         With cmndLocal
            .Connection = connLocal
            .CommandText = _
               "INSERT ""Order Details"" " & _
               " (OrderID, ProductID, UnitPrice, " & _
               "  Quantity, Discount) " & _
               " VALUES (10258, 1, 19.95, 44, 0.0)"
            .ExecuteNonQuery()
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         cmndLocal.Dispose()
         connLocal.Close()
      End Try
   End Sub

   Private Sub mitemObjects_Click(ByVal sender As Object, _
                                  ByVal e As EventArgs _
                                  ) _
                                  Handles mitemObjects.Click

      '  Show all database objects.
      DisplayResultSet("SELECT * FROM msysObjects", _
                       "Type, Flags DESC, Name")
   End Sub

   Private Sub mitemConstraints_Click( _
                                 ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles mitemConstraints.Click

      '  Show all database constraints.
      DisplayResultSet("SELECT * FROM msysConstraints", _
                       "TABLE_NAME, CONSTRAINT_TYPE DESC, CONSTRAINT_NAME, ORDINAL")
   End Sub

   Private Sub mitemTables_Click(ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles mitemEmployees.Click, _
                                         mitemEmployees.Click, _
                                         mitemProducts.Click, _
                                         mitemOrders.Click, _
                                         mitemOrderDetails.Click

      With DirectCast(sender, MenuItem)
         DisplayResultSet("SELECT * FROM " & .Text, String.Empty)
      End With

   End Sub

   Private Sub mitemExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mitemExit.Click
      Application.Exit()
   End Sub

   Private Sub HandleSQLException(ByVal exSQL As SqlCeException)
      Dim errSQL As SqlCeError
      For Each errSQL In exSQL.Errors
         With errSQL
            MessageBox.Show(.Message & " : " & .Source & " : " & .ErrorParameters(0) & " : " & .ErrorParameters(1) & " : " & .ErrorParameters(2))
            If Not exSQL.InnerException Is Nothing Then
               MessageBox.Show(exSQL.InnerException.ToString())
            End If
         End With
      Next
   End Sub

   Private Sub DisplayResultSet(ByVal strSQL As String, _
                                ByVal strSort As String)
      '  Create adapter.
      Dim daptDB As New SqlCeDataAdapter(strSQL, strConnLocal)

      '  Create data table.
      Dim dtabTemp As New DataTable("Temp")

      '  Fill it.
      daptDB.Fill(dtabTemp)

      '  Sort it
      dtabTemp.DefaultView.Sort = strSort

      '  Display it.
      dgridOutput.DataSource = dtabTemp
   End Sub

End Class
