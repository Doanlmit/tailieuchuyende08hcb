' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.IO
Imports System.Data
Imports System.Data.Common
Imports System.Data.SqlServerCe
Imports System.Windows.Forms

Public Class FormMain
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents MenuMain As System.Windows.Forms.MainMenu
   Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemExit As System.Windows.Forms.MenuItem
   Friend WithEvents mitemRecreate As System.Windows.Forms.MenuItem
   Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemPull As System.Windows.Forms.MenuItem
   Friend WithEvents mitemUpdate As System.Windows.Forms.MenuItem
   Friend WithEvents mitemPush As System.Windows.Forms.MenuItem
   Friend WithEvents mitemSubmitSQL As System.Windows.Forms.MenuItem
   Private Sub InitializeComponent()
      Me.MenuMain = New System.Windows.Forms.MainMenu
      Me.MenuItem1 = New System.Windows.Forms.MenuItem
      Me.mitemExit = New System.Windows.Forms.MenuItem
      Me.MenuItem3 = New System.Windows.Forms.MenuItem
      Me.mitemRecreate = New System.Windows.Forms.MenuItem
      Me.MenuItem2 = New System.Windows.Forms.MenuItem
      Me.mitemPull = New System.Windows.Forms.MenuItem
      Me.mitemUpdate = New System.Windows.Forms.MenuItem
      Me.mitemPush = New System.Windows.Forms.MenuItem
      Me.mitemSubmitSQL = New System.Windows.Forms.MenuItem
      '
      'MenuMain
      '
      Me.MenuMain.MenuItems.Add(Me.MenuItem1)
      Me.MenuMain.MenuItems.Add(Me.MenuItem3)
      Me.MenuMain.MenuItems.Add(Me.MenuItem2)
      '
      'MenuItem1
      '
      Me.MenuItem1.MenuItems.Add(Me.mitemExit)
      Me.MenuItem1.Text = "File"
      '
      'mitemExit
      '
      Me.mitemExit.Text = "Exit"
      '
      'MenuItem3
      '
      Me.MenuItem3.MenuItems.Add(Me.mitemRecreate)
      Me.MenuItem3.Text = "DataBase"
      '
      'mitemRecreate
      '
      Me.mitemRecreate.Text = "Re-create"
      '
      'MenuItem2
      '
      Me.MenuItem2.MenuItems.Add(Me.mitemPull)
      Me.MenuItem2.MenuItems.Add(Me.mitemUpdate)
      Me.MenuItem2.MenuItems.Add(Me.mitemPush)
      Me.MenuItem2.MenuItems.Add(Me.mitemSubmitSQL)
      Me.MenuItem2.Text = "RDA"
      '
      'mitemPull
      '
      Me.mitemPull.Text = "Pull"
      '
      'mitemUpdate
      '
      Me.mitemUpdate.Text = "Update"
      '
      'mitemPush
      '
      Me.mitemPush.Text = "Push"
      '
      'mitemSubmitSQL
      '
      Me.mitemSubmitSQL.Text = "Submit SQL"
      '
      'FormMain
      '
      Me.Menu = Me.MenuMain
      Me.Text = "RDA"

   End Sub

#End Region

   '  The database file.
   Private strDBFile As String = _
                           "My Documents\Northwind.sdf"

   '  The local connection string.
   Private strConnLocal As String = "Data Source=" + _
                           "My Documents\Northwind.sdf"

   '  The remote connection string.
   Private strConnRemote As String = _
                           "Provider=sqloledb; " + _
                           "Data Source=Snowden; " + _
                           "Initial Catalog=Northwind; " + _
                           "Integrated Security=SSPI; "

   '  The URL
   Private strURL As String = _
                  "http://207.202.168.30/YaoDurantRDA/sscesa20.dll"


   Private Sub FormMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
      mitemRecreate_Click(mitemRecreate, e.Empty)
      mitemPull_Click(mitemPull, e.Empty)
      mitemUpdate_Click(mitemUpdate, e.Empty)
      mitemSubmitSQL_Click(mitemSubmitSQL, e.Empty)
      mitemPush_Click(mitemPush, e.Empty)

      Me.MinimizeBox = False
   End Sub


   Private Sub mitemRecreate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mitemRecreate.Click
      If File.Exists(strDBFile) Then File.Delete(strDBFile)

      Dim engine As New SqlCeEngine(strConnLocal)
      engine.CreateDatabase()
      engine.Dispose()
   End Sub


   Private Sub mitemPull_Click(ByVal sender As Object, _
                               ByVal e As EventArgs _
                               ) _
                               Handles mitemPull.Click

      '  Create a remote data access object
      Dim rdaNW As New _
         SqlCeRemoteDataAccess(strURL, strConnLocal)

      Try
         '  Have RDA:
         '     Create local tables named Categories and
         '        ErrorCategories.  
         '     Connect to the remote server and submit the
         '        SELECT statement.
         '     Place the results in the local Categories table.
         With rdaNW
            .LocalConnectionString = strConnLocal
            .InternetUrl = strURL
            .InternetLogin = ""
            .InternetPassword = ""
            .Pull("Categories", _
                  "SELECT CategoryID, CategoryName " & _
                       "  FROM Categories", _
                  strConnRemote, _
                  RdaTrackOption.TrackingOnWithIndexes, _
                  "ErrorCategories")
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         rdaNW.Dispose()
      End Try


      '  The Identity property seed value of the new table is
      '     at 1, even after the retrieved rows have been 
      '     added to the table.  "Fix" it.
      Dim connLocal As New SqlCeConnection(strConnLocal)
      connLocal.Open()

      Dim cmndLocal As New SqlCeCommand
      Dim intMaxCategoryID As Integer
      Try
         With cmndLocal
            .Connection = connLocal

            '  Retrieve the highest CategoryID in the table.
            .CommandText = "SELECT max(CategoryID)" & _
                           "  FROM Categories"
            intMaxCategoryID = .ExecuteScalar

            '  Set the seed one higher.
            .CommandText = _
                  "ALTER TABLE Categories " & _
                     "ALTER COLUMN CategoryID IDENTITY (" & _
                     (intMaxCategoryID + 1).ToString() & _
                     ",1)"
            .ExecuteNonQuery()
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         connLocal.Close()
      End Try
   End Sub


   Private Sub mitemUpdate_Click(ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles mitemUpdate.Click

      Dim connLocal As New SqlCeConnection(strConnLocal)
      connLocal.Open()

      Dim cmndLocal As New SqlCeCommand
      Try
         With cmndLocal
            .Connection = connLocal
            .CommandText = _
                  "UPDATE Categories " & _
                  "   SET CategoryName = 'New Name'  " & _
                  " WHERE CategoryID = 2"
            .ExecuteNonQuery()
            .CommandText = _
                  "DELETE Categories " & _
                  " WHERE CategoryID = 3"
            .ExecuteNonQuery()
            .CommandText = _
                  "INSERT Categories (CategoryName) " & _
                  "VALUES ('New Category I') "
            .ExecuteNonQuery()
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         cmndLocal.Dispose()
         connLocal.Close()
      End Try
   End Sub


   Private Sub mitemPush_Click(ByVal sender As Object, _
                               ByVal e As EventArgs _
                               ) _
                               Handles mitemPush.Click
      Dim rdaNW As New _
         SqlCeRemoteDataAccess(strURL, strConnLocal)
      Try
         With rdaNW
            .LocalConnectionString = strConnLocal
            .InternetUrl = strURL
            .InternetLogin = ""
            .InternetPassword = ""
            .Push("Categories", strConnRemote)
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         rdaNW.Dispose()
      End Try
   End Sub


   Private Sub mitemSubmitSQL_Click(ByVal sender As Object, _
                                    ByVal e As EventArgs _
                                    ) _
                                    Handles mitemSubmitSQL.Click
      Dim rdaNW As New _
         SqlCeRemoteDataAccess(strURL, strConnLocal)
      Try
         With rdaNW
            .LocalConnectionString = strConnLocal
            .InternetUrl = strURL
            .InternetLogin = ""
            .InternetPassword = ""
            .SubmitSql("INSERT Categories (CategoryName, Description)" & _
                           "values ('New Category II', 'From SubmitSQL')", _
                       strConnRemote)
         End With
      Catch exSQL As SqlCeException
         HandleSQLException(exSQL)
      Finally
         rdaNW.Dispose()
      End Try
   End Sub


   Private Sub mitemExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mitemExit.Click
      Application.DoEvents()
      Application.Exit()
   End Sub


   Private Sub HandleSQLException(ByVal exSQL As SqlCeException)
      Dim errSQL As SqlCeError
      For Each errSQL In exSQL.Errors
         With errSQL
            MessageBox.Show(.Message & " : " & .Source)
         End With
      Next
   End Sub
End Class
