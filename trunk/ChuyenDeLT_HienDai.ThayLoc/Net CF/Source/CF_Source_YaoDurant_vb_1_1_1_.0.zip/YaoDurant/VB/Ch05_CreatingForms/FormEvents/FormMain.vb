' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Windows.Forms

Public Class FormMain
   Inherits System.Windows.Forms.Form

   Friend WithEvents Label1 As Label
   Friend WithEvents textBox1 As TextBox
   Friend WithEvents cmdNothing As Button
   Friend WithEvents textBox2 As TextBox
   Friend WithEvents cmdMessageBox As Button
   Friend WithEvents panel1 As Panel
   Friend WithEvents cmdFormFocus As Button
   Friend WithEvents chkMouseMove As CheckBox
   Friend WithEvents lboxEvents As ListBox
   Friend WithEvents cmdClear As Button
   Friend WithEvents mnuMain As MainMenu

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Private Sub InitializeComponent()
      Me.mnuMain = New System.Windows.Forms.MainMenu
      Me.Label1 = New System.Windows.Forms.Label
      Me.textBox1 = New System.Windows.Forms.TextBox
      Me.cmdNothing = New System.Windows.Forms.Button
      Me.textBox2 = New System.Windows.Forms.TextBox
      Me.cmdMessageBox = New System.Windows.Forms.Button
      Me.panel1 = New System.Windows.Forms.Panel
      Me.cmdFormFocus = New System.Windows.Forms.Button
      Me.chkMouseMove = New System.Windows.Forms.CheckBox
      Me.lboxEvents = New System.Windows.Forms.ListBox
      Me.cmdClear = New System.Windows.Forms.Button
      '
      'Label1
      '
      Me.Label1.Location = New System.Drawing.Point(8, 133)
      Me.Label1.Size = New System.Drawing.Size(40, 20)
      Me.Label1.Text = "Label:"
      '
      'textBox1
      '
      Me.textBox1.Location = New System.Drawing.Point(56, 131)
      Me.textBox1.Size = New System.Drawing.Size(168, 22)
      Me.textBox1.Text = "textBox1"
      '
      'cmdNothing
      '
      Me.cmdNothing.Location = New System.Drawing.Point(56, 235)
      Me.cmdNothing.Size = New System.Drawing.Size(120, 24)
      Me.cmdNothing.Text = "Do Nothing"
      '
      'textBox2
      '
      Me.textBox2.Location = New System.Drawing.Point(56, 163)
      Me.textBox2.Size = New System.Drawing.Size(168, 22)
      Me.textBox2.Text = "textBox2"
      '
      'cmdMessageBox
      '
      Me.cmdMessageBox.Location = New System.Drawing.Point(56, 203)
      Me.cmdMessageBox.Size = New System.Drawing.Size(120, 24)
      Me.cmdMessageBox.Text = "Show MessageBox"
      '
      'panel1
      '
      Me.panel1.Controls.Add(Me.cmdFormFocus)
      Me.panel1.Controls.Add(Me.chkMouseMove)
      Me.panel1.Controls.Add(Me.lboxEvents)
      Me.panel1.Controls.Add(Me.cmdClear)
      Me.panel1.Location = New System.Drawing.Point(0, 11)
      Me.panel1.Size = New System.Drawing.Size(240, 104)
      '
      'cmdFormFocus
      '
      Me.cmdFormFocus.Location = New System.Drawing.Point(96, 80)
      Me.cmdFormFocus.Size = New System.Drawing.Size(80,20)
      Me.cmdFormFocus.Text = "Form Focus"
      '
      'chkMouseMove
      '
      Me.chkMouseMove.Location = New System.Drawing.Point(8, 82)
      Me.chkMouseMove.Size = New System.Drawing.Size(88, 16)
      Me.chkMouseMove.Text = "Mouse Move"
      '
      'lboxEvents
      '
      Me.lboxEvents.Location = New System.Drawing.Point(-1, -1)
      Me.lboxEvents.Size = New System.Drawing.Size(242, 72)
      '
      'cmdClear
      '
      Me.cmdClear.Location = New System.Drawing.Point(184, 80)
      Me.cmdClear.Size = New System.Drawing.Size(48, 20)
      Me.cmdClear.Text = "Clear"
      '
      'FormMain
      '
      Me.Controls.Add(Me.Label1)
      Me.Controls.Add(Me.textBox1)
      Me.Controls.Add(Me.cmdNothing)
      Me.Controls.Add(Me.textBox2)
      Me.Controls.Add(Me.cmdMessageBox)
      Me.Controls.Add(Me.panel1)
      Me.Menu = Me.mnuMain
      Me.MinimizeBox = False
      Me.Text = "FormMain"

   End Sub

#End Region

   Private Const strAppName As String = "Form Events"

   '  Number of events that have occurred.
   '     Updates the Form's caption as the
   '     count changes.
   Private m_cEvents As Integer
   Private Property cEvents() As Integer
      Get
         Return m_cEvents
      End Get
      Set(ByVal Value As Integer)
         m_cEvents = Value
         [Text] = strAppName + " (" + m_cEvents.ToString() + ")"
      End Set
   End Property

   Private bShowMouseMove As Boolean = False

   '  Records the occurrence of an event in a 
   '     listbox, and selects the most recent event.
   Private Sub AddItem(ByVal strItem As String)
      lboxEvents.Items.Add(strItem)
      lboxEvents.SelectedIndex = cEvents
      cEvents += 1
   End Sub

#Region "Form Event Handlers"

   Private Sub FormMain_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
      Me.AddItem("Activated")
   End Sub

   Private Sub FormMain_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Click
      Me.AddItem("Click")
   End Sub

   Private Sub FormMain_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
      Me.AddItem("Closed")
      MessageBox.Show("FormMain_Closed", strAppName)
   End Sub

   Private Sub FormMain_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
      Me.AddItem("Closing")
      MessageBox.Show("FormMain_Closing", strAppName)
   End Sub

   Private Sub FormMain_Deactivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Deactivate
      Me.AddItem("Deactivate")
   End Sub

   Private Sub FormMain_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Disposed
      Me.AddItem("Disposed")
      MessageBox.Show("FormMain_Closing", strAppName)
   End Sub

   Private Sub FormMain_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.EnabledChanged
      Me.AddItem("EnableChanged")
   End Sub

   Private Sub FormMain_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.GotFocus
      Me.AddItem("GotFocus")
   End Sub

   'Private Sub FormMain_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles MyBase.KeyDown
   '   Dim str As String = "FormMain_KeyDown ("
   '   If e.Alt Then
   '      str += "Alt/"
   '   End If
   '   If e.Control Then
   '      str += "Ctl/"
   '   End If
   '   If e.Shift Then
   '      str += "Sh/"
   '   End If
   '   str += e.KeyCode.ToString()
   '   str += ")"

   '   Me.AddItem(str)
   'End Sub

   'Private Sub FormMain_KeyPress(ByVal sender As Object, _
   '                              ByVal e As KeyPressEventArgs _
   '                              ) _
   '                              Handles MyBase.KeyPress
   '   Dim str As String = "FormMain_KeyDown ("
   '   str += e.KeyChar
   '   str += ")"
   '   Me.AddItem(str)
   'End Sub

   'Private Sub FormMain_KeyUp(ByVal sender As Object, ByVal e As KeyEventArgs) Handles MyBase.KeyUp
   '   Dim str As String = "FormMain_KeyUp ("
   '   If e.Alt Then
   '      str += "Alt/"
   '   End If
   '   If e.Control Then
   '      str += "Ctl/"
   '   End If
   '   If e.Shift Then
   '      str += "Sh/"
   '   End If
   '   str += e.KeyCode.ToString()
   '   str += ")"
   '   Me.AddItem(str)
   'End Sub

   Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Me.AddItem("Load")
   End Sub

   Private Sub FormMain_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.LostFocus
      Me.AddItem("LostFocus")
   End Sub

   Private Sub FormMain_MouseDown(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseDown
      Dim str As String = "FormMain_MouseDown ("
      str += e.X.ToString() + "," + e.Y.ToString()
      str += ")"
      Me.AddItem(str)
   End Sub

   Private Sub FormMain_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseMove
      If bShowMouseMove Then
         Dim str As String = "FormMain_MouseMove ("
         str += e.X.ToString() + "," + e.Y.ToString()
         str += ")"
         Me.AddItem(str)
      End If
   End Sub

   Private Sub FormMain_MouseUp(ByVal sender As Object, ByVal e As MouseEventArgs) Handles MyBase.MouseUp
      Dim str As String = "FormMain_MouseUp ("
      str += e.X.ToString() + "," + e.Y.ToString()
      str += ")"
      Me.AddItem(str)
   End Sub

   Private Sub FormMain_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles MyBase.Paint
      Me.AddItem("Paint")
   End Sub

   Private Sub FormMain_ParentChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.ParentChanged
      Me.AddItem("ParentChanged")
   End Sub

   Private Sub FormMain_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
      Dim str As String = "FormMain_Resize (" + ClientRectangle.Left.ToString() + "," + ClientRectangle.Top.ToString() + "," + ClientRectangle.Right.ToString() + "," + ClientRectangle.Bottom.ToString() + ")"
      Me.AddItem(str)
   End Sub


   Private Sub FormMain_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Validated
      Me.AddItem("Validated")
   End Sub

   Private Sub FormMain_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Validating
      Me.AddItem("Validaing")
   End Sub

#End Region

#Region "Component Event Handlers"

   Private Sub cmdClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClear.Click
      lboxEvents.Items.Clear()
      cEvents = 0
   End Sub

   Private Sub cmdMessageBox_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdMessageBox.Click
      MessageBox.Show("A Message Box", strAppName)
   End Sub

   Private Sub chkMouseMove_CheckStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkMouseMove.CheckStateChanged
      bShowMouseMove = chkMouseMove.Checked
   End Sub

   Private Sub cmdFormFocus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFormFocus.Click
      Me.Focus()
   End Sub

#End Region

End Class
