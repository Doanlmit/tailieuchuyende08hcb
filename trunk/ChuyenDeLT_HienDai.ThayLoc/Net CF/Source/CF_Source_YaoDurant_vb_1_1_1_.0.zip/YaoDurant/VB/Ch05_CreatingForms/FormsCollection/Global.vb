Module Global
   Friend arrForms As New ArrayList

   Friend Function OpenForm(ByVal typeForm As Type) As Form
      Dim frmWork As Form
      Dim boolExists As Boolean = False

      '  Check to see if a form of the
      '     requested type already exists.
      For Each frmWork In arrForms
         If frmWork.GetType Is typeForm Then
            boolExists = True
            Exit For
         End If
      Next

      '  If is does not exist, create it
      '     and add it to the collection.
      If Not boolExists Then
         If typeForm Is GetType(FormTemperature) Then _
                                 frmWork = New FormTemperature
         If typeForm Is GetType(FormPressure) Then _
                                 frmWork = New FormPressure
         If typeForm Is GetType(FormPrecipitation) Then _
                                 frmWork = New FormPrecipitation
         arrForms.Add(frmWork)
      End If

      '  In either case, the reference to the form 
      '     of the correct type is now in frmWork.
      '     Return it.
      Return frmWork
   End Function

   Friend Sub RemoveForm(ByVal frmRemovee As Form)
      arrForms.Remove(frmRemovee)
   End Sub
End Module
