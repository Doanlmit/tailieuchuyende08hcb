' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.Windows.forms

Public Class FormMain
   Inherits System.Windows.Forms.Form
   Friend WithEvents lblIntro As System.Windows.Forms.Label
   Friend WithEvents lblTitle As System.Windows.Forms.Label
   Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents cmdPress As System.Windows.Forms.Button
   Friend WithEvents cmdTemp As System.Windows.Forms.Button
   Friend WithEvents cmdPrecip As System.Windows.Forms.Button
   Private Sub InitializeComponent()
      Me.MainMenu1 = New System.Windows.Forms.MainMenu
      Me.lblIntro = New System.Windows.Forms.Label
      Me.lblTitle = New System.Windows.Forms.Label
      Me.cmdPress = New System.Windows.Forms.Button
      Me.cmdTemp = New System.Windows.Forms.Button
      Me.cmdPrecip = New System.Windows.Forms.Button
      '
      'lblIntro
      '
      Me.lblIntro.Location = New System.Drawing.Point(0, 64)
      Me.lblIntro.Size = New System.Drawing.Size(240, 136)
      Me.lblIntro.Text = "Click on a button to see more information about temperature, precipitation, or ba" & _
      "rametric pressure."
      Me.lblIntro.TextAlign = System.Drawing.ContentAlignment.TopCenter
      '
      'lblTitle
      '
      Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Regular)
      Me.lblTitle.Size = New System.Drawing.Size(240, 48)
      Me.lblTitle.Text = "Welcome to your Weather"
      Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter
      '
      'cmdPress
      '
      Me.cmdPress.Location = New System.Drawing.Point(168, 216)
      Me.cmdPress.Size = New System.Drawing.Size(64, 24)
      Me.cmdPress.Text = "Pressure"
      '
      'cmdTemp
      '
      Me.cmdTemp.Location = New System.Drawing.Point(8, 216)
      Me.cmdTemp.Size = New System.Drawing.Size(64, 24)
      Me.cmdTemp.Text = "Temp"
      '
      'cmdPrecip
      '
      Me.cmdPrecip.Location = New System.Drawing.Point(88, 216)
      Me.cmdPrecip.Size = New System.Drawing.Size(64, 24)
      Me.cmdPrecip.Text = "Precip"
      '
      'FormMain
      '
      Me.Controls.Add(Me.cmdPrecip)
      Me.Controls.Add(Me.cmdTemp)
      Me.Controls.Add(Me.cmdPress)
      Me.Controls.Add(Me.lblTitle)
      Me.Controls.Add(Me.lblIntro)
      Me.Menu = Me.MainMenu1
      Me.Text = "Main"

   End Sub

#End Region

   Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Me.MinimizeBox = False
   End Sub

   Private Sub cmdTemp_Click(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles cmdTemp.Click
      Global.CreateForm(GetType(FormTemperature)).Show()
   End Sub

   Private Sub cmdPrecip_Click(ByVal sender As System.Object, _
                               ByVal e As System.EventArgs _
                               ) _
                               Handles cmdPrecip.Click
      Global.CreateForm(GetType(FormPrecipitation)).Show()
   End Sub

   Private Sub cmdPress_Click(ByVal sender As System.Object, _
                              ByVal e As System.EventArgs _
                              ) _
                              Handles cmdPress.Click
      Global.CreateForm(GetType(FormPressure)).Show()
   End Sub
End Class



