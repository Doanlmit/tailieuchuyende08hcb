Module Global
   Friend frmPrecipitation As FormPrecipitation
   Friend frmPressure As FormPressure
   Friend frmTemperature As FormTemperature
End Module
