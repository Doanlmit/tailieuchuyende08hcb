Imports System
Imports System.Drawing
Imports System.Windows.forms

Public Class FormTemperature
   '#Const FORM_DESIGN = True
#If FORM_DESIGN = True Then
   Inherits System.Windows.Forms.Form
#Else
   Inherits WeatherGage.FormGage
#End If

   Friend WithEvents cmdConvert As System.Windows.Forms.Button


#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.cmdConvert = New System.Windows.Forms.Button
      '
      'cmdConvert
      '
      Me.cmdConvert.Location = New System.Drawing.Point(24, 176)
      Me.cmdConvert.Text = "Convert"
      '
      'FormTemperature
      '
      Me.Controls.Add(Me.cmdConvert)
      Me.Text = "Temperature"

   End Sub

#End Region

   Private Sub Me_Load(ByVal sender As System.Object, _
                       ByVal e As System.EventArgs _
                       ) _
                       Handles MyBase.Load
      '  Place some sample 
      '     tempratures into the controls.
      LoadTemperatures()
   End Sub

   Private Sub Me_Closed(ByVal sender As Object, _
                         ByVal e As System.EventArgs _
                         ) _
                         Handles MyBase.Closed
      Global.RemoveForm(Me)
   End Sub

   Private Sub cmdConvert_Click(ByVal sender As System.Object, _
                                ByVal e As System.EventArgs _
                                ) _
                                Handles cmdConvert.Click

      '  Code to convert termeratures.
   End Sub

   Private Sub LoadTemperatures()
      '  Load sample temps into controls.
      Dim aintTemps() As Integer = {12, 12, 13, 13, 13, 13, _
                                    14, 14, 14, 15, 16, 16, _
                                    16, 16, 17, 17, 16, 16, _
                                    15, 15, 14, 14, 13, 13}

      lblCurrent.Text = aintTemps(0)
      With lboxPast.Items
         Dim intTemp As Integer
         For Each intTemp In aintTemps
            .Add(intTemp.ToString())
         Next
      End With
   End Sub

End Class
