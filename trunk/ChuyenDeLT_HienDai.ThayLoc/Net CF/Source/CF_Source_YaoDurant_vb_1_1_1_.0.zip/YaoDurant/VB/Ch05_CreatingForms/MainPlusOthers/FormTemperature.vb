Imports System
Imports System.Drawing
Imports System.Windows.forms

Public Class FormTemperature
   Inherits System.Windows.Forms.Form
   Friend WithEvents Label1 As System.Windows.Forms.Label
   Friend WithEvents lblCurrent As System.Windows.Forms.Label
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents lboxPast As System.Windows.Forms.ListBox

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.Label1 = New System.Windows.Forms.Label
      Me.lblCurrent = New System.Windows.Forms.Label
      Me.Label3 = New System.Windows.Forms.Label
      Me.lboxPast = New System.Windows.Forms.ListBox
      '
      'Label1
      '
      Me.Label1.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Regular)
      Me.Label1.Location = New System.Drawing.Point(8, 8)
      Me.Label1.Text = "Current"
      '
      'lblCurrent
      '
      Me.lblCurrent.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Regular)
      Me.lblCurrent.Location = New System.Drawing.Point(8, 40)
      '
      'Label3
      '
      Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Regular)
      Me.Label3.Location = New System.Drawing.Point(128, 8)
      Me.Label3.Text = "Past 24 Hours"
      '
      'lboxPast
      '
      Me.lboxPast.Location = New System.Drawing.Point(128, 40)
      Me.lboxPast.Size = New System.Drawing.Size(100, 212)
      '
      'FormTemperature
      '
      Me.Controls.Add(Me.lboxPast)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.lblCurrent)
      Me.Controls.Add(Me.Label1)
      Me.Text = "Temperature"

   End Sub

#End Region

   Private Sub FormTemperature_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      '  Place some sample 
      '     tempratures into the controls.
      LoadTemperatures()
   End Sub

   Private Sub LoadTemperatures()
      '  Load sample temps into controls.
      Dim aintTemps() As Integer = {12, 12, 13, 13, 13, 13, _
                                    14, 14, 14, 15, 16, 16, _
                                    16, 16, 17, 17, 16, 16, _
                                    15, 15, 14, 14, 13, 13}

      lblCurrent.Text = aintTemps(0)
      With lboxPast.Items
         Dim intTemp As Integer
         For Each intTemp In aintTemps
            .Add(intTemp.ToString())
         Next
      End With
   End Sub
End Class
