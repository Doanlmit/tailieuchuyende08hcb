' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.Windows.forms

Public Class FormPressure
   Inherits System.Windows.Forms.Form
   Friend WithEvents lboxPast As System.Windows.Forms.ListBox
   Friend WithEvents Label3 As System.Windows.Forms.Label
   Friend WithEvents lblCurrent As System.Windows.Forms.Label
   Friend WithEvents Label1 As System.Windows.Forms.Label

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call
   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.lboxPast = New System.Windows.Forms.ListBox
      Me.Label3 = New System.Windows.Forms.Label
      Me.lblCurrent = New System.Windows.Forms.Label
      Me.Label1 = New System.Windows.Forms.Label
      '
      'lboxPast
      '
      Me.lboxPast.Location = New System.Drawing.Point(130, 46)
      Me.lboxPast.Size = New System.Drawing.Size(100, 198)
      '
      'Label3
      '
      Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Regular)
      Me.Label3.Location = New System.Drawing.Point(130, 14)
      Me.Label3.Text = "Past 24 Hours"
      '
      'lblCurrent
      '
      Me.lblCurrent.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Regular)
      Me.lblCurrent.Location = New System.Drawing.Point(10, 46)
      '
      'Label1
      '
      Me.Label1.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Regular)
      Me.Label1.Location = New System.Drawing.Point(10, 14)
      Me.Label1.Text = "Current"
      '
      'FormPressure
      '
      Me.Controls.Add(Me.lboxPast)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.lblCurrent)
      Me.Controls.Add(Me.Label1)
      Me.Text = "Pressure"

   End Sub

#End Region

   Private Sub FormPressure_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      LoadPressures()
   End Sub

   Private Sub FormPressure_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
      Global.RemoveForm(Me)
   End Sub

   Private Sub LoadPressures()
      '  Load sample pressures into controls.
      Dim asinPress() As Single = _
               {29.92, 29.92, 29.94, 29.95, 29.97, 29.99, _
                30.01, 30.01, 30.01, 30.03, 30.02, 30.01, _
                29.99, 29.99, 29.98, 29.96, 29.94, 29.92, _
                29.91, 29.88, 29.88, 29.89, 29.91, 29.92}

      lblCurrent.Text = asinPress(0)
      With lboxPast.Items
         Dim sinPress As Single
         For Each sinPress In asinPress
            .Add(sinPress.ToString())
         Next
      End With
   End Sub

End Class
