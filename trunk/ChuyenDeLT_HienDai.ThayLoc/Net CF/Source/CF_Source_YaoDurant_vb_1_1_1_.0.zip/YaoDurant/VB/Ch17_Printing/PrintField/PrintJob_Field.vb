' PrintJob_Field.vb - Print job handler for PrintField program,
' which demonstrates printing with rendering provided by the 
' PrintCF product from Field Software, Inc.
' http://www.fieldsoftware.com/PrinterCE_NetCF.htm
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.IO
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports FieldSoftware.PrinterCE_NetCF

Namespace PrintField
   Public Class PrintJob_Field
      '--------------------------------------------------------
      Public Shared Sub PrintText( _
      ByVal textIn As TextBox, _
      ByVal prce As PrinterCE)
         ' Define drawing coordinates
         ' Units are pixels
         prce.ScaleMode = PrinterCE.MEASUREMENT_UNITS.PIXELS

         ' Get device resolution
         Dim cxyInch As Double = prce.PrinterResolution

         ' Set margins to 1-inch.
         prce.PrLeftMargin = cxyInch
         prce.PrTopMargin = cxyInch
         prce.PrRightMargin = cxyInch
         prce.PrBottomMargin = cxyInch

         ' Calculate page size.
         Dim cxPhysPage As Double = prce.PrPgWidth
         Dim cyPhysPage As Double = prce.PrPgHeight

         ' Calculate line height.
         ' For timing tests, hard-code this value to
         ' 46 for line height for 10 Point Courier New.
         Dim cyLineHeight As Double = prce.GetStringHeight

         ' Init text drawing coordinates;
         Dim xText As Double = 0
         Dim yText As Double = 0

         ' Calculate page boundaries
         Dim yFirst As Double = yText
         Dim yLast As Double = cyPhysPage

         ' Set up some useful character constants.
         Dim achLineFeed() As Char = New Char() {vbLf}
         Dim chReturn As Char = vbCr.Chars(0)

         ' Split input data into separate lines of text.
         Dim astrSplit() As String
         astrSplit = textIn.Text.Split(achLineFeed)

         ' Check for longest string in the document
         Dim i As Integer
         Dim cchMax As Integer = 0
         Dim [cstr] As Integer = astrSplit.Length
         For i = 0 To [cstr] - 1
            If astrSplit(i).Length > cchMax Then
               cchMax = astrSplit(i).Length
            End If
         Next

         ' Set iEnd -- trim extra carriage-return from text
         Dim iEnd As Integer = 0
         Dim cchString As Integer = astrSplit(0).Length
         Dim ch As Char = astrSplit(0).Chars(cchString - 1)
         If ch = chReturn Then
             iEnd = -1
         End If

         ' Loop on available strings.
         For i = 0 To [cstr] - 1
            cchString = astrSplit(i).Length
            If cchString > 0 Then
               ' Draw line of text.
               prce.DrawText(astrSplit(i), xText, yText, _
                  cchString + iEnd)
            End If

            ' Advance to next line.
            yText += cyLineHeight

            ' Skip to next page (if not at end of document)
            If yText >= yLast And (i + 1) < [cstr] Then
               prce.NewPage()
               yText = yFirst
            End If
         Next

         ' End of page & end of document.
         prce.EndDoc()

      End Sub

   End Class
End Namespace