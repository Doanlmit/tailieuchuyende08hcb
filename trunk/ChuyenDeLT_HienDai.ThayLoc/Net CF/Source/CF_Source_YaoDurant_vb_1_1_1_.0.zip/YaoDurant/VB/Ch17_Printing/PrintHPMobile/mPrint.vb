Imports System
Imports System.Text
Imports System.Runtime.InteropServices

Namespace mPrint

   ' Possible status values for the mPrint SDK.
   ' This enumeration defines the possible return values for GetLastError when
   ' an mPrint method returns false.
   '
   ' @version 2.0
   ' @since 1.0

   Public Enum MPRINT_RESULT As Byte
      ' 		* Job was successfully submitted  */
      MPRINT_SUCCESS = 0
      '  Memory problem - probably  of available memory
      MPRINT_MEMORY_ERROR
      ' 		* The user canceled the request
      MPRINT_USER_CANCELLED
      ' 		* There is no content transformation available for the document type
      MPRINT_CT_NOT_AVAILABLE
      ' 		* There was a NULL pointer in the mPrint SDK
      MPRINT_NULL_POINTER
      ' 		* There was a problem reading the document
      MPRINT_DOCUMENT_ERROR
      ' 		* The target printer is currently busy and cannot be used
      MPRINT_PRINTER_BUSY
      ' 		* There was in non-recoverable internal error in the mPrint SDK
      MPRINT_INTERNAL_ERROR
      ' 		* The background printing process is currently busy and can't be used
      MPRINT_PRINT_SUBSYSTEM_BUSY
      ' 		* File I/O failure during Inline CT
      MPRINT_FILE_IO_ERROR
      ' * The Interface called is not supported in this version
      MPRINT_NOT_IMPLEMENTED
   End Enum


   Public Class mPrintWrapper
      <DllImport("mPrintWrapper.dll", EntryPoint:="PrintJob1")> _
      Public Shared Function PrintJob(ByVal szContentName As String) As Boolean
      End Function

      <DllImport("mPrintWrapper.dll", EntryPoint:="PrintJob3")> _
      Public Shared Function PrintJob(ByVal pbyMemoryBuffer() As Byte, ByVal uBufferLen As System.UInt32, ByVal szContentType As String) As Boolean
      End Function


      <DllImport("mPrintWrapper.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function GetVersion(ByVal szVersionInfo As StringBuilder, ByVal uBufferSize As UInt32) As UInt32
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function GetLastError() As MPRINT_RESULT
      End Function

   End Class


   Public Class mPrintRenderWrapper
      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function CreatePrinterContext() As IntPtr
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Sub DeletePrinterContext(ByVal hPrinterContext As IntPtr)
      End Sub
   End Class

   Public Class WinCEGDIHelper
      <DllImport("coredll.dll")> _
      Public Shared Function SelectObject(ByVal hdc As IntPtr, ByVal hgdiobj As IntPtr) As IntPtr
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function DeleteObject(ByVal hgdiobj As IntPtr) As Int32
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function Rectangle(ByVal hdc As IntPtr, ByVal nLeftRect As Int32, ByVal nTopRect As Int32, ByVal nRightRect As Int32, ByVal nBottomRect As Int32) As Boolean
      End Function


      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function NativeStartDoc(ByVal hPrinterContext As IntPtr, ByVal szDocName As String) As Integer
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function NativeStartPage(ByVal hPrinterContext As IntPtr) As Integer
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function NativeEndPage(ByVal hPrinterContext As IntPtr) As Integer
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function NativeEndDoc(ByVal hPrinterContext As IntPtr) As Integer
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function NativeCreatePen(ByVal Red As Int32, ByVal Green As Int32, ByVal Blue As Int32) As IntPtr
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Function NativeCreateFont(ByVal szFaceName As String, ByVal height As Int32) As IntPtr
      End Function

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Sub NativeSetTextColor(ByVal hPrinterContext As IntPtr, ByVal Red As Int32, ByVal Green As Int32, ByVal Blue As Int32)
      End Sub

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Sub NativeGetTextExtentPoint(ByVal hPrinterContext As IntPtr, ByRef cx As Int32, ByRef cy As Int32)
      End Sub

      <DllImport("mPrintWrapper.dll")> _
      Public Shared Sub NativeExtTextOut(ByVal hPrinterContext As IntPtr, ByVal szLineOfText As String, ByVal x As Int32, ByVal y As Int32)
      End Sub

   End Class

End Namespace
