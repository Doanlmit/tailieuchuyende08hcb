' YaoDurant.Drawing.GdiGraphics.cs - Supports native drawing
' with GDI drawing functions.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System
Imports System.Runtime.InteropServices

Namespace YaoDurant.Drawing
   Public Class GdiGraphics
      <DllImport("coredll.dll")> _
      Public Shared Function GetDC( _
      ByVal hWnd As IntPtr) As IntPtr
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function ReleaseDC(ByVal hWnd As IntPtr, _
      ByVal hDC As IntPtr) As Integer
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function GetDeviceCaps(ByVal hdc As IntPtr, _
      ByVal iIndex As CAPS) As Integer
      End Function

      <DllImport("coredll.dll", EnTryPoint:="ExtTextOutW")> _
      Public Shared Function Real_ExtTextOut( _
      ByVal hdc As IntPtr, ByVal X As Integer, _
      ByVal Y As Integer, ByVal fuOptions As Integer, _
      ByVal lprc As IntPtr, ByVal lpString As String, _
      ByVal cbCount As Integer, ByVal lpDx As IntPtr) As Integer
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function DeleteObject( _
      ByVal hObject As IntPtr) As Integer
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function SelectObject(ByVal hdc As IntPtr, _
      ByVal hgdiobj As IntPtr) As IntPtr
      End Function

      <DllImport("coredll.dll")> _
      Public Shared Function SetBkMode(ByVal hdc As IntPtr, _
      ByVal bkmode As BKMODE) As Integer
      End Function

      Public Shared Function ExtTextOut(ByVal hdc As IntPtr, _
      ByVal X As Integer, ByVal Y As Integer, _
      ByVal fuOptions As Integer, ByVal lprc As IntPtr, _
      ByVal lpString As String, ByVal cbCount As Integer, _
      ByVal lpDx As IntPtr) As Integer
         ' "Transparent" only touches foreground pixels.
         SetBkMode(hdc, BKMODE.TRANSPARENT)

         Return Real_ExtTextOut(hdc, X, Y, fuOptions, lprc, lpString, cbCount, lpDx)
      End Function

   End Class


   Public Enum BKMODE
      TRANSPARENT = 1
      OPAQUE = 2
   End Enum

   Public Enum CAPS
      HORZRES = 8             ' Horizontal width in pixels
      VERTRES = 10            ' Vertical height in pixels
      LOGPIXELSY = 90
      PHYSICALWIDTH = 110     ' Physical Width in device units  
      PHYSICALHEIGHT = 111    ' Physical Height in device units 
      PHYSICALOFFSETX = 112   ' Physical Printable Area x margin
      PHYSICALOFFSETY = 113   ' Physical Printable Area y margin
   End Enum
End Namespace

 
 

 
 
 
 
