' PrintJob_Socket.vb - Creates a print job by sending raw text
' to a printer identified by an IP address.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Windows.Forms
Imports System.Net
Imports System.Net.Sockets

Namespace PrintDirect
   Public Class PrintJob_Socket

   '--------------------------------------------------------
   '--------------------------------------------------------
   Public Shared Sub PrintText( _
   ByVal textIn As TextBox, _
   ByVal strPort As String)
      ' Split input data into separate lines of text.
      Dim achNewLine() As Char = New Char() {vbCr}

      Dim astrSplit() As String
      astrSplit = textIn.Text.Split(achNewLine)

      ' Calculate longest string in the document.
      Dim cchMax As Integer = 0
      Dim [cstr] As Integer = astrSplit.Length
      Dim i As Integer
      For i = 0 To [cstr] - 1
         If astrSplit(i).Length > cchMax Then
            cchMax = astrSplit(i).Length
         End If
      Next

      ' Allocate conversion buffer.
      Dim byteData() As Byte = New Byte(cchMax) {}
      Dim chData() As Char = New Char(cchMax) {}
      Dim d As System.Text.Encoder
      d = System.Text.Encoding.UTF8.GetEncoder()

      ' Put form-feed into a byte array
      Dim achFF() As Char = vbFormFeed.ToCharArray()
      Dim abyteFF() As Byte = New Byte(2) {}
      d.GetBytes(achFF, 0, 1, abyteFF, 0, True)

      ' Put Carriage-return into a byte array
      Dim achCR() As Char = vbCr.ToCharArray()
      Dim abyteCrLf() As Byte = New Byte(2) {}
      d.GetBytes(achCR, 0, 1, abyteCrLf, 0, True)

      Dim s As Socket = Nothing

      Try
         ' Connect to printer.
         s = New Socket(AddressFamily.InterNetwork, _
            SocketType.Stream, ProtocolType.IP)
         Dim addr As IPAddress = IPAddress.Parse(strPort)
         Dim ipep As IPEndPoint = New IPEndPoint(addr, 9100)
         s.Connect(ipep)

         ' Loop through list of strings.
         For i = 0 To [cstr] - 1
            Dim cch As Integer = astrSplit(i).Length
            If cch > 0 Then
               chData = astrSplit(i).ToCharArray()

               ' Convert Unicode string to UTF-8 encoding.
               d.GetBytes(chData, 0, cch, byteData, 0, True)

               ' Output bytes to printer.
               s.Send(byteData, 0, cch, SocketFlags.None)
            End If

            ' Put a <CR> at line end.
            s.Send(abyteCrLf, 0, 1, SocketFlags.None)
         Next

         ' Put a <FF> at the end of the document.
         s.Send(abyteFF, 0, 1, SocketFlags.None)
      Finally
         s.Close()
      End Try
   End Sub


   '--------------------------------------------------------
   Public Shared Function IsIPAddress( _
   ByVal strIn As String) As Boolean
      Dim bRetVal As Boolean = True
      Try
         IPAddress.Parse(strIn)
      Catch
         bRetVal = False
      End Try

      Return bRetVal
   End Function

   End Class
End Namespace
