' YaoDurant.Drawing.Printing.cs - Printing support class.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.
Imports System
Imports System.Runtime.InteropServices

Namespace YaoDurant.Drawing
   Public Class Printing
      ' Generic version of CreateDC
      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function CreateDC( _
      ByVal lpszDriver As String, ByVal lpszDevice As String, _
      ByVal lpszOutput As String, ByRef lpInitData As DEVMODE) _
      As IntPtr
      End Function

      ' Slightly more efficient version of CreateDC
      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function CreateDC( _
      ByVal lpszDriver As IntPtr, ByVal lpszDevice As IntPtr, _
      ByVal lpszOutput As IntPtr, ByVal lpInitData As IntPtr) _
      As IntPtr
      End Function

      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function DeleteDC(ByVal hdc As IntPtr) _
      As Integer
      End Function

      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function StartDoc(ByVal hdc As IntPtr, _
      ByRef lpdi As DOCINFO) As Integer
      End Function

      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function EndDoc(ByVal hdc As IntPtr) As Integer
      End Function

      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function StartPage(ByVal hDC As IntPtr) As Integer
      End Function

      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function EndPage(ByVal hdc As IntPtr) As Integer
      End Function

      '--------------------------------------------------------
      ' Create a DC using return values from PageSetupDlgW
      '--------------------------------------------------------
      Public Shared Function CreatePrinterDC(ByRef lppsd As PAGESETUPDLGSTRUCT) As IntPtr
         ' Create managed structure for DEVNAMES
         Dim dn As DEVNAMES = New DEVNAMES
         Marshal.PtrToStructure(lppsd.hDevNames, dn)

         ' Get base address of native structure
         Dim iBase As Integer = lppsd.hDevNames.ToInt32()

         ' Get pointer to driver name.
         Dim iptrDriver As IntPtr = New IntPtr(iBase + dn.wDriverOffset)
         Dim strDriver As String = Marshal.PtrToStringUni(iptrDriver)

         ' Get pointer to device name. 
         Dim iptrDevice As IntPtr = New IntPtr(iBase + dn.wDeviceOffset)
         Dim strDevice As String = Marshal.PtrToStringUni(iptrDevice)

         ' Get pointer to output port.
         Dim iptrOutput As IntPtr = New IntPtr(iBase + dn.wOutputOffset)
         Dim strOutput As String = Marshal.PtrToStringUni(iptrOutput)

         Dim hdc As IntPtr = _
            CreateDC(iptrDriver, iptrDevice, iptrOutput, lppsd.hDevMode)
         Return hdc
      End Function

   End Class


   Public Structure DOCINFO
      Public cbSize As Integer
      Public lpszDocName As IntPtr
      Public lpszOutput As IntPtr
      Public lpszDatatype As IntPtr
      Public fwType As Integer
   End Structure


   Public Structure DEVMODE
      Public dmDeviceName As CHARNAME32 ' WCHAR  dmDeviceName[CCHDEVICENAME]
      Public dmSpecVersion As Short
      Public dmDriverVersion As Short
      Public dmSize As Short
      Public dmDriverExtra As Short
      Public dmFields As Integer
      Public dmOrientation As Short
      Public dmPaperSize As Short
      Public dmPaperLength As Short
      Public dmPaperWidth As Short
      Public dmScale As Short
      Public dmCopies As Short
      Public dmDefaultSource As Short
      Public dmPrintQuality As Short
      Public dmColor As Short
      Public dmDuplex As Short
      Public dmYResolution As Short
      Public dmTTOption As Short
      Public dmCollate As Short
      Public dmFormName As CHARNAME32 ' WCHAR  dmFormName[CCHFORMNAME];
      Public dmLogPixels As Short
      Public dmBitsPerPel As Integer
      Public dmPelsWidth As Integer
      Public dmPelsHeight As Integer
      Public dmDisplayFlags As Integer
      Public dmDisplayFrequency As Integer
   End Structure

End Namespace
