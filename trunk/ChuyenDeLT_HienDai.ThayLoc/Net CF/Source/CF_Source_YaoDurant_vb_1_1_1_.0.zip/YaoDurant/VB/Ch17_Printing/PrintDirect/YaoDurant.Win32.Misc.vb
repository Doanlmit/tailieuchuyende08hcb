' YaoDurant.Win32.Misc.vb - Generic wrappers for various
' Win32 API functions.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Runtime.InteropServices

Namespace YaoDurant.Win32

   Public Class NativeHeap
      ' Memory allocation functions & definitions.
      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function LocalAlloc( _
         ByVal uFlags As Integer, _
         ByVal uBytes As Integer) As IntPtr
      End Function
      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function LocalFree( _
         ByVal hMem As IntPtr) As IntPtr
      End Function
      Public Const LPTR As Integer = &H40
   End Class


   Public Class WinFocus
      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function SetFocus(ByVal hWnd As IntPtr) As IntPtr
      End Function

      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function GetFocus() As IntPtr
      End Function
   End Class

   Public Class WinIO
      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function CreateFile( _
         ByVal lpFileName As String, _
         ByVal dwDesiredAccess As ACCESS, _
         ByVal dwShareMode As FILE_SHARE, _
         ByVal Res As Integer, _
         ByVal dwCreationDispostion As FILE_ACTION, _
         ByVal dwFlagsAndAttributes As FILE_ATTRIBUTE, _
         ByVal Res2 As Integer) As IntPtr
      End Function


      <DllImport("coredll.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function CloseHandle( _
         ByVal hObject As IntPtr) As Integer
      End Function

      Public Shared Function WriteFile( _
         ByVal hFile As IntPtr, _
         ByVal lpBuffer() As Byte, _
         ByVal nNumberOfBytesToWrite As Integer, _
         ByRef lpNumberOfBytesWritten As Integer, _
         ByVal Res As IntPtr) As Integer
      End Function

      Public Shared INVALID_FILE_HANDLE As IntPtr = New IntPtr(-1)

      Public Enum ACCESS
         READ = &H80000000
         WRITE = &H40000000
         EXECUTE = &H20000000
         ALL = &H10000000
         NONE = 0
      End Enum


      Public Enum FILE_SHARE
         READ = &H1
         WRITE = &H2
      End Enum


      Public Enum FILE_ACTION
         CREATE_NEW = 1
         CREATE_ALWAYS = 2
         OPEN_EXISTING = 3
         OPEN_ALWAYS = 4
         TRUNCATE_EXISTING = 5
         OPEN_FOR_LOADER = 6
      End Enum

      Public Enum FILE_ATTRIBUTE
         [READONLY] = &H1
         HIDDEN = &H2
         SYSTEM = &H4
         DIRECTORY = &H10
         ARCHIVE = &H20
         INROM = &H40
         ENCRYPTED = &H40
         NORMAL = &H80
         TEMPORARY = &H100
         SPARSE_FILE = &H200
         REPARSE_POINT = &H400
         COMPRESSED = &H800
         OFFLINE = &H1000
         ROMSTATICREF = &H1000
         NOT_CONTENT_INDEXED = &H2000
         ROMMODULE = &H2000
      End Enum

   End Class
End Namespace
