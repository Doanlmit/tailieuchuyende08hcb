' PrintJob_Gdi.vb - Creates a print job by creating a DC
' and calling GDI drawing calls.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.IO
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports YaoDurant.Win32
Imports YaoDurant.Drawing

Namespace PrintGdi
   Public Class PrintJob_Gdi

      '--------------------------------------------------------
      Public Shared Sub PrintText( _
      ByVal textIn As TextBox, _
      ByVal hdc As IntPtr)

         ' Set up some useful character constants.
         Dim achLineFeed() As Char = New Char() {vbLf}
         Dim chReturn As Char = vbCr.Chars(0)

         ' Split input data into separate lines of text.
         Dim astrSplit() As String
         astrSplit = textIn.Text.Split(achLineFeed)

         ' Calculate longest string in the document.
         Dim cchMax As Integer = 0
         Dim [cstr] As Integer = astrSplit.Length
         Dim i As Integer
         For i = 0 To [cstr] - 1
            If astrSplit(i).Length > cchMax Then
               cchMax = astrSplit(i).Length
            End If
         Next

         ' Allocate conversion buffer.
         Dim byteData() As Byte = New Byte(cchMax) {}
         Dim chData() As Char = New Char(cchMax) {}
         Dim d As System.Text.Encoder
         d = System.Text.Encoding.UTF8.GetEncoder()

         ' Get device resolution
         Dim cxyInch As Integer = _
            GdiGraphics.GetDeviceCaps(hdc, CAPS.LOGPIXELSY)
         ' In draft mode, the PCL driver returns wrong value.
         If cxyInch = 0 Then
            cxyInch = 150
         End If

         ' Calculate page size.
         Dim cxPhysPage As Integer = _
            GdiGraphics.GetDeviceCaps(hdc, CAPS.PHYSICALWIDTH)
         Dim cyPhysPage As Integer = _
            GdiGraphics.GetDeviceCaps(hdc, CAPS.PHYSICALHEIGHT)
         Dim cxOff As Integer = _
            GdiGraphics.GetDeviceCaps(hdc, CAPS.PHYSICALOFFSETX)
         Dim cyOff As Integer = _
            GdiGraphics.GetDeviceCaps(hdc, CAPS.PHYSICALOFFSETY)

         Dim cxHorzRes As Integer = _
            GdiGraphics.GetDeviceCaps(hdc, CAPS.HORZRES)
         Dim cyVertRes As Integer = _
            GdiGraphics.GetDeviceCaps(hdc, CAPS.VERTRES)

         ' Calculate line height.
         Dim tm As TEXTMETRIC = New TEXTMETRIC
         GdiFont.GetTextMetrics(hdc, tm)
         Dim cyLineHeight As Integer = tm.tmHeight + tm.tmExternalLeading

         ' Init text drawing coordinates;
         Dim xText As Integer = cxyInch - cxOff
         Dim yText As Integer = cxyInch - cyOff

         ' Calculate page boundaries
         Dim yFirst As Integer = yText
         Dim yLast As Integer = cyPhysPage - cxyInch

         Try
            ' Notify GDI of document and page start.
            Dim di As DOCINFO = New DOCINFO
            di.cbSize = Marshal.SizeOf(di)
            Printing.StartDoc(hdc, di)
            Printing.StartPage(hdc)

            ' Set iEnd -- trim extra carriage-return from text
            Dim iEnd As Integer = 0
            Dim cchString As Integer = astrSplit(0).Length
            Dim ch As Char = astrSplit(0).Chars(cchString - 1)
            If ch = chReturn Then
                iEnd = -1
            End If

            ' Loop through list of strings.
            For i = 0 To [cstr] - 1 Step i + 1
               cchString = astrSplit(i).Length
               If cchString > 0 Then
                  ' Draw line of text.
                  GdiGraphics.ExtTextOut(hdc, xText, yText, 0, _
                     IntPtr.Zero, astrSplit(i), cchString + iEnd, _
                     IntPtr.Zero)
               End If

               ' Advance to next line.
               yText += cyLineHeight

               ' Skip to next page (if not at document end)
               If yText >= yLast And (i + 1) < [cstr] Then
                  Printing.EndPage(hdc)
                  Printing.StartPage(hdc)
                  yText = yFirst
               End If
            Next
         Finally
            ' End of page & end of document.
            Printing.EndPage(hdc)
            Printing.EndDoc(hdc)
         End Try

      End Sub
   End Class
End Namespace
