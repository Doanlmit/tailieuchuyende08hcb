' YaoDurant.Drawing.PrintSetupDlg.vb - Generic Print setup 
' dialog box.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Runtime.InteropServices
Imports YaoDurant.Win32

Namespace YaoDurant.Drawing

   Public Class PrintSetupDlg
      '--------------------------------------------------------
      ' Declarations for native printing dialog boxes.
      '--------------------------------------------------------
      <DllImport("commdlg.dll", CharSet:=CharSet.Unicode)> _
      Private Shared Function PageSetupDlgW(ByRef lppsd As PAGESETUPDLGSTRUCT) As Integer
      End Function
      <DllImport("commdlg.dll", CharSet:=CharSet.Unicode)> _
      Public Shared Function CommDlgExtendedError() As Integer
      End Function

      '--------------------------------------------------------
      ' Clean up memory allocated by call to PageSetupDlgW
      '--------------------------------------------------------
      Public Shared Sub Close(ByRef lppsd As PAGESETUPDLGSTRUCT)
         If lppsd.hDevMode.ToInt32() <> 0 Then
            NativeHeap.LocalFree(lppsd.hDevMode)
         End If
         If lppsd.hDevNames.ToInt32() <> 0 Then
            NativeHeap.LocalFree(lppsd.hDevNames)
         End If
      End Sub

      '--------------------------------------------------------
      ' Allocate and initialize PAGESETUPDLGSTRUCT structure
      '--------------------------------------------------------
      Public Shared Sub InitDlgStruct( _
      ByRef psd As PAGESETUPDLGSTRUCT, ByVal hwndParent As IntPtr)
         psd.lStructSize = Marshal.SizeOf(psd)
         psd.Flags = 0
         psd.hwndOwner = hwndParent
      End Sub

      '--------------------------------------------------------
      ' Display dialog box.
      '--------------------------------------------------------
      Public Shared Function ShowDialog(ByRef psd As PAGESETUPDLGSTRUCT) As Integer
         Return PageSetupDlgW(psd)
      End Function

      '--------------------------------------------------------
      ' Fetch error string
      '--------------------------------------------------------
      Public Shared Function GetErrorString() As String
         ' User clicked cancel [x] button -or- we have an error.
         Dim ierrDlg As Integer = CommDlgExtendedError()
         If ierrDlg = 0 Then
            Return "Ok"
         End If

         Dim strReason As String = String.Empty

         If (ierrDlg >= pderr.PRINTERCODES And _
            ierrDlg <= pderr.DEFAULTDIFFERENT) Then
            Dim pderr As pderr = CType(ierrDlg, pderr)
            strReason = "PDERR_" + pderr.ToString()
         Else
            strReason = "&H" + ierrDlg.ToString("x")
         End If

         Return strReason
      End Function

      '--------------------------------------------------------
      '--------------------------------------------------------
      Public Shared Function QueryOutputPort(ByRef lppsd As PAGESETUPDLGSTRUCT) As String
         ' Create managed structure for DEVNAMES
         Dim dn As DEVNAMES = New DEVNAMES
         Marshal.PtrToStructure(lppsd.hDevNames, dn)

         ' Get base address of native structure
         Dim iBase As Integer = lppsd.hDevNames.ToInt32()

         ' Get pointer to output port.
         Dim iptrOutput As IntPtr = New IntPtr(iBase + dn.wOutputOffset)
         Dim strOutput As String = Marshal.PtrToStringUni(iptrOutput)

         Return strOutput
      End Function

   End Class

   '--------------------------------------------------------
   '--------------------------------------------------------
   Public Structure PAGESETUPDLGSTRUCT
      Public lStructSize As Integer
      Public hwndOwner As IntPtr
      Public hDevMode As IntPtr
      Public hDevNames As IntPtr
      Public Flags As Integer
      Public ptPaperSize As System.Drawing.Point
      Public rtMinMargin As System.Drawing.Rectangle
      Public rtMargin As System.Drawing.Rectangle
      Public hInstance As IntPtr
      Public lCustData As Integer
      Public lpfnPageSetupHook As IntPtr
      Public lpfnPagePaintHook As IntPtr
      Public reserved As IntPtr
      Public hPageSetupTemplate As IntPtr
   End Structure

   '  Size of a device name String
   ' #define CCHDEVICENAME 32

   ' Size of a form name String
   ' #define CCHFORMNAME 32

   Public Structure CHARNAME32
      Public ch00 As Char, ch01 As Char, ch02 As Char, ch03 As Char, ch04 As Char
      Public ch05 As Char, ch06 As Char, ch07 As Char, ch08 As Char, ch09 As Char
      Public ch10 As Char, ch11 As Char, ch12 As Char, ch13 As Char, ch14 As Char
      Public ch15 As Char, ch16 As Char, ch17 As Char, ch18 As Char, ch19 As Char
      Public ch20 As Char, ch21 As Char, ch22 As Char, ch23 As Char, ch24 As Char
      Public ch25 As Char, ch26 As Char, ch27 As Char, ch28 As Char, ch29 As Char
      Public ch30 As Char, ch31 As Char
   End Structure


   Public Class DEVNAMES
      Public wDriverOffset As Short
      Public wDeviceOffset As Short
      Public wOutputOffset As Short
      Public wDefault As Short
   End Class


   Public Enum PSD
      MINMARGINS = &H1
      MARGINS = &H2
      INTHOUSANDTHSOFINCHES = &H4
      INHUNDREDTHSOFMILLIMETERS = &H8
      DISABLEMARGINS = &H10
      DISABLEPRINTER = &H20
      DISABLEORIENTATION = &H100
      RETURNDEFAULT = &H400
      DISABLEPAPER = &H200
      ENABLEPAGESETUPHOOK = &H2000
      ENABLEPAGESETUPTEMPLATE = &H8000
      ENABLEPAGESETUPTEMPLATEHANDLE = &H20000
   End Enum

   Public Enum PDERR
      PRINTERCODES = &H1000
      SETUPFAILURE = &H1001
      PARSEFAILURE = &H1002
      RETDEFFAILURE = &H1003
      LOADDRVFAILURE = &H1004
      GETDEVMODEFAIL = &H1005
      INITFAILURE = &H1006
      NODEVICES = &H1007
      NODEFAULTPRN = &H1008
      DNDMMISMATCH = &H1009
      CREATEICFAILURE = &H100A
      PRINTERNOTFOUND = &H100B
      DEFAULTDIFFERENT = &H100C
   End Enum

End Namespace
