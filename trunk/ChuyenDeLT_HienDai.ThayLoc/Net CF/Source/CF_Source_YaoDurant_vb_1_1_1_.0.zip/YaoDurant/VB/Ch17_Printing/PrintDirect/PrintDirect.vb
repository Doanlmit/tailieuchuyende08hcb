' PrintDirect.vb - Main form for direct printing sample.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.Text               '  StringBuilder
Imports System.Drawing            '  FontStyle
Imports System.Windows.Forms      '  DialogResult
Imports Microsoft.WindowsCE.Forms ' InputPanel
Imports System.IO                 '  Directories, Files, Streams
Imports YaoDurant.Win32           '  Heap, focus, Win32 I/O
Imports YaoDurant.Drawing         '  Native drawing support

Namespace PrintDirect
Public Class FormMain
   Inherits System.Windows.Forms.Form
      Friend WithEvents cmenuMain As ContextMenu
      Friend WithEvents mitemProgramMenu As MenuItem
      Friend WithEvents mitemToolbar As MenuItem
      Friend WithEvents ilistCommands As ImageList
      Friend WithEvents menuMain As MainMenu
      Friend WithEvents mitemFilePopup As MenuItem
      Friend WithEvents mitemFileOpen As MenuItem
      Friend WithEvents mitemFileSave As MenuItem
      Friend WithEvents mitemFileSaveAs As MenuItem
      Friend WithEvents mitemFileFormat As MenuItem
      Friend WithEvents mitemFFAscii As MenuItem
      Friend WithEvents mitemFFUnicode As MenuItem
      Friend WithEvents mitemFFUtf7 As MenuItem
      Friend WithEvents mitemFFUtf8 As MenuItem
      Friend WithEvents mitemFFDefault As MenuItem
      Friend WithEvents mitemEditPopup As MenuItem
      Friend WithEvents mitemEditFont As MenuItem
      Friend WithEvents mitemToolsPopup As MenuItem
      Friend WithEvents mitemToolsOptions As MenuItem
      Friend WithEvents mitemSettingsPopup As MenuItem
      Friend WithEvents mitemSettingsSave As MenuItem
      Friend WithEvents mitemSettingsRestore As MenuItem
      Friend WithEvents mitemSettingsInit As MenuItem
      Friend WithEvents tbarCommands As ToolBar
      Friend WithEvents tbbEditFormat As ToolBarButton
      Friend WithEvents tbbViewOptions As ToolBarButton

#Region " Windows Form Designer generated code "

      Public Sub New()
         MyBase.New()

         'This call is required by the Windows Form Designer.
         InitializeComponent()

         'Add any initialization after the InitializeComponent() call

      End Sub

      'Form overrides dispose to clean up the component list.
      Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
         MyBase.Dispose(disposing)
      End Sub

      'NOTE: The following procedure is required by the Windows Form Designer
      'It can be modified using the Windows Form Designer.  
      'Do not modify it using the code editor.
      Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemFilePrint As System.Windows.Forms.MenuItem
      Friend WithEvents tboxInput As System.Windows.Forms.TextBox
      Friend WithEvents mitemCut As System.Windows.Forms.MenuItem
      Friend WithEvents mitemCopy As System.Windows.Forms.MenuItem
      Friend WithEvents mitemPaste As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
      Friend WithEvents mitemClear As System.Windows.Forms.MenuItem
      Friend WithEvents mitemUndo As System.Windows.Forms.MenuItem
      Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
      Private Sub InitializeComponent()
Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FormMain))
Me.tboxInput = New System.Windows.Forms.TextBox
Me.cmenuMain = New System.Windows.Forms.ContextMenu
Me.mitemProgramMenu = New System.Windows.Forms.MenuItem
Me.mitemToolbar = New System.Windows.Forms.MenuItem
Me.ilistCommands = New System.Windows.Forms.ImageList
Me.menuMain = New System.Windows.Forms.MainMenu
Me.mitemFilePopup = New System.Windows.Forms.MenuItem
Me.mitemFileOpen = New System.Windows.Forms.MenuItem
Me.mitemFileSave = New System.Windows.Forms.MenuItem
Me.mitemFileSaveAs = New System.Windows.Forms.MenuItem
Me.mitemFileFormat = New System.Windows.Forms.MenuItem
Me.mitemFFAscii = New System.Windows.Forms.MenuItem
Me.mitemFFUnicode = New System.Windows.Forms.MenuItem
Me.mitemFFUtf7 = New System.Windows.Forms.MenuItem
Me.mitemFFUtf8 = New System.Windows.Forms.MenuItem
Me.mitemFFDefault = New System.Windows.Forms.MenuItem
Me.MenuItem1 = New System.Windows.Forms.MenuItem
Me.mitemFilePrint = New System.Windows.Forms.MenuItem
Me.mitemEditPopup = New System.Windows.Forms.MenuItem
Me.mitemEditFont = New System.Windows.Forms.MenuItem
Me.mitemToolsPopup = New System.Windows.Forms.MenuItem
Me.mitemToolsOptions = New System.Windows.Forms.MenuItem
Me.mitemSettingsPopup = New System.Windows.Forms.MenuItem
Me.mitemSettingsSave = New System.Windows.Forms.MenuItem
Me.mitemSettingsRestore = New System.Windows.Forms.MenuItem
Me.mitemSettingsInit = New System.Windows.Forms.MenuItem
Me.tbarCommands = New System.Windows.Forms.ToolBar
Me.tbbEditFormat = New System.Windows.Forms.ToolBarButton
Me.tbbViewOptions = New System.Windows.Forms.ToolBarButton
Me.mitemCut = New System.Windows.Forms.MenuItem
Me.mitemCopy = New System.Windows.Forms.MenuItem
Me.mitemPaste = New System.Windows.Forms.MenuItem
Me.MenuItem5 = New System.Windows.Forms.MenuItem
Me.mitemClear = New System.Windows.Forms.MenuItem
Me.mitemUndo = New System.Windows.Forms.MenuItem
Me.MenuItem8 = New System.Windows.Forms.MenuItem
'
'tboxInput
'
Me.tboxInput.Location = New System.Drawing.Point(-1, -1)
Me.tboxInput.Multiline = True
Me.tboxInput.ScrollBars = System.Windows.Forms.ScrollBars.Both
Me.tboxInput.Size = New System.Drawing.Size(242, 250)
Me.tboxInput.Text = "Some text inside a textbox."
'
'cmenuMain
'
Me.cmenuMain.MenuItems.Add(Me.mitemProgramMenu)
Me.cmenuMain.MenuItems.Add(Me.mitemToolbar)
'
'mitemProgramMenu
'
Me.mitemProgramMenu.Text = "Program Menu"
'
'mitemToolbar
'
Me.mitemToolbar.Text = "Toolbar"
'
'ilistCommands
'
Me.ilistCommands.Images.Add(CType(resources.GetObject("resource"), System.Drawing.Image))
Me.ilistCommands.Images.Add(CType(resources.GetObject("resource1"), System.Drawing.Image))
Me.ilistCommands.ImageSize = New System.Drawing.Size(16, 16)
'
'menuMain
'
Me.menuMain.MenuItems.Add(Me.mitemFilePopup)
Me.menuMain.MenuItems.Add(Me.mitemEditPopup)
Me.menuMain.MenuItems.Add(Me.mitemToolsPopup)
Me.menuMain.MenuItems.Add(Me.mitemSettingsPopup)
'
'mitemFilePopup
'
Me.mitemFilePopup.MenuItems.Add(Me.mitemFileOpen)
Me.mitemFilePopup.MenuItems.Add(Me.mitemFileSave)
Me.mitemFilePopup.MenuItems.Add(Me.mitemFileSaveAs)
Me.mitemFilePopup.MenuItems.Add(Me.mitemFileFormat)
Me.mitemFilePopup.MenuItems.Add(Me.MenuItem1)
Me.mitemFilePopup.MenuItems.Add(Me.mitemFilePrint)
Me.mitemFilePopup.Text = "File"
'
'mitemFileOpen
'
Me.mitemFileOpen.Text = "Open..."
'
'mitemFileSave
'
Me.mitemFileSave.Text = "Save"
'
'mitemFileSaveAs
'
Me.mitemFileSaveAs.Text = "SaveAs..."
'
'mitemFileFormat
'
Me.mitemFileFormat.MenuItems.Add(Me.mitemFFAscii)
Me.mitemFileFormat.MenuItems.Add(Me.mitemFFUnicode)
Me.mitemFileFormat.MenuItems.Add(Me.mitemFFUtf7)
Me.mitemFileFormat.MenuItems.Add(Me.mitemFFUtf8)
Me.mitemFileFormat.MenuItems.Add(Me.mitemFFDefault)
Me.mitemFileFormat.Text = "Format"
'
'mitemFFAscii
'
Me.mitemFFAscii.Text = "Ascii"
'
'mitemFFUnicode
'
Me.mitemFFUnicode.Text = "Unicode"
'
'mitemFFUtf7
'
Me.mitemFFUtf7.Text = "Utf7"
'
'mitemFFUtf8
'
Me.mitemFFUtf8.Text = "Utf8"
'
'mitemFFDefault
'
Me.mitemFFDefault.Text = "Default"
'
'MenuItem1
'
Me.MenuItem1.Text = "-"
'
'mitemFilePrint
'
Me.mitemFilePrint.Text = "Print..."
'
'mitemEditPopup
'
Me.mitemEditPopup.MenuItems.Add(Me.mitemCut)
Me.mitemEditPopup.MenuItems.Add(Me.mitemCopy)
Me.mitemEditPopup.MenuItems.Add(Me.mitemPaste)
Me.mitemEditPopup.MenuItems.Add(Me.MenuItem5)
Me.mitemEditPopup.MenuItems.Add(Me.mitemClear)
Me.mitemEditPopup.MenuItems.Add(Me.mitemUndo)
Me.mitemEditPopup.MenuItems.Add(Me.MenuItem8)
Me.mitemEditPopup.MenuItems.Add(Me.mitemEditFont)
Me.mitemEditPopup.Text = "Edit"
'
'mitemEditFont
'
Me.mitemEditFont.Text = "Font..."
'
'mitemToolsPopup
'
Me.mitemToolsPopup.MenuItems.Add(Me.mitemToolsOptions)
Me.mitemToolsPopup.Text = "Tools"
'
'mitemToolsOptions
'
Me.mitemToolsOptions.Text = "Options..."
'
'mitemSettingsPopup
'
Me.mitemSettingsPopup.MenuItems.Add(Me.mitemSettingsSave)
Me.mitemSettingsPopup.MenuItems.Add(Me.mitemSettingsRestore)
Me.mitemSettingsPopup.MenuItems.Add(Me.mitemSettingsInit)
Me.mitemSettingsPopup.Text = "Settings"
'
'mitemSettingsSave
'
Me.mitemSettingsSave.Text = "Save"
'
'mitemSettingsRestore
'
Me.mitemSettingsRestore.Text = "Restore"
'
'mitemSettingsInit
'
Me.mitemSettingsInit.Text = "Initialize"
'
'tbarCommands
'
Me.tbarCommands.Buttons.Add(Me.tbbEditFormat)
Me.tbarCommands.Buttons.Add(Me.tbbViewOptions)
Me.tbarCommands.ImageList = Me.ilistCommands
'
'tbbEditFormat
'
Me.tbbEditFormat.ImageIndex = 0
'
'tbbViewOptions
'
Me.tbbViewOptions.ImageIndex = 1
'
'mitemCut
'
Me.mitemCut.Text = "Cut"
'
'mitemCopy
'
Me.mitemCopy.Text = "Copy"
'
'mitemPaste
'
Me.mitemPaste.Text = "Paste"
'
'MenuItem5
'
Me.MenuItem5.Text = "-"
'
'mitemClear
'
Me.mitemClear.Text = "Clear"
'
'mitemUndo
'
Me.mitemUndo.Text = "Undo"
'
'MenuItem8
'
Me.MenuItem8.Text = "-"
'
'FormMain
'
Me.ContextMenu = Me.cmenuMain
Me.Controls.Add(Me.tboxInput)
Me.Controls.Add(Me.tbarCommands)
Me.Menu = Me.menuMain
Me.MinimizeBox = False
Me.Text = "PrintDirect"

      End Sub

#End Region

      Private Sub FormMain_Load( _
      ByVal sender As Object, _
      ByVal e As EventArgs) Handles MyBase.Load
         mitemSettingsRestore_Click(Me, EventArgs.Empty)
         SaveSettingsToFile()
         ReadSettingsFromFile()

         ' Set focus to text box window.
         tboxInput.Focus()

         ' Fetch window handle of text box.
         Dim hwndEditor As IntPtr = WinFocus.GetFocus()

         ' Create message structure for sending Win32 messages
         m_msg = Message.Create(hwndEditor, 0, IntPtr.Zero, _
            IntPtr.Zero)
      End Sub

#Region "Settings Menu Handlers"
      ' mitemEditFont - Respond to menu selection Edit->Font...
      Private Sub mitemEditFont_Click( _
      ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles mitemEditFont.Click

         Dim dlg As DlgFont = New DlgFont(Me)

         ' Initialize input values to dialog.
         dlg.strFontName = tboxInput.Font.Name
         dlg.cemFontSize = tboxInput.Font.Size
         Dim fsTemp As FontStyle = tboxInput.Font.Style
         dlg.bBold = ((fsTemp And FontStyle.Bold) <> 0)
         dlg.bItalic = ((fsTemp And FontStyle.Italic) <> 0)
         dlg.bUnderline = ((fsTemp And FontStyle.Underline) <> 0)

         ' Summon dialog box.
         If (dlg.ShowDialog() <> DialogResult.OK) Then
            Return
         End If

         ' Modify settings based on user input.
         Dim fontOld As Font = tboxInput.Font
         fsTemp = 0
         If (dlg.bBold) Then
            fsTemp = fsTemp Or FontStyle.Bold
         End If
         If (dlg.bItalic) Then
            fsTemp = fsTemp Or FontStyle.Italic
         End If
         If (dlg.bUnderline) Then
            fsTemp = fsTemp Or FontStyle.Underline
         End If
         tboxInput.Font = New Font(dlg.strFontName, _
            dlg.cemFontSize, fsTemp)
         fontOld.Dispose()

      End Sub

      ' mitemToolsOptions -- Respond to menu selection
      ' Tools->Options...
      Private Sub mitemToolsOptions_Click( _
      ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles mitemToolsOptions.Click

         Dim dlg As DlgToolsOptions = New DlgToolsOptions(Me)

         ' Get flag for whether toolbar is being displayed
         Dim bHasTB As Boolean = Me.Controls.Contains(tbarCommands)

         ' Initialize input values to dialog.
         dlg.sbScrollBars = tboxInput.ScrollBars
         dlg.bProgramMenu = Not (Me.Menu Is Nothing)
         dlg.bToolbar = bHasTB
         dlg.haTextAlign = tboxInput.TextAlign
         dlg.bWordWrap = tboxInput.WordWrap

         ' Summon dialog box.
         If dlg.ShowDialog() <> DialogResult.OK Then
            Return
         End If

         ' Hide textbox to minimize redrawing time.
         tboxInput.Visible = False

         ' Modify settings based on user input.
         tboxInput.ScrollBars = dlg.sbScrollBars
         Me.Menu = IIf((dlg.bProgramMenu), menuMain, Nothing)

         ' Do we need to add toolbar?
         ' (adding a toolbar twice causes an
         '  exception, so we have to be careful)
         If dlg.bToolbar And (Not bHasTB) Then
            Me.Controls.Add(tbarCommands)
         End If

         ' Do we need to remove toolbar?
         ' (okay to remove a toolbar twice -- we
         '  do the following to parallel the add code)
         If bHasTB And (Not dlg.bToolbar) Then
            Me.Controls.Remove(tbarCommands)
         End If

         ' Update text alignment.
         tboxInput.TextAlign = dlg.haTextAlign

         ' Update word-wrap setting.
         tboxInput.WordWrap = dlg.bWordWrap

         ' Make textbox visible again.
         tboxInput.Visible = True

      End Sub

      ' tbarCommands_ButtonClick - Respond to ButtonClick
      ' event for toolbar tbarCommands
      Private Sub tbarCommands_ButtonClick( _
      ByVal sender As System.Object, _
      ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) _
      Handles tbarCommands.ButtonClick

         If (e.Button Is tbbEditFormat) Then
            mitemEditFont_Click(sender, e)
         Else
            mitemToolsOptions_Click(sender, e)
         End If
      End Sub

      ' cmenuMain_Popup -- Handle Popup event for
      ' context menu. Set/clear check-mark on context
      ' menu items.
      Private Sub cmenuMain_Popup(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmenuMain.Popup

         Dim bMenu As Boolean = Not (Me.Menu Is Nothing)
         mitemProgramMenu.Checked = bMenu

         Dim bTB As Boolean = Me.Controls.Contains(tbarCommands)
         mitemToolbar.Checked = bTB
      End Sub

      Private Sub mitemProgramMenu_Click( _
      ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles mitemProgramMenu.Click

         If (Me.Menu Is Nothing) Then
            Me.Menu = menuMain
         Else
            Me.Menu = Nothing
         End If
      End Sub

      Private Sub mitemToolbar_Click( _
      ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles mitemToolbar.Click

         If (mitemToolbar.Checked) Then
            Me.Controls.Remove(tbarCommands)
         Else
            Me.Controls.Add(tbarCommands)
         End If

      End Sub

#End Region

#Region "Text FileIO routines"

      Private fdlgOpen As OpenFileDialog
      Private fdlgSave As SaveFileDialog
      Private encodeFile As Text.Encoding = Encoding.Default
      Private strCurrentFile As String = String.Empty

      Private Sub mitemFileOpen_Click( _
                     ByVal sender As Object, _
                     ByVal e As EventArgs _
                     ) _
                     Handles mitemFileOpen.Click

         '  Create a OpenFile dialog if necessary.
         If fdlgOpen Is Nothing Then _
            fdlgOpen = New OpenFileDialog
         fdlgOpen.InitialDirectory = "NotepadCE"
         fdlgOpen.Filter = "dat files (*.dat)|*.dat|" & _
                           "txt files (*.txt)|*.txt|" & _
                           "All files (*.*)|*.*"

         '  Show it.
         Select Case fdlgOpen.ShowDialog()

            '  Check user's response.
         Case DialogResult.OK

               '  Save file name.
               strCurrentFile = fdlgOpen.FileName

               '  Open, read, close file.
               Dim srdrFile As New StreamReader _
                  ( _
                     New FileStream(strCurrentFile, _
                                    FileMode.Open), _
                         Me.encodeFile _
                  )
               With srdrFile
                  Me.tboxInput.Text = .ReadToEnd()
                  .Close()
               End With
            Case Else
         End Select
      End Sub

      Private Sub mitemFileSave_Click( _
                     ByVal sender As Object, _
                     ByVal e As EventArgs _
                     ) _
                     Handles mitemFileSave.Click

         '  If the user has not yet specified
         '     a file name, do SaveAs.
         '  Else,
         '     open, write, close file.
         If strCurrentFile = String.Empty Then
            mitemFileSaveAs_Click(sender, e)
         Else
            Dim swrtFile As New StreamWriter _
               ( _
                  New FileStream(strCurrentFile, _
                                 FileMode.Truncate), _
                  Me.encodeFile _
               )
            With swrtFile
               .Write(Me.tboxInput.Text)
               .Close()
            End With
         End If
      End Sub

      Private Sub mitemFileSaveAs_Click( _
                     ByVal sender As Object, _
                     ByVal e As EventArgs _
                     ) _
                     Handles mitemFileSaveAs.Click

         '  Get the file name from the user.
         If fdlgSave Is Nothing Then _
            fdlgSave = New SaveFileDialog
         Select Case fdlgSave.ShowDialog()
            Case DialogResult.OK
               '  Save file name.
               strCurrentFile = fdlgSave.FileName
               '  Save file.
               mitemFileSave_Click(sender, e)
            Case Else
         End Select
      End Sub

      Private Sub mitemFileFormat_Click( _
                     ByVal sender As Object, _
                     ByVal e As EventArgs _
                     ) _
                     Handles mitemFFAscii.Click, _
                             mitemFFDefault.Click, _
                             mitemFFUnicode.Click, _
                             mitemFFUtf7.Click, _
                             mitemFFUtf8.Click

         If sender.Equals(mitemFFAscii) Then
            Me.encodeFile = Encoding.ASCII
         ElseIf sender.Equals(mitemFFUnicode) Then
            Me.encodeFile = Encoding.Unicode
         ElseIf sender.Equals(mitemFFUtf7) Then
            Me.encodeFile = Encoding.UTF7
         ElseIf sender.Equals(mitemFFUtf8) Then
            Me.encodeFile = Encoding.UTF8
         Else
            Me.encodeFile = Encoding.Default
         End If
      End Sub

#End Region

#Region "Binary File IO routines"

      Private strDirName As String = _
                              "My Documents\YaoDurant\NotepadCE"
      Private strFileName As String = _
                              "Settings.dat"

      '  A structure containing font information and 
      '     routines to dump and restore that info 
      '     to / from a file.
      Private Structure ourFontInfo
         Public strName As String
         Public sglSize As Single
         Public intStyle As Integer

         Public Sub New(ByVal strName As String, _
                        ByVal sglSize As Single, _
                        ByVal intStyle As Integer)
            Me.strName = strName
            Me.sglSize = sglSize
            Me.intStyle = intStyle
         End Sub

         Public Sub WriteToFile(ByVal strDirName As String, _
                                ByVal strFileName As String, _
                                ByVal encodeFile As Encoding)

            If Not Directory.Exists(strDirName) Then _
                   Directory.CreateDirectory(strDirName)
            Directory.SetCurrentDirectory(strDirName)
            If Not File.Exists(strFileName) Then _
                              File.Create(strFileName).Close()

            Dim bwrtFile As New BinaryWriter _
               ( _
                  New FileStream(strFileName, _
                                 FileMode.OpenOrCreate, _
                                 FileAccess.Write, _
                                 FileShare.None), _
                  encodeFile _
               )
            With bwrtFile
               .Write(Me.strName)
               .Write(Me.sglSize)
               .Write(Me.intStyle)
               .Close()
            End With
         End Sub

         Public Sub ReadFromFile(ByVal strDirName As String, _
                                 ByVal strFileName As String, _
                                 ByVal encodeFile As Encoding)

            Directory.SetCurrentDirectory(strDirName)

            Dim brdrFile As New BinaryReader _
               ( _
                  New FileStream(strFileName, _
                                 FileMode.OpenOrCreate, _
                                 FileAccess.Read, _
                                 FileShare.None), _
                  encodeFile _
               )
            With brdrFile
               Me.strName = .ReadString()
               Me.sglSize = .ReadSingle()
               Me.intStyle = .ReadInt32()
               .Close()
            End With
         End Sub

      End Structure

      Private Sub SaveSettingsToFile()

         '  Create the directory and the file, if necessary.
         If Not Directory.Exists(strDirName) Then _
                           Directory.CreateDirectory(strDirName)
         Directory.SetCurrentDirectory(strDirName)
         If Not File.Exists(strFileName) Then _
                           File.Create(strFileName).Close()

         '  Open a writer for the file
         Dim bwrtFile As New BinaryWriter _
            ( _
               New FileStream(strFileName, _
                              FileMode.OpenOrCreate, _
                              FileAccess.Write, _
                              FileShare.None), _
               Me.encodeFile _
            )

         '  Write the data to the file.
         With bwrtFile
            .Write(tboxInput.Font.Name)      '  String.
            .Write(tboxInput.Font.Size)      '  Single.
            .Write(tboxInput.Font.Style)     '  Integer.
            .Close()
         End With

         '  Create an ourFontInfo structure, load it from
         '     tboxInput's font, have the structure save
         '     its contents to the file.
         'Dim fiFont As ourFontInfo
         'With tboxInput.Font
         '   fiFont.strName = .Name
         '   fiFont.sglSize = .Size
         '   fiFont.intStyle = .Style
         'End With
         'fiFont.WriteToFile(strDirName, _
         '                   strFileName, _
         '                   Encoding.Default)
      End Sub

      Private Sub ReadSettingsFromFile()

         '  Make the directory the current directory.
         Directory.SetCurrentDirectory(strDirName)

         '  Open a reader for the file.
         Dim brdrFile As New BinaryReader _
            ( _
               New FileStream(strFileName, _
                              FileMode.OpenOrCreate, _
                              FileAccess.Read, _
                              FileShare.None), _
               Me.encodeFile _
            )

         '  Read each field from the file, then 
         '     close the file.
         With brdrFile
            Dim strName As String = .ReadString()
            Dim sglSize As Single = .ReadSingle()
            Dim intStyle As Integer = .ReadInt32()
            tboxInput.Font = _
               New Font(strName, sglSize, intStyle)
            .Close()
         End With

      End Sub

#End Region

#Region "Save/Restore to Registry"

      '  Utility object for registry access.
      Dim urNotepad As New UtilRegistry

      '  Field names for the settings in the registry.
      Dim strNotepadCE As String = "NotepadCe", _
          strFont As String = "Font", _
          strName As String = "Name", _
          strSize As String = "Size", _
          strStyle As String = "Style", _
          strBold As String = "Bold", _
          strItalic As String = "Italic", _
          strUnderline As String = "Underline", _
          strOptions As String = "Options", _
          strMenu As String = "Menu", _
          strToolBar As String = "ToolBar", _
          strScrollBars As String = "ScrollBars", _
          strTextAlign As String = "TextAlign", _
          strWordWrap As String = "WordWrap"

      Private Sub mitemSettingsSave_Click( _
                           ByVal sender As System.Object, _
                           ByVal e As System.EventArgs _
                           ) _
                           Handles mitemSettingsSave.Click

         With tboxInput.Font
            urNotepad.SetValue(strNotepadCE + "\" + strFont, _
                               strName, _
                               .Name)
            urNotepad.SetValue(strNotepadCE + "\" + strFont, _
                               strSize, _
                               Convert.ToInt16(.Size))
            urNotepad.SetValue(strNotepadCE + "\" + strFont, _
                               strStyle, _
                               Convert.ToInt16(.Style))

            urNotepad.SetValue(strNotepadCE + "\" + strOptions, _
                               strMenu, _
                               Me.Menu Is Me.menuMain)
            urNotepad.SetValue(strNotepadCE + "\" + strOptions, _
                               strToolBar, _
                               Me.Controls.Contains(tbarCommands))
            urNotepad.SetValue(strNotepadCE + "\" + strOptions, _
                               strScrollBars, _
                               tboxInput.ScrollBars)
            urNotepad.SetValue(strNotepadCE + "\" + strOptions, _
                               strTextAlign, _
                               tboxInput.TextAlign)
            urNotepad.SetValue(strNotepadCE + "\" + strOptions, _
                               strWordWrap, _
                               tboxInput.WordWrap)
         End With
      End Sub

      Private Sub mitemSettingsRestore_Click( _
                           ByVal sender As System.Object, _
                           ByVal e As System.EventArgs _
                           ) _
                           Handles mitemSettingsRestore.Click

         '  Read Font info, if any, from the registry, 
         '  Create a font from that info, or use default
         '     values if no info is in the registry
         '  Set tboxInput.Font = that font
         With urNotepad
            Dim strFontName As String
            Dim intFontSize As Integer
            Dim intFontStyle As Integer

            strFontName = "Tahoma"
            .GetValue(strNotepadCE + "\" + strFont, _
                      strName, _
                      strFontName)

            intFontSize = 9
            .GetValue(strNotepadCE + "\" + strFont, _
                      strSize, _
                      intFontSize)

            intFontStyle = FontStyle.Regular
            .GetValue(strNotepadCE + "\" + strFont, _
                      strStyle, _
                      intFontStyle)

            tboxInput.Font = _
               New Font(strFontName, intFontSize, intFontStyle)
         End With

         '  Read Option info, if any, from the registry
         '  Set the properties from that info, or use default
         '     values if no info is in the registry
         Dim boolTemp As Boolean
         Dim intTemp As Integer
         With urNotepad

            '  .Menu is either menuMain or Nothing
            boolTemp = True
            .GetValue(strNotepadCE + "\" + strOptions, _
                      strMenu, _
                      boolTemp)
            Me.Menu = IIf(boolTemp, Me.menuMain, Nothing)

            '  .Controls either contains 
            '     tbarCommands or it doesn't
            boolTemp = True
            .GetValue(strNotepadCE + "\" + strOptions, _
                      strToolBar, _
                      boolTemp)
            If boolTemp Then
               If Not Me.Controls.Contains(Me.tbarCommands) Then
                  Me.Controls.Add(Me.tbarCommands)
               End If
            Else
               If Me.Controls.Contains(Me.tbarCommands) Then
                  Me.Controls.Remove(Me.tbarCommands)
               End If
            End If

            '  .ScrollBars
            intTemp = ScrollBars.Both
            .GetValue(strNotepadCE + "\" + strOptions, _
                      strScrollBars, _
                      intTemp)
            tboxInput.ScrollBars = intTemp

            '  .TextAlign
            intTemp = HorizontalAlignment.Left
            .GetValue(strNotepadCE + "\" + strOptions, _
                      strTextAlign, _
                      intTemp)
            tboxInput.TextAlign = intTemp

            '  .WordWrap
            boolTemp = True
            .GetValue(strNotepadCE + "\" + strOptions, _
                      strWordWrap, _
                      boolTemp)
            tboxInput.WordWrap = boolTemp
         End With
      End Sub

      Private Sub mitemSettingsInit_Click( _
                           ByVal sender As System.Object, _
                           ByVal e As System.EventArgs _
                           ) _
                           Handles mitemSettingsInit.Click

         urNotepad.DeleteKey(strNotepadCE)
         mitemSettingsRestore_Click(Me, EventArgs.Empty)
      End Sub

#End Region

#Region "Clipboard Support"
      ' Clipboard messages
      Public Const WM_CUT = &H300
      Public Const WM_COPY = &H301
      Public Const WM_PASTE = &H302
      Public Const WM_CLEAR = &H303
      Public Const WM_UNDO = &H304

      ' Supports clipboard messages to text box.
      Private m_msg As Microsoft.WindowsCE.Forms.Message

      Private Sub mitemClipboard_Click( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) _
         Handles mitemCut.Click, mitemCopy.Click, _
         mitemPaste.Click, mitemUndo.Click, mitemClear.Click

         If sender.Equals(mitemCut) Then
            m_msg.Msg = WM_CUT
            ' Cut does not work, so do equivalent...
            m_msg.Msg = WM_COPY
            MessageWindow.SendMessage(m_msg)
            m_msg.Msg = WM_CLEAR
         ElseIf sender.Equals(mitemCopy) Then
            m_msg.Msg = WM_COPY
         ElseIf sender.Equals(mitemPaste) Then
            m_msg.Msg = WM_PASTE
         ElseIf sender.Equals(mitemClear) Then
            m_msg.Msg = WM_CLEAR
         ElseIf sender.Equals(mitemUndo) Then
            m_msg.Msg = WM_UNDO
         End If

         MessageWindow.SendMessage(m_msg)
      End Sub

#End Region

#Region "Printing"

      Dim hwndForm As IntPtr

      Private Sub mitemFilePrint_Click( _
      ByVal sender As System.Object, _
      ByVal e As System.EventArgs) Handles mitemFilePrint.Click
         ' Init print setup dialog data.
         Dim psd As PAGESETUPDLGSTRUCT
         psd = New PAGESETUPDLGSTRUCT
         PrintSetupDlg.InitDlgStruct(psd, hwndForm)

         Try
            ' Display print setup dialog box 
            Dim iErr As Integer = PrintSetupDlg.ShowDialog(psd)
            If iErr <> 0 Then
               ' Fetch port name from print setup data.
               Dim strPort As String
               strPort = PrintSetupDlg.QueryOutputPort(psd)

               ' Check whether port is an IP address.
               If PrintJob_Socket.IsIPAddress(strPort) Then
                  PrintJob_Socket.PrintText(tboxInput, strPort)
               Else
                  ' Send text to selected port.
                  PrintJob_Direct.PrintText(tboxInput, strPort)
               End If
            Else
               Dim strErr As String = PrintSetupDlg.GetErrorString()
               If strErr <> "Ok" Then
                  MessageBox.Show(strErr, "PrintDirect")
               End If
            End If
         Catch
            MessageBox.Show("Error printing.", "PrintDirect")
         Finally
            ' Clean up resources associated with print dialog.
            PrintSetupDlg.Close(psd)
         End Try

      End Sub

      Private Sub FormMain_GotFocus( _
      ByVal sender As Object, _
      ByVal e As System.EventArgs) Handles MyBase.GotFocus
         hwndForm = WinFocus.GetFocus()
      End Sub
#End Region

   End Class
End Namespace
