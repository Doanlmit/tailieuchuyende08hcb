' PrintJob_Direct.vb - Creates a print job by opening a port
' and sending output as a byte stream.
'
' Code from _Programming the .NET Compact Framework with C#_
' and _Programming the .NET Compact Framework with VB_
' (c) Copyright 2002-2003 Paul Yao and David Durant. 
' All rights reserved.

Imports System
Imports System.IO
Imports System.Windows.Forms
Imports YaoDurant.Win32

Namespace PrintDirect
   Public Class PrintJob_Direct
      '--------------------------------------------------------
      '--------------------------------------------------------
      Public Shared Sub PrintText( _
      ByVal textIn As TextBox, _
      ByVal strPort As String)
         ' Strip baud rate from port name.
         If strPort.StartsWith("COM1:") Then
             strPort = "COM1:"
         End If

         ' Open printer port.
         Dim fs As System.IO.FileStream
         fs = New System.IO.FileStream(strPort, FileMode.Create)
         If fs Is Nothing Then
            Throw (New ApplicationException("Cannot open port."))
         End If

         Try
            ' Split input data into separate lines of text.
            Dim achNewLine() As Char = New Char() {vbCr}

            Dim astrSplit() As String
            astrSplit = textIn.Text.Split(achNewLine)

            ' Calculate longest string in the document.
            Dim cchMax As Integer = 0
            Dim [cstr] As Integer = astrSplit.Length
            Dim i As Integer
            For i = 0 To [cstr] - 1
               If astrSplit(i).Length > cchMax Then
                  cchMax = astrSplit(i).Length
               End If
            Next

            ' Allocate conversion buffer.
            Dim byteData() As Byte = New Byte(cchMax) {}
            Dim chData() As Char = New Char(cchMax) {}
            Dim d As System.Text.Encoder
            d = System.Text.Encoding.UTF8.GetEncoder()

            ' Put form-feed into a byte array
            Dim achFF() As Char = vbFormFeed.ToCharArray()
            Dim abyteFF() As Byte = New Byte(2) {}
            d.GetBytes(achFF, 0, 1, abyteFF, 0, True)

            ' Put Carriage-return into a byte array
            Dim achCR() As Char = vbCr.ToCharArray()
            Dim abyteCrLf() As Byte = New Byte(2) {}
            d.GetBytes(achCR, 0, 1, abyteCrLf, 0, True)

            ' Loop through list of strings.
            For i = 0 To [cstr] - 1
               Dim cch As Integer = astrSplit(i).Length
               If cch > 0 Then
                  chData = astrSplit(i).ToCharArray()

                  ' Convert Unicode string to UTF-8 encoding.
                  d.GetBytes(chData, 0, cch, byteData, 0, True)

                  ' Output bytes to printer.
                  fs.Write(byteData, 0, cch)
               End If

               ' Put a <CR> at line end.
               fs.Write(abyteCrLf, 0, 1)
            Next

            ' Put a <FF> at the end of the document.
            fs.Write(abyteFF, 0, 1)
         Finally
            ' Close file stream.
            fs.Close()
         End Try
      End Sub

#Region " An alternative using native Win32 functions"
#If False Then
      '--------------------------------------------------------
      '--------------------------------------------------------
      Public Shared Sub PrintTextWin32(ByVal textIn As TextBox)
         Dim hPort As IntPtr

         Dim strPort As String
         ' strPort = "\\Server\HP5si_PCL";
         ' strPort = "COM1:";
         strPort = "\My Documents\TextPrint.dat"

         hPort = WinIO.CreateFile(strPort, _
            WinIO.ACCESS.WRITE, WinIO.FILE_SHARE.WRITE, 0, _
            WinIO.FILE_ACTION.OPEN_ALWAYS, WinIO.FILE_ATTRIBUTE.NORMAL, 0)

         ' ?? Need to call SetCommState to set baud rate, etc. ??
         If hPort.Equals(WinIO.INVALID_FILE_HANDLE) Then
            MessageBox.Show("Error opening port", "PrintDirect")
         Else
         ' Split input data into separate lines of text.
         Dim achNewLine() As Char = New Char() {vbCr}

         Dim astrSplit() As String
         astrSplit = textIn.Text.Split(achNewLine)

         Dim i As Integer
         Dim [cstr] As Integer = astrSplit.Length

         ' Check for largest string in document.
         Dim cchMax As Integer = 0
         For i = 0 To [cstr] - 1 Step i + 1
            If astrSplit(i).Length > cchMax Then
               cchMax = astrSplit(i).Length
            End If
         Next
         cchMax = cchMax + 5  ' Add some padding.

         ' Allocate conversion buffers.
         Dim byteData() As Byte = New Byte(cchMax) {}
         Dim chData() As Char = New Char(cchMax) {}
         Dim cbWritten As Integer = 0
         Dim d As System.Text.Encoder = System.Text.Encoding.UTF8.GetEncoder()

         For i = 0 To [cstr] - 1 Step i + 1
            Dim cch As Integer = astrSplit(i).Length
            If cch > 0 Then
               'MessageBox.Show(i.ToString() + " " + astrSplit[i]);
               chData = astrSplit(i).ToCharArray()
               Dim charLen As Integer = d.GetBytes(chData, 0, cch, byteData, 0, True)
               WinIO.WriteFile(hPort, byteData, charLen, cbWritten, IntPtr.Zero)
            End If

            ' Put a <CR><LF> at the end of the line.
            Dim byteCrLf() As Byte = New Byte() {vbLf}

            WinIO.WriteFile(hPort, byteCrLf, 2, cbWritten, IntPtr.Zero)
         Next
         ' Put a <FF> at the end of the document.
         Dim byteFF() As Byte = New Byte() {vbFormFeed}

         WinIO.WriteFile(hPort, byteFF, 1, cbWritten, IntPtr.Zero)
         WinIO.CloseHandle(hPort)
         End If

      End Sub
#End If
#End Region

   End Class
End Namespace
