' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.ComponentModel
Imports System.Windows.Forms

Public Class FormUpdate
   Inherits System.Windows.Forms.Form
   Friend WithEvents panelCategory As System.Windows.Forms.Panel
   Friend WithEvents comboCategoryIDs As System.Windows.Forms.ComboBox
   Friend WithEvents textCategoryName As System.Windows.Forms.TextBox
   Friend WithEvents lblCategoryName As System.Windows.Forms.Label
   Friend WithEvents textCategoryID As System.Windows.Forms.TextBox
   Friend WithEvents lblCategoryID As System.Windows.Forms.Label

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.panelCategory = New System.Windows.Forms.Panel
      Me.comboCategoryIDs = New System.Windows.Forms.ComboBox
      Me.textCategoryName = New System.Windows.Forms.TextBox
      Me.lblCategoryName = New System.Windows.Forms.Label
      Me.textCategoryID = New System.Windows.Forms.TextBox
      Me.lblCategoryID = New System.Windows.Forms.Label
      '
      'panelCategory
      '
      Me.panelCategory.Controls.Add(Me.comboCategoryIDs)
      Me.panelCategory.Controls.Add(Me.textCategoryName)
      Me.panelCategory.Controls.Add(Me.lblCategoryName)
      Me.panelCategory.Controls.Add(Me.textCategoryID)
      Me.panelCategory.Controls.Add(Me.lblCategoryID)
      Me.panelCategory.Location = New System.Drawing.Point(0, 11)
      Me.panelCategory.Size = New System.Drawing.Size(240, 248)
      '
      'comboCategoryIDs
      '
      Me.comboCategoryIDs.Size = New System.Drawing.Size(136, 22)
      '
      'textCategoryName
      '
      Me.textCategoryName.Location = New System.Drawing.Point(120, 144)
      Me.textCategoryName.Size = New System.Drawing.Size(120, 22)
      Me.textCategoryName.Text = ""
      '
      'lblCategoryName
      '
      Me.lblCategoryName.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblCategoryName.Location = New System.Drawing.Point(120, 120)
      Me.lblCategoryName.Size = New System.Drawing.Size(120, 20)
      '
      'textCategoryID
      '
      Me.textCategoryID.Location = New System.Drawing.Point(120, 80)
      Me.textCategoryID.Size = New System.Drawing.Size(120, 22)
      Me.textCategoryID.Text = ""
      '
      'lblCategoryID
      '
      Me.lblCategoryID.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblCategoryID.Location = New System.Drawing.Point(120, 56)
      Me.lblCategoryID.Size = New System.Drawing.Size(120, 20)
      '
      'FormUpdate
      '
      Me.Controls.Add(Me.panelCategory)
      Me.MinimizeBox = False
      Me.Text = "FormUpdate"

   End Sub

#End Region

   '  Connection string.
   Private strConn As String = _
         "data source=207.202.168.30;" & _
         "initial catalog=Northwind;" & _
         "user id=DeliveryDriver;" & _
         "pwd=DD;" & _
         "workstation id=SNOWDEN;" & _
         "packet size=4096;" & _
         "persist security info=False;"

   '  The dataset, adapter, table. 
   Private dsetDB As DataSet
   Private daptCategories As sqlDataAdapter
   Private dtabCategories As DataTable


   Private Sub FormUpdate_Load(ByVal sender As Object, _
                               ByVal e As System.EventArgs _
                               ) _
                               Handles MyBase.Load
      '  Present a Close box
      Me.MinimizeBox = False

      '  Create the data set.
      dsetDB = New DataSet("Produce")

      '  Create the data adapter.
      daptCategories = New _
         SqlDataAdapter("SELECT CategoryID, CategoryName " & _
                          "  FROM Categories", _
                          strConn)

      '  Create and fill the data table, save a reference to it.
      daptCategories.Fill(dsetDB, "Categories")
      dtabCategories = dsetDB.Tables("Categories")

      '  Initialize the command (including 
      '    creating the parameters).
      Dim cmndDB As SqlCommand = New SqlCommand
      cmndDB.CommandText = "procModifyCategoryInfo"
      cmndDB.CommandType = CommandType.StoredProcedure
      cmndDB.Connection = _
         daptCategories.SelectCommand.Connection
      cmndDB.Parameters.Add( _
         New SqlParameter( _
            "@RETURN_VALUE", SqlDbType.Int, 4, _
            ParameterDirection.ReturnValue, False, _
            0, 0, "", DataRowVersion.Current, Nothing))
      cmndDB.Parameters.Add( _
         New SqlParameter( _
            "@CategoryID", SqlDbType.Int, 4, "CategoryID"))
      cmndDB.Parameters.Add( _
         New SqlParameter( _
            "@CategoryName", SqlDbType.NVarChar, _
            40, "CategoryName"))

      cmndDB.Parameters("@CategoryID").SourceVersion = _
         DataRowVersion.Original

      daptCategories.UpdateCommand = cmndDB

      '  Bind the ComboBox with the Category names.
      With comboCategoryIDs
         .DataSource = dtabCategories
         .DisplayMember = "CategoryName"
         .ValueMember = "CategoryID"
         .SelectedIndex = 0
      End With

      '  Load lables with DataTable column names.
      lblCategoryID.Text = "CategoryID"
      lblCategoryName.Text = "CategoryName"

      '  Bind the DataTable's columns to the textboxes.
      textCategoryID.DataBindings.Add _
                  ("Text", dtabCategories, "CategoryID")
      textCategoryName.DataBindings.Add _
                  ("Text", dtabCategories, "CategoryName")

      '  Give the panel some tone.
      panelCategory.BackColor = Color.Beige

      '  Loading is finished.
      comboCategoryIDs.SelectedIndex = 0

   End Sub

   Private Sub textCategoryName_Validated( _
                           ByVal sender As Object, _
                           ByVal e As EventArgs _
                           ) _
                           Handles textCategoryName.Validated

      '  Force the current modification to complete.
      Me.BindingContext(dtabCategories).EndCurrentEdit()
   End Sub

   Private Sub FormUpdate_Closed(ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles MyBase.Closed

      '  Force the current modification to complete.
      Me.BindingContext(dtabCategories).EndCurrentEdit()

      '  Push dataset changes back to database.
      With daptCategories
         .Update(dsetDB, "Categories")
      End With
      '  Set table status to clean.
      With dsetDB.Tables("Categories")
         .AcceptChanges()
      End With
   End Sub

   Private connNorthwind As New SqlConnection
   Private cmndDB As New SqlCommand

   Private Sub UpdateSelectedRow(ByVal intProductID As Integer, _
                                 ByVal strProductName As String)

      '  A connection and a command.
      Dim connDB As New SqlConnection(strConn)
      Dim cmndDB As New SqlCommand

      Try
         '  Open the connection.
         connDB.Open()

      Catch ex As Exception
      Finally
      End Try
   End Sub

   Private Sub Dummmy()
      ' 
      ' cmndModifyProductInfo
      ' 
      Me.cmndDB.CommandText = "ModifyProductInfo"
      Me.cmndDB.CommandType = CommandType.StoredProcedure
      Me.cmndDB.Connection = Me.connNorthwind
      Me.cmndDB.Parameters.Add( _
         New SqlClient.SqlParameter( _
            "@RETURN_VALUE", SqlDbType.Int, 4, _
            ParameterDirection.ReturnValue, False, _
            0, 0, _
            "", DataRowVersion.Current, Nothing))
      Me.cmndDB.Parameters.Add( _
         New SqlClient.SqlParameter( _
            "@ProductID", SqlDbType.Int, 4))
      Me.cmndDB.Parameters.Add( _
         New SqlClient.SqlParameter( _
            "@ProductName", SqlDbType.NVarChar, 40))
      Me.cmndDB.Parameters.Add( _
         New SqlClient.SqlParameter( _
            "@UnitPrice", SqlDbType.Money, 4))

   End Sub
End Class
