Public Class FormPrimes
   Inherits System.Windows.Forms.Form
   Friend WithEvents cmdGet As System.Windows.Forms.Button
   Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblFloorPrime As System.Windows.Forms.Label
   Friend WithEvents txtTarget As System.Windows.Forms.TextBox
   Private Sub InitializeComponent()
      Me.MainMenu1 = New System.Windows.Forms.MainMenu
      Me.lblFloorPrime = New System.Windows.Forms.Label
      Me.txtTarget = New System.Windows.Forms.TextBox
      Me.cmdGet = New System.Windows.Forms.Button
      '
      'lblFloorPrime
      '
      Me.lblFloorPrime.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Regular)
      Me.lblFloorPrime.Location = New System.Drawing.Point(48, 96)
      '
      'txtTarget
      '
      Me.txtTarget.Font = New System.Drawing.Font("Tahoma", 13.0!, System.Drawing.FontStyle.Regular)
      Me.txtTarget.Location = New System.Drawing.Point(48, 48)
      Me.txtTarget.Text = ""
      '
      'cmdGet
      '
      Me.cmdGet.Location = New System.Drawing.Point(72, 144)
      Me.cmdGet.Text = "Get"
      '
      'FormPrimes
      '
      Me.Controls.Add(Me.cmdGet)
      Me.Controls.Add(Me.txtTarget)
      Me.Controls.Add(Me.lblFloorPrime)
      Me.Menu = Me.MainMenu1
      Me.Text = "Floor Prime"

   End Sub

#End Region

   Private Sub FormMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Me.MinimizeBox = False
   End Sub

   Private Sub cmdGet_Click(ByVal sender As System.Object, _
                            ByVal e As EventArgs _
                            ) _
                            Handles cmdGet.Click
      Dim refPrimes As New Primes.Primes

      lblFloorPrime.Text = _
         refPrimes.GetFloorPrime(txtTarget.Text)
   End Sub
End Class
