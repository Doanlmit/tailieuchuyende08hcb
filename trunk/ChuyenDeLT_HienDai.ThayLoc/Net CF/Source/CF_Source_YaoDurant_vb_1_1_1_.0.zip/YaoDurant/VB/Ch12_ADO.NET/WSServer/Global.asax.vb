Imports System.Web
Imports System.Web.SessionState
Imports System.Data

Public Class Global
    Inherits System.Web.HttpApplication

#Region " Component Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
   Friend WithEvents connNorthwind As System.Data.SqlClient.SqlConnection
   Friend WithEvents daptCategories As System.Data.SqlClient.SqlDataAdapter
   Friend WithEvents daptProducts As System.Data.SqlClient.SqlDataAdapter
   Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
   Friend WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.connNorthwind = New System.Data.SqlClient.SqlConnection
      Me.daptCategories = New System.Data.SqlClient.SqlDataAdapter
      Me.daptProducts = New System.Data.SqlClient.SqlDataAdapter
      Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
      Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand
      '
      'connNorthwind
      '
      Me.connNorthwind.ConnectionString = "workstation id=SNOWDEN;packet size=4096;integrated security=SSPI;data source=SNOW" & _
      "DEN;persist security info=False;initial catalog=Northwind"
      '
      'daptCategories
      '
      Me.daptCategories.SelectCommand = Me.SqlSelectCommand1
      Me.daptCategories.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Categories", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CategoryID", "CategoryID"), New System.Data.Common.DataColumnMapping("CategoryName", "CategoryName"), New System.Data.Common.DataColumnMapping("Description", "Description"), New System.Data.Common.DataColumnMapping("Picture", "Picture"), New System.Data.Common.DataColumnMapping("rowguid", "rowguid")})})
      '
      'daptProducts
      '
      Me.daptProducts.SelectCommand = Me.SqlSelectCommand2
      Me.daptProducts.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Products", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ProductID", "ProductID"), New System.Data.Common.DataColumnMapping("ProductName", "ProductName"), New System.Data.Common.DataColumnMapping("SupplierID", "SupplierID"), New System.Data.Common.DataColumnMapping("CategoryID", "CategoryID"), New System.Data.Common.DataColumnMapping("QuantityPerUnit", "QuantityPerUnit"), New System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice"), New System.Data.Common.DataColumnMapping("UnitsInStock", "UnitsInStock"), New System.Data.Common.DataColumnMapping("UnitsOnOrder", "UnitsOnOrder"), New System.Data.Common.DataColumnMapping("ReorderLevel", "ReorderLevel"), New System.Data.Common.DataColumnMapping("Discontinued", "Discontinued"), New System.Data.Common.DataColumnMapping("rowguid", "rowguid")})})
      '
      'SqlSelectCommand1
      '
      Me.SqlSelectCommand1.CommandText = "SELECT CategoryID, CategoryName, Description, Picture, rowguid FROM Categories"
      Me.SqlSelectCommand1.Connection = Me.connNorthwind
      '
      'SqlSelectCommand2
      '
      Me.SqlSelectCommand2.CommandText = "SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice" & _
      ", UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued, rowguid FROM Products"
      Me.SqlSelectCommand2.Connection = Me.connNorthwind

   End Sub

#End Region

   Public Shared dsetDB As DataSet


   Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
      dsetDB = New DataSet
      LoadDataSet(dsetDB)
   End Sub

   Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
      ' Fires when the session is started
   End Sub

   Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
      ' Fires at the beginning of each request
   End Sub

   Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
      ' Fires upon attempting to authenticate the use
   End Sub

   Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
      ' Fires when an error occurs
   End Sub

   Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
      ' Fires when the session ends
   End Sub

   Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
      ' Fires when the application ends
   End Sub

   Private Sub LoadDataSet(ByVal dsetDB As DataSet)
      daptCategories.Fill(dsetDB, "Categories")
      daptProducts.Fill(dsetDB, "Products")
      dsetDB.Relations.Add( _
         "FKProdCAt", _
         dsetDB.Tables("Categories").Columns("CategoryID"), _
         dsetDB.Tables("Products").Columns("CategoryID"), _
         True)
   End Sub

End Class
