Imports System.Web.Services

<System.Web.Services.WebService(Namespace:="http://tempuri.org/Primes/Primes")> _
Public Class Primes
   Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Web Services Designer.
      InitializeComponent()

      'Add your own initialization code after the InitializeComponent() call

   End Sub

   'Required by the Web Services Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Web Services Designer
   'It can be modified using the Web Services Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      components = New System.ComponentModel.Container
   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      'CODEGEN: This procedure is required by the Web Services Designer
      'Do not modify it using the code editor.
      If disposing Then
         If Not (components Is Nothing) Then
            components.Dispose()
         End If
      End If
      MyBase.Dispose(disposing)
   End Sub

#End Region

   <WebMethod()> _
   Public Function GetFloorPrime(ByVal Target As Integer _
                                ) _
                                As Integer
      If Target <= 1 Then
         Return 1
      End If
      If Target = 2 Then
         Return 2
      End If
      Dim j As Integer = Target - IIf(Target Mod 2 = 0, 1, 0)
      For j = j To 1 Step -2
         If IsPrime(j) Then
            Return j
         End If
      Next
      Dim FloorPrime As Integer = 1

   End Function

   Private Function IsPrime(ByVal Candidate As Integer) As Boolean
      Dim j As Integer
      For j = 3 To Candidate - 1 Step 2
         If Candidate Mod j = 0 Then
            Return False
         End If
         If j * j >= Candidate Then
            Exit For
         End If
      Next
      Return True
   End Function

End Class
