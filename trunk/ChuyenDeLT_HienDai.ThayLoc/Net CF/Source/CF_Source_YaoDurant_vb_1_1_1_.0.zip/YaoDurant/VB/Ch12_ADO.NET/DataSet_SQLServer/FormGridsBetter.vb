' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class FormGridsBetter
   Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents MenuMain As MainMenu
   Friend WithEvents mitemFile As MenuItem
   Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
   Friend WithEvents mitemBuildDS As System.Windows.Forms.MenuItem
   Friend WithEvents mitemExit As System.Windows.Forms.MenuItem
   Friend WithEvents dgridParent As System.Windows.Forms.DataGrid
   Friend WithEvents dgridChild As System.Windows.Forms.DataGrid
   Friend WithEvents mitemDisplayDS As System.Windows.Forms.MenuItem
   Friend WithEvents mitemDisplayProducts As System.Windows.Forms.MenuItem
   Friend WithEvents mitemDisplayUpdater As System.Windows.Forms.MenuItem
   Private Sub InitializeComponent()
      Me.MenuMain = New System.Windows.Forms.MainMenu
      Me.mitemFile = New System.Windows.Forms.MenuItem
      Me.mitemExit = New System.Windows.Forms.MenuItem
      Me.MenuItem1 = New System.Windows.Forms.MenuItem
      Me.mitemBuildDS = New System.Windows.Forms.MenuItem
      Me.mitemDisplayDS = New System.Windows.Forms.MenuItem
      Me.mitemDisplayProducts = New System.Windows.Forms.MenuItem
      Me.dgridParent = New System.Windows.Forms.DataGrid
      Me.dgridChild = New System.Windows.Forms.DataGrid
      Me.mitemDisplayUpdater = New System.Windows.Forms.MenuItem
      '
      'MenuMain
      '
      Me.MenuMain.MenuItems.Add(Me.mitemFile)
      Me.MenuMain.MenuItems.Add(Me.MenuItem1)
      '
      'mitemFile
      '
      Me.mitemFile.MenuItems.Add(Me.mitemExit)
      Me.mitemFile.Text = "File"
      '
      'mitemExit
      '
      Me.mitemExit.Text = "Exit"
      '
      'MenuItem1
      '
      Me.MenuItem1.MenuItems.Add(Me.mitemBuildDS)
      Me.MenuItem1.MenuItems.Add(Me.mitemDisplayDS)
      Me.MenuItem1.MenuItems.Add(Me.mitemDisplayProducts)
      Me.MenuItem1.MenuItems.Add(Me.mitemDisplayUpdater)
      Me.MenuItem1.Text = "DataSet"
      '
      'mitemBuildDS
      '
      Me.mitemBuildDS.Text = "Build DS"
      '
      'mitemDisplayDS
      '
      Me.mitemDisplayDS.Text = "Display DS"
      '
      'mitemDisplayProducts
      '
      Me.mitemDisplayProducts.Text = "Display Products"
      '
      'dgridParent
      '
      Me.dgridParent.Size = New System.Drawing.Size(240, 104)
      Me.dgridParent.Text = "vc"
      '
      'dgridChild
      '
      Me.dgridChild.Location = New System.Drawing.Point(0, 160)
      Me.dgridChild.Size = New System.Drawing.Size(240, 104)
      Me.dgridChild.Text = "Child"
      '
      'mitemDisplayUpdater
      '
      Me.mitemDisplayUpdater.Text = "Display Updater"
      '
      'FormGrids
      '
      Me.Controls.Add(Me.dgridChild)
      Me.Controls.Add(Me.dgridParent)
      Me.Menu = Me.MenuMain
      Me.MinimizeBox = False
      Me.Text = "FormGrids"

   End Sub

#End Region

   '  Connection string.
   Private strConn As String = _
         "data source=207.202.168.30;" & _
         "initial catalog=Northwind;" & _
         "user id=DeliveryDriver;" & _
         "pwd=DD;" & _
         "workstation id=SNOWDEN;" & _
         "packet size=4096;" & _
         "persist security info=False;"

   '  The DataSet
   Private dsetDB As DataSet

   '  The DataAdapters
   Private daptCategories As sqlDataAdapter
   Private daptProducts As sqlDataAdapter


   Private Sub FormGrids_Load(ByVal sender As Object, _
                              ByVal e As EventArgs _
                              ) _
                              Handles MyBase.Load
      '  Display a Close box.
      Me.MinimizeBox = False

      '  Let the form present itself.
      Application.DoEvents()

      ' Make menu selections load and display data.
      mitemBuildDS_Click(mitemBuildDS, e.Empty)
      mitemDisplayDS_Click(mitemDisplayDS, e.Empty)
   End Sub


   Private Sub mitemBuildDS_Click(ByVal sender As Object, _
                                  ByVal e As EventArgs _
                                  ) _
                                  Handles mitemBuildDS.Click
      '  Create the dataset.
      dsetDB = New DataSet("Produce")

      '  Load the Categories and Products tables
      '     from the database into the dataset.

      '  Create an adapter to load Categories.  Pass it
      '     the SQL statement and the connection string.
      '     Use its Fill method to transfer the rows from
      '     the database to the dataset.
      daptCategories = New _
         sqlDataAdapter("SELECT CategoryID, CategoryName FROM Categories", strConn)
      daptCategories.Fill(dsetDB, "Categories")

      '  Now do the same for Products.
      daptProducts = New _
         sqlDataAdapter( _
            " SELECT P.ProductID, P.ProductName, " & _
            "        P.CategoryID, C.CategoryName " & _
            "   FROM Products P " & _
            "   JOIN Categories C on C.CategoryID = P.CategoryID", _
         strConn)
      Dim cbldProducts As New _
                           sqlCommandBuilder(daptProducts)
      daptProducts.Fill(dsetDB, "Products")

      '  Now define the relationship 
      '     between Products and Categories.
      With dsetDB
         .Relations.Add( _
                  "FKProdCat", _
                  .Tables("Categories").Columns("CategoryID"), _
                  .Tables("Products").Columns("CategoryID"), _
                  True)
      End With
   End Sub


   Private Sub mitemDisplayDS_Click(ByVal sender As Object, _
                                    ByVal e As EventArgs _
                                    ) _
                                    Handles mitemDisplayDS.Click
      '  Display the Categories and Products tables
      '     in the parent and child DataGrids.
      dgridParent.DataSource = dsetDB.Tables("Categories")
      dgridChild.DataSource = dsetDB.Tables("Products").DefaultView
   End Sub


   Private Sub dgridParent_Click(ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles dgridParent.Click
      '  Set the Product's row filter to view
      '     only Products for the selected Category.
      Dim dtabParent As DataTable = dgridParent.DataSource
      Dim dviewChild As DataView = dgridChild.DataSource
      dviewChild.RowFilter = _
         "CategoryID = " & _
         dtabParent.Rows(dgridParent.CurrentRowIndex) _
                        ("CategoryID")
   End Sub

   Private Sub mitemDisplayProducts_Click(ByVal sender As Object, _
                                          ByVal e As EventArgs _
                                          ) _
                                          Handles mitemDisplayProducts.Click
      ModData.dsetDB = Me.dsetDB
      ModData.daptProducts = Me.daptProducts
      ModData.daptCategories = Me.daptCategories
      Dim frmOneRow As New FormOneRow
      With frmOneRow
         .MinimizeBox = False
         .Show()
      End With
   End Sub

   Private Sub mitemExit_Click(ByVal sender As Object, _
                               ByVal e As EventArgs _
                               ) _
                               Handles mitemExit.Click
      Application.Exit()
   End Sub

   Private Sub mitemDisplayUpdater_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mitemDisplayUpdater.Click
      Dim frmUpdate As New FormUpdate
      frmUpdate.Show()
   End Sub
End Class
