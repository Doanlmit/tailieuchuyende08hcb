' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Windows.Forms

Public Class FormOneRow
   Inherits System.Windows.Forms.Form
   Friend WithEvents panelProduct As System.Windows.Forms.Panel
   Friend WithEvents hsbRows As System.Windows.Forms.HScrollBar
   Friend WithEvents textCategoryName As System.Windows.Forms.TextBox
   Friend WithEvents lblCategoryName As System.Windows.Forms.Label
   Friend WithEvents textProductName As System.Windows.Forms.TextBox
   Friend WithEvents lblProductName As System.Windows.Forms.Label
   Friend WithEvents textProductID As System.Windows.Forms.TextBox
   Friend WithEvents lblProductID As System.Windows.Forms.Label

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents comboProductIDs As System.Windows.Forms.ComboBox
   Friend WithEvents textGet As System.Windows.Forms.TextBox
   Friend WithEvents cmdGet As System.Windows.Forms.Button
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.panelProduct = New System.Windows.Forms.Panel
      Me.cmdGet = New System.Windows.Forms.Button
      Me.textGet = New System.Windows.Forms.TextBox
      Me.comboProductIDs = New System.Windows.Forms.ComboBox
      Me.hsbRows = New System.Windows.Forms.HScrollBar
      Me.textCategoryName = New System.Windows.Forms.TextBox
      Me.lblCategoryName = New System.Windows.Forms.Label
      Me.textProductName = New System.Windows.Forms.TextBox
      Me.lblProductName = New System.Windows.Forms.Label
      Me.textProductID = New System.Windows.Forms.TextBox
      Me.lblProductID = New System.Windows.Forms.Label
      '
      'panelProduct
      '
      Me.panelProduct.Controls.Add(Me.cmdGet)
      Me.panelProduct.Controls.Add(Me.textGet)
      Me.panelProduct.Controls.Add(Me.comboProductIDs)
      Me.panelProduct.Controls.Add(Me.hsbRows)
      Me.panelProduct.Controls.Add(Me.textCategoryName)
      Me.panelProduct.Controls.Add(Me.lblCategoryName)
      Me.panelProduct.Controls.Add(Me.textProductName)
      Me.panelProduct.Controls.Add(Me.lblProductName)
      Me.panelProduct.Controls.Add(Me.textProductID)
      Me.panelProduct.Controls.Add(Me.lblProductID)
      Me.panelProduct.Location = New System.Drawing.Point(0, 24)
      Me.panelProduct.Size = New System.Drawing.Size(240, 248)
      '
      'cmdGet
      '
      Me.cmdGet.Location = New System.Drawing.Point(200, 0)
      Me.cmdGet.Size = New System.Drawing.Size(40, 20)
      Me.cmdGet.Text = "Get"
      '
      'textGet
      '
      Me.textGet.Location = New System.Drawing.Point(160, 0)
      Me.textGet.Size = New System.Drawing.Size(40, 22)
      Me.textGet.Text = ""
      '
      'comboProductIDs
      '
      Me.comboProductIDs.Size = New System.Drawing.Size(136, 22)
      '
      'hsbRows
      '
      Me.hsbRows.Location = New System.Drawing.Point(0, 232)
      Me.hsbRows.Maximum = 91
      Me.hsbRows.Size = New System.Drawing.Size(240, 13)
      '
      'textCategoryName
      '
      Me.textCategoryName.Location = New System.Drawing.Point(120, 208)
      Me.textCategoryName.Size = New System.Drawing.Size(120, 22)
      Me.textCategoryName.Text = ""
      '
      'lblCategoryName
      '
      Me.lblCategoryName.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblCategoryName.Location = New System.Drawing.Point(120, 184)
      Me.lblCategoryName.Size = New System.Drawing.Size(120, 20)
      '
      'textProductName
      '
      Me.textProductName.Location = New System.Drawing.Point(120, 144)
      Me.textProductName.Size = New System.Drawing.Size(120, 22)
      Me.textProductName.Text = ""
      '
      'lblProductName
      '
      Me.lblProductName.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblProductName.Location = New System.Drawing.Point(120, 120)
      Me.lblProductName.Size = New System.Drawing.Size(120, 20)
      '
      'textProductID
      '
      Me.textProductID.Location = New System.Drawing.Point(120, 80)
      Me.textProductID.Size = New System.Drawing.Size(120, 22)
      Me.textProductID.Text = ""
      '
      'lblProductID
      '
      Me.lblProductID.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblProductID.Location = New System.Drawing.Point(120, 56)
      Me.lblProductID.Size = New System.Drawing.Size(120, 20)
      '
      'FormOneRow
      '
      Me.Controls.Add(Me.panelProduct)
      Me.Text = "FormOneRow"

   End Sub

#End Region

   Private dsetDB As DataSet
   Private daptProducts As sqlDataAdapter

   Private dtabProducts As DataTable
   Private drowProducts As DataRow

   '  The Products table contains four columns.  Since we often
   '     need to use the column name, and since that name might
   '     change in later versions of our app, we store the
   '     column names by their symbolic meaning.  
   '  Now, as long as we do NOT resequence the columns.....
   Private strPKName As String      '  "ProductID"
   Private strPKDesc As String      '  "ProductName"
   Private strFKName As String      '  "CategoryID"
   Private strFKDesc As String      '  "CategoryName"

   Private boolLoading As Boolean = True

   Private Sub FormOneRow_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load

      '  Present a Close box
      Me.MinimizeBox = False

      '  FormGrids stored a reference to the dataset
      '     in the code module.  Use it to get a 
      '     reference to the Products DataTable.
      Me.dsetDB = ModData.dsetDB
      Me.daptProducts = ModData.daptProducts
      dtabProducts = dsetDB.Tables("Products")
      With dtabProducts
         strPKName = .Columns(0).ColumnName
         strPKDesc = .Columns(1).ColumnName
         strFKName = .Columns(2).ColumnName
         strFKDesc = .Columns(3).ColumnName
      End With

      '  Initialize scroll bar properties.
      With hsbRows
         .Minimum = 0
         .Maximum = dtabProducts.Rows.Count
         .SmallChange = 1
         .LargeChange = ((.Maximum - .Minimum) / 10) + 1
      End With

      '  Bind the ComboBox with the Product names.
      With comboProductIDs
         .DataSource = dtabProducts
         .DisplayMember = strPKDesc
         .ValueMember = strPKName
         .SelectedIndex = 0
      End With
      'With comboProductIDs
      '   For Each drowProducts In dtabProducts.Rows
      '      .Items.Add(drowProducts(strPKDesc))
      '   Next
      'End With

      '  Load lables with DataTable column names.
      lblProductID.Text = strPKName
      lblProductName.Text = strPKDesc
      lblCategoryName.Text = strFKDesc


      '  Bind the DataTable's columns to the textboxes.
      textProductID.DataBindings.Add _
                  ("Text", dtabProducts, strPKName)
      textProductName.DataBindings.Add _
                  ("Text", dtabProducts, strPKDesc)
      textCategoryName.DataBindings.Add _
                  ("Text", dtabProducts, strFKDesc)

      '  Give the panel some tone.
      panelProduct.BackColor = Color.Beige

      '  Loading is finished.
      boolLoading = False
      comboProductIDs.SelectedIndex = 0
   End Sub

   Private Sub hsbRows_ValueChanged _
                              (ByVal sender As Object, _
                               ByVal e As EventArgs _
                               ) _
                               Handles hsbRows.ValueChanged

      '  Get the binding context for the data table.
      '     Set the "current" row to the one indicated
      '     by the position of the scroll bar thumb.
      Me.BindingContext(dtabProducts).Position = hsbRows.Value
   End Sub

   Private Sub comboProductIDs_SelectedIndexChanged( _
                     ByVal sender As Object, _
                     ByVal e As EventArgs _
                     ) _
                     Handles comboProductIDs.SelectedIndexChanged

      '  Synch the scroll bar with the ComboBox.
      If Not boolLoading Then
         hsbRows.Value = comboProductIDs.SelectedIndex
         textGet.Text = comboProductIDs.SelectedValue
      End If
   End Sub

   Private Sub cmdGet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGet.Click
      comboProductIDs.SelectedValue = textGet.Text
   End Sub
End Class
