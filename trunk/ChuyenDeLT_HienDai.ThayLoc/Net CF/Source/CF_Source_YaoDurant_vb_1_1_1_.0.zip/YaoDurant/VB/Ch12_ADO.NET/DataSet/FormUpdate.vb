' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data
Imports System.Data.SqlServerCe
Imports System.ComponentModel
Imports System.Windows.Forms
Imports UtilData

Public Class FormUpdate
   Inherits System.Windows.Forms.Form
   Friend WithEvents panelCategory As System.Windows.Forms.Panel
   Friend WithEvents comboCategoryIDs As System.Windows.Forms.ComboBox
   Friend WithEvents textCategoryName As System.Windows.Forms.TextBox
   Friend WithEvents lblCategoryName As System.Windows.Forms.Label
   Friend WithEvents textCategoryID As System.Windows.Forms.TextBox
   Friend WithEvents lblCategoryID As System.Windows.Forms.Label

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.panelCategory = New System.Windows.Forms.Panel
      Me.comboCategoryIDs = New System.Windows.Forms.ComboBox
      Me.textCategoryName = New System.Windows.Forms.TextBox
      Me.lblCategoryName = New System.Windows.Forms.Label
      Me.textCategoryID = New System.Windows.Forms.TextBox
      Me.lblCategoryID = New System.Windows.Forms.Label
      '
      'panelCategory
      '
      Me.panelCategory.Controls.Add(Me.comboCategoryIDs)
      Me.panelCategory.Controls.Add(Me.textCategoryName)
      Me.panelCategory.Controls.Add(Me.lblCategoryName)
      Me.panelCategory.Controls.Add(Me.textCategoryID)
      Me.panelCategory.Controls.Add(Me.lblCategoryID)
      Me.panelCategory.Location = New System.Drawing.Point(0, 11)
      Me.panelCategory.Size = New System.Drawing.Size(240, 248)
      '
      'comboCategoryIDs
      '
      Me.comboCategoryIDs.Size = New System.Drawing.Size(136, 22)
      '
      'textCategoryName
      '
      Me.textCategoryName.Location = New System.Drawing.Point(120, 144)
      Me.textCategoryName.Size = New System.Drawing.Size(120, 22)
      Me.textCategoryName.Text = ""
      '
      'lblCategoryName
      '
      Me.lblCategoryName.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblCategoryName.Location = New System.Drawing.Point(120, 120)
      Me.lblCategoryName.Size = New System.Drawing.Size(120, 20)
      '
      'textCategoryID
      '
      Me.textCategoryID.Location = New System.Drawing.Point(120, 80)
      Me.textCategoryID.Size = New System.Drawing.Size(120, 22)
      Me.textCategoryID.Text = ""
      '
      'lblCategoryID
      '
      Me.lblCategoryID.Font = New System.Drawing.Font("Tahoma", 11.0!, System.Drawing.FontStyle.Bold)
      Me.lblCategoryID.Location = New System.Drawing.Point(120, 56)
      Me.lblCategoryID.Size = New System.Drawing.Size(120, 20)
      '
      'FormUpdate
      '
      Me.Controls.Add(Me.panelCategory)
      Me.MinimizeBox = False
      Me.Text = "FormUpdate"

   End Sub

#End Region

   '  File path and name.
   Private strFile As String = _
      "My Documents\ourProduceCo.sdf"

   '  Connection string.
   Private strConn As String = _
      "Data Source=" & strFile

   '  The dataset, adapter, table. 
   Private dsetDB As DataSet
   Private daptCategories As SqlCeDataAdapter
   Private dtabCategories As DataTable

   Private boolLoading As Boolean = True

   Private Sub FormUpdate_Load(ByVal sender As Object, _
                               ByVal e As System.EventArgs _
                               ) _
                               Handles MyBase.Load
      '  Present a Close box
      Me.MinimizeBox = False

      '  Create the data set.
      dsetDB = New DataSet("Produce")

      '  Create the data adapter.
      daptCategories = New _
         SqlCeDataAdapter("SELECT CategoryID, CategoryName " & _
                          "  FROM Categories", _
                          strConn)

      '  Create the command builder for the adapter.
      Dim cbldCategories As New _
                           SqlCeCommandBuilder(daptCategories)

      '  Create and fill the data table, save a reference to it.
      daptCategories.Fill(dsetDB, "Categories")
      dtabCategories = dsetDB.Tables("Categories")

      '  Bind the ComboBox with the Category names.
      With comboCategoryIDs
         .DataSource = dtabCategories
         .DisplayMember = "CategoryName"
         .ValueMember = "CategoryID"
         .SelectedIndex = 0
      End With

      '  Load lables with DataTable column names.
      lblCategoryID.Text = "CategoryID"
      lblCategoryName.Text = "CategoryName"

      '  Bind the DataTable's columns to the textboxes.
      textCategoryID.DataBindings.Add _
                  ("Text", dtabCategories, "CategoryID")
      textCategoryName.DataBindings.Add _
                  ("Text", dtabCategories, "CategoryName")

      '  Give the panel some tone.
      panelCategory.BackColor = Color.Beige

      '  Loading is finished.
      boolLoading = False
      comboCategoryIDs.SelectedIndex = 0

   End Sub

   Private Sub textCategoryName_Validated( _
                           ByVal sender As Object, _
                           ByVal e As EventArgs _
                           ) _
                           Handles textCategoryName.Validated

      '  Force the current modification to complete.
      Me.BindingContext(dtabCategories).EndCurrentEdit()
   End Sub

   Private Sub FormUpdate_Closing(ByVal sender As Object, _
                                  ByVal e As CancelEventArgs _
                                  ) _
                                  Handles MyBase.Closing

      '  Force the current modification to complete.
      Me.BindingContext(dtabCategories).EndCurrentEdit()
   End Sub

   Private Sub FormUpdate_Closed(ByVal sender As Object, _
                                 ByVal e As EventArgs _
                                 ) _
                                 Handles MyBase.Closed

      '  Push dataset changes back to database.
      With daptCategories
         .Update(dsetDB, "Categories")
      End With
      '  Set table status to clean.
      With dsetDB.Tables("Categories")
         .AcceptChanges()
      End With
   End Sub

End Class
