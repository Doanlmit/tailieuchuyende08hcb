Public Class FormData
   Inherits System.Windows.Forms.Form
   Friend WithEvents dgridNorthwind As System.Windows.Forms.DataGrid

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.dgridNorthwind = New System.Windows.Forms.DataGrid
      '
      'dgridNorthwind
      '
      Me.dgridNorthwind.Size = New System.Drawing.Size(240, 200)
      '
      'FormData
      '
      Me.Controls.Add(Me.dgridNorthwind)
      Me.Text = "FormData"

   End Sub

#End Region

   Private Sub FormData_Load(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles MyBase.Load
      Dim refDataSupplier As New DataSupplier.DataSupplier

      dgridNorthwind.DataSource = _
         refDataSupplier.GetNorthwindData().Tables("Categories")
   End Sub
End Class
