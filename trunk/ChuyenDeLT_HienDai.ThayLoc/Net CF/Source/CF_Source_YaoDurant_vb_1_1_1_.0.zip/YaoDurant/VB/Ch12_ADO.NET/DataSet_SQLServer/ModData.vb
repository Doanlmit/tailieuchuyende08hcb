' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Data
Imports System.Data.SqlClient

Module ModData
   Friend dsetDB As DataSet
   Friend daptProducts As SqlDataAdapter
   Friend daptCategories As SqlDataAdapter
End Module
