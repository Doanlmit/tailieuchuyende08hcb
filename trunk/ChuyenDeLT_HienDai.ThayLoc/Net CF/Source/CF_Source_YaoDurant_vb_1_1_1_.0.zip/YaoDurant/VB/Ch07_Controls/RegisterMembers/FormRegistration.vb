' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Windows.Forms
Imports System.Drawing

Public Class FormRegistration
   Inherits System.Windows.Forms.Form

   '  Need this to write some sample code later
   Private genderMember As String

   Friend WithEvents optAdult As RadioButton
   Friend WithEvents optChild As RadioButton
   Friend WithEvents optAssociate As RadioButton

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents panelMemberType As System.Windows.Forms.Panel
   Friend WithEvents lblID As System.Windows.Forms.Label
   Friend WithEvents lblPC As System.Windows.Forms.Label
   Friend WithEvents lblGender As System.Windows.Forms.Label
   Friend WithEvents lblBorn As System.Windows.Forms.Label
   Friend WithEvents textID As System.Windows.Forms.TextBox
   Friend WithEvents textStreet As System.Windows.Forms.TextBox
   Friend WithEvents textCity As System.Windows.Forms.TextBox
   Friend WithEvents textSP As System.Windows.Forms.TextBox
   Friend WithEvents textPC As System.Windows.Forms.TextBox
   Friend WithEvents textBorn As System.Windows.Forms.TextBox
   Friend WithEvents optFemale As System.Windows.Forms.RadioButton
   Friend WithEvents optMale As System.Windows.Forms.RadioButton
   Friend WithEvents panelAddress As System.Windows.Forms.Panel
   Friend WithEvents bttnAdd As System.Windows.Forms.Button
   Friend WithEvents menuMain As System.Windows.Forms.MainMenu
   Friend WithEvents lblStreet As System.Windows.Forms.Label
   Friend WithEvents lblCity As System.Windows.Forms.Label
   Friend WithEvents lblSP As System.Windows.Forms.Label
   Friend WithEvents panelSponsor As System.Windows.Forms.Panel
   Friend WithEvents lblSponsID As System.Windows.Forms.Label
   Friend WithEvents textSponsID As System.Windows.Forms.TextBox
   Friend WithEvents panelWho As System.Windows.Forms.Panel
   Friend WithEvents lblName As System.Windows.Forms.Label
   Friend WithEvents textName As System.Windows.Forms.TextBox
   Friend WithEvents panelChild As System.Windows.Forms.Panel
   Friend WithEvents cboxCity As System.Windows.Forms.ComboBox
   Private Sub InitializeComponent()
      Me.menuMain = New System.Windows.Forms.MainMenu
      Me.optAdult = New System.Windows.Forms.RadioButton
      Me.optChild = New System.Windows.Forms.RadioButton
      Me.optAssociate = New System.Windows.Forms.RadioButton
      Me.panelMemberType = New System.Windows.Forms.Panel
      Me.lblID = New System.Windows.Forms.Label
      Me.lblPC = New System.Windows.Forms.Label
      Me.lblGender = New System.Windows.Forms.Label
      Me.lblBorn = New System.Windows.Forms.Label
      Me.textID = New System.Windows.Forms.TextBox
      Me.textStreet = New System.Windows.Forms.TextBox
      Me.textCity = New System.Windows.Forms.TextBox
      Me.textSP = New System.Windows.Forms.TextBox
      Me.textPC = New System.Windows.Forms.TextBox
      Me.textBorn = New System.Windows.Forms.TextBox
      Me.optMale = New System.Windows.Forms.RadioButton
      Me.optFemale = New System.Windows.Forms.RadioButton
      Me.panelAddress = New System.Windows.Forms.Panel
      Me.cboxCity = New System.Windows.Forms.ComboBox
      Me.lblSP = New System.Windows.Forms.Label
      Me.lblCity = New System.Windows.Forms.Label
      Me.lblStreet = New System.Windows.Forms.Label
      Me.bttnAdd = New System.Windows.Forms.Button
      Me.panelSponsor = New System.Windows.Forms.Panel
      Me.lblSponsID = New System.Windows.Forms.Label
      Me.textSponsID = New System.Windows.Forms.TextBox
      Me.panelWho = New System.Windows.Forms.Panel
      Me.textName = New System.Windows.Forms.TextBox
      Me.lblName = New System.Windows.Forms.Label
      Me.panelChild = New System.Windows.Forms.Panel
      '
      'optAdult
      '
      Me.optAdult.Location = New System.Drawing.Point(8, 8)
      Me.optAdult.Size = New System.Drawing.Size(56, 20)
      Me.optAdult.Text = "Adult"
      '
      'optChild
      '
      Me.optChild.Location = New System.Drawing.Point(64, 8)
      Me.optChild.Size = New System.Drawing.Size(48, 20)
      Me.optChild.Text = "Child"
      '
      'optAssociate
      '
      Me.optAssociate.Location = New System.Drawing.Point(112, 8)
      Me.optAssociate.Size = New System.Drawing.Size(80, 20)
      Me.optAssociate.Text = "Associate"
      '
      'panelMemberType
      '
      Me.panelMemberType.Controls.Add(Me.optAssociate)
      Me.panelMemberType.Controls.Add(Me.optChild)
      Me.panelMemberType.Controls.Add(Me.optAdult)
      Me.panelMemberType.Location = New System.Drawing.Point(32, 0)
      Me.panelMemberType.Size = New System.Drawing.Size(200, 32)
      '
      'lblID
      '
      Me.lblID.Location = New System.Drawing.Point(8, 0)
      Me.lblID.Size = New System.Drawing.Size(56, 20)
      Me.lblID.Text = "ID No"
      Me.lblID.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblPC
      '
      Me.lblPC.Location = New System.Drawing.Point(120, 49)
      Me.lblPC.Size = New System.Drawing.Size(24, 20)
      Me.lblPC.Text = "PC"
      Me.lblPC.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblGender
      '
      Me.lblGender.Location = New System.Drawing.Point(8, 0)
      Me.lblGender.Size = New System.Drawing.Size(56, 20)
      Me.lblGender.Text = "Gender"
      Me.lblGender.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblBorn
      '
      Me.lblBorn.Location = New System.Drawing.Point(8, 24)
      Me.lblBorn.Size = New System.Drawing.Size(56, 20)
      Me.lblBorn.Text = "Born"
      Me.lblBorn.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'textID
      '
      Me.textID.Location = New System.Drawing.Point(72, 0)
      Me.textID.Text = ""
      '
      'textStreet
      '
      Me.textStreet.Location = New System.Drawing.Point(72, 0)
      Me.textStreet.Size = New System.Drawing.Size(152, 22)
      Me.textStreet.Text = ""
      '
      'textCity
      '
      Me.textCity.Location = New System.Drawing.Point(72, 23)
      Me.textCity.Size = New System.Drawing.Size(152, 22)
      Me.textCity.Text = ""
      '
      'textSP
      '
      Me.textSP.Location = New System.Drawing.Point(72, 46)
      Me.textSP.Size = New System.Drawing.Size(40, 22)
      Me.textSP.Text = ""
      '
      'textPC
      '
      Me.textPC.Location = New System.Drawing.Point(152, 47)
      Me.textPC.Size = New System.Drawing.Size(80, 22)
      Me.textPC.Text = ""
      '
      'textBorn
      '
      Me.textBorn.Location = New System.Drawing.Point(72, 23)
      Me.textBorn.Text = ""
      '
      'optMale
      '
      Me.optMale.Location = New System.Drawing.Point(112, 0)
      Me.optMale.Size = New System.Drawing.Size(32, 20)
      Me.optMale.Text = "M"
      '
      'optFemale
      '
      Me.optFemale.Location = New System.Drawing.Point(73, 0)
      Me.optFemale.Size = New System.Drawing.Size(32, 20)
      Me.optFemale.Text = "F"
      '
      'panelAddress
      '
      Me.panelAddress.Controls.Add(Me.cboxCity)
      Me.panelAddress.Controls.Add(Me.lblSP)
      Me.panelAddress.Controls.Add(Me.lblCity)
      Me.panelAddress.Controls.Add(Me.lblStreet)
      Me.panelAddress.Controls.Add(Me.textSP)
      Me.panelAddress.Controls.Add(Me.textCity)
      Me.panelAddress.Controls.Add(Me.textStreet)
      Me.panelAddress.Controls.Add(Me.lblPC)
      Me.panelAddress.Controls.Add(Me.textPC)
      Me.panelAddress.Location = New System.Drawing.Point(0, 112)
      Me.panelAddress.Size = New System.Drawing.Size(232, 72)
      '
      'cboxCity
      '
      Me.cboxCity.Items.Add("Seattle")
      Me.cboxCity.Items.Add("Bellevue")
      Me.cboxCity.Items.Add("Kirkland")
      Me.cboxCity.Items.Add("Redmond")
      Me.cboxCity.Items.Add("Bothell")
      Me.cboxCity.Items.Add("Monroe")
      Me.cboxCity.Location = New System.Drawing.Point(72, 23)
      Me.cboxCity.Size = New System.Drawing.Size(152, 22)
      '
      'lblSP
      '
      Me.lblSP.Location = New System.Drawing.Point(8, 48)
      Me.lblSP.Size = New System.Drawing.Size(56, 20)
      Me.lblSP.Text = "SP"
      Me.lblSP.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblCity
      '
      Me.lblCity.Location = New System.Drawing.Point(8, 26)
      Me.lblCity.Size = New System.Drawing.Size(56, 20)
      Me.lblCity.Text = "City"
      Me.lblCity.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'lblStreet
      '
      Me.lblStreet.Location = New System.Drawing.Point(8, 6)
      Me.lblStreet.Size = New System.Drawing.Size(56, 16)
      Me.lblStreet.Text = "Street"
      Me.lblStreet.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'bttnAdd
      '
      Me.bttnAdd.Location = New System.Drawing.Point(192, 240)
      Me.bttnAdd.Size = New System.Drawing.Size(40, 20)
      Me.bttnAdd.Text = "Add"
      '
      'panelSponsor
      '
      Me.panelSponsor.Controls.Add(Me.lblSponsID)
      Me.panelSponsor.Controls.Add(Me.textSponsID)
      Me.panelSponsor.Location = New System.Drawing.Point(0, 88)
      Me.panelSponsor.Size = New System.Drawing.Size(232, 24)
      '
      'lblSponsID
      '
      Me.lblSponsID.Location = New System.Drawing.Point(8, 1)
      Me.lblSponsID.Size = New System.Drawing.Size(56, 20)
      Me.lblSponsID.Text = "Spons ID"
      Me.lblSponsID.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'textSponsID
      '
      Me.textSponsID.Location = New System.Drawing.Point(72, 0)
      Me.textSponsID.Text = ""
      '
      'panelWho
      '
      Me.panelWho.Controls.Add(Me.textName)
      Me.panelWho.Controls.Add(Me.lblName)
      Me.panelWho.Controls.Add(Me.lblID)
      Me.panelWho.Controls.Add(Me.textID)
      Me.panelWho.Location = New System.Drawing.Point(0, 40)
      Me.panelWho.Size = New System.Drawing.Size(232, 48)
      '
      'textName
      '
      Me.textName.Location = New System.Drawing.Point(72, 24)
      Me.textName.Text = ""
      '
      'lblName
      '
      Me.lblName.Location = New System.Drawing.Point(8, 25)
      Me.lblName.Size = New System.Drawing.Size(56, 20)
      Me.lblName.Text = "Name"
      Me.lblName.TextAlign = System.Drawing.ContentAlignment.TopRight
      '
      'panelChild
      '
      Me.panelChild.Controls.Add(Me.lblGender)
      Me.panelChild.Controls.Add(Me.optFemale)
      Me.panelChild.Controls.Add(Me.optMale)
      Me.panelChild.Controls.Add(Me.lblBorn)
      Me.panelChild.Controls.Add(Me.textBorn)
      Me.panelChild.Location = New System.Drawing.Point(0, 184)
      Me.panelChild.Size = New System.Drawing.Size(232, 48)
      '
      'formRegistration
      '
      Me.Controls.Add(Me.panelChild)
      Me.Controls.Add(Me.panelWho)
      Me.Controls.Add(Me.panelSponsor)
      Me.Controls.Add(Me.panelAddress)
      Me.Controls.Add(Me.panelMemberType)
      Me.Controls.Add(Me.bttnAdd)
      Me.Menu = Me.menuMain
      Me.Text = "Register Members"

   End Sub

#End Region

   Private Sub Form_Load(ByVal sender As System.Object, _
                          ByVal e As System.EventArgs _
                          ) _
                          Handles MyBase.Load

      '  Clear the input fields
      ClearTextBoxes(Me)

      '  Place the option buttons in a line along the
      '     top of the form, right justified.
      PositionOptionButtons()

      '  Co-locate the City combobox and 
      '     its associated text box.
      textCity.Bounds = cboxCity.Bounds
      '  Add the "(New Entry)" item at to top of the list.
      '  Select it.
      '  Show the ComboBox
      With cboxCity
         .Items.Insert(0, "(New Entry)")
         .SelectedIndex = 0
         .BringToFront()
      End With
   End Sub

   Private Sub optAny_CheckedChanged( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles optAdult.CheckedChanged, _
                          optChild.CheckedChanged, _
                          optAssociate.CheckedChanged

      '  Hide what you do not need, 
      '     show what you do need.
      panelSponsor.Visible = _
         optAssociate.Checked Or optChild.Checked
      panelAddress.Visible = _
         optAdult.Checked Or optAssociate.Checked
      panelChild.Visible = optChild.Checked

      '  Position panels.
      Dim topNext As Integer = panelWho.Bottom
      With panelSponsor
         If .Visible Then
            .Top = topNext
            topNext = .Bottom
         End If
      End With
      With panelAddress
         If .Visible Then
            .Top = topNext
            topNext = .Bottom
         End If
      End With
      With panelChild
         If .Visible Then
            .Top = topNext
            topNext = .Bottom
         End If
      End With
   End Sub

   Private Sub cboxCity_SelectedIndexChanged( _
                     ByVal sender As System.Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles cboxCity.SelectedIndexChanged

      '  If the user requested free form test entry
      If cboxCity.SelectedIndex = 0 Then
         '  Clear the TextBox
         '  Show it
         '  Give it the focus.
         With textCity
            .Text = String.Empty
            .BringToFront()
            .Focus()
         End With
      End If
   End Sub

   Private Sub textCity_Validated( _
                     ByVal sender As System.Object, _
                     ByVal e As System.EventArgs _
                     ) _
                     Handles textCity.Validated

      With cboxCity
         '  The user has completed their data entry
         '     and that data has passed all edits.
         If textCity.Text.Trim <> String.Empty Then
            '  Add their entry to the ComboBox's dropdown list.
            '  Select it.
            '  Show the ComboBox.
            .Items.Insert(1, textCity.Text)
            .SelectedIndex = 1
         End If
         .BringToFront()
      End With
   End Sub

   Private Sub bttnAdd_Click(ByVal sender As System.Object, _
                             ByVal e As System.EventArgs _
                             ) _
                             Handles bttnAdd.Click

      '  Code to register a member goes here 
      '        :
      '        :
      genderMember = IIf(optFemale.Checked, "F", _
                        IIf(optMale.Checked, "M", " "))
      '        :
      '        :
      ClearTextBoxes(Me)
   End Sub

   Private Sub PositionOptionButtons()
      '  Place the option buttons in a line along the
      '     top of the form, right justified.
      With panelMemberType
         .BackColor = Color.Bisque
         .Height = optAdult.Height
         .Width = optAdult.Width _
                + optAssociate.Width _
                + optChild.Width
         .Location = _
            New Point(Me.ClientRectangle.Width - .Width, 0)
      End With
      With optAssociate
         .Location = _
            New Point( _
               panelMemberType.ClientRectangle.Width - .Width _
                     , 0)
      End With
      With optChild
         .Location = _
            New Point(optAssociate.Left - .Width, 0)
      End With
      With optAdult
         .Location = _
            New Point(optChild.Left - .Width, 0)
      End With
   End Sub

   Private Sub ClearTextBoxes(ByVal ctrlContainer As Control)

      Dim theControl As Control
      For Each theControl In ctrlContainer.Controls
         '  Recursively perform this routine.
         ClearTextBoxes(theControl)
         '  Clear all TextBoxes that are first
         '     level children of this control.
         If theControl.GetType.ToString() = _
                     "System.Windows.Forms.TextBox" Then
            theControl.Text = String.Empty
         End If
      Next
   End Sub

End Class


