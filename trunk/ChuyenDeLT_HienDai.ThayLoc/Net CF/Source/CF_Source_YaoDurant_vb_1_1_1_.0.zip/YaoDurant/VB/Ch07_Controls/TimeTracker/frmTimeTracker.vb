' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System
Imports System.Drawing
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Collections

Public Class frmTimeTracker
   Inherits System.Windows.Forms.Form
   Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

   Public Sub New()
      MyBase.New()

      'This call is required by the Windows Form Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

   End Sub

   'Form overrides dispose to clean up the component list.
   Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      MyBase.Dispose(disposing)
   End Sub

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   Friend WithEvents lblProjName As System.Windows.Forms.Label
   Friend WithEvents txtTaskEnd As System.Windows.Forms.TextBox
   Friend WithEvents txtTaskStart As System.Windows.Forms.TextBox
   Friend WithEvents lblProjStart As System.Windows.Forms.Label
   Friend WithEvents lblProjEnd As System.Windows.Forms.Label
   Friend WithEvents cboxTasks As System.Windows.Forms.ComboBox
   Friend WithEvents txtTaskNo As System.Windows.Forms.TextBox
   Friend WithEvents txtTaskName As System.Windows.Forms.TextBox
   Friend WithEvents txtTaskEstimated As System.Windows.Forms.TextBox
   Friend WithEvents txtTaskActual As System.Windows.Forms.TextBox
   Friend WithEvents btnNewTask As System.Windows.Forms.Button
   Friend WithEvents btnAddTask As System.Windows.Forms.Button
   Friend WithEvents btnCancel As System.Windows.Forms.Button
   Private Sub InitializeComponent()
      Me.MainMenu1 = New System.Windows.Forms.MainMenu
      Me.lblProjStart = New System.Windows.Forms.Label
      Me.btnNewTask = New System.Windows.Forms.Button
      Me.lblProjName = New System.Windows.Forms.Label
      Me.lblProjEnd = New System.Windows.Forms.Label
      Me.txtTaskNo = New System.Windows.Forms.TextBox
      Me.txtTaskEnd = New System.Windows.Forms.TextBox
      Me.txtTaskStart = New System.Windows.Forms.TextBox
      Me.txtTaskName = New System.Windows.Forms.TextBox
      Me.txtTaskEstimated = New System.Windows.Forms.TextBox
      Me.txtTaskActual = New System.Windows.Forms.TextBox
      Me.cboxTasks = New System.Windows.Forms.ComboBox
      Me.btnAddTask = New System.Windows.Forms.Button
      Me.btnCancel = New System.Windows.Forms.Button
      '
      'lblProjStart
      '
      Me.lblProjStart.Location = New System.Drawing.Point(144, 16)
      Me.lblProjStart.Size = New System.Drawing.Size(40, 20)
      '
      'btnNewTask
      '
      Me.btnNewTask.Location = New System.Drawing.Point(80, 240)
      Me.btnNewTask.Text = "New &Task"
      '
      'lblProjName
      '
      Me.lblProjName.Location = New System.Drawing.Point(16, 16)
      Me.lblProjName.Size = New System.Drawing.Size(120, 20)
      '
      'lblProjEnd
      '
      Me.lblProjEnd.Location = New System.Drawing.Point(192, 16)
      Me.lblProjEnd.Size = New System.Drawing.Size(40, 20)
      '
      'txtTaskNo
      '
      Me.txtTaskNo.Location = New System.Drawing.Point(8, 136)
      Me.txtTaskNo.Size = New System.Drawing.Size(40, 22)
      Me.txtTaskNo.Text = ""
      '
      'txtTaskEnd
      '
      Me.txtTaskEnd.Location = New System.Drawing.Point(168, 136)
      Me.txtTaskEnd.Size = New System.Drawing.Size(64, 22)
      Me.txtTaskEnd.Text = ""
      '
      'txtTaskStart
      '
      Me.txtTaskStart.Location = New System.Drawing.Point(96, 136)
      Me.txtTaskStart.Size = New System.Drawing.Size(64, 22)
      Me.txtTaskStart.Text = ""
      '
      'txtTaskName
      '
      Me.txtTaskName.Location = New System.Drawing.Point(8, 168)
      Me.txtTaskName.Size = New System.Drawing.Size(144, 22)
      Me.txtTaskName.Text = ""
      '
      'txtTaskEstimated
      '
      Me.txtTaskEstimated.Location = New System.Drawing.Point(160, 168)
      Me.txtTaskEstimated.Size = New System.Drawing.Size(32, 22)
      Me.txtTaskEstimated.Text = ""
      '
      'txtTaskActual
      '
      Me.txtTaskActual.Location = New System.Drawing.Point(200, 168)
      Me.txtTaskActual.Size = New System.Drawing.Size(32, 22)
      Me.txtTaskActual.Text = ""
      '
      'cboxTasks
      '
      Me.cboxTasks.Location = New System.Drawing.Point(8, 200)
      Me.cboxTasks.Size = New System.Drawing.Size(224, 22)
      '
      'btnAddTask
      '
      Me.btnAddTask.Location = New System.Drawing.Point(0, 240)
      Me.btnAddTask.Text = "Add &Task"
      '
      'btnCancel
      '
      Me.btnCancel.Location = New System.Drawing.Point(160, 240)
      Me.btnCancel.Text = "&Cancel"
      '
      'frmTimeTracker
      '
      Me.Controls.Add(Me.btnCancel)
      Me.Controls.Add(Me.btnAddTask)
      Me.Controls.Add(Me.cboxTasks)
      Me.Controls.Add(Me.txtTaskActual)
      Me.Controls.Add(Me.txtTaskEstimated)
      Me.Controls.Add(Me.txtTaskName)
      Me.Controls.Add(Me.txtTaskStart)
      Me.Controls.Add(Me.txtTaskEnd)
      Me.Controls.Add(Me.txtTaskNo)
      Me.Controls.Add(Me.lblProjEnd)
      Me.Controls.Add(Me.lblProjName)
      Me.Controls.Add(Me.btnNewTask)
      Me.Controls.Add(Me.lblProjStart)
      Me.Menu = Me.MainMenu1
      Me.Text = "Time Tracker"

   End Sub

#End Region

#Region " Database Structure Simulated "
   Private Structure Project
      Public strProjNo As String
      Public strProjName As String
      Public dateProjStart As Date
      Public dateProjEnd As Date
      Public ctProjTasks As Integer
      Public strProjComments As String
      Public Sub New(ByVal strNo As String, _
                     ByVal strName As String, _
                     ByVal dateStart As Date, _
                     ByVal dateEnd As Date, _
                     ByVal ctTasks As Integer, _
                     ByVal strComments As String)
         strProjNo = strNo
         strProjName = strName
         dateProjStart = dateStart
         dateProjEnd = dateEnd
         ctProjTasks = ctTasks
         strProjComments = strComments
      End Sub
   End Structure

   Private Structure Task
      Public strTaskIdent As String
      Public strTaskName As String
      Public dateTaskStart As Date
      Public dateTaskEnd As Date
      Public durTaskEstimated As Integer  '  In hours
      Public durTaskActual As Integer     '  In hours
      Public strTaskComments As String
      Public Sub New(ByVal strNo As String, _
                     ByVal strName As String, _
                     ByVal dateStart As Date, _
                     ByVal dateEnd As Date, _
                     ByVal durEstimated As Integer, _
                     ByVal durActual As Integer, _
                     ByVal strComments As String)
         strTaskIdent = strNo
         strTaskName = strName
         dateTaskStart = dateStart
         dateTaskEnd = dateEnd
         durTaskEstimated = durEstimated
         durTaskActual = durActual
         strTaskComments = strComments
      End Sub
   End Structure
#End Region

   Private theProject As Project
   Private theTasks As New ArrayList

   '  A text box that we will create later in the program.
   Private txtTaskComments As Windows.Forms.TextBox

   '  The index number of the previous task.  We will
   '     need to know it in case the users cancels out 
   '  `during task creation.
   Private ixTaskPrev As Integer

   Private Sub Form1_Load( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles MyBase.Load
      '  Set the initial state of the controls.
      InitControlState()

      '  Load and display a project.
      If LoadProject(42) Then
         DisplayProject()
      Else
         Me.Close()
      End If
   End Sub

   Private Sub lbldateProjEnd_TextChanged( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles lblProjEnd.TextChanged
      '  If this project is due or
      '      overdue, use red ink.
      'With lblProjEnd
      '   If CDate(.Text) <= DateTime.Today Then
      '      .ForeColor = Color.Red
      '   End If
      'End With
      '  If this project is due or overdue,
      '      make the background light red.
      SetBkColor(lblProjEnd, Color.LightPink)
   End Sub

   Private Sub txtTaskDates_Validating( _
                  ByVal sender As System.Object, _
                  ByVal e As CancelEventArgs _
                  ) _
                  Handles txtTaskStart.Validating, _
                          txtTaskEnd.Validating

      '  If the date entered is not within one year
      '     of today, make the background light red.
      Dim txtSender As TextBox = sender
      With txtSender
         If CDate(.Text) <= DateTime.Today.AddYears(-1) _
         Or CDate(.Text) >= DateTime.Today.AddYears(1) Then
            .BackColor = Color.LightPink
         End If
      End With
   End Sub

   Private Sub cboxTasks_SelectedIndexChanged( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles cboxTasks.SelectedIndexChanged
      '  Since every task was loaded into the ComboBox, 
      '     the index values for any task are the same
      '     in the ComboBox as they are in the ArrayList.
      LoadTaskFields(cboxTasks.SelectedIndex)
   End Sub

   Private Sub btnNewTask_Click( _
                  ByVal sender As System.Object, _
                  ByVal e As System.EventArgs _
                  ) _
                  Handles btnNewTask.Click
      '  Save the index number of the previous task.  We will
      '     need to know it in case the users cancels out 
      '     during task creation.
      ixTaskPrev = cboxTasks.SelectedIndex

      '  Deselect the current task from the dropdown
      '     ComboBox.  This will also cause the 
      '     SelectedIndexChanged event to fire 
      '     which will cause the task fields to clear.
      cboxTasks.SelectedIndex = -1
      cboxTasks.SelectedIndex = -1

      '  Create and display a multiline textbox
      '     for the user to enter comments.
      txtTaskComments = New Windows.Forms.TextBox
      With txtTaskComments
         .Multiline = True

         '  Locate it relative to other 
         '     controls on the form.
         .Left = txtTaskNo.Left
         .Top = lblProjName.Top
         .Width = Me.Width - (2 * .Left)
         .Height = (txtTaskNo.Top - .Top) - (txtTaskNo.Height / 3)

         '  Enter and select some text.
         .Text = "Add task comments here."
         .SelectAll()

         '  Add the control to the form.
         Me.Controls.Add(txtTaskComments)

         '  Bring it to the z-axis top and
         '     set the focus into it.
         .BringToFront()
         .Focus()
      End With

      '  Designate the handler for the TextChanged
      '      event of the newly created control.
      AddHandler txtTaskComments.TextChanged, _
         AddressOf txtTaskComments_TextChanged

      '  Hide self and show Add and Cancel.
      btnAddTask.Visible = True
      btnCancel.Visible = True
      btnNewTask.Visible = False
   End Sub

   Private Sub btnAddTask_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddTask.Click
      '  Unbind the Tasks array list from 
      '     the dropdown ComboBox.
      cboxTasks.DataSource = Nothing


      '  Add the task to the Tasks array list.
      theTasks.Add(New Task(txtTaskNo.Text, txtTaskName.Text, _
                            txtTaskStart.Text, txtTaskEnd.Text, _
                            txtTaskEstimated.Text, _
                            txtTaskActual.Text, _
                            txtTaskComments.Text))

      With cboxTasks
         '  Rebind the Tasks array list to 
         '     the dropdown ComboBox.
         .DataSource = theTasks
         .DisplayMember = "strTaskName"
         .ValueMember = "strTaskIdent"

         '  Start with the new task
         '     as the selected task.
         .SelectedIndex = theTasks.Count - 1
      End With

      '  Cleanup the form and re-select the old task.
      AfterNewTaskCleanup(ixTaskPrev)
   End Sub

   Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
      '  Cleanup the form and re-select the old task.
      AfterNewTaskCleanup(ixTaskPrev)
   End Sub

   '  The event handler for a control
   '     that is created "on the fly".
   Private Sub txtTaskComments_TextChanged( _
                  ByVal sender As System.Object, _
                  ByVal e As EventArgs _
                  )
      With txtTaskComments
         .BackColor = IIf(.Text.Length > 30, _
                           Color.Red, _
                           Color.White)
      End With
   End Sub

   Private Sub InitControlState()
      '  Hide the Add button directly under the new button.
      btnAddTask.Visible = False
      btnAddTask.Bounds = btnNewTask.Bounds
      '  Hide the cancel button
      btnCancel.Visible = False
   End Sub

   Private Sub DisplayProject()
      '  Load Proj data into the labels.
      With theProject
         lblProjName.Text = .strProjName
         lblProjStart.Text = .dateProjStart.ToString("ddMMM")
         lblProjEnd.Text = .dateProjEnd.ToString("ddMMM")
      End With

      '  Load Proj data into the listbox.
      Dim theTask As Task
      With cboxTasks
         For Each theTask In theTasks
            .Items.Add(theTask.strTaskName)
         Next
         '  Start with the first task as 
         '     the currently selected task.
         .SelectedIndex = 0
         '  Set focus to the tasks ComboBox.
         .Focus()
      End With
   End Sub

   Private Sub LoadTaskFields(ByVal intTaskNo As Integer)
      '  Load the fields for the specified
      '     task into the text boxes.  If 
      '     intTaskNo is out of range, clear
      '     the textboxes.  
      If intTaskNo >= 0 And intTaskNo < theTasks.Count Then
         '  Create a variable of a specific type 
         '     so that we can do early binding.
         Dim refTask As Task = theTasks(intTaskNo)
         With refTask
            txtTaskNo.Text = .strTaskIdent
            txtTaskName.Text = .strTaskName
            txtTaskStart.Text = .dateTaskStart.ToString("MM/dd/yy")
            txtTaskEnd.Text = .dateTaskEnd.ToString("MM/dd/yy")
            txtTaskEstimated.Text = .durTaskEstimated
            txtTaskActual.Text = .durTaskActual
         End With
      Else
         txtTaskNo.Text = String.Empty
         txtTaskName.Text = String.Empty
         txtTaskStart.Text = String.Empty
         txtTaskEnd.Text = String.Empty
         txtTaskEstimated.Text = String.Empty
         txtTaskActual.Text = String.Empty
      End If
   End Sub

   Private Sub AfterNewTaskCleanup(ByVal ixTask As Integer)
      '  Destroy the comments textbox
      txtTaskComments.Dispose()
      txtTaskComments = Nothing

      '  Hide Add and Cancel and show New.
      btnAddTask.Visible = False
      btnCancel.Visible = False
      btnNewTask.Visible = True

      '  Select the specified task.
      cboxTasks.SelectedIndex = ixTaskPrev

      '  Set focus to the tasks ComboBox.
      cboxTasks.Focus()
   End Sub

   Private Sub SetBkColor( _
                  ByVal lblTarget As Label, _
                  ByVal colorBack As Color _
                  )
      '  If the desired background color is the background 
      '     color of this form, remove the label from the
      '     panel and dispose of the panel.
      Dim panelBackColor As New Panel
      If colorBack.Equals(Me.BackColor) Then
         If Not lblTarget.Parent Is Me Then
            panelBackColor = lblTarget.Parent
            lblTarget.Bounds = panelBackColor.Bounds
            lblTarget.Parent = Me
            panelBackColor.Dispose()
         End If
      Else
         '  If the desired background color is not the 
         '     background color of this form, then if the
         '     label is already inside a panel, set the
         '     background color of that panel.  If not,
         '     create a panel, position it, put the label 
         '     in it, and set the background color.  
         If lblTarget.Parent Is Me Then
            panelBackColor = New Panel
            Me.Controls.Add(panelBackColor)
            With panelBackColor
               .Visible = True
               .Bounds = lblTarget.Bounds
               lblTarget.Location = New Point(0, 0)
               .Controls.Add(lblTarget)
            End With
         End If
         panelBackColor.BackColor = colorBack
      End If
   End Sub

#Region " Database Read Simulation "

   Private Function LoadProject( _
                        ByVal ProjectID As Integer _
                        ) _
                        As Boolean
      '  Simulate having retrieved project data
      '     from a database.  Here, we'll use our
      '     Project and Task data structures to
      '     hold the data.
      With theProject
         .strProjNo = 1
         .strProjName = "Net CF Book"
         .dateProjStart = DateTime.Today.AddDays(-100)
         .dateProjEnd = DateTime.Today.AddDays(100)
      End With

      theTasks.Add(New Task(0, "Create Blueprints", _
                            DateTime.Today.AddDays(-17), _
                            DateTime.Today.AddDays(22), _
                            120, 60, ""))
      theTasks.Add(New Task(1, "Build Franistans", _
                            DateTime.Today.AddDays(-11), _
                            DateTime.Today.AddDays(0), _
                            35, 30, ""))
      theTasks.Add(New Task(2, "Build Widgets", _
                            DateTime.Today.AddDays(-4), _
                            DateTime.Today.AddDays(44), _
                            400, 45, ""))
      theTasks.Add(New Task(3, "Assemble Woobletogles", _
                            DateTime.Today.AddDays(-19), _
                            DateTime.Today.AddDays(2), _
                            20, 20, ""))
      theTasks.Add(New Task(4, "Weld Mainwareing", _
                            DateTime.Today.AddDays(-100), _
                            DateTime.Today.AddDays(50), _
                            20, 6, ""))
      Return True
   End Function

#End Region

End Class

