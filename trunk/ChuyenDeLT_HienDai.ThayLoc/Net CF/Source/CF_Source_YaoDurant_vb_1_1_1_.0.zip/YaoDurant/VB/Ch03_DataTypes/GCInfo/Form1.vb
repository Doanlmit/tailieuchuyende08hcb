' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Runtime.InteropServices

Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents label1 As System.Windows.Forms.Label
      Friend WithEvents labMaxGenerations As System.Windows.Forms.Label
      Friend WithEvents cmdCollect As System.Windows.Forms.Button
      Friend WithEvents button1 As System.Windows.Forms.Button
      Friend WithEvents label2 As System.Windows.Forms.Label
      Friend WithEvents labTotalMemory As System.Windows.Forms.Label
      Friend WithEvents cmdWaitForFinalizers As System.Windows.Forms.Button
      Friend WithEvents textNumObjects As System.Windows.Forms.TextBox
      Friend WithEvents cboxObjects As System.Windows.Forms.ComboBox
      Friend WithEvents cmdAllocFree As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.label1 = New System.Windows.Forms.Label
Me.labMaxGenerations = New System.Windows.Forms.Label
Me.cmdCollect = New System.Windows.Forms.Button
Me.button1 = New System.Windows.Forms.Button
Me.label2 = New System.Windows.Forms.Label
Me.labTotalMemory = New System.Windows.Forms.Label
Me.cmdWaitForFinalizers = New System.Windows.Forms.Button
Me.textNumObjects = New System.Windows.Forms.TextBox
Me.cboxObjects = New System.Windows.Forms.ComboBox
Me.cmdAllocFree = New System.Windows.Forms.Button
'
'label1
'
Me.label1.Location = New System.Drawing.Point(16, 16)
Me.label1.Text = "MaxGeneration:"
Me.label1.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'labMaxGenerations
'
Me.labMaxGenerations.Location = New System.Drawing.Point(128, 16)
Me.labMaxGenerations.Size = New System.Drawing.Size(40, 20)
'
'cmdCollect
'
Me.cmdCollect.Location = New System.Drawing.Point(24, 48)
Me.cmdCollect.Size = New System.Drawing.Size(120, 20)
Me.cmdCollect.Text = "Collect"
'
'button1
'
Me.button1.Location = New System.Drawing.Point(24, 88)
Me.button1.Size = New System.Drawing.Size(120, 20)
Me.button1.Text = "GetTotalMemory"
'
'label2
'
Me.label2.Location = New System.Drawing.Point(32, 120)
Me.label2.Size = New System.Drawing.Size(88, 20)
Me.label2.Text = "Total Memory:"
'
'labTotalMemory
'
Me.labTotalMemory.Location = New System.Drawing.Point(128, 120)
Me.labTotalMemory.Size = New System.Drawing.Size(64, 20)
'
'cmdWaitForFinalizers
'
Me.cmdWaitForFinalizers.Location = New System.Drawing.Point(24, 152)
Me.cmdWaitForFinalizers.Size = New System.Drawing.Size(168, 20)
Me.cmdWaitForFinalizers.Text = "WaitForPendingFinalizers"
'
'textNumObjects
'
Me.textNumObjects.Location = New System.Drawing.Point(40, 192)
Me.textNumObjects.Size = New System.Drawing.Size(48, 22)
Me.textNumObjects.Text = ""
'
'cboxObjects
'
Me.cboxObjects.Items.Add("Brushes")
Me.cboxObjects.Items.Add("Controls")
Me.cboxObjects.Items.Add("Graphics")
Me.cboxObjects.Items.Add("Integers (in Array)")
Me.cboxObjects.Items.Add("Longs (In Array)")
Me.cboxObjects.Location = New System.Drawing.Point(104, 192)
Me.cboxObjects.Size = New System.Drawing.Size(112, 22)
'
'cmdAllocFree
'
Me.cmdAllocFree.Enabled = False
Me.cmdAllocFree.Location = New System.Drawing.Point(40, 232)
Me.cmdAllocFree.Text = "Allocate"
'
'FormMain
'
Me.Controls.Add(Me.cmdAllocFree)
Me.Controls.Add(Me.cboxObjects)
Me.Controls.Add(Me.textNumObjects)
Me.Controls.Add(Me.cmdWaitForFinalizers)
Me.Controls.Add(Me.labTotalMemory)
Me.Controls.Add(Me.label2)
Me.Controls.Add(Me.button1)
Me.Controls.Add(Me.cmdCollect)
Me.Controls.Add(Me.labMaxGenerations)
Me.Controls.Add(Me.label1)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "GC Info"

    End Sub

#End Region

   Private cObjects As Integer = 0
   Private iItem As Integer = -1
   Private bAllocate As Boolean = True

   Private Sub FormMain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Dim c As Long = GC.MaxGeneration
      labMaxGenerations.Text = c.ToString()

   End Sub

   Private Sub cmdCollect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCollect.Click
      GC.Collect()
   End Sub

   Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
      Dim lmem As Long = GC.GetTotalMemory(False)
      labTotalMemory.Text = lmem.ToString("D")
   End Sub

   Private Sub cmdWaitForFinalizers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdWaitForFinalizers.Click
      GC.WaitForPendingFinalizers()
   End Sub

   Private Sub SetButtonState()
      cmdAllocFree.Enabled = (iItem >= -1 And cObjects > 0)
   End Sub

   Private Sub textNumObjects_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles textNumObjects.TextChanged
      Try
         cObjects = Integer.Parse(textNumObjects.Text)
      Catch
         cObjects = 0
      End Try

      SetButtonState()

   End Sub

   Private Sub cboxObjects_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboxObjects.SelectedIndexChanged
      iItem = cboxObjects.SelectedIndex
      SetButtonState()

   End Sub

      Dim abr() As Brush = Nothing
      Dim actrl() As Control = Nothing
      Dim ag() As Graphics = Nothing
      Dim ai() As Integer = Nothing
      Dim al() As Long = Nothing

   Private Sub cmdAllocFree_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAllocFree.Click
      If (bAllocate) Then
         bAllocate = False
         cmdAllocFree.Text = "Free"
         cboxObjects.Enabled = False
         Dim objCurrent As Object = Nothing
         Dim cbObject As Integer = 0
         Dim i As Integer
         Select Case iItem
            Case 0
               objCurrent = abr
               cbObject = Marshal.SizeOf(abr(0).GetType())
            Case 1
               objCurrent = actrl
               cbObject = Marshal.SizeOf(actrl(0).GetType())
            Case 2
               objCurrent = ag
               cbObject = Marshal.SizeOf(ag(0).GetType())
            Case 3
                  For i = 0 To cObjects - 1 Step i + 1
                     ai(i) = i + 3
                  Next
               objCurrent = ai
               cbObject = Marshal.SizeOf(ai(0).GetType())
            Case 4
               objCurrent = al
               cbObject = Marshal.SizeOf(al(0).GetType())
         End Select

         Dim cbTot As Integer = cbObject * cObjects
         MessageBox.Show("Allocated " + cbTot.ToString() + " bytes")
      Else
         bAllocate = True
         cmdAllocFree.Text = "Allocate"
         cboxObjects.Enabled = True
         abr = Nothing
         actrl = Nothing
         ag = Nothing
         ai = Nothing
         al = Nothing
         MessageBox.Show("Freed stuff")
      End If

   End Sub
End Class
