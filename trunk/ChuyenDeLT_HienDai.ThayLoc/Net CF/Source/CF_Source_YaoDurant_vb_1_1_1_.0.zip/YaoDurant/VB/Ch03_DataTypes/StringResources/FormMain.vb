' -----------------------------------------------------------------------------
' Code from _Programming the .NET Compact Framework with VB_
' and _Programming the .NET Compact Framework with C#_
' (c) Copyright 2002-2004 Paul Yao and David Durant. 
' All rights reserved.
' -----------------------------------------------------------------------------

Imports System.Resources
Imports System.Reflection

Public Class FormMain
    Inherits System.Windows.Forms.Form
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
'
'FormMain
'
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "StringResources"

    End Sub

#End Region

   ' Resource manager for our set of strings.
   Dim resman As ResourceManager

   ' The four strings we load
   Dim strA As String
   Dim strB As String
   Dim strC As String
   Dim strD As String

   Private Sub FormMain_Load( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles MyBase.Load
      ' Create the resource manager.
      Dim assem As System.Reflection.Assembly
      assem = Me.GetType().Assembly
      resman = New ResourceManager( _
         "StringResources.Strings", assem)

      ' Load the strings.
      strA = resman.GetString("A")
      strB = resman.GetString("B")
      strC = resman.GetString("C")
      strD = resman.GetString("D")
   End Sub

   Private Sub FormMain_Paint( _
   ByVal sender As Object, _
   ByVal e As PaintEventArgs) Handles MyBase.Paint
      Dim sinX As Single = 10
      Dim sinY As Single = 10
      Dim szf As SizeF

      Dim brText As Brush = New SolidBrush(SystemColors.WindowText)
      szf = e.Graphics.MeasureString(strA, Font)

      e.Graphics.DrawString(strA, Font, brText, sinX, sinY)
      sinY = sinY + szf.Height
      e.Graphics.DrawString(strB, Font, brText, sinX, sinY)
      sinY = sinY + szf.Height
      e.Graphics.DrawString(strC, Font, brText, sinX, sinY)
      sinY = sinY + szf.Height
      e.Graphics.DrawString(strD, Font, brText, sinX, sinY)
      sinY = sinY + szf.Height
   End Sub
End Class
