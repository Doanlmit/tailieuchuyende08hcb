Public Class FormMain
    Inherits System.Windows.Forms.Form
      Friend WithEvents cmdCreate As System.Windows.Forms.Button
      Friend WithEvents cmdDispose As System.Windows.Forms.Button
      Friend WithEvents cmdSuppress As System.Windows.Forms.Button
      Friend WithEvents cmdDereference As System.Windows.Forms.Button
      Friend WithEvents cmdCollect As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
Me.MainMenu1 = New System.Windows.Forms.MainMenu
Me.cmdCreate = New System.Windows.Forms.Button
Me.cmdDispose = New System.Windows.Forms.Button
Me.cmdSuppress = New System.Windows.Forms.Button
Me.cmdDereference = New System.Windows.Forms.Button
Me.cmdCollect = New System.Windows.Forms.Button
'
'cmdCreate
'
Me.cmdCreate.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdCreate.Location = New System.Drawing.Point(24, 40)
Me.cmdCreate.Size = New System.Drawing.Size(128, 20)
Me.cmdCreate.Text = "1) Create Object"
'
'cmdDispose
'
Me.cmdDispose.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdDispose.Location = New System.Drawing.Point(24, 80)
Me.cmdDispose.Size = New System.Drawing.Size(128, 20)
Me.cmdDispose.Text = "2) Dispose"
'
'cmdSuppress
'
Me.cmdSuppress.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdSuppress.Location = New System.Drawing.Point(24, 120)
Me.cmdSuppress.Size = New System.Drawing.Size(128, 20)
Me.cmdSuppress.Text = "3) Suppress Finalize"
'
'cmdDereference
'
Me.cmdDereference.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdDereference.Location = New System.Drawing.Point(24, 160)
Me.cmdDereference.Size = New System.Drawing.Size(128, 20)
Me.cmdDereference.Text = "4) DeReference"
'
'cmdCollect
'
Me.cmdCollect.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
Me.cmdCollect.Location = New System.Drawing.Point(24, 200)
Me.cmdCollect.Size = New System.Drawing.Size(128, 20)
Me.cmdCollect.Text = "5) Garbage Collect"
'
'FormMain
'
Me.Controls.Add(Me.cmdCollect)
Me.Controls.Add(Me.cmdDereference)
Me.Controls.Add(Me.cmdSuppress)
Me.Controls.Add(Me.cmdDispose)
Me.Controls.Add(Me.cmdCreate)
Me.Menu = Me.MainMenu1
Me.MinimizeBox = False
Me.Text = "Disposer"

    End Sub

#End Region

   Dim rw As ResourceWrapper = Nothing

   Private Sub cmdCreate_Click( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles cmdCreate.Click
      rw = New ResourceWrapper
   End Sub

   Private Sub cmdDispose_Click( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles cmdDispose.Click
      If (rw Is Nothing) Then
         MessageBox.Show("rw is Nothing -> Exception!")
      Else
         rw.Dispose()
      End If
   End Sub

   Private Sub cmdSuppress_Click( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles cmdSuppress.Click
      If (rw Is Nothing) Then
         MessageBox.Show("rw is Nothing -> Exception!")
      Else
         GC.SuppressFinalize(rw)
      End If
   End Sub

   Private Sub cmdDereference_Click( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles cmdDereference.Click
      rw = Nothing
   End Sub

   Private Sub cmdCollect_Click( _
   ByVal sender As Object, _
   ByVal e As EventArgs) Handles cmdCollect.Click
      GC.Collect()
   End Sub
End Class

'
' Simple resource wrapper class to demonstrate managed-code
' support for manual cleanup functions
'
Public Class ResourceWrapper
   Inherits System.Object
   Implements IDisposable

   Public Sub New()
      MessageBox.Show("Constructor called")
   End Sub

   Public Overridable Sub Dispose() Implements IDisposable.Dispose
      MessageBox.Show("Public Dispose called")
      Dispose(True)

      ' Call Dispose when supported by base class.
      ' MyBase.Dispose()
   End Sub

   Protected Sub Dispose(ByVal bDisposing As Boolean)
      If (bDisposing) Then
         MessageBox.Show("Protected Dispose called -- are disposing")
      Else
         MessageBox.Show("Protected Dispose called -- are finalizing")
      End If
   End Sub

   Protected Overrides Sub Finalize()
      Try
         MessageBox.Show("Finalize called")
         Dispose(False)
      Finally
         MyBase.Finalize()
      End Try
   End Sub

End Class
' class ResourceWrapper

