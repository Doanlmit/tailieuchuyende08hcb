Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label10 As System.Windows.Forms.Label
    Friend WithEvents label9 As System.Windows.Forms.Label
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents txtDWORDOut As System.Windows.Forms.TextBox
    Friend WithEvents txtDWORDIn As System.Windows.Forms.TextBox
    Friend WithEvents txtByteOut As System.Windows.Forms.TextBox
    Friend WithEvents txtByteIn As System.Windows.Forms.TextBox
    Friend WithEvents txtUShortOut As System.Windows.Forms.TextBox
    Friend WithEvents txtUShortIn As System.Windows.Forms.TextBox
    Friend WithEvents txtShortOut As System.Windows.Forms.TextBox
    Friend WithEvents txtShortIn As System.Windows.Forms.TextBox
    Friend WithEvents txtFloatOut As System.Windows.Forms.TextBox
    Friend WithEvents txtFloatIn As System.Windows.Forms.TextBox
    Friend WithEvents txtIntegerOut As System.Windows.Forms.TextBox
    Friend WithEvents txtIntegerIn As System.Windows.Forms.TextBox
    Friend WithEvents txtUIntOut As System.Windows.Forms.TextBox
    Friend WithEvents txtUIntIn As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents radioBoolIn As System.Windows.Forms.RadioButton
    Friend WithEvents txtBoolOut As System.Windows.Forms.TextBox
    Friend WithEvents label8 As System.Windows.Forms.Label
    Friend WithEvents txtCharOut As System.Windows.Forms.TextBox
    Friend WithEvents txtCharIn As System.Windows.Forms.TextBox
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents txtULongOut As System.Windows.Forms.TextBox
    Friend WithEvents txtULongIn As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents txtLongOut As System.Windows.Forms.TextBox
    Friend WithEvents txtLongIn As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnDoConversions As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Const MAX_CAPACITY As Integer = 100


    Declare Sub IntToString Lib "FundamentalToString.dll" (ByVal in_Int As Integer, ByVal out_IntAsString As System.Text.StringBuilder)

    Declare Sub UIntToString Lib "FundamentalToString.dll" (ByVal in_UInt As UInt32, ByVal out_UIntAsString As System.Text.StringBuilder)

    ' Float data types can only be passed from the runtime by reference.
    Declare Sub FloatToString Lib "FundamentalToString.dll" (ByRef in_Float As Single, ByVal out_FloatAsString As System.Text.StringBuilder)

    ' Long data types can only be passed from the runtime by reference.
    Declare Sub LongToString Lib "FundamentalToString.dll" (ByRef in_Long As Long, ByVal out_LongAsString As System.Text.StringBuilder)

    ' Unsigned long data types can only be passed from the runtime by reference.
    Declare Sub ULongToString Lib "FundamentalToString.dll" (ByRef in_ULong As UInt64, ByVal out_ULongAsString As System.Text.StringBuilder)

    Declare Sub ShortToString Lib "FundamentalToString.dll" (ByVal in_Short As Short, ByVal out_ShortAsString As System.Text.StringBuilder)

    Declare Sub UShortToString Lib "FundamentalToString.dll" (ByVal in_UShort As UInt16, ByVal out_UShortAsString As System.Text.StringBuilder)

    Declare Sub CharToString Lib "FundamentalToString.dll" (ByVal in_Char As Char, ByVal out_CharAsString As System.Text.StringBuilder)

    Declare Sub ByteToString Lib "FundamentalToString.dll" (ByVal in_Byte As Byte, ByVal out_ByteAsString As System.Text.StringBuilder)

    Declare Sub BoolToString Lib "FundamentalToString.dll" (ByVal in_Bool As Boolean, ByVal out_BoolAsString As System.Text.StringBuilder)

    ' Note: DWORD is a 32 bit type.
    Declare Sub DWORDToString Lib "FundamentalToString.dll" (ByVal in_DWORD As UInt32, ByVal out_DWORDAsString As System.Text.StringBuilder)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label10 = New System.Windows.Forms.Label
        Me.label9 = New System.Windows.Forms.Label
        Me.label7 = New System.Windows.Forms.Label
        Me.label5 = New System.Windows.Forms.Label
        Me.label4 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.txtDWORDOut = New System.Windows.Forms.TextBox
        Me.txtDWORDIn = New System.Windows.Forms.TextBox
        Me.txtByteOut = New System.Windows.Forms.TextBox
        Me.txtByteIn = New System.Windows.Forms.TextBox
        Me.txtUShortOut = New System.Windows.Forms.TextBox
        Me.txtUShortIn = New System.Windows.Forms.TextBox
        Me.txtShortOut = New System.Windows.Forms.TextBox
        Me.txtShortIn = New System.Windows.Forms.TextBox
        Me.txtFloatOut = New System.Windows.Forms.TextBox
        Me.txtFloatIn = New System.Windows.Forms.TextBox
        Me.txtIntegerOut = New System.Windows.Forms.TextBox
        Me.txtIntegerIn = New System.Windows.Forms.TextBox
        Me.txtUIntOut = New System.Windows.Forms.TextBox
        Me.txtUIntIn = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.radioBoolIn = New System.Windows.Forms.RadioButton
        Me.txtBoolOut = New System.Windows.Forms.TextBox
        Me.label8 = New System.Windows.Forms.Label
        Me.txtCharOut = New System.Windows.Forms.TextBox
        Me.txtCharIn = New System.Windows.Forms.TextBox
        Me.label6 = New System.Windows.Forms.Label
        Me.txtULongOut = New System.Windows.Forms.TextBox
        Me.txtULongIn = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.txtLongOut = New System.Windows.Forms.TextBox
        Me.txtLongIn = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.btnDoConversions = New System.Windows.Forms.Button
        '
        'label10
        '
        Me.label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label10.Location = New System.Drawing.Point(0, 120)
        Me.label10.Size = New System.Drawing.Size(64, 16)
        Me.label10.Text = "DWORD"
        '
        'label9
        '
        Me.label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label9.Location = New System.Drawing.Point(0, 96)
        Me.label9.Size = New System.Drawing.Size(64, 16)
        Me.label9.Text = "Byte"
        '
        'label7
        '
        Me.label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label7.Location = New System.Drawing.Point(0, 72)
        Me.label7.Size = New System.Drawing.Size(64, 16)
        Me.label7.Text = "UShort"
        '
        'label5
        '
        Me.label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label5.Location = New System.Drawing.Point(0, 48)
        Me.label5.Size = New System.Drawing.Size(64, 16)
        Me.label5.Text = "Short"
        '
        'label4
        '
        Me.label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label4.Location = New System.Drawing.Point(0, 24)
        Me.label4.Size = New System.Drawing.Size(64, 16)
        Me.label4.Text = "Float"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label1.Size = New System.Drawing.Size(64, 16)
        Me.label1.Text = "Int"
        '
        'txtDWORDOut
        '
        Me.txtDWORDOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtDWORDOut.Location = New System.Drawing.Point(88, 120)
        Me.txtDWORDOut.ReadOnly = True
        Me.txtDWORDOut.Size = New System.Drawing.Size(24, 21)
        Me.txtDWORDOut.Text = ""
        '
        'txtDWORDIn
        '
        Me.txtDWORDIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtDWORDIn.Location = New System.Drawing.Point(64, 120)
        Me.txtDWORDIn.Size = New System.Drawing.Size(24, 21)
        Me.txtDWORDIn.Text = "231"
        '
        'txtByteOut
        '
        Me.txtByteOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtByteOut.Location = New System.Drawing.Point(88, 96)
        Me.txtByteOut.ReadOnly = True
        Me.txtByteOut.Size = New System.Drawing.Size(24, 21)
        Me.txtByteOut.Text = ""
        '
        'txtByteIn
        '
        Me.txtByteIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtByteIn.Location = New System.Drawing.Point(64, 96)
        Me.txtByteIn.Size = New System.Drawing.Size(24, 21)
        Me.txtByteIn.Text = "88"
        '
        'txtUShortOut
        '
        Me.txtUShortOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtUShortOut.Location = New System.Drawing.Point(88, 72)
        Me.txtUShortOut.ReadOnly = True
        Me.txtUShortOut.Size = New System.Drawing.Size(24, 21)
        Me.txtUShortOut.Text = ""
        '
        'txtUShortIn
        '
        Me.txtUShortIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtUShortIn.Location = New System.Drawing.Point(64, 72)
        Me.txtUShortIn.Size = New System.Drawing.Size(24, 21)
        Me.txtUShortIn.Text = "2"
        '
        'txtShortOut
        '
        Me.txtShortOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtShortOut.Location = New System.Drawing.Point(88, 48)
        Me.txtShortOut.ReadOnly = True
        Me.txtShortOut.Size = New System.Drawing.Size(24, 21)
        Me.txtShortOut.Text = ""
        '
        'txtShortIn
        '
        Me.txtShortIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtShortIn.Location = New System.Drawing.Point(64, 48)
        Me.txtShortIn.Size = New System.Drawing.Size(24, 21)
        Me.txtShortIn.Text = "-2"
        '
        'txtFloatOut
        '
        Me.txtFloatOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtFloatOut.Location = New System.Drawing.Point(88, 24)
        Me.txtFloatOut.ReadOnly = True
        Me.txtFloatOut.Size = New System.Drawing.Size(24, 21)
        Me.txtFloatOut.Text = ""
        '
        'txtFloatIn
        '
        Me.txtFloatIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtFloatIn.Location = New System.Drawing.Point(64, 24)
        Me.txtFloatIn.Size = New System.Drawing.Size(24, 21)
        Me.txtFloatIn.Text = "-4.2"
        '
        'txtIntegerOut
        '
        Me.txtIntegerOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtIntegerOut.Location = New System.Drawing.Point(88, 0)
        Me.txtIntegerOut.ReadOnly = True
        Me.txtIntegerOut.Size = New System.Drawing.Size(24, 21)
        Me.txtIntegerOut.Text = ""
        '
        'txtIntegerIn
        '
        Me.txtIntegerIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtIntegerIn.Location = New System.Drawing.Point(64, 0)
        Me.txtIntegerIn.Size = New System.Drawing.Size(24, 21)
        Me.txtIntegerIn.Text = "-4"
        '
        'txtUIntOut
        '
        Me.txtUIntOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtUIntOut.Location = New System.Drawing.Point(216, 0)
        Me.txtUIntOut.ReadOnly = True
        Me.txtUIntOut.Size = New System.Drawing.Size(24, 21)
        Me.txtUIntOut.Text = ""
        '
        'txtUIntIn
        '
        Me.txtUIntIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtUIntIn.Location = New System.Drawing.Point(192, 0)
        Me.txtUIntIn.Size = New System.Drawing.Size(24, 21)
        Me.txtUIntIn.Text = "4"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(112, 0)
        Me.label2.Size = New System.Drawing.Size(80, 16)
        Me.label2.Text = "Unsigned Int"
        '
        'radioBoolIn
        '
        Me.radioBoolIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.radioBoolIn.Location = New System.Drawing.Point(160, 96)
        Me.radioBoolIn.Size = New System.Drawing.Size(48, 16)
        Me.radioBoolIn.Text = "True?"
        '
        'txtBoolOut
        '
        Me.txtBoolOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtBoolOut.Location = New System.Drawing.Point(208, 96)
        Me.txtBoolOut.ReadOnly = True
        Me.txtBoolOut.Size = New System.Drawing.Size(32, 21)
        Me.txtBoolOut.Text = ""
        '
        'label8
        '
        Me.label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label8.Location = New System.Drawing.Point(112, 96)
        Me.label8.Size = New System.Drawing.Size(80, 16)
        Me.label8.Text = "Bool"
        '
        'txtCharOut
        '
        Me.txtCharOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtCharOut.Location = New System.Drawing.Point(216, 72)
        Me.txtCharOut.ReadOnly = True
        Me.txtCharOut.Size = New System.Drawing.Size(24, 21)
        Me.txtCharOut.Text = ""
        '
        'txtCharIn
        '
        Me.txtCharIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtCharIn.Location = New System.Drawing.Point(192, 72)
        Me.txtCharIn.Size = New System.Drawing.Size(24, 21)
        Me.txtCharIn.Text = "c"
        '
        'label6
        '
        Me.label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label6.Location = New System.Drawing.Point(112, 72)
        Me.label6.Size = New System.Drawing.Size(80, 16)
        Me.label6.Text = "Char"
        '
        'txtULongOut
        '
        Me.txtULongOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtULongOut.Location = New System.Drawing.Point(216, 48)
        Me.txtULongOut.ReadOnly = True
        Me.txtULongOut.Size = New System.Drawing.Size(24, 21)
        Me.txtULongOut.Text = ""
        '
        'txtULongIn
        '
        Me.txtULongIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtULongIn.Location = New System.Drawing.Point(192, 48)
        Me.txtULongIn.Size = New System.Drawing.Size(24, 21)
        Me.txtULongIn.Text = "48"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.label3.Location = New System.Drawing.Point(112, 48)
        Me.label3.Size = New System.Drawing.Size(80, 16)
        Me.label3.Text = "Unsigned Long"
        '
        'txtLongOut
        '
        Me.txtLongOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtLongOut.Location = New System.Drawing.Point(216, 24)
        Me.txtLongOut.ReadOnly = True
        Me.txtLongOut.Size = New System.Drawing.Size(24, 21)
        Me.txtLongOut.Text = ""
        '
        'txtLongIn
        '
        Me.txtLongIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.txtLongIn.Location = New System.Drawing.Point(192, 24)
        Me.txtLongIn.Size = New System.Drawing.Size(24, 21)
        Me.txtLongIn.Text = "-48"
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.Label11.Location = New System.Drawing.Point(112, 24)
        Me.Label11.Size = New System.Drawing.Size(80, 16)
        Me.Label11.Text = "Long"
        '
        'btnDoConversions
        '
        Me.btnDoConversions.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnDoConversions.Location = New System.Drawing.Point(80, 240)
        Me.btnDoConversions.Size = New System.Drawing.Size(72, 24)
        Me.btnDoConversions.Text = "Convert"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnDoConversions)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtULongOut)
        Me.Controls.Add(Me.txtULongIn)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.txtLongOut)
        Me.Controls.Add(Me.txtLongIn)
        Me.Controls.Add(Me.radioBoolIn)
        Me.Controls.Add(Me.txtBoolOut)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.txtCharOut)
        Me.Controls.Add(Me.txtCharIn)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.txtUIntOut)
        Me.Controls.Add(Me.txtUIntIn)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtDWORDOut)
        Me.Controls.Add(Me.txtDWORDIn)
        Me.Controls.Add(Me.txtByteOut)
        Me.Controls.Add(Me.txtByteIn)
        Me.Controls.Add(Me.txtUShortOut)
        Me.Controls.Add(Me.txtUShortIn)
        Me.Controls.Add(Me.txtShortOut)
        Me.Controls.Add(Me.txtShortIn)
        Me.Controls.Add(Me.txtFloatOut)
        Me.Controls.Add(Me.txtFloatIn)
        Me.Controls.Add(Me.txtIntegerOut)
        Me.Controls.Add(Me.txtIntegerIn)
        Me.Controls.Add(Me.label10)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub DoIntConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_Int As Integer = Convert.ToInt32(Me.txtIntegerIn.Text)
        IntToString(in_Int, out_StringBuilder)
        Me.txtIntegerOut.Text = out_StringBuilder.ToString()
    End Sub

    Private Sub DoUIntConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_UInt As UInt32 = Convert.ToUInt32(Me.txtUIntIn.Text)
        UIntToString(in_UInt, out_StringBuilder)
        Me.txtUIntOut.Text = out_StringBuilder.ToString()
    End Sub

    Private Sub DoFloatConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_Float As Single = Convert.ToSingle(Me.txtFloatIn.Text)
        FloatToString(in_Float, out_StringBuilder)
        Me.txtFloatOut.Text = out_StringBuilder.ToString()
    End Sub

    Private Sub DoLongConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_Long As Long = Convert.ToInt64(Me.txtLongIn.Text)
        LongToString(in_Long, out_StringBuilder)
        Me.txtLongOut.Text = out_StringBuilder.ToString()
    End Sub


    Private Sub DoULongConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_ULong As UInt64 = Convert.ToUInt64(Me.txtULongIn.Text)
        ULongToString(in_ULong, out_StringBuilder)
        Me.txtULongOut.Text = out_StringBuilder.ToString()
    End Sub


    Private Sub DoShortConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_Short As Short = Convert.ToInt16(Me.txtShortIn.Text)
        ShortToString(in_Short, out_StringBuilder)
        Me.txtShortOut.Text = out_StringBuilder.ToString()
    End Sub

    Private Sub DoUShortConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_UShort As UInt16 = Convert.ToUInt16(Me.txtUShortIn.Text)
        UShortToString(in_UShort, out_StringBuilder)
        Me.txtUShortOut.Text = out_StringBuilder.ToString()
    End Sub

    Private Sub DoCharConversion()		
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_Char As Char = Convert.ToChar(Me.txtCharIn.Text)
        CharToString(in_Char, out_StringBuilder)
        Me.txtCharOut.Text = out_StringBuilder.ToString()
    End Sub

    Private Sub DoByteConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_Byte As Byte = Convert.ToByte(Me.txtByteIn.Text)
        ByteToString(in_Byte, out_StringBuilder)
        Me.txtByteOut.Text = out_StringBuilder.ToString()
    End Sub

    Private Sub DoBoolConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_Bool As Boolean = False

        If (Me.radioBoolIn.Checked) Then
            in_Bool = True
        End If

        BoolToString(in_Bool, out_StringBuilder)
        Me.txtBoolOut.Text = out_StringBuilder.ToString()
    End Sub

    ' Pass the DWORD in as an UInt32
    Private Sub DoDWORDConversion()
        Dim out_StringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder(MAX_CAPACITY)
        Dim in_DWORD As UInt32 = Convert.ToUInt32(Me.txtDWORDIn.Text)
        DWORDToString(in_DWORD, out_StringBuilder)
        Me.txtDWORDOut.Text = out_StringBuilder.ToString()
    End Sub
    Private Sub btnDoConversions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDoConversions.Click
        DoIntConversion()
        DoUIntConversion()
        DoFloatConversion()
        DoLongConversion()
        DoULongConversion()
        DoShortConversion()
        DoUShortConversion()
        DoCharConversion()
        DoByteConversion()
        DoBoolConversion()
        DoDWORDConversion()
    End Sub
End Class
