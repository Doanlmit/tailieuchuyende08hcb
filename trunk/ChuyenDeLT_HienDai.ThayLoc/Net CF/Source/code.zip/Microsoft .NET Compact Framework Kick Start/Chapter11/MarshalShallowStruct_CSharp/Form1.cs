using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace MarshalShallowStruct_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnUpdateStruct;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtInt;
		private System.Windows.Forms.TextBox txtChar;
		private System.Windows.Forms.TextBox txtDWORD;
		private System.Windows.Forms.RadioButton radioBool;
		private System.Windows.Forms.MainMenu mainMenu1;

		[DllImport("ManipulateStruct.dll")]
		private static extern void ManipulateStruct(ref ShallowStruct in_ShallowStruct, ref ShallowStruct out_ShallowStruct);


		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.btnUpdateStruct = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.txtInt = new System.Windows.Forms.TextBox();
			this.txtChar = new System.Windows.Forms.TextBox();
			this.txtDWORD = new System.Windows.Forms.TextBox();
			this.radioBool = new System.Windows.Forms.RadioButton();
			// 
			// btnUpdateStruct
			// 
			this.btnUpdateStruct.Location = new System.Drawing.Point(72, 224);
			this.btnUpdateStruct.Size = new System.Drawing.Size(96, 32);
			this.btnUpdateStruct.Text = "Update Struct";
			this.btnUpdateStruct.Click += new System.EventHandler(this.btnUpdateStruct_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Size = new System.Drawing.Size(88, 16);
			this.label1.Text = "Struct.m_Int";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Size = new System.Drawing.Size(88, 16);
			this.label2.Text = "Struct.m_Char";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.label3.Location = new System.Drawing.Point(8, 80);
			this.label3.Size = new System.Drawing.Size(104, 16);
			this.label3.Text = "Struct.m_DWORD";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.label4.Location = new System.Drawing.Point(8, 112);
			this.label4.Size = new System.Drawing.Size(96, 16);
			this.label4.Text = "Struct.m_Bool";
			// 
			// txtInt
			// 
			this.txtInt.Location = new System.Drawing.Point(128, 16);
			this.txtInt.Size = new System.Drawing.Size(72, 22);
			this.txtInt.Text = "4";
			// 
			// txtChar
			// 
			this.txtChar.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.txtChar.Location = new System.Drawing.Point(128, 48);
			this.txtChar.Size = new System.Drawing.Size(72, 22);
			this.txtChar.Text = "c";
			// 
			// txtDWORD
			// 
			this.txtDWORD.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.txtDWORD.Location = new System.Drawing.Point(128, 80);
			this.txtDWORD.Size = new System.Drawing.Size(72, 22);
			this.txtDWORD.Text = "588";
			// 
			// radioBool
			// 
			this.radioBool.Location = new System.Drawing.Point(128, 112);
			this.radioBool.Size = new System.Drawing.Size(72, 16);
			this.radioBool.Text = "True?";
			// 
			// Form1
			// 
			this.Controls.Add(this.radioBool);
			this.Controls.Add(this.txtDWORD);
			this.Controls.Add(this.txtChar);
			this.Controls.Add(this.txtInt);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnUpdateStruct);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnUpdateStruct_Click(object sender, System.EventArgs e)
		{
			ShallowStruct in_Struct = new ShallowStruct();
			in_Struct.m_Int		= Convert.ToInt32(this.txtInt.Text);
			in_Struct.m_Char	= Convert.ToChar(this.txtChar.Text);
			in_Struct.m_DWORD	= Convert.ToInt32(this.txtDWORD.Text);
			in_Struct.m_Bool	= this.radioBool.Checked;

			ShallowStruct out_Struct = new ShallowStruct();
			ManipulateStruct(ref in_Struct, ref out_Struct);
			this.txtInt.Text		= Convert.ToString(out_Struct.m_Int);
			this.txtChar.Text		= Convert.ToString(out_Struct.m_Char);
			this.txtDWORD.Text		= Convert.ToString(out_Struct.m_DWORD);
			this.radioBool.Checked	= out_Struct.m_Bool;
		}
	}
	public struct ShallowStruct
	{
		public int    m_Int;
		public char   m_Char;
		public Int32  m_DWORD;
		public bool   m_Bool;
	}
}
