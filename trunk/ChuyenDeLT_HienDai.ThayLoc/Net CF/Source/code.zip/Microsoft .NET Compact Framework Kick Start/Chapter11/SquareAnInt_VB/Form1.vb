Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents txtResult As System.Windows.Forms.TextBox
    Friend WithEvents txtInput As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents btnComputeSquare As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Declare Sub SquareAnInt Lib "SquareAnInt.dll" (ByVal input As Int32, ByRef output As Int32)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.txtResult = New System.Windows.Forms.TextBox
        Me.txtInput = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.btnComputeSquare = New System.Windows.Forms.Button
        '
        'txtResult
        '
        Me.txtResult.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtResult.Location = New System.Drawing.Point(120, 48)
        Me.txtResult.Size = New System.Drawing.Size(80, 22)
        Me.txtResult.Text = ""
        '
        'txtInput
        '
        Me.txtInput.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtInput.Location = New System.Drawing.Point(120, 16)
        Me.txtInput.Size = New System.Drawing.Size(80, 22)
        Me.txtInput.Text = "4"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(16, 56)
        Me.label2.Size = New System.Drawing.Size(104, 24)
        Me.label2.Text = "Square of Input"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(16, 24)
        Me.label1.Size = New System.Drawing.Size(104, 16)
        Me.label1.Text = "Input"
        '
        'btnComputeSquare
        '
        Me.btnComputeSquare.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnComputeSquare.Location = New System.Drawing.Point(40, 88)
        Me.btnComputeSquare.Size = New System.Drawing.Size(160, 32)
        Me.btnComputeSquare.Text = "Compute Square"
        '
        'Form1
        '
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnComputeSquare)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub btnComputeSquare_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnComputeSquare.Click
        Dim output As Integer = 0
        Dim input As Integer = Convert.ToInt32(Me.txtInput.Text)
        SquareAnInt(input, output)
        Me.txtResult.Text = Convert.ToString(output)
    End Sub
End Class
