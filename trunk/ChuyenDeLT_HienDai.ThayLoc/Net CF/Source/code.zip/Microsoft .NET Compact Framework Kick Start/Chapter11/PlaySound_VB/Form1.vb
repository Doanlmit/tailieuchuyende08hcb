Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents btnPlaySoundContinuously As System.Windows.Forms.Button
    Friend WithEvents btnPlaySound As System.Windows.Forms.Button
    Friend WithEvents txtSoundFilename As System.Windows.Forms.TextBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Const SND_LOOP As Integer = 8   ' See PlaySound_ConstFinder
    Const SND_ASYNC As Integer = 1          ' See PlaySound_ConstFinder

    Private m_PlayingContinuously As Boolean

    ' As defined in the native WinCE API:
    '		BOOL WINAPI PlaySound( 
    '						LPCSTR pszSound, 
    '						HMODULE hmod, 
    '						DWORD fdwSound );
    Declare Sub PlaySound Lib "coredll.dll" (ByVal pszSound As String, ByVal hmod As IntPtr, ByVal fdwSound As UInt32)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.btnPlaySoundContinuously = New System.Windows.Forms.Button
        Me.btnPlaySound = New System.Windows.Forms.Button
        Me.txtSoundFilename = New System.Windows.Forms.TextBox
        '
        'btnPlaySoundContinuously
        '
        Me.btnPlaySoundContinuously.Location = New System.Drawing.Point(8, 136)
        Me.btnPlaySoundContinuously.Size = New System.Drawing.Size(224, 32)
        Me.btnPlaySoundContinuously.Text = "Play Sound Continuously"
        '
        'btnPlaySound
        '
        Me.btnPlaySound.Location = New System.Drawing.Point(8, 88)
        Me.btnPlaySound.Size = New System.Drawing.Size(224, 32)
        Me.btnPlaySound.Text = "Play Sound Once"
        '
        'txtSoundFilename
        '
        Me.txtSoundFilename.Location = New System.Drawing.Point(8, 24)
        Me.txtSoundFilename.Multiline = True
        Me.txtSoundFilename.Size = New System.Drawing.Size(224, 48)
        Me.txtSoundFilename.Text = "\Windows\notify.wav"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnPlaySoundContinuously)
        Me.Controls.Add(Me.btnPlaySound)
        Me.Controls.Add(Me.txtSoundFilename)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub btnPlaySound_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlaySound.Click
        Dim l_NULL As IntPtr = IntPtr.Zero

        PlaySound(Me.txtSoundFilename.Text, l_NULL, Convert.ToUInt32(0))
    End Sub

    Private Sub btnPlaySoundContinuously_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPlaySoundContinuously.Click
        Dim l_NULL As IntPtr = IntPtr.Zero

        If (m_PlayingContinuously) Then
            PlaySound(Nothing, l_NULL, Convert.ToUInt32(0))
            m_PlayingContinuously = False
            Me.btnPlaySoundContinuously.Text = "Play Sound Continuously"
        Else		
            PlaySound(Me.txtSoundFilename.Text, l_NULL, Convert.ToUInt32(SND_LOOP + SND_ASYNC))
            m_PlayingContinuously = True
            Me.btnPlaySoundContinuously.Text = "Stop Playing Sound!!!"
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_PlayingContinuously = False
    End Sub
End Class
