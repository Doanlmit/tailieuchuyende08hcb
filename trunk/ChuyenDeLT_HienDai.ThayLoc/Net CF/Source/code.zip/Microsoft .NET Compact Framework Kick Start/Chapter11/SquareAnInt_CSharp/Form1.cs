using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace SquareAnInt_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnComputeSquare;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtInput;
		private System.Windows.Forms.TextBox txtResult;
		private System.Windows.Forms.MainMenu mainMenu1;
		
		[DllImport("SquareAnInt.dll")]
		private static extern void SquareAnInt(int input, ref int output);

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.btnComputeSquare = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.txtInput = new System.Windows.Forms.TextBox();
			this.txtResult = new System.Windows.Forms.TextBox();
			// 
			// btnComputeSquare
			// 
			this.btnComputeSquare.Location = new System.Drawing.Point(40, 88);
			this.btnComputeSquare.Size = new System.Drawing.Size(160, 32);
			this.btnComputeSquare.Text = "Compute Square";
			this.btnComputeSquare.Click += new System.EventHandler(this.btnComputeSquare_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Size = new System.Drawing.Size(104, 16);
			this.label1.Text = "Input";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 56);
			this.label2.Size = new System.Drawing.Size(104, 24);
			this.label2.Text = "Square of Input";
			// 
			// txtInput
			// 
			this.txtInput.Location = new System.Drawing.Point(120, 16);
			this.txtInput.Size = new System.Drawing.Size(80, 22);
			this.txtInput.Text = "4";
			// 
			// txtResult
			// 
			this.txtResult.Location = new System.Drawing.Point(120, 48);
			this.txtResult.Size = new System.Drawing.Size(80, 22);
			this.txtResult.Text = "";
			// 
			// Form1
			// 
			this.Controls.Add(this.txtResult);
			this.Controls.Add(this.txtInput);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnComputeSquare);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnComputeSquare_Click(object sender, System.EventArgs e)
		{
			int output = 0;
			int input = Convert.ToInt32(this.txtInput.Text);
			SquareAnInt(input, ref output);
			this.txtResult.Text = Convert.ToString(output);
		}
	}
}
