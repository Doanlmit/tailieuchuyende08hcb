Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents radioBool As System.Windows.Forms.RadioButton
    Friend WithEvents txtDWORD As System.Windows.Forms.TextBox
    Friend WithEvents txtChar As System.Windows.Forms.TextBox
    Friend WithEvents txtInt As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents btnUpdateStruct As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu


    Declare Sub ManipulateStruct Lib "ManipulateStruct.dll" (ByRef in_ShallowStruct As ShallowStruct, ByRef out_ShallowStruct As ShallowStruct)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.radioBool = New System.Windows.Forms.RadioButton
        Me.txtDWORD = New System.Windows.Forms.TextBox
        Me.txtChar = New System.Windows.Forms.TextBox
        Me.txtInt = New System.Windows.Forms.TextBox
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.btnUpdateStruct = New System.Windows.Forms.Button
        '
        'radioBool
        '
        Me.radioBool.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.radioBool.Location = New System.Drawing.Point(128, 111)
        Me.radioBool.Size = New System.Drawing.Size(72, 16)
        Me.radioBool.Text = "True?"
        '
        'txtDWORD
        '
        Me.txtDWORD.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtDWORD.Location = New System.Drawing.Point(128, 79)
        Me.txtDWORD.Size = New System.Drawing.Size(72, 22)
        Me.txtDWORD.Text = "588"
        '
        'txtChar
        '
        Me.txtChar.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtChar.Location = New System.Drawing.Point(128, 47)
        Me.txtChar.Size = New System.Drawing.Size(72, 22)
        Me.txtChar.Text = "c"
        '
        'txtInt
        '
        Me.txtInt.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtInt.Location = New System.Drawing.Point(128, 15)
        Me.txtInt.Size = New System.Drawing.Size(72, 22)
        Me.txtInt.Text = "4"
        '
        'label4
        '
        Me.label4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label4.Location = New System.Drawing.Point(8, 111)
        Me.label4.Size = New System.Drawing.Size(96, 16)
        Me.label4.Text = "Struct.m_Bool"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label3.Location = New System.Drawing.Point(8, 79)
        Me.label3.Size = New System.Drawing.Size(104, 16)
        Me.label3.Text = "Struct.m_DWORD"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(8, 47)
        Me.label2.Size = New System.Drawing.Size(88, 16)
        Me.label2.Text = "Struct.m_Char"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(8, 15)
        Me.label1.Size = New System.Drawing.Size(88, 16)
        Me.label1.Text = "Struct.m_Int"
        '
        'btnUpdateStruct
        '
        Me.btnUpdateStruct.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnUpdateStruct.Location = New System.Drawing.Point(72, 223)
        Me.btnUpdateStruct.Size = New System.Drawing.Size(96, 32)
        Me.btnUpdateStruct.Text = "Update Struct"
        '
        'Form1
        '
        Me.Controls.Add(Me.radioBool)
        Me.Controls.Add(Me.txtDWORD)
        Me.Controls.Add(Me.txtChar)
        Me.Controls.Add(Me.txtInt)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnUpdateStruct)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    
    Private Sub btnUpdateStruct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateStruct.Click
        Dim in_Struct As ShallowStruct = New ShallowStruct
        in_Struct.m_Int = Convert.ToInt32(Me.txtInt.Text)
        in_Struct.m_Char = Convert.ToChar(Me.txtChar.Text)
        in_Struct.m_DWORD = Convert.ToInt32(Me.txtDWORD.Text)
        in_Struct.m_Bool = Me.radioBool.Checked

        Dim out_Struct As ShallowStruct = New ShallowStruct
        ManipulateStruct(in_Struct, out_Struct)
        Me.txtInt.Text = Convert.ToString(out_Struct.m_Int)
        Me.txtChar.Text = Convert.ToString(out_Struct.m_Char)
        Me.txtDWORD.Text = Convert.ToString(out_Struct.m_DWORD)
        Me.radioBool.Checked = out_Struct.m_Bool
    End Sub

    Public Structure ShallowStruct
        Public m_Int As Integer
        Public m_Char As Char
        Public m_DWORD As Int32
        Public m_Bool As Boolean
    End Structure
End Class
