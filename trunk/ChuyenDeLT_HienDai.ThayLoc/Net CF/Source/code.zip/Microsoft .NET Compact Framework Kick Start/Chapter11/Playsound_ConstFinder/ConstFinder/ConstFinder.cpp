// ConstFinder.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "stdafx.h"
#include <winbase.h>
#include <commctrl.h>
#include <winsock.h>
#include <wincrypt.h>
#include "mmsystem.h"

int WINAPI WinMain(	HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPTSTR    lpCmdLine,
					int       nCmdShow)
{

	DWORD lSND_ALIAS				= SND_ALIAS;
	DWORD lSND_ASYNC				= SND_ASYNC;
	DWORD lSND_FILENAME				= SND_FILENAME;
	DWORD lSND_LOOP					= SND_LOOP;
	DWORD lSND_MEMORY				= SND_MEMORY;
	DWORD lSND_NODEFAULT			= SND_NODEFAULT;
	DWORD lSND_NOSTOP				= SND_NOSTOP;
	DWORD lSND_NOWAIT				= SND_NOWAIT;
	DWORD lSND_RESOURCE				= SND_RESOURCE;
	DWORD lSND_SYNC					= SND_SYNC;

	

	return 0;
}

