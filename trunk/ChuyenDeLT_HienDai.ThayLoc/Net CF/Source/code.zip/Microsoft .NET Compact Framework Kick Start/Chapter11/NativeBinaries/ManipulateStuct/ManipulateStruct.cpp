#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

struct ShallowStruct
{
	int    m_Int;
	char   m_Char;
	DWORD  m_DWORD;
	bool   m_Bool;
};

struct AllIntsInside
{
	int m_one;
	int m_two;
	int m_three;
};

struct DeepStruct
{
	char			* m_message;
	AllIntsInside	* m_someInts;
};

void __cdecl ManipulateStruct(ShallowStruct * in_ShallowStruct, ShallowStruct * out_ShallowStruct)
{	
	out_ShallowStruct->m_Int	= in_ShallowStruct->m_Int + 1;
	out_ShallowStruct->m_Char	= in_ShallowStruct->m_Char + 1;
	out_ShallowStruct->m_DWORD = in_ShallowStruct->m_DWORD + 1;
	out_ShallowStruct->m_Bool  = (in_ShallowStruct->m_Bool != true);	
}


// Caution! Very unsafe code here used for demonstration purposed only.
// inout_DeepStruct is assumed to exist as a valid pointer, and m_message is a string with at least 1 character
void __cdecl ManipulateDeepStruct(DeepStruct * inout_DeepStruct)
{
	inout_DeepStruct->m_message[0] = 'c';
	inout_DeepStruct->m_someInts->m_one++;
	inout_DeepStruct->m_someInts->m_two++;
	inout_DeepStruct->m_someInts->m_three++;
}

