#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}



void __cdecl SquareAnInt(int inputInt, int * outputInt)
{
	*outputInt = inputInt * inputInt;
}

