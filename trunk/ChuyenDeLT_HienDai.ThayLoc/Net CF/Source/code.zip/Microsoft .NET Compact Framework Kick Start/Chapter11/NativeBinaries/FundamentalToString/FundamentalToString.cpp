#include "stdafx.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


void __cdecl IntToString(int in_Int, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", in_Int);
}


void __cdecl UIntToString(unsigned int in_UInt, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", in_UInt);
}


// Float data types can only be passed from the runtime by reference.
void __cdecl FloatToString(float * in_Float, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%f", *in_Float);
}


// Long data types can only be passed from the runtime by reference.
void __cdecl LongToString(long * in_Long, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", *in_Long);
}


// Unsigned long data types can only be passed from the runtime by reference.
void __cdecl ULongToString(unsigned long * in_ULong, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", *in_ULong);
}


void __cdecl ShortToString(short in_Short, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", in_Short);
}


void __cdecl UShortToString(unsigned short in_UShort, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", in_UShort);
}


void __cdecl CharToString(char in_Char, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%c", in_Char);
}


void __cdecl ByteToString(BYTE in_Byte, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", in_Byte);
}


void __cdecl BoolToString(bool in_Bool, WCHAR * out_IntAsString)
{
	if (in_Bool)
	{
		swprintf(out_IntAsString, L"TRUE");
	}
	else
	{
		swprintf(out_IntAsString, L"FALSE");
	}
}

// Note: DWORD is a 32 bit type.
void __cdecl DWORDToString(DWORD in_DWORD, WCHAR * out_IntAsString)
{
	swprintf(out_IntAsString, L"%d", in_DWORD);
}


