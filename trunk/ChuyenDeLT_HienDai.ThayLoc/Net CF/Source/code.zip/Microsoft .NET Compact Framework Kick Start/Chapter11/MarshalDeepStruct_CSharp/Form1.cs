using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace MarshalDeepStruct_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnManipulateDeepStruct;
		private System.Windows.Forms.MainMenu mainMenu1;
		[DllImport("ManipulateStruct.dll")]
		private static extern void ManipulateDeepStruct(ref DeepStruct inout_ShallowStruct);

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.btnManipulateDeepStruct = new System.Windows.Forms.Button();
			// 
			// btnManipulateDeepStruct
			// 
			this.btnManipulateDeepStruct.Location = new System.Drawing.Point(24, 216);
			this.btnManipulateDeepStruct.Size = new System.Drawing.Size(184, 32);
			this.btnManipulateDeepStruct.Text = "Manipulate Deep Struct";
			this.btnManipulateDeepStruct.Click += new System.EventHandler(this.btnManipulateDeepStruct_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.btnManipulateDeepStruct);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Puts a null terminator on a string, which makes it usable to native c-style code
		private char[] NullTerminateString(string in_managedString)
		{
			in_managedString += "\0";
			return (in_managedString.ToCharArray());
		}

		private unsafe string NativeStringToManaged(char* in_NativeNullTerminatedString)
		{
			System.Text.StringBuilder l_SB = new System.Text.StringBuilder(100);
			int i = 0;
			while (in_NativeNullTerminatedString[i] != '\0')
			{
				char[] l_toInsert = new char[1];
				l_toInsert[0] = in_NativeNullTerminatedString[i];
				l_SB.Insert(i, l_toInsert);
				i++;
			}
			return l_SB.ToString();
		}

		private void btnManipulateDeepStruct_Click(object sender, System.EventArgs e)
		{
			DeepStruct l_DeepStruct;
			l_DeepStruct = new DeepStruct();
			char [] l_messageBuffer = NullTerminateString(" ello World!");			
			AllIntsInside l_Ints = new AllIntsInside();
			l_Ints.m_one = 1;
			l_Ints.m_two = 2;
			l_Ints.m_three = 3;

			unsafe
			{
				fixed (char * l_ptrMessageBuf = &l_messageBuffer[0])
				{
					l_DeepStruct.m_message = l_ptrMessageBuf;
					l_DeepStruct.m_someInts = &l_Ints;
					//??}
					MessageBox.Show(NativeStringToManaged(l_DeepStruct.m_message), "BEFORE P/INVOKE");
					String l_IntValuesString = "Int Values: " + Convert.ToString(l_DeepStruct.m_someInts->m_one) + "," +
						Convert.ToString(l_DeepStruct.m_someInts->m_two) + "," +
						Convert.ToString(l_DeepStruct.m_someInts->m_three);
					MessageBox.Show(l_IntValuesString, "BEFORE P/INVOKE");
				
					ManipulateDeepStruct(ref l_DeepStruct);
				
					MessageBox.Show(NativeStringToManaged(l_DeepStruct.m_message), "AFTER P/INVOKE");
					l_IntValuesString = "Int Values: " + Convert.ToString(l_DeepStruct.m_someInts->m_one) + "," +
						Convert.ToString(l_DeepStruct.m_someInts->m_two) + "," +
						Convert.ToString(l_DeepStruct.m_someInts->m_three);
					MessageBox.Show(l_IntValuesString, "AFTER P/INVOKE");
				} //??
			}

		}
	}

	public unsafe struct DeepStruct
	{
		public char				* m_message;
		public AllIntsInside	* m_someInts;
	}

	public /*??unsafe*/ struct AllIntsInside
	{
		public int m_one;
		public int m_two;
		public int m_three;
	}
}
