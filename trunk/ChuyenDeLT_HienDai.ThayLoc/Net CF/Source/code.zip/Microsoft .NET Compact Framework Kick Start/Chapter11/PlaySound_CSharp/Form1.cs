using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;

namespace PlaySound_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtSoundFilename;
		private System.Windows.Forms.Button btnPlaySound;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.Button btnPlaySoundContinuously;
		
		const	int		SND_LOOP		= 8;		// See PlaySound_ConstFinder
		const   int     SND_ASYNC		= 1;		// See PlaySound_ConstFinder

		private bool	m_PlayingContinuously;

		[DllImport("coredll.dll")]
			// As defined in the native WinCE API:
			//		BOOL WINAPI PlaySound( 
			//						LPCSTR pszSound, 
			//						HMODULE hmod, 
			//						DWORD fdwSound );
		private static extern bool PlaySound(string pszSound, IntPtr hmod, uint fdwSound);

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.txtSoundFilename = new System.Windows.Forms.TextBox();
			this.btnPlaySound = new System.Windows.Forms.Button();
			this.btnPlaySoundContinuously = new System.Windows.Forms.Button();
			// 
			// txtSoundFilename
			// 
			this.txtSoundFilename.Location = new System.Drawing.Point(8, 24);
			this.txtSoundFilename.Multiline = true;
			this.txtSoundFilename.Size = new System.Drawing.Size(224, 48);
			this.txtSoundFilename.Text = "\\Windows\\notify.wav";
			// 
			// btnPlaySound
			// 
			this.btnPlaySound.Location = new System.Drawing.Point(8, 88);
			this.btnPlaySound.Size = new System.Drawing.Size(224, 32);
			this.btnPlaySound.Text = "Play Sound Once";
			this.btnPlaySound.Click += new System.EventHandler(this.btnPlaySound_Click);
			// 
			// btnPlaySoundContinuously
			// 
			this.btnPlaySoundContinuously.Location = new System.Drawing.Point(8, 136);
			this.btnPlaySoundContinuously.Size = new System.Drawing.Size(224, 32);
			this.btnPlaySoundContinuously.Text = "Play Sound Continuously";
			this.btnPlaySoundContinuously.Click += new System.EventHandler(this.btnPlaySoundContinuously_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.btnPlaySoundContinuously);
			this.Controls.Add(this.btnPlaySound);
			this.Controls.Add(this.txtSoundFilename);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnPlaySound_Click(object sender, System.EventArgs e)
		{
			IntPtr l_NULL = IntPtr.Zero;

			PlaySound(this.txtSoundFilename.Text, l_NULL, 0);		
		}

		private void btnPlaySoundContinuously_Click(object sender, System.EventArgs e)
		{
			IntPtr l_NULL = IntPtr.Zero;

			if(m_PlayingContinuously)
			{
				PlaySound(null, l_NULL, 0);
				m_PlayingContinuously = false;
				this.btnPlaySoundContinuously.Text = "Play Sound Continuously";
			}
			else
			{
				PlaySound(this.txtSoundFilename.Text, l_NULL, SND_LOOP + SND_ASYNC);
				m_PlayingContinuously = true;
				this.btnPlaySoundContinuously.Text = "Stop Playing Sound!!!";
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_PlayingContinuously = false;
		}
	}
}
