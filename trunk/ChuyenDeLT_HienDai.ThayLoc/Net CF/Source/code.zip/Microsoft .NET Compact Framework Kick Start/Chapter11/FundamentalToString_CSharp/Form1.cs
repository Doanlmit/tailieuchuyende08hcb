using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.Runtime.InteropServices;

namespace FundamentalToString_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtIntegerIn;
		private System.Windows.Forms.TextBox txtIntegerOut;
		private System.Windows.Forms.TextBox txtUIntOut;
		private System.Windows.Forms.TextBox txtUIntIn;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnDoConversions;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.TextBox txtLongOut;
		private System.Windows.Forms.TextBox txtLongIn;
		private System.Windows.Forms.Label Long;
		private System.Windows.Forms.TextBox txtFloatOut;
		private System.Windows.Forms.TextBox txtFloatIn;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtULongOut;
		private System.Windows.Forms.TextBox txtULongIn;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtShortOut;
		private System.Windows.Forms.TextBox txtShortIn;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox txtCharOut;
		private System.Windows.Forms.TextBox txtCharIn;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txtUShortOut;
		private System.Windows.Forms.TextBox txtUShortIn;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtBoolOut;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox txtByteOut;
		private System.Windows.Forms.TextBox txtByteIn;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.RadioButton radioBoolIn;
		private System.Windows.Forms.TextBox txtDWORDOut;
		private System.Windows.Forms.TextBox txtDWORDIn;
		private System.Windows.Forms.Label label10;

		const int		MAX_CAPACITY		= 100;

		[DllImport("FundamentalToString.dll")]
		private static extern void IntToString(int in_Int, StringBuilder out_IntAsString);

		[DllImport("FundamentalToString.dll")]
		private static extern void UIntToString(uint in_UInt, StringBuilder out_UIntAsString);


		// Float data types can only be passed from the runtime by reference.
		[DllImport("FundamentalToString.dll")]
		private static extern void FloatToString(ref float in_Float, StringBuilder out_FloatAsString);


		// Long data types can only be passed from the runtime by reference.
		[DllImport("FundamentalToString.dll")]
		private static extern void LongToString(ref long in_Long, StringBuilder out_LongAsString);


		// Unsigned long data types can only be passed from the runtime by reference.
		[DllImport("FundamentalToString.dll")]
		private static extern void ULongToString(ref ulong in_ULong, StringBuilder out_ULongAsString);

		[DllImport("FundamentalToString.dll")]
		private static extern void ShortToString(short in_Short, StringBuilder out_ShortAsString);

		[DllImport("FundamentalToString.dll")]
		private static extern void UShortToString(ushort in_UShort, StringBuilder out_UShortAsString);

		[DllImport("FundamentalToString.dll")]
		private static extern void CharToString(char in_Char, StringBuilder out_CharAsString);

		[DllImport("FundamentalToString.dll")]
		private static extern void ByteToString(byte in_Byte, StringBuilder out_ByteAsString);

		[DllImport("FundamentalToString.dll")]
		private static extern void BoolToString(bool in_Bool, StringBuilder out_BoolAsString);

		// Note: DWORD is a 32 bit type.
		[DllImport("FundamentalToString.dll")]
		private static extern void DWORDToString(UInt32 in_DWORD, StringBuilder  out_DWORDString);

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.label1 = new System.Windows.Forms.Label();
			this.txtIntegerIn = new System.Windows.Forms.TextBox();
			this.txtIntegerOut = new System.Windows.Forms.TextBox();
			this.txtUIntOut = new System.Windows.Forms.TextBox();
			this.txtUIntIn = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnDoConversions = new System.Windows.Forms.Button();
			this.txtLongOut = new System.Windows.Forms.TextBox();
			this.txtLongIn = new System.Windows.Forms.TextBox();
			this.Long = new System.Windows.Forms.Label();
			this.txtFloatOut = new System.Windows.Forms.TextBox();
			this.txtFloatIn = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtULongOut = new System.Windows.Forms.TextBox();
			this.txtULongIn = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtShortOut = new System.Windows.Forms.TextBox();
			this.txtShortIn = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.txtCharOut = new System.Windows.Forms.TextBox();
			this.txtCharIn = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.txtUShortOut = new System.Windows.Forms.TextBox();
			this.txtUShortIn = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtBoolOut = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.txtByteOut = new System.Windows.Forms.TextBox();
			this.txtByteIn = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.radioBoolIn = new System.Windows.Forms.RadioButton();
			this.txtDWORDOut = new System.Windows.Forms.TextBox();
			this.txtDWORDIn = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label1.Size = new System.Drawing.Size(64, 16);
			this.label1.Text = "Int";
			// 
			// txtIntegerIn
			// 
			this.txtIntegerIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtIntegerIn.Location = new System.Drawing.Point(64, 0);
			this.txtIntegerIn.Size = new System.Drawing.Size(24, 21);
			this.txtIntegerIn.Text = "-4";
			// 
			// txtIntegerOut
			// 
			this.txtIntegerOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtIntegerOut.Location = new System.Drawing.Point(88, 0);
			this.txtIntegerOut.ReadOnly = true;
			this.txtIntegerOut.Size = new System.Drawing.Size(24, 21);
			this.txtIntegerOut.Text = "";
			// 
			// txtUIntOut
			// 
			this.txtUIntOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtUIntOut.Location = new System.Drawing.Point(216, 0);
			this.txtUIntOut.ReadOnly = true;
			this.txtUIntOut.Size = new System.Drawing.Size(24, 21);
			this.txtUIntOut.Text = "";
			// 
			// txtUIntIn
			// 
			this.txtUIntIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtUIntIn.Location = new System.Drawing.Point(192, 0);
			this.txtUIntIn.Size = new System.Drawing.Size(24, 21);
			this.txtUIntIn.Text = "4";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label2.Location = new System.Drawing.Point(112, 0);
			this.label2.Size = new System.Drawing.Size(80, 16);
			this.label2.Text = "Unsigned Int";
			// 
			// btnDoConversions
			// 
			this.btnDoConversions.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnDoConversions.Location = new System.Drawing.Point(80, 240);
			this.btnDoConversions.Size = new System.Drawing.Size(72, 24);
			this.btnDoConversions.Text = "Convert";
			this.btnDoConversions.Click += new System.EventHandler(this.btnDoConversions_Click);
			// 
			// txtLongOut
			// 
			this.txtLongOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtLongOut.Location = new System.Drawing.Point(216, 24);
			this.txtLongOut.ReadOnly = true;
			this.txtLongOut.Size = new System.Drawing.Size(24, 21);
			this.txtLongOut.Text = "";
			// 
			// txtLongIn
			// 
			this.txtLongIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtLongIn.Location = new System.Drawing.Point(192, 24);
			this.txtLongIn.Size = new System.Drawing.Size(24, 21);
			this.txtLongIn.Text = "-48";
			// 
			// Long
			// 
			this.Long.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.Long.Location = new System.Drawing.Point(112, 24);
			this.Long.Size = new System.Drawing.Size(80, 16);
			this.Long.Text = "Long";
			// 
			// txtFloatOut
			// 
			this.txtFloatOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtFloatOut.Location = new System.Drawing.Point(88, 24);
			this.txtFloatOut.ReadOnly = true;
			this.txtFloatOut.Size = new System.Drawing.Size(24, 21);
			this.txtFloatOut.Text = "";
			// 
			// txtFloatIn
			// 
			this.txtFloatIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtFloatIn.Location = new System.Drawing.Point(64, 24);
			this.txtFloatIn.Size = new System.Drawing.Size(24, 21);
			this.txtFloatIn.Text = "-4.2";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label4.Location = new System.Drawing.Point(0, 24);
			this.label4.Size = new System.Drawing.Size(64, 16);
			this.label4.Text = "Float";
			// 
			// txtULongOut
			// 
			this.txtULongOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtULongOut.Location = new System.Drawing.Point(216, 48);
			this.txtULongOut.ReadOnly = true;
			this.txtULongOut.Size = new System.Drawing.Size(24, 21);
			this.txtULongOut.Text = "";
			// 
			// txtULongIn
			// 
			this.txtULongIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtULongIn.Location = new System.Drawing.Point(192, 48);
			this.txtULongIn.Size = new System.Drawing.Size(24, 21);
			this.txtULongIn.Text = "48";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label3.Location = new System.Drawing.Point(112, 48);
			this.label3.Size = new System.Drawing.Size(80, 16);
			this.label3.Text = "Unsigned Long";
			// 
			// txtShortOut
			// 
			this.txtShortOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtShortOut.Location = new System.Drawing.Point(88, 48);
			this.txtShortOut.ReadOnly = true;
			this.txtShortOut.Size = new System.Drawing.Size(24, 21);
			this.txtShortOut.Text = "";
			// 
			// txtShortIn
			// 
			this.txtShortIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtShortIn.Location = new System.Drawing.Point(64, 48);
			this.txtShortIn.Size = new System.Drawing.Size(24, 21);
			this.txtShortIn.Text = "-2";
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label5.Location = new System.Drawing.Point(0, 48);
			this.label5.Size = new System.Drawing.Size(64, 16);
			this.label5.Text = "Short";
			// 
			// txtCharOut
			// 
			this.txtCharOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtCharOut.Location = new System.Drawing.Point(216, 72);
			this.txtCharOut.ReadOnly = true;
			this.txtCharOut.Size = new System.Drawing.Size(24, 21);
			this.txtCharOut.Text = "";
			// 
			// txtCharIn
			// 
			this.txtCharIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtCharIn.Location = new System.Drawing.Point(192, 72);
			this.txtCharIn.Size = new System.Drawing.Size(24, 21);
			this.txtCharIn.Text = "c";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label6.Location = new System.Drawing.Point(112, 72);
			this.label6.Size = new System.Drawing.Size(80, 16);
			this.label6.Text = "Char";
			// 
			// txtUShortOut
			// 
			this.txtUShortOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtUShortOut.Location = new System.Drawing.Point(88, 72);
			this.txtUShortOut.ReadOnly = true;
			this.txtUShortOut.Size = new System.Drawing.Size(24, 21);
			this.txtUShortOut.Text = "";
			// 
			// txtUShortIn
			// 
			this.txtUShortIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtUShortIn.Location = new System.Drawing.Point(64, 72);
			this.txtUShortIn.Size = new System.Drawing.Size(24, 21);
			this.txtUShortIn.Text = "2";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label7.Location = new System.Drawing.Point(0, 72);
			this.label7.Size = new System.Drawing.Size(64, 16);
			this.label7.Text = "UShort";
			// 
			// txtBoolOut
			// 
			this.txtBoolOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtBoolOut.Location = new System.Drawing.Point(208, 96);
			this.txtBoolOut.ReadOnly = true;
			this.txtBoolOut.Size = new System.Drawing.Size(32, 21);
			this.txtBoolOut.Text = "";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label8.Location = new System.Drawing.Point(112, 96);
			this.label8.Size = new System.Drawing.Size(80, 16);
			this.label8.Text = "Bool";
			// 
			// txtByteOut
			// 
			this.txtByteOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtByteOut.Location = new System.Drawing.Point(88, 96);
			this.txtByteOut.ReadOnly = true;
			this.txtByteOut.Size = new System.Drawing.Size(24, 21);
			this.txtByteOut.Text = "";
			// 
			// txtByteIn
			// 
			this.txtByteIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtByteIn.Location = new System.Drawing.Point(64, 96);
			this.txtByteIn.Size = new System.Drawing.Size(24, 21);
			this.txtByteIn.Text = "88";
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label9.Location = new System.Drawing.Point(0, 96);
			this.label9.Size = new System.Drawing.Size(64, 16);
			this.label9.Text = "Byte";
			// 
			// radioBoolIn
			// 
			this.radioBoolIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.radioBoolIn.Location = new System.Drawing.Point(160, 96);
			this.radioBoolIn.Size = new System.Drawing.Size(48, 16);
			this.radioBoolIn.Text = "True?";
			// 
			// txtDWORDOut
			// 
			this.txtDWORDOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtDWORDOut.Location = new System.Drawing.Point(88, 120);
			this.txtDWORDOut.ReadOnly = true;
			this.txtDWORDOut.Size = new System.Drawing.Size(24, 21);
			this.txtDWORDOut.Text = "";
			// 
			// txtDWORDIn
			// 
			this.txtDWORDIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.txtDWORDIn.Location = new System.Drawing.Point(64, 120);
			this.txtDWORDIn.Size = new System.Drawing.Size(24, 21);
			this.txtDWORDIn.Text = "231";
			// 
			// label10
			// 
			this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.label10.Location = new System.Drawing.Point(0, 120);
			this.label10.Size = new System.Drawing.Size(64, 16);
			this.label10.Text = "DWORD";
			// 
			// Form1
			// 
			this.Controls.Add(this.txtDWORDOut);
			this.Controls.Add(this.txtDWORDIn);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.radioBoolIn);
			this.Controls.Add(this.txtBoolOut);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.txtByteOut);
			this.Controls.Add(this.txtByteIn);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.txtCharOut);
			this.Controls.Add(this.txtCharIn);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.txtUShortOut);
			this.Controls.Add(this.txtUShortIn);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.txtULongOut);
			this.Controls.Add(this.txtULongIn);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtShortOut);
			this.Controls.Add(this.txtShortIn);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtLongOut);
			this.Controls.Add(this.txtLongIn);
			this.Controls.Add(this.Long);
			this.Controls.Add(this.txtFloatOut);
			this.Controls.Add(this.txtFloatIn);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.btnDoConversions);
			this.Controls.Add(this.txtUIntOut);
			this.Controls.Add(this.txtUIntIn);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtIntegerOut);
			this.Controls.Add(this.txtIntegerIn);
			this.Controls.Add(this.label1);
			this.Menu = this.mainMenu1;
			this.Text = "Native Conversion Demo";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}



		private void DoIntConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			int				in_Int				= Convert.ToInt32(this.txtIntegerIn.Text);
			
			IntToString(in_Int, out_StringBuilder);

			this.txtIntegerOut.Text = out_StringBuilder.ToString();		
		}

		private void DoUIntConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			uint			in_UInt				= Convert.ToUInt32(this.txtUIntIn.Text);
			
			UIntToString(in_UInt, out_StringBuilder);

			this.txtUIntOut.Text = out_StringBuilder.ToString();		
		}

		private void DoFloatConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			float			in_Float			= Convert.ToSingle(this.txtFloatIn.Text);
			
			FloatToString(ref in_Float, out_StringBuilder);

			this.txtFloatOut.Text = out_StringBuilder.ToString();		
		}

		private void DoLongConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			long			in_Long				= Convert.ToInt64(this.txtLongIn.Text);
			
			LongToString(ref in_Long, out_StringBuilder);

			this.txtLongOut.Text = out_StringBuilder.ToString();		
		}


		private void DoULongConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			ulong			in_ULong			= Convert.ToUInt64(this.txtULongIn.Text);
			
			ULongToString(ref in_ULong, out_StringBuilder);

			this.txtULongOut.Text = out_StringBuilder.ToString();		
		}


		private void DoShortConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			short			in_Short			= Convert.ToInt16(this.txtShortIn.Text);
			
			ShortToString(in_Short, out_StringBuilder);

			this.txtShortOut.Text = out_StringBuilder.ToString();		
		}

		private void DoUShortConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			ushort			in_UShort			= Convert.ToUInt16(this.txtUShortIn.Text);
			
			UShortToString(in_UShort, out_StringBuilder);

			this.txtUShortOut.Text = out_StringBuilder.ToString();		
		}

		private void DoCharConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			char			in_Char				= Convert.ToChar(this.txtCharIn.Text);
			
			CharToString(in_Char, out_StringBuilder);

			this.txtCharOut.Text = out_StringBuilder.ToString();		
		}

        private void DoByteConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			byte			in_Byte				= Convert.ToByte(this.txtByteIn.Text);
			
			ByteToString(in_Byte, out_StringBuilder);

			this.txtByteOut.Text = out_StringBuilder.ToString();		
		}

		private void DoBoolConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			bool			in_Bool				= false;
			
			if (this.radioBoolIn.Checked)
			{
				in_Bool = true;
			}
			
			BoolToString(in_Bool, out_StringBuilder);

			this.txtBoolOut.Text = out_StringBuilder.ToString();		
		}

		// Pass the DWORD in as an UInt32
		private void DoDWORDConversion()
		{
			StringBuilder	out_StringBuilder	= new StringBuilder(MAX_CAPACITY);
			UInt32			in_DWORD			= Convert.ToUInt32(this.txtDWORDIn.Text);
			
			DWORDToString(in_DWORD, out_StringBuilder);

			this.txtDWORDOut.Text = out_StringBuilder.ToString();		
		}



		private void btnDoConversions_Click(object sender, System.EventArgs e)
		{
			DoIntConversion();
			DoUIntConversion();
			DoFloatConversion();
			DoLongConversion();
			DoULongConversion();
			DoShortConversion();
			DoUShortConversion();
			DoCharConversion();
			DoByteConversion();
			DoBoolConversion();
			DoDWORDConversion();
		}
	}
}
