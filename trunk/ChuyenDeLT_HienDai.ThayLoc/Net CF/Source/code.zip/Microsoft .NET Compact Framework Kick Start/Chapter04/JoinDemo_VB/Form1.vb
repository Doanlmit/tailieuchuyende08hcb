Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_ThreadAliveMutex As System.Threading.Mutex
    Private m_threadStart As System.Threading.ThreadStart
    Private m_workerThread As System.Threading.Thread
    Private m_isThreadRunning As Boolean


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        '
        'Form1
        '
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region


    Private Sub DoSomeWork()

        m_ThreadAliveMutex.WaitOne()
        m_isThreadRunning = True

        ' Do some work here.  We'll just sleep to simulate work that took a while
        System.Threading.Thread.Sleep(10000)


        ' Release the "alive" mutex on thread exit, indicating that
        ' this thread is dying.
        m_ThreadAliveMutex.ReleaseMutex()

    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_isThreadRunning = False

        m_ThreadAliveMutex = New System.Threading.Mutex(False)

        m_threadStart = New System.Threading.ThreadStart(AddressOf DoSomeWork)
        m_workerThread = New System.Threading.Thread(m_threadStart)

        MessageBox.Show("Starting thread and then waiting for it to finish")

        m_workerThread.Start()

        ' We actually need to know that the thread has started before
        ' we wait for it.
        While (m_isThreadRunning = False)
            System.Threading.Thread.Sleep(0)
        End While

        ' This is like a join - no CPU cycles consumed while we wait
        m_ThreadAliveMutex.WaitOne()
        m_ThreadAliveMutex.ReleaseMutex()

        MessageBox.Show("Worker thread has stopped")
    End Sub
End Class
