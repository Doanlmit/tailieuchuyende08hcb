Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents btnStartAllThreads As System.Windows.Forms.Button
    Friend WithEvents txtDecade As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents txtSingle As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.btnStartAllThreads = New System.Windows.Forms.Button
        Me.txtDecade = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.txtSingle = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        '
        'btnStartAllThreads
        '
        Me.btnStartAllThreads.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnStartAllThreads.Location = New System.Drawing.Point(8, 243)
        Me.btnStartAllThreads.Size = New System.Drawing.Size(112, 24)
        Me.btnStartAllThreads.Text = "Start Threads"
        '
        'txtDecade
        '
        Me.txtDecade.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtDecade.Location = New System.Drawing.Point(8, 139)
        Me.txtDecade.ReadOnly = True
        Me.txtDecade.Size = New System.Drawing.Size(96, 22)
        Me.txtDecade.Text = ""
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(8, 123)
        Me.label2.Size = New System.Drawing.Size(96, 16)
        Me.label2.Text = "Decade Counter:"
        '
        'txtSingle
        '
        Me.txtSingle.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtSingle.Location = New System.Drawing.Point(8, 19)
        Me.txtSingle.ReadOnly = True
        Me.txtSingle.Size = New System.Drawing.Size(96, 22)
        Me.txtSingle.Text = ""
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(8, 3)
        Me.label1.Size = New System.Drawing.Size(96, 16)
        Me.label1.Text = "Singles Counter:"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnStartAllThreads)
        Me.Controls.Add(Me.txtDecade)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtSingle)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region


    Private m_SinglesThreadRunning As Boolean
    Private m_DecadeThreadRunning As Boolean
    Private m_QuitRequested As Boolean

    Private m_singlesWaitCallBack As System.Threading.WaitCallback
    Private m_decadeWaitCallBack As System.Threading.WaitCallback

    Private m_controlInvoker As ControlInvoker

    Private Sub setTextBox(ByVal in_args() As Object)
        Dim in_text As String = in_args(0)
        Dim in_textBox As System.Windows.Forms.TextBox = in_args(1)
        in_textBox.Text = in_text
    End Sub


    Private Sub SinglesCounter(ByVal obj As Object)
        Dim l_currentSinglesCount As Int32 = 0

        While (m_QuitRequested = False)
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(l_currentSinglesCount), Me.txtSingle)
            l_currentSinglesCount += 1
            System.Threading.Thread.Sleep(500)
        End While

        m_SinglesThreadRunning = False

        ' Last thread out closes form
        If (m_DecadeThreadRunning = False) Then
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf ShutDown))
        End If
    End Sub

    Private Sub DecadeCounter(ByVal obj As Object)
        Dim l_currentDecadeCount As Int32 = 0
        While (m_QuitRequested = False)
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(l_currentDecadeCount), Me.txtDecade)
            l_currentDecadeCount += 10
            System.Threading.Thread.Sleep(500)
        End While
        m_DecadeThreadRunning = False


        ' Last thread out closes form
        If (m_SinglesThreadRunning = False) Then
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf ShutDown))
        End If
    End Sub

    Private Sub ShutDown(ByVal arguments() As Object)
        Me.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_SinglesThreadRunning = False
        m_DecadeThreadRunning = False
        m_QuitRequested = False

        m_controlInvoker = New ControlInvoker(Me)
    End Sub
    Private Sub btnStartAllThreads_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartAllThreads.Click
        m_singlesWaitCallBack = New System.Threading.WaitCallback(AddressOf SinglesCounter)
        m_decadeWaitCallBack = New System.Threading.WaitCallback(AddressOf DecadeCounter)
        System.Threading.ThreadPool.QueueUserWorkItem(m_singlesWaitCallBack)
        System.Threading.ThreadPool.QueueUserWorkItem(m_decadeWaitCallBack)
        m_SinglesThreadRunning = True
        m_DecadeThreadRunning = True
    End Sub

    Protected Overrides Sub OnClosing(ByVal e As System.ComponentModel.CancelEventArgs)

        If (m_SinglesThreadRunning Or m_DecadeThreadRunning) Then
            e.Cancel = True
            m_QuitRequested = True
        Else
            Close()
        End If
    End Sub

End Class
