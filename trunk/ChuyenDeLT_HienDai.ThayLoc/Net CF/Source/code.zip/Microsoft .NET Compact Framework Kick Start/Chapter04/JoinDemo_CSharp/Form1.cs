using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace JoinDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;

		System.Threading.Mutex m_ThreadAliveMutex;
		System.Threading.ThreadStart m_threadStart;
		System.Threading.Thread m_workerThread;

		bool m_isThreadRunning;
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			// 
			// Form1
			// 
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void DoSomeWork()
		{
			m_ThreadAliveMutex.WaitOne();
			m_isThreadRunning = true;

			// Do some work here.  We'll just sleep to simulate work that took a while
			System.Threading.Thread.Sleep(10000);


			// Release the "alive" mutex on thread exit, indicating that
			// this thread is dying.
			m_ThreadAliveMutex.ReleaseMutex();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_isThreadRunning = false;

			m_ThreadAliveMutex = new System.Threading.Mutex(false);

			m_threadStart = new System.Threading.ThreadStart(DoSomeWork);
			m_workerThread = new System.Threading.Thread(m_threadStart);

			MessageBox.Show("Starting thread and then waiting for it to finish");

			m_workerThread.Start();

			// We actually need to know that the thread has started before
			// we wait for it.
			while (m_isThreadRunning == false)
			{
				System.Threading.Thread.Sleep(0);
			}

            // This is like a join - np CPU cycles consumed while we wait			
			m_ThreadAliveMutex.WaitOne();
			m_ThreadAliveMutex.ReleaseMutex();

			MessageBox.Show("Worker thread has stopped");

		}
	}
}
