using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using ControlInvokerSample;
using System.ComponentModel;

namespace SuspendAndTerminateThreads_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtDecade;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtSingle;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.Button btnSinglesSuspend;
		private System.Windows.Forms.Button btnDecadeSuspend;
		private System.Windows.Forms.Button btnSinglesResume;
		private System.Windows.Forms.Button btnDecadeResume;

		System.Threading.Thread m_singlesThread;
		System.Threading.ThreadStart m_singlesThreadStart;		
		System.Threading.Thread m_decadeThread;
		System.Threading.ThreadStart m_decadeThreadStart;

		System.Threading.Mutex m_singlesMutex;
		private System.Windows.Forms.Button btnStartThreads;
		System.Threading.Mutex m_decadeMutex;

		bool m_SinglesThreadDeath;
		bool m_DecadeThreadDeath;
		System.Threading.Mutex m_SinglesAliveMutex;
		private System.Windows.Forms.Button btnTerminateDecadeCounter;
		private System.Windows.Forms.Button btnTerminateSinglesCounter;
		System.Threading.Mutex m_DecadeAliveMutex;

		private ControlInvoker m_controlInvoker;

		private bool m_SinglesThreadRunning;
		private bool m_DecadeThreadRunning;
		private bool m_QuitRequested;

		bool m_singlesThreadSuspended;
		bool m_decadeThreadSuspended;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.btnTerminateDecadeCounter = new System.Windows.Forms.Button();
			this.btnTerminateSinglesCounter = new System.Windows.Forms.Button();
			this.btnDecadeSuspend = new System.Windows.Forms.Button();
			this.btnSinglesSuspend = new System.Windows.Forms.Button();
			this.txtDecade = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtSingle = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnSinglesResume = new System.Windows.Forms.Button();
			this.btnDecadeResume = new System.Windows.Forms.Button();
			this.btnStartThreads = new System.Windows.Forms.Button();
			// 
			// btnTerminateDecadeCounter
			// 
			this.btnTerminateDecadeCounter.Location = new System.Drawing.Point(8, 200);
			this.btnTerminateDecadeCounter.Size = new System.Drawing.Size(160, 24);
			this.btnTerminateDecadeCounter.Text = "Terminate";
			this.btnTerminateDecadeCounter.Click += new System.EventHandler(this.btnTerminateRestartDecadeCounter_Click);
			// 
			// btnTerminateSinglesCounter
			// 
			this.btnTerminateSinglesCounter.Location = new System.Drawing.Point(8, 80);
			this.btnTerminateSinglesCounter.Size = new System.Drawing.Size(160, 24);
			this.btnTerminateSinglesCounter.Text = "Terminate";
			this.btnTerminateSinglesCounter.Click += new System.EventHandler(this.btnTerminateRestartSinglesCounter_Click);
			// 
			// btnDecadeSuspend
			// 
			this.btnDecadeSuspend.Location = new System.Drawing.Point(8, 168);
			this.btnDecadeSuspend.Size = new System.Drawing.Size(64, 24);
			this.btnDecadeSuspend.Text = "Suspend";
			this.btnDecadeSuspend.Click += new System.EventHandler(this.btnDecadeSuspend_Click);
			// 
			// btnSinglesSuspend
			// 
			this.btnSinglesSuspend.Location = new System.Drawing.Point(8, 48);
			this.btnSinglesSuspend.Size = new System.Drawing.Size(64, 24);
			this.btnSinglesSuspend.Text = "Suspend";
			this.btnSinglesSuspend.Click += new System.EventHandler(this.btnSinglesSuspend_Click);
			// 
			// txtDecade
			// 
			this.txtDecade.Location = new System.Drawing.Point(8, 139);
			this.txtDecade.ReadOnly = true;
			this.txtDecade.Size = new System.Drawing.Size(160, 22);
			this.txtDecade.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(0, 123);
			this.label2.Size = new System.Drawing.Size(96, 16);
			this.label2.Text = "Decade Counter:";
			// 
			// txtSingle
			// 
			this.txtSingle.Location = new System.Drawing.Point(8, 19);
			this.txtSingle.ReadOnly = true;
			this.txtSingle.Size = new System.Drawing.Size(160, 22);
			this.txtSingle.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(0, 3);
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.Text = "Singles Counter:";
			// 
			// btnSinglesResume
			// 
			this.btnSinglesResume.Location = new System.Drawing.Point(96, 48);
			this.btnSinglesResume.Size = new System.Drawing.Size(72, 24);
			this.btnSinglesResume.Text = "Resume";
			this.btnSinglesResume.Click += new System.EventHandler(this.btnSinglesResume_Click);
			// 
			// btnDecadeResume
			// 
			this.btnDecadeResume.Location = new System.Drawing.Point(104, 168);
			this.btnDecadeResume.Size = new System.Drawing.Size(64, 24);
			this.btnDecadeResume.Text = "Resume";
			this.btnDecadeResume.Click += new System.EventHandler(this.btnDecadeResume_Click);
			// 
			// btnStartThreads
			// 
			this.btnStartThreads.Location = new System.Drawing.Point(8, 240);
			this.btnStartThreads.Size = new System.Drawing.Size(128, 24);
			this.btnStartThreads.Text = "Start Threads";
			this.btnStartThreads.Click += new System.EventHandler(this.btnStartThreads_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.btnStartThreads);
			this.Controls.Add(this.btnDecadeResume);
			this.Controls.Add(this.btnSinglesResume);
			this.Controls.Add(this.btnTerminateDecadeCounter);
			this.Controls.Add(this.btnTerminateSinglesCounter);
			this.Controls.Add(this.btnDecadeSuspend);
			this.Controls.Add(this.btnSinglesSuspend);
			this.Controls.Add(this.txtDecade);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtSingle);
			this.Controls.Add(this.label1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		
		private void setTextBox(object[] in_args)
		{
			string in_text = (string)in_args[0];
			System.Windows.Forms.TextBox in_textBox = (System.Windows.Forms.TextBox)in_args[1];
			in_textBox.Text = in_text;
		}


		private void SinglesCounter()
		{
			m_SinglesThreadRunning = true;
			int l_currentCount = 0;
			m_SinglesThreadDeath = false;
			m_SinglesAliveMutex.WaitOne();
			while (!m_SinglesThreadDeath)
			{
				// Surround body of thread with mutex access request.  Another party can
				// effectively suspend this thread by calling m_singledMutex.WaitOne() 
				m_singlesMutex.WaitOne();
				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(l_currentCount), this.txtSingle);
				l_currentCount++;
				System.Threading.Thread.Sleep(500);
				m_singlesMutex.ReleaseMutex();
			}

			// Release the "alive" mutex on thread exit, indicating that
			// this thread is dying.  Advanced applications would want to know
			// this fact before attempting to re-start the thread
			m_SinglesAliveMutex.ReleaseMutex();

			m_SinglesThreadRunning = false;

			
			// Last thread out closes form
			if (m_QuitRequested && !m_DecadeThreadRunning)
				m_controlInvoker.Invoke(new MethodCallInvoker(ShutDown));
		}



		private void DecadeCounter()
		{
			m_DecadeThreadRunning = true;
			int l_currentCount = 0;
			m_DecadeThreadDeath = false;
			m_DecadeAliveMutex.WaitOne();
			while (!m_DecadeThreadDeath)
			{
				// Surround body of thread with mutex access request.  Another party can
				// effectively suspend this thread by calling m_decadeMutex.WaitOne() 
				m_decadeMutex.WaitOne();
				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(l_currentCount), this.txtDecade);
				l_currentCount += 10;
				System.Threading.Thread.Sleep(500);
				m_decadeMutex.ReleaseMutex();
			}

			// Release the "alive" mutex on thread exit, indicating that
			// this thread is dying and it could be re-started.
			m_DecadeAliveMutex.ReleaseMutex();
			m_DecadeThreadRunning = false;

			// Last thread out closes form
			if (m_QuitRequested && !m_SinglesThreadRunning)
				m_controlInvoker.Invoke(new MethodCallInvoker(ShutDown));
		}


		private void Form1_Load(object sender, System.EventArgs e)
		{			
			m_QuitRequested = false;
			m_singlesThreadStart = new System.Threading.ThreadStart(SinglesCounter);
			m_singlesThread = new System.Threading.Thread(m_singlesThreadStart);

			m_decadeThreadStart = new System.Threading.ThreadStart(DecadeCounter);
			m_decadeThread = new System.Threading.Thread(m_decadeThreadStart);

			m_singlesMutex = new System.Threading.Mutex(false);
			m_decadeMutex = new System.Threading.Mutex(false);
			m_SinglesAliveMutex = new System.Threading.Mutex(false);
			m_DecadeAliveMutex = new System.Threading.Mutex(false);

			m_singlesThreadSuspended = false;
			m_decadeThreadSuspended = false;


			m_SinglesThreadDeath = false;
			m_DecadeThreadDeath = false;

			m_controlInvoker = new ControlInvoker(this);
			m_SinglesThreadRunning = false;
			m_DecadeThreadRunning = false;
		}


		private void ShutDown(object[] arguments) 
		{
			this.Close();
		}



		private void btnStartThreads_Click(object sender, System.EventArgs e)
		{
			m_singlesThread.Start();
			m_decadeThread.Start();	
		}

		private void btnSinglesSuspend_Click(object sender, System.EventArgs e)
		{
			m_singlesMutex.WaitOne();
			m_singlesThreadSuspended = true;
			this.btnSinglesSuspend.Enabled = false;
			this.btnSinglesResume.Enabled = true;
		}

		private void btnSinglesResume_Click(object sender, System.EventArgs e)
		{
			m_singlesMutex.ReleaseMutex();
			m_singlesThreadSuspended = false;
			this.btnSinglesSuspend.Enabled = true;
			this.btnSinglesResume.Enabled = false;
		}

		private void btnDecadeSuspend_Click(object sender, System.EventArgs e)
		{
			m_decadeMutex.WaitOne();
	        m_decadeThreadSuspended = true;
			this.btnDecadeSuspend.Enabled = false;
			this.btnDecadeResume.Enabled = true;		
		}

		private void btnDecadeResume_Click(object sender, System.EventArgs e)
		{
			m_decadeMutex.ReleaseMutex();
			m_decadeThreadSuspended = true;
			this.btnDecadeSuspend.Enabled = true;
			this.btnDecadeResume.Enabled = false;				
		}

		private void btnTerminateRestartSinglesCounter_Click(object sender, System.EventArgs e)
		{
			KillSinglesThread();
		}

		private void KillSinglesThread()
		{
			// Ask for cooperative thread death
			m_SinglesThreadDeath = true;

			// Then wait for the thread to actually die
			m_SinglesAliveMutex.WaitOne();
			m_SinglesAliveMutex.ReleaseMutex();
		}

		private void btnTerminateRestartDecadeCounter_Click(object sender, System.EventArgs e)
		{
			KillDecadeThread();
		}

		private void KillDecadeThread()
		{
			// Ask for cooperative thread death
			m_DecadeThreadDeath = true;

			// Then wait for the thread to actually die
			m_DecadeAliveMutex.WaitOne();
			m_DecadeAliveMutex.ReleaseMutex();
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			if (m_SinglesThreadRunning || m_DecadeThreadRunning)	
			{
				// Unsuspend threads so they can cooperatively quit
				if (m_singlesThreadSuspended)
				{
					m_singlesMutex.ReleaseMutex();
				}
				if (m_decadeThreadSuspended) 
				{
					m_decadeMutex.ReleaseMutex();
				}

				m_QuitRequested = true;
				m_SinglesThreadDeath = true;
				m_DecadeThreadDeath = true;
				e.Cancel = true;
			}
			else
			{
				Close();
			}
		}


	}
}
