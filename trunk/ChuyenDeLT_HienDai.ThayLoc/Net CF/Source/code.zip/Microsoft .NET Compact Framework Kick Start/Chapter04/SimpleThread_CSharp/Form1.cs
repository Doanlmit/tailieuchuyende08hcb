using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using ControlInvokerSample;
using System.ComponentModel;

namespace SimpleThread_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtSingle;
		private System.Windows.Forms.TextBox txtDecade;
		private System.Windows.Forms.Button btnStartAllThreads;
		private System.Windows.Forms.MainMenu mainMenu1;

		System.Threading.Thread m_singlesThread;
		System.Threading.ThreadStart m_singlesThreadStart;
		
		System.Threading.Thread m_decadeThread;
		System.Threading.ThreadStart m_decadeThreadStart;

		private bool m_SinglesThreadRunning;
		private bool m_DecadeThreadRunning;
		private bool m_QuitRequested;

		private ControlInvoker m_controlInvoker;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.label1 = new System.Windows.Forms.Label();
			this.txtSingle = new System.Windows.Forms.TextBox();
			this.txtDecade = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.btnStartAllThreads = new System.Windows.Forms.Button();
			// 
			// label1
			// 
			this.label1.Size = new System.Drawing.Size(96, 16);
			this.label1.Text = "Singles Counter:";
			// 
			// txtSingle
			// 
			this.txtSingle.Location = new System.Drawing.Point(8, 16);
			this.txtSingle.ReadOnly = true;
			this.txtSingle.Size = new System.Drawing.Size(160, 22);
			this.txtSingle.Text = "";
			// 
			// txtDecade
			// 
			this.txtDecade.Location = new System.Drawing.Point(8, 136);
			this.txtDecade.ReadOnly = true;
			this.txtDecade.Size = new System.Drawing.Size(96, 22);
			this.txtDecade.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(0, 120);
			this.label2.Size = new System.Drawing.Size(96, 16);
			this.label2.Text = "Decade Counter:";
			// 
			// btnStartAllThreads
			// 
			this.btnStartAllThreads.Location = new System.Drawing.Point(0, 240);
			this.btnStartAllThreads.Size = new System.Drawing.Size(112, 24);
			this.btnStartAllThreads.Text = "Start Threads";
			this.btnStartAllThreads.Click += new System.EventHandler(this.btnStartAllThreads_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.btnStartAllThreads);
			this.Controls.Add(this.txtDecade);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtSingle);
			this.Controls.Add(this.label1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}



		private void setTextBox(object[] in_args)
		{
			string in_text = (string)in_args[0];
			System.Windows.Forms.TextBox in_textBox = (System.Windows.Forms.TextBox)in_args[1];
			in_textBox.Text = in_text;
		}


		private void SinglesCounter()
		{
			int l_currentSinglesCount = 0;
			while (!m_QuitRequested)
			{
				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(l_currentSinglesCount), this.txtSingle);
				l_currentSinglesCount++;
				System.Threading.Thread.Sleep(200);
			}
			m_SinglesThreadRunning = false;

			// Last thread out closes form
			if (m_DecadeThreadRunning == false)
				m_controlInvoker.Invoke(new MethodCallInvoker(ShutDown));
		}


		private void DecadeCounter()
		{
			int l_currentDecadeCount = 0;
			while (!m_QuitRequested)
			{
				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(l_currentDecadeCount), this.txtDecade);
				l_currentDecadeCount += 10;
				System.Threading.Thread.Sleep(200);
			}
			m_DecadeThreadRunning = false;


			// Last thread out closes form
			if (m_SinglesThreadRunning == false)
				m_controlInvoker.Invoke(new MethodCallInvoker(ShutDown));
		}



		private void ShutDown(object[] arguments) 
		{
			this.Close();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{			
			m_SinglesThreadRunning = false;
			m_DecadeThreadRunning = false;
			m_QuitRequested = false;

			m_singlesThreadStart = new System.Threading.ThreadStart(SinglesCounter);
			m_singlesThread = new System.Threading.Thread(m_singlesThreadStart);

			m_decadeThreadStart = new System.Threading.ThreadStart(DecadeCounter);
			m_decadeThread = new System.Threading.Thread(m_decadeThreadStart);

			m_controlInvoker = new ControlInvoker(this);
		}


		private void btnStartAllThreads_Click(object sender, System.EventArgs e)
		{
			m_singlesThread.Start();
			m_decadeThread.Start();	
			m_SinglesThreadRunning = true;
			m_DecadeThreadRunning = true;
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			if (m_SinglesThreadRunning || m_DecadeThreadRunning)	
			{
				e.Cancel = true;
				MessageBox.Show("Will wait for threads to stop, then quit");
				m_QuitRequested = true;
			}
			else
			{
				Close();
			}
		}
	}
}
