Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents txtConsumed As System.Windows.Forms.TextBox
    Friend WithEvents txtProduced As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents txtObjectsAvailable As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents btnStartThreads As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private m_objectsAvailable As Int32
    Private m_producerThread As System.Threading.Thread
    Private m_producerThreadStart As System.Threading.ThreadStart
    Private m_consumerThread As System.Threading.Thread
    Private m_consumerThreadStart As System.Threading.ThreadStart

    Private m_ProducerThreadRunning As Boolean
    Private m_ConsumerThreadRunning As Boolean
    Private m_QuitRequested As Boolean

    Private m_lockObject As Object

    Private m_controlInvoker As ControlInvoker

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.txtConsumed = New System.Windows.Forms.TextBox
        Me.txtProduced = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.txtObjectsAvailable = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.btnStartThreads = New System.Windows.Forms.Button
        '
        'txtConsumed
        '
        Me.txtConsumed.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtConsumed.Location = New System.Drawing.Point(136, 160)
        Me.txtConsumed.Size = New System.Drawing.Size(96, 22)
        Me.txtConsumed.Text = ""
        '
        'txtProduced
        '
        Me.txtProduced.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtProduced.Location = New System.Drawing.Point(136, 128)
        Me.txtProduced.Size = New System.Drawing.Size(96, 22)
        Me.txtProduced.Text = ""
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label3.Location = New System.Drawing.Point(16, 160)
        Me.label3.Size = New System.Drawing.Size(104, 16)
        Me.label3.Text = "Total Consumed"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(16, 128)
        Me.label2.Size = New System.Drawing.Size(88, 24)
        Me.label2.Text = "Total Produced"
        '
        'txtObjectsAvailable
        '
        Me.txtObjectsAvailable.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtObjectsAvailable.Location = New System.Drawing.Point(16, 40)
        Me.txtObjectsAvailable.Size = New System.Drawing.Size(168, 22)
        Me.txtObjectsAvailable.Text = ""
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(8, 16)
        Me.label1.Size = New System.Drawing.Size(200, 24)
        Me.label1.Text = "Objects Available For Consumption"
        '
        'btnStartThreads
        '
        Me.btnStartThreads.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnStartThreads.Location = New System.Drawing.Point(16, 80)
        Me.btnStartThreads.Size = New System.Drawing.Size(168, 24)
        Me.btnStartThreads.Text = "Start Threads"
        '
        'Form1
        '
        Me.Controls.Add(Me.txtConsumed)
        Me.Controls.Add(Me.txtProduced)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtObjectsAvailable)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.btnStartThreads)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    Private Sub setTextBox(ByVal in_args() As Object)
        Dim in_text As String = in_args(0)
        Dim in_textBox As System.Windows.Forms.TextBox = in_args(1)
        in_textBox.Text = in_text
    End Sub


    Private Sub ProducerMethod()
        Dim l_produced As Int32 = 0
        While (m_QuitRequested = False)

            System.Threading.Monitor.Enter(m_lockObject)
            m_objectsAvailable += 1
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(m_objectsAvailable), Me.txtObjectsAvailable)
            System.Threading.Monitor.Exit(m_lockObject)


            l_produced += 1
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(l_produced), Me.txtProduced)

            System.Threading.Thread.Sleep(500)
        End While
        m_ProducerThreadRunning = False

        ' Last thread out closes form
        If (m_ConsumerThreadRunning = False) Then
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf ShutDown))
        End If
    End Sub

    Private Sub ConsumerMethod()
        Dim l_consumed As Int32 = 0
        While (m_QuitRequested = False)
            System.Threading.Monitor.Enter(m_lockObject)
            If (m_objectsAvailable > 0) Then
                m_objectsAvailable -= 1
                l_consumed += 1
            End If

            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(m_objectsAvailable), Me.txtObjectsAvailable)
            System.Threading.Monitor.Exit(m_lockObject)

            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(l_consumed), Me.txtConsumed)

            System.Threading.Thread.Sleep(300)
        End While

        m_ConsumerThreadRunning = False

        ' Last thread out closes form
        If (m_ProducerThreadRunning = False) Then
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf ShutDown))
        End If

    End Sub


    Private Sub ShutDown(ByVal arguments() As Object)
        Me.Close()
    End Sub

    Private Sub btnStartThreads_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartThreads.Click
        m_producerThread.Start()
        m_consumerThread.Start()
        m_ProducerThreadRunning = True
        m_ConsumerThreadRunning = True
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_ProducerThreadRunning = False
        m_ConsumerThreadRunning = False
        m_QuitRequested = False

        m_objectsAvailable = 4  ' Default
        Me.txtObjectsAvailable.Text = m_objectsAvailable.ToString()

        m_producerThreadStart = New System.Threading.ThreadStart(AddressOf ProducerMethod)
        m_producerThread = New System.Threading.Thread(m_producerThreadStart)
        m_consumerThreadStart = New System.Threading.ThreadStart(AddressOf ConsumerMethod)
        m_consumerThread = New System.Threading.Thread(m_consumerThreadStart)

        m_lockObject = New Object
        m_controlInvoker = New ControlInvoker(Me)
    End Sub
    Protected Overrides Sub OnClosing(ByVal e As System.ComponentModel.CancelEventArgs)
        If (m_ProducerThreadRunning Or m_ConsumerThreadRunning) Then
            e.Cancel = True
            MessageBox.Show("Will wait for threads to stop, then quit")
            m_QuitRequested = True
        Else
            Close()
        End If
    End Sub
End Class
