Imports System
Imports System.Collections
Imports System.Windows.Forms

' This code is available from: http://samples.gotdotnet.com/quickstart/CompactFramework/doc/controlinvoker.aspx
' Used with permission


Public Delegate Sub MethodCallInvoker(ByVal o() As Object)

' Control.Invoke allows a method to be invoked on the same thread as the one
' the control was created on.  Unlike in the full .NET Framework, the .NET
' Compact Framework does not support the Control.Invoke overload for passing an 
' array of objects to pass as arguments.  This ControlInvoker class overcomes
' this limitation.


Public Class ControlInvoker

    Private Class MethodCall
        Public invoker As MethodCallInvoker
        Public arguments() As Object


        Public Sub New(ByVal invoker As MethodCallInvoker, ByVal arguments() As Object)
            Me.invoker = invoker
            Me.arguments = arguments
        End Sub 'New
    End Class 'MethodCall

    Private control As Control
    Private argumentInvokeList As New Queue


    ' The constructor typically takes a form
    Public Sub New(ByVal control As Control)
        Me.control = control
    End Sub 'New


    ' The delegate wrapping the method and its arguments 
    ' to be called on the same thread as the control.
    Public Sub Invoke(ByVal invoker As MethodCallInvoker, ByVal ParamArray arguments() As Object)
        Me.argumentInvokeList.Enqueue(New MethodCall(invoker, arguments))
        control.Invoke(New EventHandler(AddressOf ControlInvoke))
    End Sub 'Invoke


    Private Sub ControlInvoke(ByVal sender As Object, ByVal e As EventArgs)
        Dim methodCall As MethodCall = CType(argumentInvokeList.Dequeue(), MethodCall)
        methodCall.invoker(methodCall.arguments)
    End Sub 'ControlInvoke
End Class 'ControlInvoker
