Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents DecadeTimer As System.Windows.Forms.Timer
    Friend WithEvents lblSingles As System.Windows.Forms.Label
    Friend WithEvents txtSingles As System.Windows.Forms.TextBox
    Friend WithEvents lblDecades As System.Windows.Forms.Label
    Friend WithEvents txtDecade As System.Windows.Forms.TextBox
    Friend WithEvents btnSinglesPause As System.Windows.Forms.Button
    Friend WithEvents btnStartSingles As System.Windows.Forms.Button
    Friend WithEvents btnDecadePause As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Dim m_SinglesCount As Integer
    Dim m_DecadeCount As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnStartDecade As System.Windows.Forms.Button
    Friend WithEvents singlesTimer As System.Windows.Forms.Timer
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.singlesTimer = New System.Windows.Forms.Timer
        Me.DecadeTimer = New System.Windows.Forms.Timer
        Me.lblSingles = New System.Windows.Forms.Label
        Me.txtSingles = New System.Windows.Forms.TextBox
        Me.lblDecades = New System.Windows.Forms.Label
        Me.txtDecade = New System.Windows.Forms.TextBox
        Me.btnSinglesPause = New System.Windows.Forms.Button
        Me.btnStartSingles = New System.Windows.Forms.Button
        Me.btnDecadePause = New System.Windows.Forms.Button
        Me.btnStartDecade = New System.Windows.Forms.Button
        '
        'singlesTimer
        '
        Me.singlesTimer.Interval = 500
        '
        'DecadeTimer
        '
        Me.DecadeTimer.Interval = 500
        '
        'lblSingles
        '
        Me.lblSingles.Location = New System.Drawing.Point(8, 8)
        Me.lblSingles.Size = New System.Drawing.Size(104, 16)
        Me.lblSingles.Text = "Singles Counter"
        '
        'txtSingles
        '
        Me.txtSingles.Location = New System.Drawing.Point(8, 24)
        Me.txtSingles.Size = New System.Drawing.Size(104, 22)
        Me.txtSingles.Text = ""
        '
        'lblDecades
        '
        Me.lblDecades.Location = New System.Drawing.Point(8, 112)
        Me.lblDecades.Size = New System.Drawing.Size(112, 16)
        Me.lblDecades.Text = "Decade Counter"
        '
        'txtDecade
        '
        Me.txtDecade.Location = New System.Drawing.Point(8, 128)
        Me.txtDecade.Size = New System.Drawing.Size(104, 22)
        Me.txtDecade.Text = ""
        '
        'btnSinglesPause
        '
        Me.btnSinglesPause.Location = New System.Drawing.Point(8, 56)
        Me.btnSinglesPause.Size = New System.Drawing.Size(104, 24)
        Me.btnSinglesPause.Text = "Pause"
        '
        'btnStartSingles
        '
        Me.btnStartSingles.Location = New System.Drawing.Point(120, 56)
        Me.btnStartSingles.Size = New System.Drawing.Size(104, 24)
        Me.btnStartSingles.Text = "Start / Resume"
        '
        'btnDecadePause
        '
        Me.btnDecadePause.Location = New System.Drawing.Point(8, 160)
        Me.btnDecadePause.Size = New System.Drawing.Size(104, 24)
        Me.btnDecadePause.Text = "Pause"
        '
        'btnStartDecade
        '
        Me.btnStartDecade.Location = New System.Drawing.Point(120, 160)
        Me.btnStartDecade.Size = New System.Drawing.Size(104, 24)
        Me.btnStartDecade.Text = "Start / Resume"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnStartDecade)
        Me.Controls.Add(Me.btnDecadePause)
        Me.Controls.Add(Me.btnStartSingles)
        Me.Controls.Add(Me.btnSinglesPause)
        Me.Controls.Add(Me.txtDecade)
        Me.Controls.Add(Me.lblDecades)
        Me.Controls.Add(Me.txtSingles)
        Me.Controls.Add(Me.lblSingles)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_SinglesCount = 0
        m_DecadeCount = 0
    End Sub


    Private Sub DecadeTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DecadeTimer.Tick
        Me.txtDecade.Text = Convert.ToString(m_DecadeCount)
        m_DecadeCount = m_DecadeCount + 10
    End Sub

    Private Sub btnSinglesPause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSinglesPause.Click
        Me.singlesTimer.Enabled = False
    End Sub

    Private Sub btnStartSingles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartSingles.Click
        Me.singlesTimer.Enabled = True
    End Sub

    Private Sub btnDecadePause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDecadePause.Click
        Me.DecadeTimer.Enabled = False
    End Sub

    Private Sub singlesTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles singlesTimer.Tick
        Me.txtSingles.Text = Convert.ToString(m_SinglesCount)
        m_SinglesCount = m_SinglesCount + 1
    End Sub

    Private Sub btnStartDecade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartDecade.Click
        Me.DecadeTimer.Enabled = True
    End Sub
End Class
