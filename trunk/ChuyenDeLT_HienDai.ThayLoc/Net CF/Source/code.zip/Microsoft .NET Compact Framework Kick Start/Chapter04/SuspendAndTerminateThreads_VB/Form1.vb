Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents btnStartThreads As System.Windows.Forms.Button
    Friend WithEvents btnDecadeResume As System.Windows.Forms.Button
    Friend WithEvents btnSinglesResume As System.Windows.Forms.Button
    Friend WithEvents btnTerminateDecadeCounter As System.Windows.Forms.Button
    Friend WithEvents btnTerminateSinglesCounter As System.Windows.Forms.Button
    Friend WithEvents btnDecadeSuspend As System.Windows.Forms.Button
    Friend WithEvents btnSinglesSuspend As System.Windows.Forms.Button
    Friend WithEvents txtDecade As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents txtSingle As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_singlesThread As System.Threading.Thread
    Private m_singlesThreadStart As System.Threading.ThreadStart
    Private m_decadeThread As System.Threading.Thread
    Private m_decadeThreadStart As System.Threading.ThreadStart

    Private m_singlesMutex As System.Threading.Mutex
    Private m_decadeMutex As System.Threading.Mutex

    Private m_SinglesThreadDeath As Boolean
    Private m_DecadeThreadDeath As Boolean
    Private m_SinglesAliveMutex As System.Threading.Mutex
    Private m_DecadeAliveMutex As System.Threading.Mutex

    Private m_controlInvoker As ControlInvoker
    Private m_singlesThreadSuspended As Boolean
    Private m_decadeThreadSuspended As Boolean

    Private m_SinglesThreadRunning As Boolean
    Private m_DecadeThreadRunning As Boolean
    Private m_QuitRequested As Boolean


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.btnStartThreads = New System.Windows.Forms.Button
        Me.btnDecadeResume = New System.Windows.Forms.Button
        Me.btnSinglesResume = New System.Windows.Forms.Button
        Me.btnTerminateDecadeCounter = New System.Windows.Forms.Button
        Me.btnTerminateSinglesCounter = New System.Windows.Forms.Button
        Me.btnDecadeSuspend = New System.Windows.Forms.Button
        Me.btnSinglesSuspend = New System.Windows.Forms.Button
        Me.txtDecade = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.txtSingle = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        '
        'btnStartThreads
        '
        Me.btnStartThreads.Location = New System.Drawing.Point(8, 242)
        Me.btnStartThreads.Size = New System.Drawing.Size(128, 24)
        Me.btnStartThreads.Text = "Start Threads"
        '
        'btnDecadeResume
        '
        Me.btnDecadeResume.Location = New System.Drawing.Point(104, 170)
        Me.btnDecadeResume.Size = New System.Drawing.Size(64, 24)
        Me.btnDecadeResume.Text = "Resume"
        '
        'btnSinglesResume
        '
        Me.btnSinglesResume.Location = New System.Drawing.Point(96, 50)
        Me.btnSinglesResume.Size = New System.Drawing.Size(72, 24)
        Me.btnSinglesResume.Text = "Resume"
        '
        'btnTerminateDecadeCounter
        '
        Me.btnTerminateDecadeCounter.Location = New System.Drawing.Point(8, 202)
        Me.btnTerminateDecadeCounter.Size = New System.Drawing.Size(160, 24)
        Me.btnTerminateDecadeCounter.Text = "Terminate"
        '
        'btnTerminateSinglesCounter
        '
        Me.btnTerminateSinglesCounter.Location = New System.Drawing.Point(8, 82)
        Me.btnTerminateSinglesCounter.Size = New System.Drawing.Size(160, 24)
        Me.btnTerminateSinglesCounter.Text = "Terminate"
        '
        'btnDecadeSuspend
        '
        Me.btnDecadeSuspend.Location = New System.Drawing.Point(8, 170)
        Me.btnDecadeSuspend.Size = New System.Drawing.Size(64, 24)
        Me.btnDecadeSuspend.Text = "Suspend"
        '
        'btnSinglesSuspend
        '
        Me.btnSinglesSuspend.Location = New System.Drawing.Point(8, 50)
        Me.btnSinglesSuspend.Size = New System.Drawing.Size(64, 24)
        Me.btnSinglesSuspend.Text = "Suspend"
        '
        'txtDecade
        '
        Me.txtDecade.Location = New System.Drawing.Point(8, 141)
        Me.txtDecade.ReadOnly = True
        Me.txtDecade.Size = New System.Drawing.Size(160, 22)
        Me.txtDecade.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(0, 125)
        Me.label2.Size = New System.Drawing.Size(96, 16)
        Me.label2.Text = "Decade Counter:"
        '
        'txtSingle
        '
        Me.txtSingle.Location = New System.Drawing.Point(8, 21)
        Me.txtSingle.ReadOnly = True
        Me.txtSingle.Size = New System.Drawing.Size(160, 22)
        Me.txtSingle.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(0, 5)
        Me.label1.Size = New System.Drawing.Size(96, 16)
        Me.label1.Text = "Singles Counter:"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnStartThreads)
        Me.Controls.Add(Me.btnDecadeResume)
        Me.Controls.Add(Me.btnSinglesResume)
        Me.Controls.Add(Me.btnTerminateDecadeCounter)
        Me.Controls.Add(Me.btnTerminateSinglesCounter)
        Me.Controls.Add(Me.btnDecadeSuspend)
        Me.Controls.Add(Me.btnSinglesSuspend)
        Me.Controls.Add(Me.txtDecade)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtSingle)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    Private Sub setTextBox(ByVal in_args() As Object)
        Dim in_text As String
        in_text = in_args(0)
        Dim in_textBox As System.Windows.Forms.TextBox
        in_textBox = in_args(1)
        in_textBox.Text = in_text
    End Sub

    Private Sub SinglesCounter()
        m_SinglesThreadRunning = True
        Dim l_currentCount As Int32 = 0
        m_SinglesThreadDeath = False
        m_SinglesAliveMutex.WaitOne()
        While (m_SinglesThreadDeath = False)

            ' Surround body of thread with mutex access request.  Another party can
            ' effectively suspend this thread by calling m_singledMutex.WaitOne() 
            m_singlesMutex.WaitOne()
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(l_currentCount), Me.txtSingle)
            l_currentCount = l_currentCount + 1
            System.Threading.Thread.Sleep(500)
            m_singlesMutex.ReleaseMutex()

        End While
        ' Release the "alive" mutex on thread exit, indicating that
        ' this thread is dying.  Advanced applications would want to know
        ' this fact before attempting to re-start the thread
        m_SinglesAliveMutex.ReleaseMutex()

        m_SinglesThreadRunning = False


        ' Last thread out closes form
        If (m_QuitRequested = True And m_DecadeThreadRunning = False) Then
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf ShutDown))
        End If

    End Sub


    Private Sub DecadeCounter()
        m_DecadeThreadRunning = True
        Dim l_currentCount As Int32 = 0
        m_DecadeThreadDeath = False
        m_DecadeAliveMutex.WaitOne()
        While (m_DecadeThreadDeath = False)
            ' Surround body of thread with mutex access request.  Another party can
            ' effectively suspend this thread by calling m_decadeMutex.WaitOne() 
            m_decadeMutex.WaitOne()
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf setTextBox), Convert.ToString(l_currentCount), Me.txtDecade)
            l_currentCount += 10
            System.Threading.Thread.Sleep(500)
            m_decadeMutex.ReleaseMutex()
        End While
        ' Release the "alive" mutex on thread exit, indicating that
        ' this thread is dying and it could be re-started.
        m_DecadeAliveMutex.ReleaseMutex()
        m_DecadeThreadRunning = False

        ' Last thread out closes form
        If (m_QuitRequested = True And m_SinglesThreadRunning = False) Then
            m_controlInvoker.Invoke(New MethodCallInvoker(AddressOf ShutDown))
        End If
    End Sub

    Private Sub ShutDown(ByVal arguments() As Object)
        Me.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_QuitRequested = False
        m_singlesThreadStart = New System.Threading.ThreadStart(AddressOf SinglesCounter)
        m_singlesThread = New System.Threading.Thread(m_singlesThreadStart)

        m_decadeThreadStart = New System.Threading.ThreadStart(AddressOf DecadeCounter)
        m_decadeThread = New System.Threading.Thread(m_decadeThreadStart)

        m_singlesMutex = New System.Threading.Mutex(False)
        m_decadeMutex = New System.Threading.Mutex(False)
        m_SinglesAliveMutex = New System.Threading.Mutex(False)
        m_DecadeAliveMutex = New System.Threading.Mutex(False)

        m_singlesThreadSuspended = False
        m_decadeThreadSuspended = False

        m_SinglesThreadDeath = False
        m_DecadeThreadDeath = False

        m_controlInvoker = New ControlInvoker(Me)
        m_SinglesThreadRunning = False
        m_DecadeThreadRunning = False
    End Sub

    Private Sub KillDecadeThread()
        ' Ask for cooperative thread death
        m_DecadeThreadDeath = True

        ' Then wait for the thread to actually die
        m_DecadeAliveMutex.WaitOne()
        m_DecadeAliveMutex.ReleaseMutex()
    End Sub

    Private Sub KillSinglesThread()
        ' Ask for cooperative thread death
        m_SinglesThreadDeath = True

        ' Then wait for the thread to actually die
        m_SinglesAliveMutex.WaitOne()
        m_SinglesAliveMutex.ReleaseMutex()
    End Sub

    Protected Overrides Sub OnClosing(ByVal e As System.ComponentModel.CancelEventArgs)
        If (m_SinglesThreadRunning = True Or m_DecadeThreadRunning = True) Then
            ' Unsuspend threads so they can cooperatively quit
            If (m_singlesThreadSuspended = True) Then
                m_singlesMutex.ReleaseMutex()
            End If
            If (m_decadeThreadSuspended = True) Then
                m_decadeMutex.ReleaseMutex()
            End If

            m_QuitRequested = True
            m_SinglesThreadDeath = True
            m_DecadeThreadDeath = True
            e.Cancel = True
        Else
            Close()
        End If
    End Sub

    Private Sub btnSinglesSuspend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSinglesSuspend.Click
        m_singlesMutex.WaitOne()
        m_singlesThreadSuspended = True
        Me.btnSinglesSuspend.Enabled = False
        Me.btnSinglesResume.Enabled = True
    End Sub

    Private Sub btnSinglesResume_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSinglesResume.Click
        m_singlesMutex.ReleaseMutex()
        m_singlesThreadSuspended = False
        Me.btnSinglesSuspend.Enabled = True
        Me.btnSinglesResume.Enabled = False
    End Sub

    Private Sub btnTerminateSinglesCounter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTerminateSinglesCounter.Click
        KillSinglesThread()
    End Sub

    Private Sub btnDecadeSuspend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDecadeSuspend.Click
        m_decadeMutex.WaitOne()
        Me.m_decadeThreadSuspended = True
        Me.btnDecadeSuspend.Enabled = False
        Me.btnDecadeResume.Enabled = True
    End Sub

    Private Sub btnDecadeResume_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDecadeResume.Click
        m_decadeMutex.ReleaseMutex()
        Me.m_decadeThreadSuspended = False
        Me.btnDecadeSuspend.Enabled = True
        Me.btnDecadeResume.Enabled = False
    End Sub

    Private Sub btnTerminateDecadeCounter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTerminateDecadeCounter.Click
        KillDecadeThread()
    End Sub

    Private Sub btnStartThreads_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStartThreads.Click
        m_singlesThread.Start()
        m_decadeThread.Start()
    End Sub
End Class
