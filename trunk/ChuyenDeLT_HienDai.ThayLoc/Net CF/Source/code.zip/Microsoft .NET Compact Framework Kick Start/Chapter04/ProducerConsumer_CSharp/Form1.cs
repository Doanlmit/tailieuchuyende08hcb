using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using ControlInvokerSample;
using System.ComponentModel;

namespace ProducerConsumer_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnStartThreads;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.TextBox txtObjectsAvailable;

		System.Int32 m_objectsAvailable;
		System.Threading.Thread m_producerThread;
		System.Threading.ThreadStart m_producerThreadStart;
		System.Threading.Thread m_consumerThread;
		System.Threading.ThreadStart m_consumerThreadStart;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtProduced;
		private System.Windows.Forms.TextBox txtConsumed;

		private bool m_ProducerThreadRunning;
		private bool m_ConsumerThreadRunning;
		private bool m_QuitRequested;

		System.Data.DataSet m_lockObject;

		private ControlInvoker m_controlInvoker;


		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.btnStartThreads = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.txtObjectsAvailable = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtProduced = new System.Windows.Forms.TextBox();
			this.txtConsumed = new System.Windows.Forms.TextBox();
			// 
			// btnStartThreads
			// 
			this.btnStartThreads.Location = new System.Drawing.Point(16, 72);
			this.btnStartThreads.Size = new System.Drawing.Size(168, 24);
			this.btnStartThreads.Text = "Start Threads";
			this.btnStartThreads.Click += new System.EventHandler(this.btnStartThreads_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Size = new System.Drawing.Size(200, 24);
			this.label1.Text = "Objects Available For Consumption";
			// 
			// txtObjectsAvailable
			// 
			this.txtObjectsAvailable.Location = new System.Drawing.Point(16, 32);
			this.txtObjectsAvailable.Size = new System.Drawing.Size(168, 22);
			this.txtObjectsAvailable.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(16, 120);
			this.label2.Size = new System.Drawing.Size(88, 24);
			this.label2.Text = "Total Produced";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 152);
			this.label3.Size = new System.Drawing.Size(104, 16);
			this.label3.Text = "Total Consumed";
			// 
			// txtProduced
			// 
			this.txtProduced.Location = new System.Drawing.Point(136, 120);
			this.txtProduced.Size = new System.Drawing.Size(96, 22);
			this.txtProduced.Text = "";
			// 
			// txtConsumed
			// 
			this.txtConsumed.Location = new System.Drawing.Point(136, 152);
			this.txtConsumed.Size = new System.Drawing.Size(96, 22);
			this.txtConsumed.Text = "";
			// 
			// Form1
			// 
			this.Controls.Add(this.txtConsumed);
			this.Controls.Add(this.txtProduced);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtObjectsAvailable);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnStartThreads);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void setTextBox(object[] in_args)
		{
			string in_text = (string)in_args[0];
			System.Windows.Forms.TextBox in_textBox = (System.Windows.Forms.TextBox)in_args[1];
			in_textBox.Text = in_text;
		}


		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_ProducerThreadRunning = false;
			m_ConsumerThreadRunning = false;
			m_QuitRequested = false;

			m_objectsAvailable = 4;  // Default;
			this.txtObjectsAvailable.Text = m_objectsAvailable.ToString();

			m_producerThreadStart = new System.Threading.ThreadStart(ProducerMethod);
			m_producerThread = new System.Threading.Thread(m_producerThreadStart);
			m_consumerThreadStart = new System.Threading.ThreadStart(ConsumerMethod);
			m_consumerThread = new System.Threading.Thread(m_consumerThreadStart);

			m_lockObject = new System.Data.DataSet();
			m_controlInvoker = new ControlInvoker(this);
		}

		private void ProducerMethod()
		{
			int l_produced = 0;
			while (!m_QuitRequested)
			{
				System.Threading.Monitor.Enter(m_lockObject);
				m_objectsAvailable++;
				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(m_objectsAvailable), this.txtObjectsAvailable);
				System.Threading.Monitor.Exit(m_lockObject);

				
				l_produced++;
				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(l_produced), this.txtProduced);

				System.Threading.Thread.Sleep(500);
			}
			m_ProducerThreadRunning = false;

			// Last thread out closes form
			if (m_ConsumerThreadRunning == false)
				m_controlInvoker.Invoke(new MethodCallInvoker(ShutDown));
		}

		private void ConsumerMethod()
		{
			int l_consumed = 0;
			while (!m_QuitRequested)
			{
				System.Threading.Monitor.Enter(m_lockObject);
				if (m_objectsAvailable > 0)
				{
					m_objectsAvailable--;
					l_consumed++;
				}
				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(m_objectsAvailable), this.txtObjectsAvailable);
				System.Threading.Monitor.Exit(m_lockObject);


				m_controlInvoker.Invoke (new MethodCallInvoker (setTextBox), Convert.ToString(l_consumed), this.txtConsumed);

				System.Threading.Thread.Sleep(300);
			}
			m_ConsumerThreadRunning = false;

			// Last thread out closes form
			if (m_ProducerThreadRunning == false)
				m_controlInvoker.Invoke(new MethodCallInvoker(ShutDown));

		}


		private void ShutDown(object[] arguments) 
		{
			this.Close();
		}


		private void btnStartThreads_Click(object sender, System.EventArgs e)
		{
			m_producerThread.Start();
			m_consumerThread.Start();
			m_ProducerThreadRunning = true;
			m_ConsumerThreadRunning = true;
		}


		protected override void OnClosing(CancelEventArgs e)
		{
			if (m_ProducerThreadRunning || m_ConsumerThreadRunning)	
			{
				e.Cancel = true;
				MessageBox.Show("Will wait for threads to stop, then quit");
				m_QuitRequested = true;
			}
			else
			{
				Close();
			}
		}
	}
}
