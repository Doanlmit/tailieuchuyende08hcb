using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace TimerDemo_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Timer singlesTimer;
		private System.Windows.Forms.Timer decadeTimer;
		internal System.Windows.Forms.Button btnStartDecade;
		internal System.Windows.Forms.Button btnDecadePause;
		internal System.Windows.Forms.Button btnStartSingles;
		internal System.Windows.Forms.Button btnSinglesPause;
		internal System.Windows.Forms.TextBox txtDecade;
		internal System.Windows.Forms.Label lblDecades;
		internal System.Windows.Forms.TextBox txtSingles;
		internal System.Windows.Forms.Label lblSingles;
		private System.Windows.Forms.MainMenu mainMenu1;

		private int m_SinglesCount;
		private int m_DecadeCount;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.singlesTimer = new System.Windows.Forms.Timer();
			this.decadeTimer = new System.Windows.Forms.Timer();
			this.btnStartDecade = new System.Windows.Forms.Button();
			this.btnDecadePause = new System.Windows.Forms.Button();
			this.btnStartSingles = new System.Windows.Forms.Button();
			this.btnSinglesPause = new System.Windows.Forms.Button();
			this.txtDecade = new System.Windows.Forms.TextBox();
			this.lblDecades = new System.Windows.Forms.Label();
			this.txtSingles = new System.Windows.Forms.TextBox();
			this.lblSingles = new System.Windows.Forms.Label();
			// 
			// singlesTimer
			// 
			this.singlesTimer.Tick += new System.EventHandler(this.singlesTimer_Tick);
			// 
			// decadeTimer
			// 
			this.decadeTimer.Tick += new System.EventHandler(this.decadeTimer_Tick);
			// 
			// btnStartDecade
			// 
			this.btnStartDecade.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.btnStartDecade.Location = new System.Drawing.Point(124, 160);
			this.btnStartDecade.Size = new System.Drawing.Size(104, 24);
			this.btnStartDecade.Text = "Start / Resume";
			this.btnStartDecade.Click += new System.EventHandler(this.btnStartDecade_Click);
			// 
			// btnDecadePause
			// 
			this.btnDecadePause.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.btnDecadePause.Location = new System.Drawing.Point(12, 160);
			this.btnDecadePause.Size = new System.Drawing.Size(104, 24);
			this.btnDecadePause.Text = "Pause";
			this.btnDecadePause.Click += new System.EventHandler(this.btnDecadePause_Click);
			// 
			// btnStartSingles
			// 
			this.btnStartSingles.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.btnStartSingles.Location = new System.Drawing.Point(124, 56);
			this.btnStartSingles.Size = new System.Drawing.Size(104, 24);
			this.btnStartSingles.Text = "Start / Resume";
			this.btnStartSingles.Click += new System.EventHandler(this.btnStartSingles_Click);
			// 
			// btnSinglesPause
			// 
			this.btnSinglesPause.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.btnSinglesPause.Location = new System.Drawing.Point(12, 56);
			this.btnSinglesPause.Size = new System.Drawing.Size(104, 24);
			this.btnSinglesPause.Text = "Pause";
			this.btnSinglesPause.Click += new System.EventHandler(this.btnSinglesPause_Click);
			// 
			// txtDecade
			// 
			this.txtDecade.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.txtDecade.Location = new System.Drawing.Point(12, 128);
			this.txtDecade.Size = new System.Drawing.Size(104, 22);
			this.txtDecade.Text = "";
			// 
			// lblDecades
			// 
			this.lblDecades.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.lblDecades.Location = new System.Drawing.Point(12, 112);
			this.lblDecades.Size = new System.Drawing.Size(112, 16);
			this.lblDecades.Text = "Decade Counter";
			// 
			// txtSingles
			// 
			this.txtSingles.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.txtSingles.Location = new System.Drawing.Point(12, 24);
			this.txtSingles.Size = new System.Drawing.Size(104, 22);
			this.txtSingles.Text = "";
			// 
			// lblSingles
			// 
			this.lblSingles.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.lblSingles.Location = new System.Drawing.Point(12, 8);
			this.lblSingles.Size = new System.Drawing.Size(104, 16);
			this.lblSingles.Text = "Singles Counter";
			// 
			// Form1
			// 
			this.Controls.Add(this.btnStartDecade);
			this.Controls.Add(this.btnDecadePause);
			this.Controls.Add(this.btnStartSingles);
			this.Controls.Add(this.btnSinglesPause);
			this.Controls.Add(this.txtDecade);
			this.Controls.Add(this.lblDecades);
			this.Controls.Add(this.txtSingles);
			this.Controls.Add(this.lblSingles);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
	        m_SinglesCount = 0;
		    m_DecadeCount = 0;		
		}

		private void singlesTimer_Tick(object sender, System.EventArgs e)
		{
			this.txtSingles.Text = Convert.ToString(m_SinglesCount);
			m_SinglesCount = m_SinglesCount + 1;
		}

		private void decadeTimer_Tick(object sender, System.EventArgs e)
		{
			this.txtDecade.Text = Convert.ToString(m_DecadeCount);
			m_DecadeCount = m_DecadeCount + 10;		
		}

		private void btnStartDecade_Click(object sender, System.EventArgs e)
		{
			this.decadeTimer.Enabled = true;
		}

		private void btnDecadePause_Click(object sender, System.EventArgs e)
		{
			this.decadeTimer.Enabled = false;
		}

		private void btnStartSingles_Click(object sender, System.EventArgs e)
		{
			this.singlesTimer.Enabled = true;
		}

		private void btnSinglesPause_Click(object sender, System.EventArgs e)
		{
			this.singlesTimer.Enabled = false;
		}
	}
}
