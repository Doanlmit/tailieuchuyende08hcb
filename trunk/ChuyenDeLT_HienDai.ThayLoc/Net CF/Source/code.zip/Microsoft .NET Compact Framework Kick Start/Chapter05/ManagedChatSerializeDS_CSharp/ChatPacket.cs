using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Xml;
using System.IO;

namespace ManagedChat_CSharp
{
	public class ChatPacket
	{
		// Internal member variables
		private DataSet m_DataSet;
		private string m_Sender;
		private string m_ChatText;


		// This method creates a new DataSet with the right schema to hold all of
		// the state held inside this class.
		private DataSet CreateDataSet()
		{
			DataSet l_DataSet = new DataSet("ChatPacketDS");

			// Create a data table that holds a "Name" and a "PhoneNumber"
			DataTable  l_newTable = new DataTable("ManagedChatStateInfo");
			l_newTable.Columns.Add(new DataColumn("m_Sender", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("m_ChatText", typeof(System.String)));
			
			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);

			l_DataSet.AcceptChanges();

			return l_DataSet;
		}

		//
		// Constructor
		//
		public ChatPacket()
		{
			m_DataSet = CreateDataSet();
		}


		// Return to initialized
		public void Clear()
		{
			m_Sender = "";
			m_ChatText = "";
			m_DataSet.Clear();
			m_DataSet.AcceptChanges();
		}

		//
		//
		//
		public String Sender
		{
			get
			{
				return m_Sender;
			}
			set
			{
				m_Sender = value;
			}
		}

		//
		//
		//
		public String ChatText
		{
			get
			{
				return m_ChatText;
			}
			set
			{
				m_ChatText = value;
			}
		}



		public String ToXml()
		{
			// Put the state information into the DataSet
			DataRow l_newRow = m_DataSet.Tables[0].NewRow();
			l_newRow["m_Sender"] = m_Sender;
			l_newRow["m_ChatText"] = m_ChatText;
			m_DataSet.Tables[0].Rows.Add(l_newRow);

			m_DataSet.AcceptChanges();

			// Ask for the XML Representation from the DataSet
			return m_DataSet.GetXml();
		}

		public void FromXml(string serializedChatPacket)
		{
			Clear();
			
			// Wrap the string into a StringReader and XmlTextReader
			StringReader l_StringReader = new StringReader(serializedChatPacket);
			XmlTextReader l_XmlTextReader = new XmlTextReader(l_StringReader);

			// Consume the string into the dataset
			m_DataSet.ReadXml(l_XmlTextReader);
			
			// Acquire member variables from the DataSet
			m_Sender = (string)m_DataSet.Tables["ManagedChatStateInfo"].Rows[0]["m_Sender"];
			m_ChatText = (string)m_DataSet.Tables["ManagedChatStateInfo"].Rows[0]["m_ChatText"];
		}
	}
}