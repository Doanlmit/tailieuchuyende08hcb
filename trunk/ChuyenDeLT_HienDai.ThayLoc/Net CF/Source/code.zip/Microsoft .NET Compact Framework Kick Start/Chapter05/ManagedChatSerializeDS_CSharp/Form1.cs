using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.Xml;

namespace ManagedChat_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckBox checkbx_doDNS;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox txtSendText;
		private System.Windows.Forms.Button btnSend;
		private System.Windows.Forms.ListBox lbInText;
		private System.Windows.Forms.CheckBox cbHost;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.TextBox txtPort;

		private Socket m_connectedSocket;
		private Socket m_listenSocket;
		bool	m_Connected;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtSenderName;
		System.Threading.Thread m_listenerThread;
		ChatPacket m_ChatPacket;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.checkbx_doDNS = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtPort = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.txtSendText = new System.Windows.Forms.TextBox();
			this.btnSend = new System.Windows.Forms.Button();
			this.lbInText = new System.Windows.Forms.ListBox();
			this.cbHost = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtSenderName = new System.Windows.Forms.TextBox();
			// 
			// checkbx_doDNS
			// 
			this.checkbx_doDNS.Location = new System.Drawing.Point(184, 24);
			this.checkbx_doDNS.Size = new System.Drawing.Size(48, 24);
			this.checkbx_doDNS.Text = "DNS";
			// 
			// label1
			// 
			this.label1.Size = new System.Drawing.Size(232, 24);
			this.label1.Text = "Remote IP Address or hostname / PORT";
			// 
			// txtPort
			// 
			this.txtPort.Location = new System.Drawing.Point(112, 24);
			this.txtPort.Size = new System.Drawing.Size(40, 22);
			this.txtPort.Text = "8758";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(0, 24);
			this.textBox1.Size = new System.Drawing.Size(96, 22);
			this.textBox1.Text = "192.168.0.200";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(0, 48);
			this.button1.Size = new System.Drawing.Size(112, 24);
			this.button1.Text = "Connect";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// txtSendText
			// 
			this.txtSendText.Location = new System.Drawing.Point(8, 120);
			this.txtSendText.Size = new System.Drawing.Size(224, 22);
			this.txtSendText.Text = "textBox3";
			// 
			// btnSend
			// 
			this.btnSend.Location = new System.Drawing.Point(8, 144);
			this.btnSend.Size = new System.Drawing.Size(48, 24);
			this.btnSend.Text = "Send";
			this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
			// 
			// lbInText
			// 
			this.lbInText.Location = new System.Drawing.Point(8, 176);
			this.lbInText.Size = new System.Drawing.Size(224, 86);
			// 
			// cbHost
			// 
			this.cbHost.Location = new System.Drawing.Point(184, 48);
			this.cbHost.Size = new System.Drawing.Size(48, 24);
			this.cbHost.Text = "Host";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 88);
			this.label2.Size = new System.Drawing.Size(72, 24);
			this.label2.Text = "Your name:";
			// 
			// txtSenderName
			// 
			this.txtSenderName.Location = new System.Drawing.Point(80, 88);
			this.txtSenderName.Size = new System.Drawing.Size(152, 22);
			this.txtSenderName.Text = "textBox2";
			// 
			// Form1
			// 
			this.Controls.Add(this.txtSenderName);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.cbHost);
			this.Controls.Add(this.lbInText);
			this.Controls.Add(this.btnSend);
			this.Controls.Add(this.txtSendText);
			this.Controls.Add(this.checkbx_doDNS);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtPort);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.button1);
			this.Menu = this.mainMenu1;
			this.Text = "ManagedChat";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}


		private void WaitForConnection()
		{
			try
			{
				m_listenSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			
				m_listenSocket.Bind(new IPEndPoint(IPAddress.Any, System.Int32.Parse(this.txtPort.Text)));
				m_listenSocket.Listen((int)SocketOptionName.MaxConnections);

				m_connectedSocket = m_listenSocket.Accept();


				if (m_connectedSocket != null)
				{
					if (m_connectedSocket.Connected)
					{
						MessageBox.Show("Connected to remote party!");
						m_Connected = true;
						m_listenerThread = new System.Threading.Thread(new System.Threading.ThreadStart(ChatListener));
						m_listenerThread.Start();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		private void ChatListener()
		{
			while (true)
			{
				// l_Socket is now ready to send and receive data
				Byte[] l_Buffer = new Byte[1000];
									
				// Get the message from the socket, a serialized ChatPacket
				m_connectedSocket.Receive(l_Buffer, l_Buffer.Length, SocketFlags.None);
				
				string l_receivedString = System.Text.Encoding.ASCII.GetString(l_Buffer, 0, l_Buffer.Length);
				m_ChatPacket.FromXml(l_receivedString);

				this.lbInText.Items.Add(m_ChatPacket.Sender + ":" +  m_ChatPacket.ChatText);
			}
		}

		private void MakeConnection()
		{
			try
			{
				EndPoint l_EndPoint;
				if (this.checkbx_doDNS.Checked)
				{
					// You can use a DNS name such as "www.mycomputer.net" and the DNS resolver
					// will figure out the IP address based on the name
					IPHostEntry l_IPHostEntry = Dns.Resolve(this.textBox1.Text);
					l_EndPoint = new System.Net.IPEndPoint(l_IPHostEntry.AddressList[0], System.Int32.Parse(this.txtPort.Text));
				}
				else
				{
					// If your device does not have a DNS server available, you can
					// express the remote IP address using DOT notation (eg 192.168.0.1)
					l_EndPoint = new System.Net.IPEndPoint(IPAddress.Parse(this.textBox1.Text), System.Int32.Parse(this.txtPort.Text));

				}

				m_connectedSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				
				m_connectedSocket.Connect(l_EndPoint);
				if (m_connectedSocket.Connected)
				{
					MessageBox.Show("Connected to remote party!");
					m_Connected = true;
					m_listenerThread = new System.Threading.Thread(new System.Threading.ThreadStart(ChatListener));
					m_listenerThread.Start();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}



		private void button1_Click(object sender, System.EventArgs e)
		{
			if (this.cbHost.Checked)
			{
				WaitForConnection();
			}
			else
			{
				MakeConnection();
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_Connected = false;
			m_ChatPacket = new ChatPacket();
		}

		private void btnSend_Click(object sender, System.EventArgs e)
		{
			if (this.m_Connected)
			{
				m_ChatPacket.Clear();
				m_ChatPacket.Sender = this.txtSenderName.Text;
				m_ChatPacket.ChatText = this.txtSendText.Text;

				m_connectedSocket.Send(System.Text.Encoding.ASCII.GetBytes(m_ChatPacket.ToXml()));		
			}
			else
			{
				MessageBox.Show("Must connect to remote party before sending text");
			}
		}
	}
}
