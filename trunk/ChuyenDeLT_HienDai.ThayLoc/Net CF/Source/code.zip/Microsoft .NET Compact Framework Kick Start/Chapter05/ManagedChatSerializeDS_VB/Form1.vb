Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents txtSenderName As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents cbHost As System.Windows.Forms.CheckBox
    Friend WithEvents lbInText As System.Windows.Forms.ListBox
    Friend WithEvents btnSend As System.Windows.Forms.Button
    Friend WithEvents txtSendText As System.Windows.Forms.TextBox
    Friend WithEvents checkbx_doDNS As System.Windows.Forms.CheckBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents txtPort As System.Windows.Forms.TextBox
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_connectedSocket As System.Net.Sockets.Socket
    Private m_listenSocket As System.Net.Sockets.Socket
    Private m_Connected As Boolean
    Private m_listenerThread As System.Threading.Thread
    Private m_ChatPacket As ChatPacket

    Private Sub WaitForConnection()

        Try

            m_listenSocket = New System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, System.Net.Sockets.SocketType.Stream, System.Net.Sockets.ProtocolType.Tcp)

            m_listenSocket.Bind(New System.Net.IPEndPoint(System.Net.IPAddress.Any, System.Int32.Parse(Me.txtPort.Text)))
            m_listenSocket.Listen(System.Net.Sockets.SocketOptionName.MaxConnections)

            m_connectedSocket = m_listenSocket.Accept()


            If (Not (m_connectedSocket Is Nothing)) Then
                If (m_connectedSocket.Connected) Then

                    MessageBox.Show("Connected to remote party!")
                    m_Connected = True
                    m_listenerThread = New System.Threading.Thread(New System.Threading.ThreadStart(AddressOf ChatListener))
                    m_listenerThread.Start()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
    Private Sub ChatListener()
        While (True)

            ' l_Socket is now ready to send and receive data
            Dim l_Buffer(1000) As Byte

            ' Get the message from the socket, a serialized ChatPacket
            m_connectedSocket.Receive(l_Buffer, l_Buffer.Length, System.Net.Sockets.SocketFlags.None)
            Dim l_receivedString As String
            l_receivedString = System.Text.Encoding.ASCII.GetString(l_Buffer, 0, l_Buffer.Length)
            m_ChatPacket.FromXml(l_receivedString)

            Me.lbInText.Items.Add(m_ChatPacket.GetSender + ":" + m_ChatPacket.GetChatText)

        End While
    End Sub
    Private Sub MakeConnection()		
        Try
            Dim l_EndPoint As System.Net.EndPoint
            If (Me.checkbx_doDNS.Checked) Then

                ' You can use a DNS name such as "www.mycomputer.net" and the DNS resolver
                ' will figure out the IP address based on the name
                Dim l_IPHostEntry As System.Net.IPHostEntry
                l_IPHostEntry = System.Net.Dns.Resolve(Me.textBox1.Text)
                l_EndPoint = New System.Net.IPEndPoint(l_IPHostEntry.AddressList(0), System.Int32.Parse(Me.txtPort.Text))

            Else
                ' If your device does not have a DNS server available, you can
                ' express the remote IP address using DOT notation (eg 192.168.0.1)
                l_EndPoint = New System.Net.IPEndPoint(System.Net.IPAddress.Parse(Me.textBox1.Text), System.Int32.Parse(Me.txtPort.Text))

            End If

            m_connectedSocket = New System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, System.Net.Sockets.SocketType.Stream, System.Net.Sockets.ProtocolType.Tcp)

            m_connectedSocket.Connect(l_EndPoint)
            If (m_connectedSocket.Connected) Then
                MessageBox.Show("Connected to remote party!")
                m_Connected = True
                m_listenerThread = New System.Threading.Thread(New System.Threading.ThreadStart(AddressOf ChatListener))
                m_listenerThread.Start()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.txtSenderName = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.cbHost = New System.Windows.Forms.CheckBox
        Me.lbInText = New System.Windows.Forms.ListBox
        Me.btnSend = New System.Windows.Forms.Button
        Me.txtSendText = New System.Windows.Forms.TextBox
        Me.checkbx_doDNS = New System.Windows.Forms.CheckBox
        Me.label1 = New System.Windows.Forms.Label
        Me.txtPort = New System.Windows.Forms.TextBox
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.button1 = New System.Windows.Forms.Button
        '
        'txtSenderName
        '
        Me.txtSenderName.Location = New System.Drawing.Point(84, 92)
        Me.txtSenderName.Size = New System.Drawing.Size(152, 22)
        Me.txtSenderName.Text = "textBox2"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(12, 92)
        Me.label2.Size = New System.Drawing.Size(72, 24)
        Me.label2.Text = "Your name:"
        '
        'cbHost
        '
        Me.cbHost.Location = New System.Drawing.Point(188, 52)
        Me.cbHost.Size = New System.Drawing.Size(48, 24)
        Me.cbHost.Text = "Host"
        '
        'lbInText
        '
        Me.lbInText.Location = New System.Drawing.Point(12, 180)
        Me.lbInText.Size = New System.Drawing.Size(224, 86)
        '
        'btnSend
        '
        Me.btnSend.Location = New System.Drawing.Point(12, 148)
        Me.btnSend.Size = New System.Drawing.Size(48, 24)
        Me.btnSend.Text = "Send"
        '
        'txtSendText
        '
        Me.txtSendText.Location = New System.Drawing.Point(12, 124)
        Me.txtSendText.Size = New System.Drawing.Size(224, 22)
        Me.txtSendText.Text = "textBox3"
        '
        'checkbx_doDNS
        '
        Me.checkbx_doDNS.Location = New System.Drawing.Point(188, 28)
        Me.checkbx_doDNS.Size = New System.Drawing.Size(48, 24)
        Me.checkbx_doDNS.Text = "DNS"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(4, 4)
        Me.label1.Size = New System.Drawing.Size(232, 24)
        Me.label1.Text = "Remote IP Address or hostname / PORT"
        '
        'txtPort
        '
        Me.txtPort.Location = New System.Drawing.Point(116, 28)
        Me.txtPort.Size = New System.Drawing.Size(40, 22)
        Me.txtPort.Text = "8758"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(4, 28)
        Me.textBox1.Size = New System.Drawing.Size(96, 22)
        Me.textBox1.Text = "192.168.0.200"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(4, 52)
        Me.button1.Size = New System.Drawing.Size(112, 24)
        Me.button1.Text = "Connect"
        '
        'Form1
        '
        Me.Controls.Add(Me.txtSenderName)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.cbHost)
        Me.Controls.Add(Me.lbInText)
        Me.Controls.Add(Me.btnSend)
        Me.Controls.Add(Me.txtSendText)
        Me.Controls.Add(Me.checkbx_doDNS)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.txtPort)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "ManagedChat VB"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        If (Me.cbHost.Checked) Then
            WaitForConnection()
        Else
            MakeConnection()
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_Connected = False
        m_ChatPacket = New ChatPacket
    End Sub

    Private Sub btnSend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSend.Click
        If (Me.m_Connected) Then

            m_ChatPacket.Clear()
            m_ChatPacket.SetSender(Me.txtSenderName.Text)
            m_ChatPacket.SetChatText(Me.txtSendText.Text)

            m_connectedSocket.Send(System.Text.Encoding.ASCII.GetBytes(m_ChatPacket.ToXml()))
        Else
            MessageBox.Show("Must connect to remote party before sending text")
        End If
    End Sub
End Class
