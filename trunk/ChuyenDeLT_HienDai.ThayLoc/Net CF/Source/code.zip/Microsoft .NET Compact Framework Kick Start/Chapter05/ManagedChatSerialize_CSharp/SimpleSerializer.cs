using System;
using System.IO;
using System.Xml;
using System.Collections;

namespace ManagedChat_CSharp
{
	class SimpleSerializer
	{		
		public SimpleSerializer() {}
				
		public void Serialize(object[] objs, Stream stream)
		{
			Serialize(objs, new StreamWriter(stream));
		}

		public void Serialize(object[] objs, TextWriter writer)
		{
			if(writer == null)
				throw new ArgumentException("Cannot serialize to a null writer", "writer");
			if(objs == null)
				return;

			foreach(object obj in objs)
			{
				WriteObject(obj, writer);
			}

			writer.Flush();
		}		
		
		public void Serialize(object obj, Stream stream)
		{
			Serialize(obj, new StreamWriter(stream));
		}
		
		public void Serialize(object obj, TextWriter writer)
		{
			if(writer == null)
				throw new ArgumentException("Cannot serialize to a null writer", "writer");
			if(obj == null)
				return;

			WriteObject(obj, writer);
			writer.Flush();
		}

		protected void WriteObject(object primObj, TextWriter writer)
		{
			Type objType = primObj.GetType();

			if(objType.IsPrimitive)					
				writer.WriteLine("{0}={1}", objType.Name, PrimitiveToString(primObj));				
			else if( objType == typeof(string) )
				writer.WriteLine("{0}={1}", objType.Name, (string)primObj);								
			else if( objType == typeof(DateTime) )
				writer.WriteLine("{0}={1}", objType.Name, XmlConvert.ToString((DateTime)primObj));		
			else
				throw new InvalidOperationException("Can not serialize an object of type " + objType.Name);	
		}

		public object[] Deserialize(Stream stream)
		{
			return Deserialize(new StreamReader(stream));
		}

		public object[] Deserialize(TextReader reader)
		{
			if(reader == null)
				throw new ArgumentException("Can not deserialize from a null reader", "reader");
			
			// Read the objects from the file
			object obj;
			ArrayList objects = new ArrayList();
			while(null != (obj = ReadObject(reader)))
				objects.Add(obj);

			return objects.ToArray();
		}

		protected object ReadObject(TextReader reader)
		{
			// Get the line of data that represents the object
			string line = reader.ReadLine();

			// If there is no more data then return null.
			if((line == null) || line.StartsWith("\0"))
				return null;

			// Seperate the tag from the data
			int sepNdx = line.IndexOf('=');
			if(sepNdx <= 0)
				throw new Exception("Serialization file is malformed");

			string tag = line.Substring(0, sepNdx);
			string data = line.Substring(sepNdx+1);

			// the reader should be positioned on the node to deserialize
			switch(tag.ToLower())
			{
				case "boolean":		return XmlConvert.ToBoolean(data);
				case "byte":		return XmlConvert.ToByte(data);					
				case "sbyte":		return XmlConvert.ToSByte(data);					
				case "int16":		return XmlConvert.ToInt16(data);					
				case "uint16":		return XmlConvert.ToUInt16(data);					
				case "int32":		return XmlConvert.ToInt32(data);
				case "uint32":		return XmlConvert.ToUInt32(data);
				case "int64":		return XmlConvert.ToInt64(data);
				case "uint64":		return XmlConvert.ToUInt64(data);					
				case "char":		return XmlConvert.ToChar(data);					
				case "double":		return XmlConvert.ToDouble(data);					
				case "single":		return XmlConvert.ToSingle(data);
				case "string":		return data;
				case "datetime":	return XmlConvert.ToDateTime(data);
				default:
					throw new Exception(String.Format("Unsupported type, {0}, found in the serialization stream", tag));
			}			
		}

		protected static string PrimitiveToString(object primObj)
		{
			Type objType = primObj.GetType();

			if(objType == typeof(bool))
				return XmlConvert.ToString((bool)primObj);
			else if(objType == typeof(byte))
				return XmlConvert.ToString((byte)primObj);
			else if(objType == typeof(sbyte))
				return XmlConvert.ToString((sbyte)primObj);
			else if(objType == typeof(short))
				return XmlConvert.ToString((short)primObj);
			else if(objType == typeof(ushort))
				return XmlConvert.ToString((ushort)primObj);
			else if(objType == typeof(int))
				return XmlConvert.ToString((int)primObj);
			else if(objType == typeof(uint))
				return XmlConvert.ToString((uint)primObj);
			else if(objType == typeof(long))
				return XmlConvert.ToString((long)primObj);
			else if(objType == typeof(ulong))
				return XmlConvert.ToString((ulong)primObj);
			else if(objType == typeof(char))
				return XmlConvert.ToString((ushort)(char)primObj);
			else if(objType == typeof(double))
				return XmlConvert.ToString((double)primObj);
			else if(objType == typeof(float))
				return XmlConvert.ToString((float)primObj);
			
			throw new Exception("PrimitiveToString received an object that was not a primitive");
			return string.Empty;	
		}
	}
}