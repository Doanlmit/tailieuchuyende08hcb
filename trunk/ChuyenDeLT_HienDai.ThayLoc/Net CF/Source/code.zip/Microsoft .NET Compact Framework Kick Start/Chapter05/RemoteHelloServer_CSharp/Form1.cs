using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net.Sockets;
using System.Net;

namespace RemoteHelloServer_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;

		private System.Net.Sockets.Socket m_listenSocket;
		private System.Windows.Forms.Button button1;
		private System.Net.Sockets.Socket m_connectedSocket;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.button1 = new System.Windows.Forms.Button();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(24, 16);
			this.button1.Size = new System.Drawing.Size(192, 32);
			this.button1.Text = "Start listening for connections";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.button1);
			this.Menu = this.mainMenu1;
			this.Text = "RemoteHelloServer";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}



		private void button1_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("About to start waiting for a connection");

			m_listenSocket = new Socket(AddressFamily.InterNetwork, 
				SocketType.Stream, ProtocolType.Tcp);
			
			m_listenSocket.Bind(new IPEndPoint(IPAddress.Any, 8758));
			m_listenSocket.Listen((int)SocketOptionName.MaxConnections);

			m_connectedSocket = m_listenSocket.Accept();


			if (m_connectedSocket != null)
			{
				if (m_connectedSocket.Connected)
				{
					// Someone has connected to us.  Send the string "Hello" and then disconnect.
					m_connectedSocket.Send(System.Text.Encoding.ASCII.GetBytes("Hello!"));
					m_connectedSocket.Close();
				}
			}
		}
	}
}
