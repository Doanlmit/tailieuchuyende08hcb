using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net.Sockets;
using System.Net;

namespace RemoteHelloServer_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;

		private System.Net.Sockets.Socket m_listenSocket;
		private System.Net.Sockets.Socket m_connectedSocket;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			// 
			// Form1
			// 
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_listenSocket = new Socket(AddressFamily.InterNetwork, 
									SocketType.Stream, ProtocolType.Tcp);
			
					
			//m_listenSocket.Bind(new IPEndPoint(IPAddress.Parse("192.168.55.101"), 8758));
			m_listenSocket.Bind(new IPEndPoint(IPAddress.Any, 1058));

			// Don't you have to call listen on socket before you can accept???
			// I don't no how many connections you want to listen for, I just 
			// used the max connections. Also, I would suggest not putting the
			// connection code inside of the Form_Load method. Since the app
			// won't display to the user until a made. 
			m_listenSocket.Listen((int)SocketOptionName.MaxConnections);

			// This code throws an exception.  Why?
			m_connectedSocket = m_listenSocket.Accept();

			// This code does not seem to work but maybe there is something wrong with the device 
			m_listenSocket.Listen(0);

			while (true)
			{
				if ( m_listenSocket.Poll(3000000, SelectMode.SelectRead) )
				{
				
					m_connectedSocket = m_listenSocket.Accept();
				}
			}

			if (m_connectedSocket != null)
			{
				if (m_connectedSocket.Connected)
				{
					// Someone has connected to us.  Send the string "Hello" and then disconnect.
					m_connectedSocket.Send(System.Text.Encoding.ASCII.GetBytes("Hello!"));
					m_connectedSocket.Close();
				}
			}		
		}
	}
}
