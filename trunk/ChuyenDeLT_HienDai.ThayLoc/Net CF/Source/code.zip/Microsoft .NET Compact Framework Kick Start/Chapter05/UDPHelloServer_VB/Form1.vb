Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents txtPacketsToSend As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents txtTargetPort As System.Windows.Forms.TextBox
    Friend WithEvents txtIPAddress As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.txtPacketsToSend = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.txtTargetPort = New System.Windows.Forms.TextBox
        Me.txtIPAddress = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.button1 = New System.Windows.Forms.Button
        '
        'txtPacketsToSend
        '
        Me.txtPacketsToSend.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtPacketsToSend.Location = New System.Drawing.Point(16, 159)
        Me.txtPacketsToSend.Size = New System.Drawing.Size(200, 22)
        Me.txtPacketsToSend.Text = "20"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label3.Location = New System.Drawing.Point(16, 135)
        Me.label3.Size = New System.Drawing.Size(200, 24)
        Me.label3.Text = "Packets to send"
        '
        'txtTargetPort
        '
        Me.txtTargetPort.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtTargetPort.Location = New System.Drawing.Point(16, 95)
        Me.txtTargetPort.Size = New System.Drawing.Size(208, 22)
        Me.txtTargetPort.Text = "8758"
        '
        'txtIPAddress
        '
        Me.txtIPAddress.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtIPAddress.Location = New System.Drawing.Point(16, 39)
        Me.txtIPAddress.Size = New System.Drawing.Size(208, 22)
        Me.txtIPAddress.Text = "192.168.0.2"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(16, 71)
        Me.label2.Size = New System.Drawing.Size(208, 24)
        Me.label2.Text = "Target port:"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(16, 15)
        Me.label1.Size = New System.Drawing.Size(200, 24)
        Me.label1.Text = "Target IP address:"
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(48, 215)
        Me.button1.Size = New System.Drawing.Size(144, 40)
        Me.button1.Text = "send UDP packets"
        '
        'Form1
        '
        Me.Controls.Add(Me.txtPacketsToSend)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.txtTargetPort)
        Me.Controls.Add(Me.txtIPAddress)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim senderIP As System.Net.IPEndPoint
        senderIP = New System.Net.IPEndPoint(System.Net.IPAddress.Parse(Me.txtIPAddress.Text), Convert.ToInt32(Me.txtTargetPort.Text))

        Dim l_UdpClient As System.Net.Sockets.UdpClient
        l_UdpClient = New System.Net.Sockets.UdpClient
        l_UdpClient.Connect(senderIP)

        Dim i As Integer
        For i = 1 To Convert.ToInt32(Me.txtPacketsToSend.Text)

            l_UdpClient.Send(System.Text.Encoding.ASCII.GetBytes("Hello_UDP_1"), System.Text.Encoding.ASCII.GetBytes("Hello_UDP_1").Length)
            System.Threading.Thread.Sleep(1000)

        Next i
        l_UdpClient.Close()

    End Sub
End Class
