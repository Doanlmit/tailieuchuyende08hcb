using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net.Sockets;
using System.Net;

namespace RemoteHelloClient_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox checkbx_doDNS;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.checkbx_doDNS = new System.Windows.Forms.CheckBox();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(56, 160);
			this.button1.Size = new System.Drawing.Size(112, 40);
			this.button1.Text = "Connect";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 40);
			this.textBox1.Size = new System.Drawing.Size(184, 22);
			this.textBox1.Text = "192.168.0.200";
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(8, 128);
			this.textBox2.Size = new System.Drawing.Size(184, 22);
			this.textBox2.Text = "8758";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Size = new System.Drawing.Size(184, 24);
			this.label1.Text = "Remote IP Address or hostname";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 96);
			this.label2.Size = new System.Drawing.Size(184, 24);
			this.label2.Text = "Port";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 216);
			this.label3.Size = new System.Drawing.Size(200, 16);
			this.label3.Text = "Remote Response: ";
			// 
			// checkbx_doDNS
			// 
			this.checkbx_doDNS.Location = new System.Drawing.Point(8, 64);
			this.checkbx_doDNS.Size = new System.Drawing.Size(168, 24);
			this.checkbx_doDNS.Text = "Do DNS Resolve";
			// 
			// Form1
			// 
			this.Controls.Add(this.checkbx_doDNS);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.button1);
			this.Menu = this.mainMenu1;
			this.Text = "RemoteHelloClient";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{

		}

		private void button1_Click(object sender, System.EventArgs e)
		{

			try
			{
				EndPoint l_EndPoint;
				if (this.checkbx_doDNS.Checked)
				{
					// You can use a DNS name such as "www.mycomputer.net" and the DNS resolver
					// will figure out the IP address based on the name
					IPHostEntry l_IPHostEntry = Dns.Resolve(this.textBox1.Text);
					l_EndPoint = new System.Net.IPEndPoint(l_IPHostEntry.AddressList[0], 8758);
				}
				else
				{
					// If your device does not have a DNS server available, you can
					// express the remote IP address using DOT notation (eg 192.168.0.1)
					l_EndPoint = new System.Net.IPEndPoint(IPAddress.Parse(this.textBox1.Text), 8758);

				}

				Socket l_Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				
				l_Socket.Connect(l_EndPoint);
				if (l_Socket.Connected)
				{
					// l_Socket is now ready to send and receive data
					Byte[] l_Buffer = new Byte[100];
					
					// Get the message from the socket
					l_Socket.Receive(l_Buffer, l_Buffer.Length, SocketFlags.None);

					string l_receivedString = System.Text.Encoding.ASCII.GetString(l_Buffer, 0, l_Buffer.Length);
					this.label3.Text = "Remote Response: " + l_receivedString;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}		
		}
	}
}
