Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents btnComputeHash As System.Windows.Forms.Button
    Friend WithEvents txtHashedBytes As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents txtTextToHash As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.btnComputeHash = New System.Windows.Forms.Button
        Me.txtHashedBytes = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.txtTextToHash = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        '
        'btnComputeHash
        '
        Me.btnComputeHash.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnComputeHash.Location = New System.Drawing.Point(8, 59)
        Me.btnComputeHash.Size = New System.Drawing.Size(224, 32)
        Me.btnComputeHash.Text = "Compute Hash"
        '
        'txtHashedBytes
        '
        Me.txtHashedBytes.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtHashedBytes.Location = New System.Drawing.Point(8, 139)
        Me.txtHashedBytes.Multiline = True
        Me.txtHashedBytes.Size = New System.Drawing.Size(224, 120)
        Me.txtHashedBytes.Text = ""
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(8, 123)
        Me.label2.Size = New System.Drawing.Size(224, 16)
        Me.label2.Text = "Hashed Bytes"
        '
        'txtTextToHash
        '
        Me.txtTextToHash.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtTextToHash.Location = New System.Drawing.Point(8, 27)
        Me.txtTextToHash.Size = New System.Drawing.Size(224, 22)
        Me.txtTextToHash.Text = "Compute Hash For Me"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(8, 11)
        Me.label1.Size = New System.Drawing.Size(208, 16)
        Me.label1.Text = "Text to hash"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnComputeHash)
        Me.Controls.Add(Me.txtHashedBytes)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtTextToHash)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub btnComputeHash_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnComputeHash.Click
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI
        Dim l_hProvider As IntPtr = l_Crypto.AcquireNamedContext("KICKSTART")
        Dim l_TotalHashBytes As Int32 = 0

        Dim l_TextBytes() As Byte = System.Text.Encoding.ASCII.GetBytes(Me.txtTextToHash.Text)

        Dim l_HashBytes() As Byte = l_Crypto.ManagedComputeHash(l_hProvider, l_TextBytes, l_TotalHashBytes)

        Me.txtHashedBytes.Text = ""
        Dim i As Integer
        For i = 0 To l_TotalHashBytes - 1
            Me.txtHashedBytes.Text += "[" + Convert.ToString(l_HashBytes(i)) + "] "
        Next i
    End Sub
End Class
