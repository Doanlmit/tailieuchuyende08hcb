using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace ImportLocalSessionKey_CSHARP
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtInitialText;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtEncryptedBytes;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtDecryptedText;
		private System.Windows.Forms.Button btnGo;
		private System.Windows.Forms.CheckBox chkbxUseSharedKey;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.label1 = new System.Windows.Forms.Label();
			this.txtInitialText = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtEncryptedBytes = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtDecryptedText = new System.Windows.Forms.TextBox();
			this.btnGo = new System.Windows.Forms.Button();
			this.chkbxUseSharedKey = new System.Windows.Forms.CheckBox();
			// 
			// label1
			// 
			this.label1.Size = new System.Drawing.Size(160, 24);
			this.label1.Text = "Initial Text";
			// 
			// txtInitialText
			// 
			this.txtInitialText.Location = new System.Drawing.Point(8, 16);
			this.txtInitialText.Size = new System.Drawing.Size(224, 22);
			this.txtInitialText.Text = "textBox1";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(0, 64);
			this.label2.Size = new System.Drawing.Size(176, 24);
			this.label2.Text = "Encrypted Bytes";
			// 
			// txtEncryptedBytes
			// 
			this.txtEncryptedBytes.Location = new System.Drawing.Point(8, 80);
			this.txtEncryptedBytes.Multiline = true;
			this.txtEncryptedBytes.Size = new System.Drawing.Size(224, 56);
			this.txtEncryptedBytes.Text = "textBox1";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(0, 152);
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.Text = "Decrypted Text";
			// 
			// txtDecryptedText
			// 
			this.txtDecryptedText.Location = new System.Drawing.Point(8, 168);
			this.txtDecryptedText.Size = new System.Drawing.Size(224, 22);
			this.txtDecryptedText.Text = "textBox2";
			// 
			// btnGo
			// 
			this.btnGo.Location = new System.Drawing.Point(8, 224);
			this.btnGo.Size = new System.Drawing.Size(224, 32);
			this.btnGo.Text = "Go";
			this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
			// 
			// chkbxUseSharedKey
			// 
			this.chkbxUseSharedKey.Location = new System.Drawing.Point(8, 200);
			this.chkbxUseSharedKey.Size = new System.Drawing.Size(224, 16);
			this.chkbxUseSharedKey.Text = "Used Shared Session Key";
			// 
			// Form1
			// 
			this.Controls.Add(this.chkbxUseSharedKey);
			this.Controls.Add(this.btnGo);
			this.Controls.Add(this.txtDecryptedText);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtEncryptedBytes);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtInitialText);
			this.Controls.Add(this.label1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnGo_Click(object sender, System.EventArgs e)
		{
			ManagedCryptoAPI l_Crypto = new ManagedCryptoAPI();
			IntPtr l_hProvider = IntPtr.Zero;
			IntPtr l_hPrivateSessionKey = IntPtr.Zero;

			l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART");

			// Get the bytes of the public exchange key which we already have gotten from another device.
			System.IO.BinaryReader l_Reader = null;
			if (this.chkbxUseSharedKey.Checked)
			{
				l_Reader = new BinaryReader(new System.IO.FileStream("\\ExportedSessionKey.blob", System.IO.FileMode.Open));
				byte[] l_SharedKeyBytes = l_Reader.ReadBytes(1000);
				l_Reader.Close();

				l_hPrivateSessionKey = l_Crypto.LoadSharedSessionKey(l_hProvider, l_SharedKeyBytes);

			}
			else
			{
				l_Reader = new BinaryReader(new System.IO.FileStream("\\LocalSessionKey.blob", System.IO.FileMode.Open));
				byte[] l_PrivateKeyBytes = l_Reader.ReadBytes(1000);
				l_Reader.Close();
				l_hPrivateSessionKey = l_Crypto.LoadPrivateSessionKey(l_hProvider, l_PrivateKeyBytes);
			}

			byte[] l_PlainTextBytes = System.Text.Encoding.ASCII.GetBytes(this.txtInitialText.Text);
			
			byte[] l_Encrypted = l_Crypto.KeyEncrypt(l_hPrivateSessionKey, l_PlainTextBytes);


			// Paint encrypted bytes into the UI
			this.txtEncryptedBytes.Text = "";
			for (int i = 0; i < l_Encrypted.Length; i++)
			{
				this.txtEncryptedBytes.Text += "[" + l_Encrypted[i] + "] ";
			}

			// Decrypt the bytes
			Int32 l_TotalDecrypted = l_Encrypted.Length;
			byte[] l_Decrypted = l_Crypto.KeyDecrypt(l_hPrivateSessionKey, l_Encrypted, ref l_TotalDecrypted);

			// Paint decrypted bytes into the UI
			this.txtDecryptedText.Text = System.Text.Encoding.ASCII.GetString(l_Decrypted, 0, l_TotalDecrypted);


		}
	}
}
