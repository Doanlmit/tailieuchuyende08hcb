using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace ExportPublicKeyDemo_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.button1 = new System.Windows.Forms.Button();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 24);
			this.button1.Size = new System.Drawing.Size(224, 40);
			this.button1.Text = "Export Public Key Exchange Key";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.button1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			// This code drops a public key to a binary file called \PublicExchangeKey.blob
			// Another device can use this key to encrypt a session key that they want to share
			// with this device.
			ManagedCryptoAPI l_Crypto = new ManagedCryptoAPI();
			
			IntPtr l_hProvider = IntPtr.Zero;
			Int32  l_PubKeySize = 0;

			l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART");

			byte[] l_PublicExchangeKeyBytes = l_Crypto.ExportPublicKey(l_hProvider, ref l_PubKeySize);

			if (File.Exists("\\PublicExchangeKey.blob"))
			{
				File.Delete("\\PublicExchangeKey.blob");
			}

			System.IO.BinaryWriter l_Writer = new BinaryWriter(new System.IO.FileStream("\\PublicExchangeKey.blob", System.IO.FileMode.CreateNew));
			
			l_Writer.Write(l_PublicExchangeKeyBytes, 0, (int)l_PubKeySize);

			l_Writer.Close();
		}
	}
}
