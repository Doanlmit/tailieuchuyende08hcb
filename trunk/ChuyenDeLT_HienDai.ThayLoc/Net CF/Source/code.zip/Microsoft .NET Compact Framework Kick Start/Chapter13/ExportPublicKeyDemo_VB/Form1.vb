Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button1 = New System.Windows.Forms.Button
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(8, 24)
        Me.button1.Size = New System.Drawing.Size(224, 40)
        Me.button1.Text = "Export Public Key Exchange Key"
        '
        'Form1
        '
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        ' This code drops a public key to a binary file called \PublicExchangeKey.blob
        ' Another device can use this key to encrypt a session key that they want to share
        ' with this device.
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI

        Dim l_hProvider As IntPtr = IntPtr.Zero
        Dim l_PubKeySize As Int32 = 0

        l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART")

        Dim l_PublicExchangeKeyBytes() As Byte = l_Crypto.ExportPublicKey(l_hProvider, l_PubKeySize)

        If (System.IO.File.Exists("\PublicExchangeKey.blob")) Then
            System.IO.File.Delete("\PublicExchangeKey.blob")
        End If

        Dim l_Writer As System.IO.BinaryWriter = New System.IO.BinaryWriter(New System.IO.FileStream("\PublicExchangeKey.blob", System.IO.FileMode.CreateNew))

        l_Writer.Write(l_PublicExchangeKeyBytes, 0, Convert.ToInt32(l_PubKeySize))
        l_Writer.Close()

    End Sub
End Class
