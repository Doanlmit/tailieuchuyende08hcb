using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace ExportSessionKey_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnDropPrivateSessionKey;
		private System.Windows.Forms.Button btnDropExportedSessionKey;
		private System.Windows.Forms.Button btnDropComplimentaryKeys;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.btnDropPrivateSessionKey = new System.Windows.Forms.Button();
			this.btnDropExportedSessionKey = new System.Windows.Forms.Button();
			this.btnDropComplimentaryKeys = new System.Windows.Forms.Button();
			// 
			// btnDropPrivateSessionKey
			// 
			this.btnDropPrivateSessionKey.Location = new System.Drawing.Point(8, 16);
			this.btnDropPrivateSessionKey.Size = new System.Drawing.Size(224, 40);
			this.btnDropPrivateSessionKey.Text = "Drop Private Session Key";
			this.btnDropPrivateSessionKey.Click += new System.EventHandler(this.btnDropPrivateSessionKey_Click);
			// 
			// btnDropExportedSessionKey
			// 
			this.btnDropExportedSessionKey.Location = new System.Drawing.Point(8, 88);
			this.btnDropExportedSessionKey.Size = new System.Drawing.Size(224, 48);
			this.btnDropExportedSessionKey.Text = "Drop Exported Session Key";
			this.btnDropExportedSessionKey.Click += new System.EventHandler(this.btnDropExportedSessionKey_Click);
			// 
			// btnDropComplimentaryKeys
			// 
			this.btnDropComplimentaryKeys.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
			this.btnDropComplimentaryKeys.Location = new System.Drawing.Point(8, 160);
			this.btnDropComplimentaryKeys.Size = new System.Drawing.Size(224, 48);
			this.btnDropComplimentaryKeys.Text = "Drop Pair of Session Keys";
			this.btnDropComplimentaryKeys.Click += new System.EventHandler(this.btnDropComplimentaryKeys_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.btnDropComplimentaryKeys);
			this.Controls.Add(this.btnDropExportedSessionKey);
			this.Controls.Add(this.btnDropPrivateSessionKey);
			this.Menu = this.mainMenu1;
			this.Text = "Session Key Generator";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void DropPrivateSessionKey(IntPtr in_hProvider, IntPtr in_hSessionKey, ManagedCryptoAPI in_Crypto)
		{
			Int32 l_SessionKeySize = 0;
			// Get the bytes of the session key
			byte[] l_SessionKeyBytes = in_Crypto.LocalSaveSessionKey(in_hProvider, in_hSessionKey, ref l_SessionKeySize);

			if (File.Exists("\\LocalSessionKey.blob"))
			{
				File.Delete("\\LocalSessionKey.blob");
			}
			// Store the bytes of the session key on disk
			System.IO.BinaryWriter l_Writer = new BinaryWriter(new System.IO.FileStream("\\LocalSessionKey.blob", System.IO.FileMode.CreateNew));
			l_Writer.Write(l_SessionKeyBytes, 0, (int)l_SessionKeySize);
			l_Writer.Close();
		}

		private void btnDropPrivateSessionKey_Click(object sender, System.EventArgs e)
		{
			ManagedCryptoAPI l_Crypto = new ManagedCryptoAPI();

			IntPtr l_hProvider = IntPtr.Zero;
			IntPtr l_hSessionKey = IntPtr.Zero;

			l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART");
			l_hSessionKey = l_Crypto.GenerateSessionKey(l_hProvider);
			DropPrivateSessionKey(l_hProvider, l_hSessionKey, l_Crypto);
		}

		private void DropExportedSessionKey(IntPtr in_hProvider, IntPtr in_hSessionKey, ManagedCryptoAPI in_Crypto)
		{
			IntPtr l_PublicExchangeKey = IntPtr.Zero;
			Int32 l_SessionKeySize = 0;
			
			// Get the bytes of the public exchange key which we already have gotten from another device.			
			System.IO.BinaryReader l_Reader = new BinaryReader(new System.IO.FileStream("\\PublicExchangeKey.blob", System.IO.FileMode.Open));
			byte[] l_PublicExchangeKeyBytes = l_Reader.ReadBytes(1000);
			l_Reader.Close();

			l_PublicExchangeKey = in_Crypto.ImportPublicKey(in_hProvider, l_PublicExchangeKeyBytes);

			byte[] l_ExportedSessionKeyBytes = in_Crypto.ExportSessionKey(l_PublicExchangeKey, in_hSessionKey, ref l_SessionKeySize);

			// The session key is encrypted using the public exchange key from the other device.
			// We store the bytes of the session key on disk
			if (File.Exists("\\ExportedSessionKey.blob"))
			{
				File.Delete("\\ExportedSessionKey.blob");
			}
			System.IO.BinaryWriter l_Writer = new BinaryWriter(new System.IO.FileStream("\\ExportedSessionKey.blob", System.IO.FileMode.CreateNew));
			l_Writer.Write(l_ExportedSessionKeyBytes, 0, (int)l_SessionKeySize);
			l_Writer.Close();
		}

		private void btnDropExportedSessionKey_Click(object sender, System.EventArgs e)
		{
			ManagedCryptoAPI l_Crypto = new ManagedCryptoAPI();

			IntPtr l_hProvider = IntPtr.Zero;
			IntPtr l_hSessionKey = IntPtr.Zero;

			l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART");
			l_hSessionKey = l_Crypto.GenerateSessionKey(l_hProvider);

			DropExportedSessionKey(l_hProvider, l_hSessionKey, l_Crypto);
		}

		private void btnDropComplimentaryKeys_Click(object sender, System.EventArgs e)
		{
			ManagedCryptoAPI l_Crypto = new ManagedCryptoAPI();

			IntPtr l_hProvider = IntPtr.Zero;
			IntPtr l_hSessionKey = IntPtr.Zero;

			l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART");
			l_hSessionKey = l_Crypto.GenerateSessionKey(l_hProvider);

			// By dropping these keys with the SAME handle to the session key, they can be used as
			// complimentary keys for encryption and decryption between two devices
			DropPrivateSessionKey(l_hProvider, l_hSessionKey, l_Crypto);
			DropExportedSessionKey(l_hProvider, l_hSessionKey, l_Crypto);		
		}
	}
}
