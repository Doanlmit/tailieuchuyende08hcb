using System;
using System.Runtime.InteropServices;

// This class wraps functionality that is available via the CryptoAPI in a way that is
// natural for managed code users to consume.
public class ManagedCryptoAPI
{

	#region CRYPTO_API_CONSTANTS
	// These constants were found by using the ConstFinder application for Windows CE 3.0.
	private static Int32 PROV_RSA_FULL				= 1;  
	private static UInt32 CRYPT_NEWKEYSET			= 8; 
    private static UInt32 AT_KEYEXCHANGE			= 1; 
	private static UInt32 PUBLICKEYBLOB				= 6;
	private static UInt32 SIMPLEBLOB				= 1;  
	private static UInt32 CALG_DES					= 26113;       
	private static uint CALG_MD5					= 32771;
	private static uint CALG_RC4					= 26625;

	private static Int32 CRYPT_EXPORTABLE			= 1;
	
	private static uint   MAX_HASH					= 64;
	private static UInt32 HP_HASHVAL				= 2;  


	private const uint lERROR_INVALID_HANDLE		= 6;
	private const uint lERROR_INVALID_PARAMETER		= 87;
	private const uint lERROR_MORE_DATA				= 234;
	private const uint lNTE_BAD_FLAGS				= 2148073481;
	private const uint lNTE_BAD_KEY					= 2148073475;
	private const uint lNTE_BAD_KEY_STATE			= 2148073483;
	private const uint lNTE_BAD_PUBLIC_KEY			= 2148073493; 
	private const uint lNTE_BAD_TYPE				= 2148073482;
	private const uint lNTE_BAD_UID					= 2148073473;
	private const uint lNTE_NO_KEY					= 2148073485;
	private const uint lNTE_BAD_ALGID				= 2148073480;
	private const uint lNTE_BAD_DATA				= 2148073477;
	private const uint lNTE_BAD_HASH				= 2148073474;
	private const uint lNTE_BAD_LEN					= 2148073476;
	private const uint lNTE_DOUBLE_ENCRYPT			= 2148073490; 
	private const uint lNTE_FAIL					= 2148073504;


	private static int MAX_KEYBLOB = 1000;
	#endregion    
	


	private string TranslateErrorCode(long in_code)
	{
		switch (in_code)
		{
			case lERROR_INVALID_HANDLE:
			{		return "ERROR_INVALID_HANDLE";		}
			case lERROR_INVALID_PARAMETER:
			{		return "ERROR_INVALID_PARAMETER";	}
			case lERROR_MORE_DATA:
			{		return "ERROR_MORE_DATA";			}
			case lNTE_BAD_FLAGS:
			{		return "NTE_BAD_FLAGS";				}
			case lNTE_BAD_KEY:
			{		return "NTE_BAD_KEY";				}
			case lNTE_BAD_KEY_STATE:
			{		return "NTE_BAD_KEY_STATE"; 		}
			case lNTE_BAD_PUBLIC_KEY:
			{		return "NTE_BAD_PUBLIC_KEY";		}
			case lNTE_BAD_TYPE:
			{		return "NTE_BAD_TYPE";				}
			case lNTE_BAD_UID:
			{		return "NTE_BAD_UID";				}
			case lNTE_NO_KEY:
			{		return "NTE_NO_KEY";				}
			case lNTE_BAD_ALGID:
			{		return "lNTE_BAD_ALGID";			}
			case lNTE_BAD_DATA:
			{		return "lNTE_BAD_DATA";				}
			case lNTE_BAD_HASH:
			{		return "lNTE_BAD_HASH";				}
			case lNTE_BAD_LEN:
			{		return "lNTE_BAD_LEN";				}
			case lNTE_DOUBLE_ENCRYPT:
			{		return "lNTE_DOUBLE_ENCRYPT";		}
			case lNTE_FAIL:
			{		return "lNTE_FAIL";					}
			default:
			{		return in_code.ToString();			}
		}
	}

	#region DLLIMPORTS
	[DllImport("coredll.dll")]
	private static extern uint GetLastError();

	[DllImport("coredll.dll")]
	// As defined in the native CryptoAPI:
	//BOOL WINAPI CryptAcquireContext(
	//				HCRYPTPROV* phProv,
	//				LPCTSTR pszContainer,
	//				LPCTSTR pszProvider,
	//				DWORD dwProvType,
	//				DWORD dwFlags
	//				);
	private static extern bool CryptAcquireContext(ref IntPtr phProv, string pszContainer, string pszProvider, Int32 dwProvType, uint dwFlags);

	[DllImport("coredll.dll")]
	// As defined in the native CryptoAPI:
	//	BOOL WINAPI CryptCreateHash(
	//					HCRYPTPROV hProv,
	//					ALG_ID Algid,
	//					HCRYPTKEY hKey,
	//					DWORD dwFlags,
	//					HCRYPTHASH* phHash);
	private static extern bool CryptCreateHash(IntPtr hProv, uint Algid, IntPtr hKey, uint dwFlags, ref IntPtr phHash);

	[DllImport("coredll.dll")]
	// As defined in the native CryptoAPI:
	//	BOOL WINAPI CryptHashData(
	//					HCRYPTHASH hHash,
	//					BYTE* pbData,
	//					DWORD dwDataLen,
	//					DWORD dwFlags);
	private static extern bool CryptHashData(IntPtr hHash, byte[] pbData, Int32 dwDataLen, uint dwFlags);

	[DllImport("coredll.dll")]
	// As defined in the native CryptoAPI:
	//	BOOL CRYPTFUNC CryptDeriveKey( 
	//					   HCRYPTPROV hProv, 
	//					   ALG_ID Algid, 
	//					   HCRYPTHASH hBaseData, 
	//					   DWORD dwFlags, 
	//					   HCRYPTKEY *phKey);
	private static extern bool CryptDeriveKey(IntPtr hProv, uint Algid, IntPtr hBaseData, Int32 dwFlags, ref IntPtr phKey);

	[DllImport("coredll.dll")]
	// As defined in the native CryptoAPI:
	//	BOOL CRYPTFUNC CryptEncrypt( 
	//					   HCRYPTKEY hKey,
	//					   HCRYPTHASH hHash, 
	//					   BOOL Final, 
	//					   DWORD dwFlags, 
	//					   BYTE *pbData,
	//					   DWORD *pdwDataLen, 
	//					   DWORD dwBufLen);
	private static extern bool CryptEncrypt(IntPtr hKey, IntPtr hHash, bool Final, uint dwFlags, byte[] pbData, ref Int32 pdwDataLen, Int32 dwBufLen);

	[DllImport("coredll.dll")]
	// As defined in the native CryptoAPI:
	//	BOOL CRYPTFUNC CryptDecrypt( 
	//					   HCRYPTKEY hKey,
	//					   HCRYPTHASH hHash, 
	//					   BOOL Final, 
	//					   DWORD dwFlags, 
	//					   BYTE *pbData,
	//					   DWORD *pdwDataLen);
	private static extern bool CryptDecrypt(IntPtr hKey, IntPtr hHash, bool Final, uint dwFlags, byte[] pbData, ref Int32 pdwDataLen);

	[DllImport("coredll.dll")]
		// As defined in the native CryptoAPI:
	// BOOL WINAPI CryptGetHashParam(
	//				HCRYPTHASH hHash,
	//				DWORD dwParam,
	//				BYTE* pbData,
	//				DWORD* pdwDataLen,
	//				DWORD dwFlags);
	private static extern bool CryptGetHashParam(IntPtr hHash,	uint dwParam, byte[] pbData, ref Int32 out_NumHashBytes, uint dwFlags);

	[DllImport("coredll.dll")]
	// BOOL WINAPI CryptImportKey(
	//				HCRYPTPROV hProv,
	//				BYTE* pbData,
	//				DWORD dwDataLen,
	//				HCRYPTKEY hPubKey,
	//				DWORD dwFlags,
	//				HCRYPTKEY* phKey);
	private static extern bool CryptImportKey(IntPtr hProv, byte[] pbData, uint dwDataLen, IntPtr hPubKey, uint dwFlags, ref IntPtr phKey);

	[DllImport("coredll.dll")]
	//BOOL WINAPI CryptExportKey(
	//				HCRYPTKEY hKey,
	//				HCRYPTKEY hExpKey,
	//				DWORD dwBlobType,
	//				DWORD dwFlags,
	//				BYTE* pbData,
	//				DWORD* pdwDataLen);
	private static extern bool CryptExportKey(IntPtr hKey, IntPtr hExpKey, uint dwBlobType, uint dwFlags, byte[] pbData, ref Int32 pdwDataLen);

	[DllImport("coredll.dll")]
	//BOOL WINAPI CryptGetUserKey(
	//				HCRYPTPROV hProv,
	//				DWORD dwKeySpec,
	//				HCRYPTKEY* phUserKey);
	private static extern bool CryptGetUserKey(IntPtr hProv, uint dwKeySpec, ref IntPtr phUserKey);

	[DllImport("coredll.dll")]
	//BOOL WINAPI CryptGenKey(
	//				HCRYPTPROV hProv,
	//				ALG_ID Algid,
	//				DWORD dwFlags,
	//				HCRYPTKEY* phKey);
	private static extern bool CryptGenKey(IntPtr hProv, uint Algid, int dwFlags, ref IntPtr phKey);


#endregion

	// Constructor
	public ManagedCryptoAPI()
	{
	}

	// Acquires a handle to the default key container on the device,
	// creating the default key container if needed
	// We assume the use of the PROV_RSA_FULL provider
	public IntPtr AcquireDefaultContext()
	{
		IntPtr hProvider = IntPtr.Zero;

		if (!CryptAcquireContext(ref hProvider,									// Set to a handle to a provider
								 null,											// null == use default key store
								 "Microsoft Base Cryptographic Provider v1.0",  // Specifically ask by provider name, to insure compatibility between OS versions
								 PROV_RSA_FULL,								    // RSA implementation as done in Windows CE
								 0))
		{
			// We might have to create a new keyset...
			if (!CryptAcquireContext(ref hProvider,									// Set to a handle to a provider
									 null,											// null == use default key store
									 "Microsoft Base Cryptographic Provider v1.0",  // Specifically ask by provider name, to insure compatibility between OS versions
									 PROV_RSA_FULL,								    // RSA implementation as done in Windows CE
									 CRYPT_NEWKEYSET))
			{
				// Big trouble, could not create a new keyset and could not acquire
				// default keyset
				throw new Exception("ManagedCryptoAPI cannot access default keyset or create new default keyset!");
			}
			
		}

		return hProvider;
	}




	// Acquires a handle to a specific, named key container on the device,
	// creating the named key container if needed
	// We assume the use of the PROV_RSA_FULL provider
	public IntPtr AcquireNamedContext(string in_ContainerName)
	{
		IntPtr hProvider = IntPtr.Zero;

		if (!CryptAcquireContext(ref hProvider,									// Set to a handle to a provider
								 in_ContainerName,								// name of the container to acquire
								 "Microsoft Base Cryptographic Provider v1.0",  // Specifically ask by provider name, to insure compatibility between OS versions
								 PROV_RSA_FULL,								    // RSA implementation as done in Windows CE
								 0))
		{
			// We might have to create a new keyset...
			if (!CryptAcquireContext(ref hProvider,									// Set to a handle to a provider
						 			 in_ContainerName,								// name of the container to acquire
									 "Microsoft Base Cryptographic Provider v1.0",  // Specifically ask by provider name, to insure compatibility between OS versions
									 PROV_RSA_FULL,								    // RSA implementation as done in Windows CE
									 CRYPT_NEWKEYSET))
			{
				// Big trouble, could not create a new keyset and could not acquire
				// default keyset
				throw new Exception("ManagedCryptoAPI cannot access default keyset or create new default keyset!");
			}		
		}

		return hProvider;
	}



	// Encrypts data by using the bytes passed in as the key for the encryption
	// This method allocates enough memory to encrypt the data even if CryptoAPI needs
	// more bytes than in_BytesToEncrypt holds.  The allocation is done dynamically
	public byte[] PasswordEncrypt(byte [] in_BytesToEncrypt, IntPtr in_hProvider, byte[] in_passwordBytes, ref Int32 out_NumEncryptedBytes)
	{
		byte[] l_encryptedBytes = new byte[2 * in_BytesToEncrypt.Length];

		// We are not going to catch exceptions.  If things go wrong, any system-generated
		// exceptions might help the user of this code understand more about what is going on.
		// We need a finally clause because we want to release the CryptoAPI resources if something goes wrong
		try
		{
			// Step 1: Get a handle to a new hash object that will hash the password bytes
			IntPtr l_hHash = IntPtr.Zero;

			if (!CryptCreateHash(in_hProvider,									// Handle to cryptographic provider: call AcquireDefaultContext or AcquireNamedContext to get it
								 CALG_MD5,										// Use the MD5 hashing algorithm, included with base provider
								 IntPtr.Zero,									// According to CryptoAPI docs, must be zero
								 0,												// No special flags
								 ref l_hHash))									// l_hHash is set to a handle to the hash
			{
				throw new Exception("Could not create a hash object!");
			}
	
			// Step 2: hash the password data....
			// l_hHash - reference to hash object   in_passwordBytes - bytes to add to hash
			// in_passwordBytes.Length - length of data to compute hash on
			// 0 - extra flags

			// Note: We don't actually get the hash bytes back, we just have a handle to
			// the hash object that did the computation.  It is holding those bytes internally,
			// so we don't want or need them
			if (!CryptHashData(l_hHash, in_passwordBytes, in_passwordBytes.Length, 0))
			{
				throw new Exception("Failure while hashing password bytes!");
			}


			// Step 3: Derive an encryption key based on hashed data
			// in_hProvider - Handle to provider we previously acquired
			// CALG_RC4 - Popular encryption algorithm
			// l_hHash - Handle to hash object which will hand over the hash as part of the key derivation
			// CRYPT_EXPORTABLE - Means the key's bytes could be exported into a byte array, using CryptExportKey
			// l_hKey - Handle to the key we are deriving
			IntPtr l_hKey = IntPtr.Zero;
			if (!CryptDeriveKey(in_hProvider, CALG_RC4, l_hHash, CRYPT_EXPORTABLE, ref l_hKey))
			{
				throw new Exception("Failure when trying to derive the key!");
			}

			// Step 4: Acquire enough memory to assure that encryption succeeds even allowing for some
			// overflow
			for (int i = 0; i < in_BytesToEncrypt.Length; i++)
			{
				l_encryptedBytes[i] = in_BytesToEncrypt[i];
			}
			out_NumEncryptedBytes = in_BytesToEncrypt.Length;

			// Step 5: Do the encryption
			// l_hKey - Previously acquired key for encryption
			// IntPtr.Zero - Indicates that we don't want any additional hashing
			// true - Passed in because this is the only and last data to be encrypted in this session
			// 0 - Additional flags (none)
			// l_encryptedBytes - in/out - bytes to be encrypted in place in this buffer
			// l_datalength - Length of data (number of bytes) to be encrypted
			// l_encryptedBytes.Length - Lets CryptoAPI know how big the buffer it.  2X data size is plenty
			if (!CryptEncrypt(l_hKey, IntPtr.Zero, true ,0, l_encryptedBytes, ref out_NumEncryptedBytes, l_encryptedBytes.Length))
			{
				throw new Exception("Failure when calling CryptEncrypt!");
			}
		}
		finally
		{
			// TODO: Release resources
		}
		return l_encryptedBytes;
	}





	// Decrypts data by using the bytes passed in as the key for the decryption
	// This method allocates enough memory to decrypt the data even if CryptoAPI needs
	// more bytes than in_BytesToDecrypt holds.  The allocation is done dynamically,
	public byte[] PasswordDecrypt(byte [] in_BytesToDecrypt, Int32 in_NumBytesToDecrypt, IntPtr in_hProvider, byte[] in_passwordBytes, ref Int32 out_NumDecryptedBytes)
	{
		byte[] l_decryptedBytes = new byte[in_BytesToDecrypt.Length];

		for (int i = 0; i < in_BytesToDecrypt.Length; i++)
		{
			l_decryptedBytes[i] = in_BytesToDecrypt[i];
		}

		// We are not going to catch exceptions.  If things go wrong, any system-generated
		// exceptions might help the user of this code understand more about what is going on.
		// We need a finally clause because we want to release the CryptoAPI resources if something goes wrong
		try
		{
			// Step 1: Get a handle to a new hash object that will hash the password bytes
			IntPtr l_hHash = IntPtr.Zero;

			if (!CryptCreateHash(in_hProvider,									// Handle to cryptographic provider: call AcquireDefaultContext or AcquireNamedContext to get it
								 CALG_MD5,										// Use the MD5 hashing algorithm, included with base provider
								 IntPtr.Zero,									// According to CryptoAPI docs, must be zero
								 0,												// No special flags
								 ref l_hHash))									// l_hHash is set to a handle to the hash
			{
				throw new Exception("Could not create a hash object!");
			}

			// Step 2: hash the password data....
			// l_hHash - reference to hash object   in_passwordBytes - bytes to add to hash
			// in_passwordBytes.Length - length of data to compute hash on
			// 0 - extra flags

			// Note: We don't actually get the hash bytes back, we just have a handle to
			// the hash object that did the computation.  It is holding those bytes internally,
			// so we don't want or need them
			if (!CryptHashData(l_hHash, in_passwordBytes, in_passwordBytes.Length, 0))
			{
				throw new Exception("Failure while hashing password bytes!");
			}


			// Step 3: Derive an encryption key based on hashed data
			// in_hProvider - Handle to provider we previously acquired
			// CALG_RC4 - Popular encryption algorithm
			// l_hHash - Handle to hash object which will hand over the hash as part of the key derivation
			// CRYPT_EXPORTABLE - Means the key's bytes could be exported into a byte array, using CryptExportKey
			// l_hKey - Handle to the key we are deriving
			IntPtr l_hKey = IntPtr.Zero;
			if (!CryptDeriveKey(in_hProvider, CALG_RC4, l_hHash, CRYPT_EXPORTABLE, ref l_hKey))
			{
				throw new Exception("Failure when trying to derive the key!");
			}

			// And now decrypt the data
			out_NumDecryptedBytes = in_NumBytesToDecrypt; //in_BytesToDecrypt.Length;

			if (!CryptDecrypt(l_hKey, IntPtr.Zero, true , 0, l_decryptedBytes, ref out_NumDecryptedBytes))
			{
				throw new Exception("Failure when trying to decrypt the data");
			}		
		}
		finally
		{
			// TODO: Release resources
		}

		return l_decryptedBytes;
	}

	// Computes a hash of the bytes passed in
	public byte[] ManagedComputeHash(IntPtr in_hProvider, byte [] in_DataToHash, ref Int32 out_NumHashBytes)
	{
		byte [] l_HashBuffer = new byte[MAX_HASH];
		out_NumHashBytes = (int)MAX_HASH;

		try
		{
			// Step 1: Get a handle to a new hash object that will hash the password bytes
			IntPtr l_hHash = IntPtr.Zero;

			if (!CryptCreateHash(in_hProvider,									// Handle to cryptographic provider: call AcquireDefaultContext or AcquireNamedContext to get it
								CALG_MD5,										// Use the MD5 hashing algorithm, included with base provider
								IntPtr.Zero,									// According to CryptoAPI docs, must be zero
								0,												// No special flags
								ref l_hHash))									// l_hHash is set to a handle to the hash
			{
				throw new Exception("Could not create a hash object!");
			}
	
			// Step 2: hash the password data....
			// l_hHash - reference to hash object   in_passwordBytes - bytes to add to hash
			// in_passwordBytes.Length - length of data to compute hash on
			// 0 - extra flags
			if (!CryptHashData(l_hHash, in_DataToHash, in_DataToHash.Length, 0))
			{
				throw new Exception("Failure while hashing password bytes!");
			}

			// Step 3: Retreive the hash bytes
			if (!CryptGetHashParam(l_hHash,	HP_HASHVAL,	l_HashBuffer, ref out_NumHashBytes, 0))
			{
				throw new Exception("Failure when retreiving hash bytes with CryptGetHashParam!");
			}

		}
		finally
		{
			// Release hash object.
			//CryptDestroyHash(hHash);
		}

		return l_HashBuffer;
	}



	// TODO - Export and import key blobs

	// This section is for when another party has handed us a public key exchange key,
	// and we want to import that key exchange key and write out a session key

	//
	//
	//
	public IntPtr ImportPublicKey(IntPtr in_hProvider, byte [] in_PublicExchangeKey)
	{
		IntPtr h_PublicExchangeKey = IntPtr.Zero;
		// Import the bytes into the CSP, and acquire a handle to the corresponding public key
		if (!CryptImportKey(in_hProvider, in_PublicExchangeKey,	(uint)in_PublicExchangeKey.Length, IntPtr.Zero, 0, ref h_PublicExchangeKey))
		{
			throw new Exception("Could no import the public key with CryptImportKey!");
		}

		return h_PublicExchangeKey;
	}

	//
	//
	//
	public IntPtr LoadPrivateSessionKey(IntPtr in_hProvider, byte [] in_PrivateSessionKey)
	{
		IntPtr h_PrivateSessionKey = IntPtr.Zero;

		// Import the bytes into the CSP, and acquire a handle to the corresponding private session key
		if (!CryptImportKey(in_hProvider, in_PrivateSessionKey,	(uint)in_PrivateSessionKey.Length, IntPtr.Zero, 0, ref h_PrivateSessionKey))
		{
			throw new Exception("Could no import the private session key with CryptImportKey!");
		}

		return h_PrivateSessionKey;
	}


	// This method loads a shared session key that was created by some other device.
	// The remote device needs to store the same session key privately and load it with LoadPrivateSessionkey.
	// The remote device can decrypt data that is encrypted with this loaded key and vice versa
	public IntPtr LoadSharedSessionKey(IntPtr in_hProvider, byte [] in_SessionKey)
	{
		IntPtr h_SharedSessionKey = IntPtr.Zero;

		if (!CryptImportKey (in_hProvider, in_SessionKey, (uint)in_SessionKey.Length, IntPtr.Zero, (uint)CRYPT_EXPORTABLE, ref h_SharedSessionKey))
		{
			throw new Exception("Could not import the shared session key with CryptImportKey! " + TranslateErrorCode(GetLastError()));
		}

		return h_SharedSessionKey;
	}

	//
	// Exports the public key, also called the Exchange Key, into a byte array
	//
	public byte[] ExportPublicKey(IntPtr in_hProvider, ref Int32 out_PublicExchangeKeySize)
	{
		IntPtr l_hXchgKey = GetKeyExchangeKey(in_hProvider);
		byte [] l_keyBytes = new byte[MAX_KEYBLOB];

		// CryptExportKey expects out_PublicExchangeKeySize to be the size of the buffer l_KeyBytes when it is called...
		out_PublicExchangeKeySize = l_keyBytes.Length;

		if(!CryptExportKey(l_hXchgKey, IntPtr.Zero, PUBLICKEYBLOB, 0, l_keyBytes, ref out_PublicExchangeKeySize))
		{
			throw new Exception("Error while calling CryptExportKey! " + TranslateErrorCode(GetLastError()));
		}

		return l_keyBytes;
	}



	//
	// in_hPublicXChgKey - Get by calling ImportPublicKey
	// in_hSessionKey - Get by calling GenerateSessionKey
	//
	public byte[] ExportSessionKey(IntPtr in_hPublicXChgKey, IntPtr in_hSessionKey, ref Int32 out_SessionKeySize)
	{
		byte [] l_SessionKeyBytes = new byte[MAX_KEYBLOB];

		// CryptExportKey expects out_SessionKeySize to be the size of the buffer l_SessionKeyBytes when it is called...
		out_SessionKeySize = l_SessionKeyBytes.Length;

		if(!CryptExportKey(in_hSessionKey, in_hPublicXChgKey, SIMPLEBLOB, 0, l_SessionKeyBytes, ref out_SessionKeySize))
		{
			throw new Exception("Error when calling CryptExportKey!");
		}

		return l_SessionKeyBytes;
	}



	//
	//
	// in_hSessionKey - Get by calling GenerateSessionKey
	//
	public byte[] LocalSaveSessionKey(IntPtr in_hProvider, IntPtr in_hSessionKey, ref Int32 out_SessionKeySize)
	{
		IntPtr l_hXchgKey = GetKeyExchangeKey(in_hProvider);

		byte[] l_SessionKeyBytes = new byte[MAX_KEYBLOB];

		// CryptExportKey expects out_SessionKeySize to be the size of the buffer l_SessionKeyBytes when it is called...
		out_SessionKeySize = l_SessionKeyBytes.Length;

		if(!CryptExportKey(in_hSessionKey, l_hXchgKey, SIMPLEBLOB, 0, l_SessionKeyBytes, ref out_SessionKeySize))
		{
			throw new Exception("Error calling CryptExportKey!");
		}

		return l_SessionKeyBytes;
	}


	public IntPtr GenerateSessionKey(IntPtr in_hProvider)
	{
		IntPtr h_SessionKey = IntPtr.Zero;

		// Create a random session key
		if (!CryptGenKey(
			in_hProvider, 
			CALG_DES,
			CRYPT_EXPORTABLE, 
			ref h_SessionKey))
		{
			throw new Exception("Error trying to call CryptGenKey");
		}

		return h_SessionKey;
	}



	//
	//
	//
	private IntPtr GetKeyExchangeKey(IntPtr in_hProvider)
	{
		IntPtr l_hXchgKey = IntPtr.Zero;
		if(!CryptGetUserKey(in_hProvider, AT_KEYEXCHANGE, ref l_hXchgKey))
		{
			IntPtr l_hSessionKey = IntPtr.Zero;

			// Create an key exchange key pair.
			if(CryptGenKey(in_hProvider, AT_KEYEXCHANGE, 0,	ref l_hSessionKey))
			{
				if(!CryptGetUserKey(in_hProvider, AT_KEYEXCHANGE, ref l_hXchgKey))
				{
					throw new Exception("Second call to CryptGetUserKey failed!");
				}
			}
			else
			{
				throw new Exception("Could not create key exchange keyset");
			}	
		}
		return l_hXchgKey;
	}	

	
	// TODO - Encrypt and decrypt using key blobs
	public byte[] KeyEncrypt(IntPtr in_CryptKey, byte[] in_BytesToEncrypt)
	{
		byte[] l_encryptedBytes = new byte[in_BytesToEncrypt.Length * 2];

		for (int i = 0; i < in_BytesToEncrypt.Length; i++)
		{
			l_encryptedBytes[i] = in_BytesToEncrypt[i];
		}

		// Set this to length of array holding the encrypted bytes.  That is how CryptoAPI knows how much space it has
		Int32 l_NumEncryptedBytes = in_BytesToEncrypt.Length;


		if (!CryptEncrypt(in_CryptKey, IntPtr.Zero, true ,0, l_encryptedBytes, ref l_NumEncryptedBytes, l_encryptedBytes.Length))
		{
			throw new Exception("Failure when calling CryptEncrypt! " + TranslateErrorCode(GetLastError()));
		}

		byte[] l_ReturnBytes = new byte[l_NumEncryptedBytes];
		
		for (int i = 0; i < l_NumEncryptedBytes; i++)
		{
			l_ReturnBytes[i] = l_encryptedBytes[i];
		}

		return l_ReturnBytes;
	}


	public byte[] KeyDecrypt(IntPtr in_CryptKey, byte[] in_BytesToDecrypt, ref Int32 out_BytesDecrypted)
	{
		byte[] l_decryptedBytes = new byte[in_BytesToDecrypt.Length * 2];

		for (int i = 0; i < in_BytesToDecrypt.Length; i++)
		{
			l_decryptedBytes[i] = in_BytesToDecrypt[i];
		}

		if (!CryptDecrypt(in_CryptKey, IntPtr.Zero, true , 0, l_decryptedBytes, ref out_BytesDecrypted))
		{
			throw new Exception("Failure when trying to decrypt the data! " + TranslateErrorCode(GetLastError()));
		}

		return l_decryptedBytes;
	}

}