Imports System
Imports System.Runtime.InteropServices
Public Class ManagedCryptoAPI

    ' These constants were found by using the ConstFinder application for Windows CE 3.0.
    Private PROV_RSA_FULL As UInt32 = Convert.ToUInt32(1)
    Private CRYPT_NEWKEYSET As UInt32 = Convert.ToUInt32(8)
    Private AT_KEYEXCHANGE As UInt32 = Convert.ToUInt32(1)
    Private PUBLICKEYBLOB As UInt32 = Convert.ToUInt32(6)
    Private SIMPLEBLOB As UInt32 = Convert.ToUInt32(1)
    Private CALG_DES As UInt32 = Convert.ToUInt32(26113)
    Private CALG_MD5 As UInt32 = Convert.ToUInt32(32771)
    Private CALG_RC4 As UInt32 = Convert.ToUInt32(26625)

    Private Const CRYPT_EXPORTABLE As Int32 = 1

    Private MAX_HASH As UInt32 = Convert.ToUInt32(64)
    Private HP_HASHVAL As UInt32 = Convert.ToUInt32(2)


    Private lERROR_INVALID_HANDLE As UInt32 = Convert.ToUInt32(6)
    Private lERROR_INVALID_PARAMETER As UInt32 = Convert.ToUInt32(87)
    Private lERROR_MORE_DATA As UInt32 = Convert.ToUInt32(234)
    Private lNTE_BAD_FLAGS As UInt32 = Convert.ToUInt32(2148073481)
    Private lNTE_BAD_KEY As UInt32 = Convert.ToUInt32(2148073475)
    Private lNTE_BAD_KEY_STATE As UInt32 = Convert.ToUInt32(2148073483)
    Private lNTE_BAD_PUBLIC_KEY As UInt32 = Convert.ToUInt32(2148073493)
    Private lNTE_BAD_TYPE As UInt32 = Convert.ToUInt32(2148073482)
    Private lNTE_BAD_UID As UInt32 = Convert.ToUInt32(2148073473)
    Private lNTE_NO_KEY As UInt32 = Convert.ToUInt32(2148073485)
    Private lNTE_BAD_ALGID As UInt32 = Convert.ToUInt32(2148073480)
    Private lNTE_BAD_DATA As UInt32 = Convert.ToUInt32(2148073477)
    Private lNTE_BAD_HASH As UInt32 = Convert.ToUInt32(2148073474)
    Private lNTE_BAD_LEN As UInt32 = Convert.ToUInt32(2148073476)
    Private lNTE_DOUBLE_ENCRYPT As UInt32 = Convert.ToUInt32(2148073490)
    Private lNTE_FAIL As UInt32 = Convert.ToUInt32(2148073504)
    Private lERROR_NOT_ENOUGH_MEMORY As UInt32 = Convert.ToUInt32(8)
    Private lNTE_BAD_KEYSET As UInt32 = Convert.ToUInt32(2148073494)
    Private lNTE_BAD_KEYSET_PARAM As UInt32 = Convert.ToUInt32(2148073503)
    Private lNTE_BAD_PROV_TYPE As UInt32 = Convert.ToUInt32(2148073492)
    Private lNTE_BAD_SIGNATURE As UInt32 = Convert.ToUInt32(2148073478)
    Private lNTE_EXISTS As UInt32 = Convert.ToUInt32(2148073487)
    Private lNTE_KEYSET_ENTRY_BAD As UInt32 = Convert.ToUInt32(2148073498)
    Private lNTE_KEYSET_NOT_DEF As UInt32 = Convert.ToUInt32(2148073497)
    Private lNTE_NO_MEMORY As UInt32 = Convert.ToUInt32(2148073486)
    Private lNTE_PROV_DLL_NOT_FOUND As UInt32 = Convert.ToUInt32(2148073502)
    Private lNTE_PROV_TYPE_ENTRY_BAD As UInt32 = Convert.ToUInt32(2148073496)
    Private lNTE_PROV_TYPE_NO_MATCH As UInt32 = Convert.ToUInt32(2148073499)
    Private lNTE_PROV_TYPE_NOT_DEF As UInt32 = Convert.ToUInt32(2148073495)
    Private lNTE_PROVIDER_DLL_FAIL As UInt32 = Convert.ToUInt32(2148073501)


    Private Const MAX_KEYBLOB As Integer = 1000

    Private Function TranslateErrorCode(ByVal in_code As Long) As String
        If in_code = Convert.ToInt64(lERROR_INVALID_HANDLE) Then
            Return "ERROR_INVALID_HANDLE"
        ElseIf in_code = Convert.ToInt64(lERROR_INVALID_PARAMETER) Then
            Return "ERROR_INVALID_PARAMETER"
        ElseIf in_code = Convert.ToInt64(lERROR_MORE_DATA) Then
            Return "ERROR_MORE_DATA"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_FLAGS) Then
            Return "NTE_BAD_FLAGS"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_KEY) Then
            Return "NTE_BAD_KEY"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_KEY_STATE) Then
            Return "NTE_BAD_KEY_STATE"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_PUBLIC_KEY) Then
            Return "NTE_BAD_PUBLIC_KEY"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_TYPE) Then
            Return "NTE_BAD_TYPE"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_UID) Then
            Return "NTE_BAD_UID"
        ElseIf in_code = Convert.ToInt64(lNTE_NO_KEY) Then
            Return "NTE_NO_KEY"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_ALGID) Then
            Return "lNTE_BAD_ALGID"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_DATA) Then
            Return "lNTE_BAD_DATA"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_HASH) Then
            Return "lNTE_BAD_HASH"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_LEN) Then
            Return "lNTE_BAD_LEN"
        ElseIf in_code = Convert.ToInt64(lNTE_DOUBLE_ENCRYPT) Then
            Return "lNTE_DOUBLE_ENCRYPT"
        ElseIf in_code = Convert.ToInt64(lNTE_FAIL) Then
            Return "lNTE_FAIL"
        ElseIf in_code = Convert.ToInt64(lERROR_NOT_ENOUGH_MEMORY) Then
            Return "lERROR_NOT_ENOUGH_MEMORY"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_KEYSET) Then
            Return "lNTE_BAD_KEYSET"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_KEYSET_PARAM) Then
            Return "lNTE_BAD_KEYSET_PARAM"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_PROV_TYPE) Then
            Return "lNTE_BAD_PROV_TYPE"
        ElseIf in_code = Convert.ToInt64(lNTE_BAD_SIGNATURE) Then
            Return "lNTE_BAD_SIGNATURE"
        ElseIf in_code = Convert.ToInt64(lNTE_EXISTS) Then
            Return "lNTE_EXISTS"
        ElseIf in_code = Convert.ToInt64(lNTE_KEYSET_ENTRY_BAD) Then
            Return "lNTE_KEYSET_ENTRY_BAD"
        ElseIf in_code = Convert.ToInt64(lNTE_KEYSET_NOT_DEF) Then
            Return "lNTE_KEYSET_NOT_DEF"
        ElseIf in_code = Convert.ToInt64(lNTE_NO_MEMORY) Then
            Return "lNTE_NO_MEMORY"
        ElseIf in_code = Convert.ToInt64(lNTE_PROV_DLL_NOT_FOUND) Then
            Return "lNTE_PROV_DLL_NOT_FOUND"
        ElseIf in_code = Convert.ToInt64(lNTE_PROV_TYPE_ENTRY_BAD) Then
            Return "lNTE_PROV_TYPE_ENTRY_BAD"
        ElseIf in_code = Convert.ToInt64(lNTE_PROV_TYPE_NO_MATCH) Then
            Return "lNTE_PROV_TYPE_NO_MATCH"
        ElseIf in_code = Convert.ToInt64(lNTE_PROV_TYPE_NOT_DEF) Then
            Return "lNTE_PROV_TYPE_NOT_DEF"
        ElseIf in_code = Convert.ToInt64(lNTE_PROVIDER_DLL_FAIL) Then
            Return "lNTE_PROVIDER_DLL_FAIL"
        Else
            Return in_code.ToString()
        End If
    End Function

    Declare Function GetLastError Lib "coredll.dll" () As UInt32


    'As defined in the native CryptoAPI:
    'BOOL WINAPI CryptAcquireContext(
    '				HCRYPTPROV* phProv,
    '				LPCTSTR pszContainer,
    '				LPCTSTR pszProvider,
    '				DWORD dwProvType,
    '				DWORD dwFlags
    '				);
    Declare Function CryptAcquireContext Lib "coredll.dll" (ByRef phProv As IntPtr, ByVal pszContainer As String, ByVal pszProvider As String, ByVal dwProvType As UInt32, ByVal dwFlags As UInt32) As Boolean

    ' As defined in the native CryptoAPI:
    '	BOOL WINAPI CryptCreateHash(
    '					HCRYPTPROV hProv,
    '					ALG_ID Algid,
    '					HCRYPTKEY hKey,
    '					DWORD dwFlags,
    '					HCRYPTHASH* phHash);
    Declare Function CryptCreateHash Lib "coredll.dll" (ByVal hProv As IntPtr, ByVal Algid As Int32, ByVal hKey As IntPtr, ByVal dwFlags As UInt32, ByRef phHash As IntPtr) As Boolean


    ' As defined in the native CryptoAPI:
    '	BOOL WINAPI CryptHashData(
    '					HCRYPTHASH hHash,
    '					BYTE* pbData,
    '					DWORD dwDataLen,
    '					DWORD dwFlags);
    Declare Function CryptHashData Lib "coredll.dll" (ByVal hHash As IntPtr, ByVal pbData() As Byte, ByVal dwDataLen As Int32, ByVal dwFlags As UInt32) As Boolean


    ' As defined in the native CryptoAPI:
    '	BOOL CRYPTFUNC CryptDeriveKey( 
    '					   HCRYPTPROV hProv, 
    '					   ALG_ID Algid, 
    '					   HCRYPTHASH hBaseData, 
    '					   DWORD dwFlags, 
    '					   HCRYPTKEY *phKey);
    Declare Function CryptDeriveKey Lib "coredll.dll" (ByVal hProv As IntPtr, ByVal Algid As UInt32, ByVal hBaseData As IntPtr, ByVal dwFlags As Int32, ByRef phKey As IntPtr) As Boolean


    ' As defined in the native CryptoAPI:
    '	BOOL CRYPTFUNC CryptEncrypt( 
    '					   HCRYPTKEY hKey,
    '					   HCRYPTHASH hHash, 
    '					   BOOL Final, 
    '   				   DWORD dwFlags, 
    '					   BYTE *pbData,
    '					   DWORD *pdwDataLen, 
    '					   DWORD dwBufLen);
    Declare Function CryptEncrypt Lib "coredll.dll" (ByVal hKey As IntPtr, ByVal hHash As IntPtr, ByVal Final As Boolean, ByVal dwFlags As UInt32, ByVal pbData() As Byte, ByRef pdwDataLen As Int32, ByVal dwBufLen As Int32) As Boolean


    ' As defined in the native CryptoAPI:
    '	BOOL CRYPTFUNC CryptDecrypt( 
    '					   HCRYPTKEY hKey,
    '					   HCRYPTHASH hHash, 
    '					   BOOL Final, 
    '					   DWORD dwFlags, 
    '					   BYTE *pbData,
    '					   DWORD *pdwDataLen);
    Declare Function CryptDecrypt Lib "coredll.dll" (ByVal hKey As IntPtr, ByVal hHash As IntPtr, ByVal Final As Boolean, ByVal dwFlags As UInt32, ByVal pbData() As Byte, ByRef pdwDataLen As Int32) As Boolean

    ' As defined in the native CryptoAPI:
    ' BOOL WINAPI CryptGetHashParam(
    '				HCRYPTHASH hHash,
    '				DWORD dwParam,
    '				BYTE* pbData,
    '				DWORD* pdwDataLen,
    '				DWORD dwFlags);
    Declare Function CryptGetHashParam Lib "coredll.dll" (ByVal hHash As IntPtr, ByVal dwParam As UInt32, ByVal pbData() As Byte, ByRef out_NumHashBytes As Int32, ByVal dwFlags As UInt32) As Boolean

    ' BOOL WINAPI CryptImportKey(
    '				HCRYPTPROV hProv,
    '				BYTE* pbData,
    '				DWORD dwDataLen,
    '				HCRYPTKEY hPubKey,
    '				DWORD dwFlags,
    '				HCRYPTKEY* phKey);
    Declare Function CryptImportKey Lib "coredll.dll" (ByVal hProv As IntPtr, ByVal pbData() As Byte, ByVal dwDataLen As UInt32, ByVal hPubKey As IntPtr, ByVal dwFlags As UInt32, ByRef phKey As IntPtr) As Boolean



    'BOOL WINAPI CryptExportKey(
    '				HCRYPTKEY hKey,
    '				HCRYPTKEY hExpKey,
    '				DWORD dwBlobType,
    '				DWORD dwFlags,
    '				BYTE* pbData,
    '				DWORD* pdwDataLen);
    Declare Function CryptExportKey Lib "coredll.dll" (ByVal hKey As IntPtr, ByVal hExpKey As IntPtr, ByVal dwBlobType As UInt32, ByVal dwFlags As UInt32, ByVal pbData() As Byte, ByRef pdwDataLen As Int32) As Boolean

    'BOOL WINAPI CryptGetUserKey(
    '				HCRYPTPROV hProv,
    '				DWORD dwKeySpec,
    '				HCRYPTKEY* phUserKey);
    Declare Function CryptGetUserKey Lib "coredll.dll" (ByVal hProv As IntPtr, ByVal dwKeySpec As UInt32, ByRef phUserKey As IntPtr) As Boolean

    'BOOL WINAPI CryptGenKey(
    '				HCRYPTPROV hProv,
    '				ALG_ID Algid,
    '				DWORD dwFlags,
    '				HCRYPTKEY* phKey);
    Declare Function CryptGenKey Lib "coredll.dll" (ByVal hProv As IntPtr, ByVal Algid As UInt32, ByVal dwFlags As Int32, ByRef phKey As IntPtr) As Boolean


    ' Acquires a handle to the default key container on the device,
    ' creating the default key container if needed
    ' We assume the use of the PROV_RSA_FULL provider
    Public Function AcquireDefaultContext() As IntPtr
        Dim hProvider As IntPtr = IntPtr.Zero

        If (CryptAcquireContext(hProvider, Nothing, "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, Convert.ToUInt32(0)) = False) Then
            Dim l_Failure As String = TranslateErrorCode(Convert.ToInt64(GetLastError()))
            ' We might have to create a new keyset...
            If (CryptAcquireContext(hProvider, Nothing, "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, CRYPT_NEWKEYSET) = False) Then
                ' Big trouble, could not create a new keyset and could not acquire
                ' default keyset
                Throw New Exception("ManagedCryptoAPI cannot access default keyset or create new default keyset!" + TranslateErrorCode(Convert.ToInt64(GetLastError())))
            End If

        End If
        Return hProvider
    End Function


    ' Acquires a handle to a specific, named key container on the device,
    ' creating the named key container if needed
    ' We assume the use of the PROV_RSA_FULL provider
    Public Function AcquireNamedContext(ByVal in_ContainerName As String) As IntPtr
        Dim hProvider As IntPtr = IntPtr.Zero

        If (CryptAcquireContext(hProvider, in_ContainerName, "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, Convert.ToUInt32(0)) = False) Then
            Dim l_Failure As String = TranslateErrorCode(Convert.ToInt64(GetLastError()))
            ' We might have to create a new keyset...
            If (CryptAcquireContext(hProvider, in_ContainerName, "Microsoft Base Cryptographic Provider v1.0", PROV_RSA_FULL, CRYPT_NEWKEYSET) = False) Then
                ' Big trouble, could not create a new keyset and could not acquire
                ' default keyset
                Throw New Exception("ManagedCryptoAPI cannot access default keyset or create new default keyset!" + TranslateErrorCode(Convert.ToInt64(GetLastError())))
            End If
        End If

        Return hProvider
    End Function



    ' Encrypts data by using the bytes passed in as the key for the encryption
    ' This method allocates enough memory to encrypt the data even if CryptoAPI needs
    ' more bytes than in_BytesToEncrypt holds.  The allocation is done dynamically
    Public Function PasswordEncrypt(ByVal in_BytesToEncrypt() As Byte, ByVal in_hProvider As IntPtr, ByVal in_passwordBytes() As Byte, ByRef out_NumEncryptedBytes As Int32) As Byte()
        Dim l_encryptedBytes(2 * in_BytesToEncrypt.Length) As Byte ' = New Byte(2 * in_BytesToEncrypt.Length)

        ' We are not going to catch exceptions.  If things go wrong, any system-generated
        ' exceptions might help the user of this code understand more about what is going on.
        ' We need a finally clause because we want to release the CryptoAPI resources if something goes wrong
        Try
            ' Step 1: Get a handle to a new hash object that will hash the password bytes
            Dim l_hHash As IntPtr = IntPtr.Zero

            If (CryptCreateHash(in_hProvider, Convert.ToInt32(CALG_MD5), IntPtr.Zero, Convert.ToUInt32(0), l_hHash) = False) Then
                Throw New Exception("Could not create a hash object!")
            End If

            ' Step 2: hash the password data....
            ' l_hHash - reference to hash object   in_passwordBytes - bytes to add to hash
            ' in_passwordBytes.Length - length of data to compute hash on
            ' 0 - extra flags

            ' Note: We don't actually get the hash bytes back, we just have a handle to
            ' the hash object that did the computation.  It is holding those bytes internally,
            ' so we don't want or need them
            If (CryptHashData(l_hHash, in_passwordBytes, in_passwordBytes.Length, Convert.ToUInt32(0)) = False) Then
                Throw New Exception("Failure while hashing password bytes!")
            End If


            ' Step 3: Derive an encryption key based on hashed data
            ' in_hProvider - Handle to provider we previously acquired
            ' CALG_RC4 - Popular encryption algorithm
            ' l_hHash - Handle to hash object which will hand over the hash as part of the key derivation
            ' CRYPT_EXPORTABLE - Means the key's bytes could be exported into a byte array, using CryptExportKey
            ' l_hKey - Handle to the key we are deriving
            Dim l_hKey As IntPtr = IntPtr.Zero
            If (CryptDeriveKey(in_hProvider, CALG_RC4, l_hHash, CRYPT_EXPORTABLE, l_hKey) = False) Then
                Throw New Exception("Failure when trying to derive the key!")
            End If

            ' Step 4: Acquire enough memory to assure that encryption succeeds even allowing for some
            ' overflow
            Dim i As Integer
            For i = 0 To in_BytesToEncrypt.Length - 1
                l_encryptedBytes(i) = in_BytesToEncrypt(i)
            Next i

            out_NumEncryptedBytes = in_BytesToEncrypt.Length

            ' Step 5: Do the encryption
            ' l_hKey - Previously acquired key for encryption
            ' IntPtr.Zero - Indicates that we don't want any additional hashing
            ' true - Passed in because this is the only and last data to be encrypted in this session
            ' 0 - Additional flags (none)
            ' l_encryptedBytes - in/out - bytes to be encrypted in place in this buffer
            ' l_datalength - Length of data (number of bytes) to be encrypted
            ' l_encryptedBytes.Length - Lets CryptoAPI know how big the buffer it.  2X data size is plenty
            If (CryptEncrypt(l_hKey, IntPtr.Zero, True, Convert.ToUInt32(0), l_encryptedBytes, out_NumEncryptedBytes, l_encryptedBytes.Length) = False) Then
                Throw New Exception("Failure when calling CryptEncrypt!")
            End If
        Finally
            ' TODO: Release resources
        End Try
        Return l_encryptedBytes
    End Function





    ' Decrypts data by using the bytes passed in as the key for the decryption
    ' This method allocates enough memory to decrypt the data even if CryptoAPI needs
    ' more bytes than in_BytesToDecrypt holds.  The allocation is done dynamically,
    Public Function PasswordDecrypt(ByVal in_BytesToDecrypt() As Byte, ByVal in_NumBytesToDecrypt As Int32, ByVal in_hProvider As IntPtr, ByVal in_passwordBytes() As Byte, ByRef out_NumDecryptedBytes As Int32) As Byte()
        Dim l_decryptedBytes(in_BytesToDecrypt.Length) As Byte

        Dim i As Integer
        For i = 0 To in_BytesToDecrypt.Length - 1
            l_decryptedBytes(i) = in_BytesToDecrypt(i)
        Next i

        ' We are not going to catch exceptions.  If things go wrong, any system-generated
        ' exceptions might help the user of this code understand more about what is going on.
        ' We need a finally clause because we want to release the CryptoAPI resources if something goes wrong
        Try
            ' Step 1: Get a handle to a new hash object that will hash the password bytes
            Dim l_hHash As IntPtr = IntPtr.Zero

            If (CryptCreateHash(in_hProvider, Convert.ToInt32(CALG_MD5), IntPtr.Zero, Convert.ToUInt32(0), l_hHash) = False) Then
                Throw New Exception("Could not create a hash object!")
            End If

            ' Step 2: hash the password data....
            ' l_hHash - reference to hash object   in_passwordBytes - bytes to add to hash
            ' in_passwordBytes.Length - length of data to compute hash on
            ' 0 - extra flags

            ' Note: We don't actually get the hash bytes back, we just have a handle to
            ' the hash object that did the computation.  It is holding those bytes internally,
            ' so we don't want or need them
            If (CryptHashData(l_hHash, in_passwordBytes, in_passwordBytes.Length, Convert.ToUInt32(0)) = False) Then
                Throw New Exception("Failure while hashing password bytes!")
            End If


            ' Step 3: Derive an encryption key based on hashed data
            ' in_hProvider - Handle to provider we previously acquired
            ' CALG_RC4 - Popular encryption algorithm
            ' l_hHash - Handle to hash object which will hand over the hash as part of the key derivation
            ' CRYPT_EXPORTABLE - Means the key's bytes could be exported into a byte array, using CryptExportKey
            ' l_hKey - Handle to the key we are deriving
            Dim l_hKey As IntPtr = IntPtr.Zero
            If (CryptDeriveKey(in_hProvider, CALG_RC4, l_hHash, CRYPT_EXPORTABLE, l_hKey) = False) Then
                Throw New Exception("Failure when trying to derive the key!")
            End If

            ' And now decrypt the data
            out_NumDecryptedBytes = in_NumBytesToDecrypt

            If (CryptDecrypt(l_hKey, IntPtr.Zero, True, Convert.ToUInt32(0), l_decryptedBytes, out_NumDecryptedBytes) = False) Then
                Throw New Exception("Failure when trying to decrypt the data")
            End If

        Finally
            ' TODO: Release resources
        End Try

        Return l_decryptedBytes
    End Function

    ' Computes a hash of the bytes passed in
    Public Function ManagedComputeHash(ByVal in_hProvider As IntPtr, ByVal in_DataToHash() As Byte, ByRef out_NumHashBytes As Int32) As Byte()

        Dim l_HashBuffer(Convert.ToInt32(MAX_HASH)) As Byte
        out_NumHashBytes = Convert.ToInt32(MAX_HASH)

        Try
            ' Step 1: Get a handle to a new hash object that will hash the password bytes
            Dim l_hHash As IntPtr = IntPtr.Zero

            If (CryptCreateHash(in_hProvider, Convert.ToInt32(CALG_MD5), IntPtr.Zero, Convert.ToUInt32(0), l_hHash) = False) Then
                Throw New Exception("Could not create a hash object!")
            End If

            ' Step 2: hash the password data....
            ' l_hHash - reference to hash object   in_passwordBytes - bytes to add to hash
            ' in_passwordBytes.Length - length of data to compute hash on
            ' 0 - extra flags
            If (CryptHashData(l_hHash, in_DataToHash, in_DataToHash.Length, Convert.ToUInt32(0)) = False) Then
                Throw New Exception("Failure while hashing password bytes!")
            End If

            ' Step 3: Retreive the hash bytes
            If (CryptGetHashParam(l_hHash, HP_HASHVAL, l_HashBuffer, out_NumHashBytes, Convert.ToUInt32(0)) = False) Then
                Throw New Exception("Failure when retreiving hash bytes with CryptGetHashParam!")
            End If
        Finally
            ' Release hash object.
            'CryptDestroyHash(hHash);
        End Try
        Return l_HashBuffer
    End Function




    '
    '
    '
    Public Function ImportPublicKey(ByVal in_hProvider As IntPtr, ByVal in_PublicExchangeKey() As Byte) As IntPtr

        Dim h_PublicExchangeKey As IntPtr = IntPtr.Zero
        ' Import the bytes into the CSP, and acquire a handle to the corresponding public key
        If (CryptImportKey(in_hProvider, in_PublicExchangeKey, Convert.ToUInt32(in_PublicExchangeKey.Length), IntPtr.Zero, Convert.ToUInt32(0), h_PublicExchangeKey) = False) Then
            Throw New Exception("Could not import the public key with CryptImportKey!")
        End If

        Return h_PublicExchangeKey
    End Function

    '
    '
    '
    Public Function LoadPrivateSessionKey(ByVal in_hProvider As IntPtr, ByVal in_PrivateSessionKey() As Byte) As IntPtr
        Dim h_PrivateSessionKey As IntPtr = IntPtr.Zero

        ' Import the bytes into the CSP, and acquire a handle to the corresponding private session key
        If (CryptImportKey(in_hProvider, in_PrivateSessionKey, Convert.ToUInt32(in_PrivateSessionKey.Length), IntPtr.Zero, Convert.ToUInt32(0), h_PrivateSessionKey) = False) Then
            Throw New Exception("Could no import the private session key with CryptImportKey!")
        End If

        Return h_PrivateSessionKey
    End Function


    ' This method loads a shared session key that was created by some other device.
    ' The remote device needs to store the same session key privately and load it with LoadPrivateSessionkey.
    ' The remote device can decrypt data that is encrypted with this loaded key and vice versa
    Public Function LoadSharedSessionKey(ByVal in_hProvider As IntPtr, ByVal in_SessionKey() As Byte) As IntPtr

        Dim h_SharedSessionKey As IntPtr = IntPtr.Zero

        If (CryptImportKey(in_hProvider, in_SessionKey, Convert.ToUInt32(in_SessionKey.Length), IntPtr.Zero, Convert.ToUInt32(CRYPT_EXPORTABLE), h_SharedSessionKey) = False) Then
            Throw New Exception("Could not import the shared session key with CryptImportKey! " + TranslateErrorCode(Convert.ToInt64(GetLastError())))
        End If

        Return h_SharedSessionKey
    End Function

    '
    ' Exports the public key, also called the Exchange Key, into a byte array
    '
    Public Function ExportPublicKey(ByVal in_hProvider As IntPtr, ByRef out_PublicExchangeKeySize As Int32) As Byte()

        Dim l_hXchgKey As IntPtr = GetKeyExchangeKey(in_hProvider)
        Dim l_keyBytes(MAX_KEYBLOB) As Byte

        ' CryptExportKey expects out_PublicExchangeKeySize to be the size of the buffer l_KeyBytes when it is called...
        out_PublicExchangeKeySize = l_keyBytes.Length

        If (CryptExportKey(l_hXchgKey, IntPtr.Zero, PUBLICKEYBLOB, Convert.ToUInt32(0), l_keyBytes, out_PublicExchangeKeySize) = False) Then
            Throw New Exception("Error while calling CryptExportKey! " + TranslateErrorCode(Convert.ToInt64(GetLastError())))
        End If

        Return l_keyBytes
    End Function



    '
    ' in_hPublicXChgKey - Get by calling ImportPublicKey
    ' in_hSessionKey - Get by calling GenerateSessionKey
    '
    Public Function ExportSessionKey(ByVal in_hPublicXChgKey As IntPtr, ByVal in_hSessionKey As IntPtr, ByRef out_SessionKeySize As Int32) As Byte()
        Dim l_SessionKeyBytes(MAX_KEYBLOB) As Byte

        ' CryptExportKey expects out_SessionKeySize to be the size of the buffer l_SessionKeyBytes when it is called...
        out_SessionKeySize = l_SessionKeyBytes.Length

        If (CryptExportKey(in_hSessionKey, in_hPublicXChgKey, SIMPLEBLOB, Convert.ToUInt32(0), l_SessionKeyBytes, out_SessionKeySize) = False) Then
            Throw New Exception("Error when calling CryptExportKey!")
        End If

        Return l_SessionKeyBytes
    End Function



    '
    '
    '    in_hSessionKey - Get by calling GenerateSessionKey
    '
    Public Function LocalSaveSessionKey(ByVal in_hProvider As IntPtr, ByVal in_hSessionKey As IntPtr, ByRef out_SessionKeySize As Int32) As Byte()
        Dim l_hXchgKey As IntPtr = GetKeyExchangeKey(in_hProvider)

        Dim l_SessionKeyBytes(MAX_KEYBLOB) As Byte

        ' CryptExportKey expects out_SessionKeySize to be the size of the buffer l_SessionKeyBytes when it is called...
        out_SessionKeySize = l_SessionKeyBytes.Length

        If (CryptExportKey(in_hSessionKey, l_hXchgKey, SIMPLEBLOB, Convert.ToUInt32(0), l_SessionKeyBytes, out_SessionKeySize) = False) Then

            Throw New Exception("Error calling CryptExportKey!")
        End If

        Return l_SessionKeyBytes
    End Function


    Public Function GenerateSessionKey(ByVal in_hProvider As IntPtr) As IntPtr

        Dim h_SessionKey As IntPtr = IntPtr.Zero

        ' Create a random session key
        If (CryptGenKey(in_hProvider, CALG_DES, CRYPT_EXPORTABLE, h_SessionKey) = False) Then
            Throw New Exception("Error trying to call CryptGenKey")
        End If

        Return h_SessionKey
    End Function



    '
    '
    '
    Private Function GetKeyExchangeKey(ByVal in_hProvider As IntPtr) As IntPtr
        Dim l_hXchgKey As IntPtr = IntPtr.Zero
        If (CryptGetUserKey(in_hProvider, AT_KEYEXCHANGE, l_hXchgKey) = False) Then
            Dim l_hSessionKey As IntPtr = IntPtr.Zero

            ' Create an key exchange key pair.
            If (CryptGenKey(in_hProvider, AT_KEYEXCHANGE, 0, l_hSessionKey) = False) Then
                If (CryptGetUserKey(in_hProvider, AT_KEYEXCHANGE, l_hXchgKey) = False) Then
                    Throw New Exception("Second call to CryptGetUserKey failed!")
                End If
            Else
                Throw New Exception("Could not create key exchange keyset")
            End If
        End If
        Return l_hXchgKey
    End Function


    Public Function KeyEncrypt(ByVal in_CryptKey As IntPtr, ByVal in_BytesToEncrypt() As Byte) As Byte()
        Dim l_encryptedBytes(in_BytesToEncrypt.Length * 2) As Byte

        Dim i As Integer
        For i = 0 To i < in_BytesToEncrypt.Length - 1
            l_encryptedBytes(i) = in_BytesToEncrypt(i)
        Next i

        ' Set this to length of array holding the encrypted bytes.  That is how CryptoAPI knows how much space it has
        Dim l_NumEncryptedBytes As Int32 = in_BytesToEncrypt.Length


        If (CryptEncrypt(in_CryptKey, IntPtr.Zero, True, Convert.ToUInt32(0), l_encryptedBytes, l_NumEncryptedBytes, l_encryptedBytes.Length) = False) Then
            Throw New Exception("Failure when calling CryptEncrypt! " + TranslateErrorCode(Convert.ToInt64(GetLastError())))
        End If

        Dim l_ReturnBytes(l_NumEncryptedBytes) As Byte

        For i = 0 To l_NumEncryptedBytes - 1
            l_ReturnBytes(i) = l_encryptedBytes(i)
        Next i

        Return l_ReturnBytes
    End Function


    Public Function KeyDecrypt(ByVal in_CryptKey As IntPtr, ByVal in_BytesToDecrypt() As Byte, ByRef out_BytesDecrypted As Int32) As Byte()
        Dim l_decryptedBytes(in_BytesToDecrypt.Length * 2) As Byte

        Dim i As Integer
        For i = 0 To in_BytesToDecrypt.Length - 1
            l_decryptedBytes(i) = in_BytesToDecrypt(i)
        Next i

        If (CryptDecrypt(in_CryptKey, IntPtr.Zero, True, Convert.ToUInt32(0), l_decryptedBytes, out_BytesDecrypted) = False) Then

            Throw New Exception("Failure when trying to decrypt the data! " + TranslateErrorCode(Convert.ToInt64(GetLastError())))
        End If

        Return l_decryptedBytes
    End Function

End Class
