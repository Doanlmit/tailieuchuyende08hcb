Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents btnDropComplimentaryKeys As System.Windows.Forms.Button
    Friend WithEvents btnDropExportedSessionKey As System.Windows.Forms.Button
    Friend WithEvents btnDropPrivateSessionKey As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.btnDropComplimentaryKeys = New System.Windows.Forms.Button
        Me.btnDropExportedSessionKey = New System.Windows.Forms.Button
        Me.btnDropPrivateSessionKey = New System.Windows.Forms.Button
        '
        'btnDropComplimentaryKeys
        '
        Me.btnDropComplimentaryKeys.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnDropComplimentaryKeys.Location = New System.Drawing.Point(8, 160)
        Me.btnDropComplimentaryKeys.Size = New System.Drawing.Size(224, 48)
        Me.btnDropComplimentaryKeys.Text = "Drop Pair of Session Keys"
        '
        'btnDropExportedSessionKey
        '
        Me.btnDropExportedSessionKey.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnDropExportedSessionKey.Location = New System.Drawing.Point(8, 88)
        Me.btnDropExportedSessionKey.Size = New System.Drawing.Size(224, 48)
        Me.btnDropExportedSessionKey.Text = "Drop Exported Session Key"
        '
        'btnDropPrivateSessionKey
        '
        Me.btnDropPrivateSessionKey.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnDropPrivateSessionKey.Location = New System.Drawing.Point(8, 16)
        Me.btnDropPrivateSessionKey.Size = New System.Drawing.Size(224, 40)
        Me.btnDropPrivateSessionKey.Text = "Drop Private Session Key"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnDropComplimentaryKeys)
        Me.Controls.Add(Me.btnDropExportedSessionKey)
        Me.Controls.Add(Me.btnDropPrivateSessionKey)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    Private Sub DropPrivateSessionKey(ByVal in_hProvider As IntPtr, ByVal in_hSessionKey As IntPtr, ByVal in_Crypto As ManagedCryptoAPI)
        Dim l_SessionKeySize As Int32 = 0
        ' Get the bytes of the session key
        Dim l_SessionKeyBytes() As Byte = in_Crypto.LocalSaveSessionKey(in_hProvider, in_hSessionKey, l_SessionKeySize)

        If (System.IO.File.Exists("\LocalSessionKey.blob")) Then
            System.IO.File.Delete("\LocalSessionKey.blob")
        End If

        ' Store the bytes of the session key on disk
        Dim l_Writer As System.IO.BinaryWriter = New System.IO.BinaryWriter(New System.IO.FileStream("\LocalSessionKey.blob", System.IO.FileMode.CreateNew))
        l_Writer.Write(l_SessionKeyBytes, 0, Convert.ToInt32(l_SessionKeySize))
        l_Writer.Close()
    End Sub
    Private Sub DropExportedSessionKey(ByVal in_hProvider As IntPtr, ByVal in_hSessionKey As IntPtr, ByVal in_Crypto As ManagedCryptoAPI)
        Dim l_PublicExchangeKey As IntPtr = IntPtr.Zero
        Dim l_SessionKeySize As Int32 = 0

        ' Get the bytes of the public exchange key which we already have gotten from another device.			
        Dim l_Reader As System.IO.BinaryReader = New System.IO.BinaryReader(New System.IO.FileStream("\PublicExchangeKey.blob", System.IO.FileMode.Open))
        Dim l_PublicExchangeKeyBytes() As Byte = l_Reader.ReadBytes(1000)
        l_Reader.Close()

        l_PublicExchangeKey = in_Crypto.ImportPublicKey(in_hProvider, l_PublicExchangeKeyBytes)

        Dim l_ExportedSessionKeyBytes() As Byte = in_Crypto.ExportSessionKey(l_PublicExchangeKey, in_hSessionKey, l_SessionKeySize)

        ' The session key is encrypted using the public exchange key from the other device.
        ' We store the bytes of the session key on disk
        If (System.IO.File.Exists("\ExportedSessionKey.blob")) Then
            System.IO.File.Delete("\ExportedSessionKey.blob")
        End If
        Dim l_Writer As System.IO.BinaryWriter = New System.IO.BinaryWriter(New System.IO.FileStream("\ExportedSessionKey.blob", System.IO.FileMode.CreateNew))
        l_Writer.Write(l_ExportedSessionKeyBytes, 0, Convert.ToInt32(l_SessionKeySize))
        l_Writer.Close()
    End Sub

    Private Sub btnDropComplimentaryKeys_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDropComplimentaryKeys.Click
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI

        Dim l_hProvider As IntPtr = IntPtr.Zero
        Dim l_hSessionKey As IntPtr = IntPtr.Zero

        l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART")
        l_hSessionKey = l_Crypto.GenerateSessionKey(l_hProvider)

        ' By dropping these keys with the SAME handle to the session key, they can be used as
        ' complimentary keys for encryption and decryption between two devices
        DropPrivateSessionKey(l_hProvider, l_hSessionKey, l_Crypto)
        DropExportedSessionKey(l_hProvider, l_hSessionKey, l_Crypto)

    End Sub

    Private Sub btnDropExportedSessionKey_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDropExportedSessionKey.Click
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI

        Dim l_hProvider As IntPtr = IntPtr.Zero
        Dim l_hSessionKey As IntPtr = IntPtr.Zero

        l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART")
        l_hSessionKey = l_Crypto.GenerateSessionKey(l_hProvider)

        DropExportedSessionKey(l_hProvider, l_hSessionKey, l_Crypto)
    End Sub

    Private Sub btnDropPrivateSessionKey_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDropPrivateSessionKey.Click
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI

        Dim l_hProvider As IntPtr = IntPtr.Zero
        Dim l_hSessionKey As IntPtr = IntPtr.Zero

        l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART")
        l_hSessionKey = l_Crypto.GenerateSessionKey(l_hProvider)
        DropPrivateSessionKey(l_hProvider, l_hSessionKey, l_Crypto)
    End Sub
End Class
