Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtDecryptedText As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents txtEncryptedBytes As System.Windows.Forms.TextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents txtToEncrypt As System.Windows.Forms.TextBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_EncryptedBytes() As Byte
    Private m_TotalEncryptedBytes As Int32

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label4 = New System.Windows.Forms.Label
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.txtDecryptedText = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.button2 = New System.Windows.Forms.Button
        Me.txtEncryptedBytes = New System.Windows.Forms.TextBox
        Me.button1 = New System.Windows.Forms.Button
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.txtToEncrypt = New System.Windows.Forms.TextBox
        '
        'label4
        '
        Me.label4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label4.Location = New System.Drawing.Point(0, 40)
        Me.label4.Size = New System.Drawing.Size(56, 16)
        Me.label4.Text = "Password"
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtPassword.Location = New System.Drawing.Point(0, 56)
        Me.txtPassword.Size = New System.Drawing.Size(112, 22)
        Me.txtPassword.Text = "textBox4"
        '
        'txtDecryptedText
        '
        Me.txtDecryptedText.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtDecryptedText.Location = New System.Drawing.Point(8, 240)
        Me.txtDecryptedText.ReadOnly = True
        Me.txtDecryptedText.Size = New System.Drawing.Size(224, 22)
        Me.txtDecryptedText.Text = "txtDecryptedText"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label3.Location = New System.Drawing.Point(0, 216)
        Me.label3.Size = New System.Drawing.Size(88, 16)
        Me.label3.Text = "Decrypted Text"
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button2.Location = New System.Drawing.Point(136, 96)
        Me.button2.Size = New System.Drawing.Size(104, 24)
        Me.button2.Text = "Decrypt"
        '
        'txtEncryptedBytes
        '
        Me.txtEncryptedBytes.AcceptsReturn = True
        Me.txtEncryptedBytes.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtEncryptedBytes.Location = New System.Drawing.Point(0, 120)
        Me.txtEncryptedBytes.Multiline = True
        Me.txtEncryptedBytes.ReadOnly = True
        Me.txtEncryptedBytes.Size = New System.Drawing.Size(240, 88)
        Me.txtEncryptedBytes.Text = "textBox2"
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(168, 32)
        Me.button1.Size = New System.Drawing.Size(72, 24)
        Me.button1.Text = "Encrypt"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(0, 96)
        Me.label2.Size = New System.Drawing.Size(72, 24)
        Me.label2.Text = "Cipher bytes"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(0, 8)
        Me.label1.Size = New System.Drawing.Size(56, 24)
        Me.label1.Text = "Plain text"
        '
        'txtToEncrypt
        '
        Me.txtToEncrypt.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtToEncrypt.Location = New System.Drawing.Point(56, 8)
        Me.txtToEncrypt.Size = New System.Drawing.Size(184, 22)
        Me.txtToEncrypt.Text = "textBox1"
        '
        'Form1
        '
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtDecryptedText)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.txtEncryptedBytes)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.txtToEncrypt)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI

        Dim l_PlainTextBytes() As Byte = System.Text.Encoding.ASCII.GetBytes(Me.txtToEncrypt.Text)
        Dim l_PasswordBytes() As Byte = System.Text.Encoding.ASCII.GetBytes(Me.txtPassword.Text)

        Dim l_hProvider As IntPtr = l_Crypto.AcquireNamedContext("KICKSTART")
        m_TotalEncryptedBytes = 0
        m_EncryptedBytes = l_Crypto.PasswordEncrypt(l_PlainTextBytes, l_hProvider, l_PasswordBytes, m_TotalEncryptedBytes)

        Me.txtEncryptedBytes.Text = ""

        Dim i As Integer
        For i = 0 To m_TotalEncryptedBytes - 1
            Me.txtEncryptedBytes.Text += "[" + Convert.ToString(m_EncryptedBytes(i)) + "] "
        Next i
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI


        Dim l_PasswordBytes() As Byte = System.Text.Encoding.ASCII.GetBytes(Me.txtPassword.Text)

        Dim l_hProvider As IntPtr = l_Crypto.AcquireNamedContext("KICKSTART")

        Dim l_TotalDecryptedBytes As Int32 = 0
        Dim l_DecryptedBytes() As Byte = l_Crypto.PasswordDecrypt(m_EncryptedBytes, m_TotalEncryptedBytes, l_hProvider, l_PasswordBytes, l_TotalDecryptedBytes)

        Me.txtDecryptedText.Text = System.Text.Encoding.ASCII.GetString(l_DecryptedBytes, 0, l_DecryptedBytes.Length)

    End Sub
End Class
