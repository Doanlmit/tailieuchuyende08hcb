Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents chkbxUseSharedKey As System.Windows.Forms.CheckBox
    Friend WithEvents btnGo As System.Windows.Forms.Button
    Friend WithEvents txtDecryptedText As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents txtEncryptedBytes As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents txtInitialText As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.chkbxUseSharedKey = New System.Windows.Forms.CheckBox
        Me.btnGo = New System.Windows.Forms.Button
        Me.txtDecryptedText = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.txtEncryptedBytes = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.txtInitialText = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        '
        'chkbxUseSharedKey
        '
        Me.chkbxUseSharedKey.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.chkbxUseSharedKey.Location = New System.Drawing.Point(12, 207)
        Me.chkbxUseSharedKey.Size = New System.Drawing.Size(224, 16)
        Me.chkbxUseSharedKey.Text = "Used Shared Session Key"
        '
        'btnGo
        '
        Me.btnGo.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnGo.Location = New System.Drawing.Point(12, 231)
        Me.btnGo.Size = New System.Drawing.Size(224, 32)
        Me.btnGo.Text = "Go"
        '
        'txtDecryptedText
        '
        Me.txtDecryptedText.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtDecryptedText.Location = New System.Drawing.Point(12, 175)
        Me.txtDecryptedText.Size = New System.Drawing.Size(224, 22)
        Me.txtDecryptedText.Text = "textBox2"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label3.Location = New System.Drawing.Point(4, 159)
        Me.label3.Size = New System.Drawing.Size(100, 16)
        Me.label3.Text = "Decrypted Text"
        '
        'txtEncryptedBytes
        '
        Me.txtEncryptedBytes.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtEncryptedBytes.Location = New System.Drawing.Point(12, 87)
        Me.txtEncryptedBytes.Multiline = True
        Me.txtEncryptedBytes.Size = New System.Drawing.Size(224, 56)
        Me.txtEncryptedBytes.Text = "textBox1"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(4, 71)
        Me.label2.Size = New System.Drawing.Size(176, 24)
        Me.label2.Text = "Encrypted Bytes"
        '
        'txtInitialText
        '
        Me.txtInitialText.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtInitialText.Location = New System.Drawing.Point(12, 23)
        Me.txtInitialText.Size = New System.Drawing.Size(224, 22)
        Me.txtInitialText.Text = "textBox1"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(4, 7)
        Me.label1.Size = New System.Drawing.Size(160, 24)
        Me.label1.Text = "Initial Text"
        '
        'Form1
        '
        Me.Controls.Add(Me.chkbxUseSharedKey)
        Me.Controls.Add(Me.btnGo)
        Me.Controls.Add(Me.txtDecryptedText)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.txtEncryptedBytes)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.txtInitialText)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        Dim l_Crypto As ManagedCryptoAPI = New ManagedCryptoAPI
        Dim l_hProvider As IntPtr = IntPtr.Zero
        Dim l_hPrivateSessionKey As IntPtr = IntPtr.Zero

        l_hProvider = l_Crypto.AcquireNamedContext("KICKSTART")

        ' Get the bytes of the public exchange key which we already have gotten from another device.
        Dim l_Reader As System.IO.BinaryReader = Nothing
        If (Me.chkbxUseSharedKey.Checked) Then
            l_Reader = New System.io.BinaryReader(New System.IO.FileStream("\ExportedSessionKey.blob", System.IO.FileMode.Open))
            Dim l_SharedKeyBytes() As Byte = l_Reader.ReadBytes(1000)
            l_Reader.Close()

            l_hPrivateSessionKey = l_Crypto.LoadSharedSessionKey(l_hProvider, l_SharedKeyBytes)
        Else
            l_Reader = New System.IO.BinaryReader(New System.IO.FileStream("\LocalSessionKey.blob", System.IO.FileMode.Open))
            Dim l_PrivateKeyBytes() As Byte = l_Reader.ReadBytes(1000)
            l_Reader.Close()
            l_hPrivateSessionKey = l_Crypto.LoadPrivateSessionKey(l_hProvider, l_PrivateKeyBytes)
        End If

        Dim l_PlainTextBytes() As Byte = System.Text.Encoding.ASCII.GetBytes(Me.txtInitialText.Text)

        Dim l_Encrypted() As Byte = l_Crypto.KeyEncrypt(l_hPrivateSessionKey, l_PlainTextBytes)


        ' Paint encrypted bytes into the UI
        Me.txtEncryptedBytes.Text = ""
        Dim i As Integer
        For i = 0 To l_Encrypted.Length - 1
            Me.txtEncryptedBytes.Text += "[" + Convert.ToString(l_Encrypted(i)) + "] "
        Next i

        ' Decrypt the bytes
        Dim l_TotalDecrypted As Int32 = l_Encrypted.Length
        Dim l_Decrypted() As Byte = l_Crypto.KeyDecrypt(l_hPrivateSessionKey, l_Encrypted, l_TotalDecrypted)

        ' Paint decrypted bytes into the UI
        Me.txtDecryptedText.Text = System.Text.Encoding.ASCII.GetString(l_Decrypted, 0, l_TotalDecrypted)
    End Sub
End Class
