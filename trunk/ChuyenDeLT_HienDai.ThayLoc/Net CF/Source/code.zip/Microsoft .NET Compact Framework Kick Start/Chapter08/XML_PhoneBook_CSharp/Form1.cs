using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Xml;

namespace XML_PhoneBook_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnNewPhoneBook;
		private System.Windows.Forms.Button btnBeamOut;
		private System.Windows.Forms.Button btnBeamIn;
		private System.Windows.Forms.Button btnAddEntry;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.DataGrid dgPhoneBook;
		
		private		DataSet		m_PhoneBookDataSet;
		private		DataView	m_PhoneBookDataView;
		private		bool		m_Connected;
		private		IrDAClient	m_IrDAClient;

		const int	m_RandomSeed = 988;
		private		Random		m_Random;

		private System.Windows.Forms.Button btnXMLLoad;
		private System.Windows.Forms.Button btnXMLSave;
		private System.Windows.Forms.CheckBox cbHost;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.dgPhoneBook = new System.Windows.Forms.DataGrid();
			this.btnNewPhoneBook = new System.Windows.Forms.Button();
			this.btnXMLLoad = new System.Windows.Forms.Button();
			this.btnBeamOut = new System.Windows.Forms.Button();
			this.btnBeamIn = new System.Windows.Forms.Button();
			this.btnAddEntry = new System.Windows.Forms.Button();
			this.btnXMLSave = new System.Windows.Forms.Button();
			this.cbHost = new System.Windows.Forms.CheckBox();
			// 
			// dgPhoneBook
			// 
			this.dgPhoneBook.Location = new System.Drawing.Point(8, 8);
			this.dgPhoneBook.Size = new System.Drawing.Size(224, 152);
			// 
			// btnNewPhoneBook
			// 
			this.btnNewPhoneBook.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnNewPhoneBook.Location = new System.Drawing.Point(16, 168);
			this.btnNewPhoneBook.Size = new System.Drawing.Size(96, 24);
			this.btnNewPhoneBook.Text = "New Phonebook";
			this.btnNewPhoneBook.Click += new System.EventHandler(this.btnNewPhoneBook_Click);
			// 
			// btnXMLLoad
			// 
			this.btnXMLLoad.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnXMLLoad.Location = new System.Drawing.Point(128, 216);
			this.btnXMLLoad.Size = new System.Drawing.Size(96, 24);
			this.btnXMLLoad.Text = "XML File Load";
			this.btnXMLLoad.Click += new System.EventHandler(this.btnXMLLoad_Click);
			// 
			// btnBeamOut
			// 
			this.btnBeamOut.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnBeamOut.Location = new System.Drawing.Point(16, 192);
			this.btnBeamOut.Size = new System.Drawing.Size(96, 24);
			this.btnBeamOut.Text = "IR Send";
			this.btnBeamOut.Click += new System.EventHandler(this.btnBeamOut_Click);
			// 
			// btnBeamIn
			// 
			this.btnBeamIn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnBeamIn.Location = new System.Drawing.Point(128, 192);
			this.btnBeamIn.Size = new System.Drawing.Size(96, 24);
			this.btnBeamIn.Text = "IR Receive";
			this.btnBeamIn.Click += new System.EventHandler(this.btnBeamIn_Click);
			// 
			// btnAddEntry
			// 
			this.btnAddEntry.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnAddEntry.Location = new System.Drawing.Point(128, 168);
			this.btnAddEntry.Size = new System.Drawing.Size(96, 24);
			this.btnAddEntry.Text = "Add Random";
			this.btnAddEntry.Click += new System.EventHandler(this.btnAddEntry_Click);
			// 
			// btnXMLSave
			// 
			this.btnXMLSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnXMLSave.Location = new System.Drawing.Point(16, 216);
			this.btnXMLSave.Size = new System.Drawing.Size(96, 24);
			this.btnXMLSave.Text = "XML File Save";
			this.btnXMLSave.Click += new System.EventHandler(this.btnXMLSave_Click);
			// 
			// cbHost
			// 
			this.cbHost.Location = new System.Drawing.Point(16, 240);
			this.cbHost.Size = new System.Drawing.Size(48, 24);
			this.cbHost.Text = "Host";
			// 
			// Form1
			// 
			this.Controls.Add(this.cbHost);
			this.Controls.Add(this.btnXMLSave);
			this.Controls.Add(this.btnAddEntry);
			this.Controls.Add(this.btnBeamIn);
			this.Controls.Add(this.btnBeamOut);
			this.Controls.Add(this.btnXMLLoad);
			this.Controls.Add(this.btnNewPhoneBook);
			this.Controls.Add(this.dgPhoneBook);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}
		
		private void WaitForConnection()
		{
			try
			{
				IrDAListener l_IrDAListener = new IrDAListener("IRDA_CHAT_SERVER");

				// Listen for anyone who wants to connect
				l_IrDAListener.Start();

				// And now pull the first queued connection request out as an IrDAClient
				m_IrDAClient = l_IrDAListener.AcceptIrDAClient();
				m_Connected = true;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}


		private void MakeConnection()
		{
			// In this method, we attempt to connect with another device which is
			// waiting for a connection.  We assume that the other device is
			// called the "IRDA_CHAT_SERVER".  We will tell users what devices are
			// in range with a MessageBox and then hope that "IRDA_CHAT_SERVER" is in
			// range.
			const int MAX_DEVICES = 5;
			try
			{
				this.m_IrDAClient = new IrDAClient();

				bool l_foundAnyDevice = false;

				// Find out who's out there to connect with...
				IrDADeviceInfo[] l_DevsAvailable = m_IrDAClient.DiscoverDevices(MAX_DEVICES);
				
				// Show a MessageBox telling user every device we see out there
				foreach (IrDADeviceInfo l_devInfo in l_DevsAvailable)
				{
					l_foundAnyDevice = true;

					// Now try to connect to the devices, hoping it offers a service named "IRDA_CHAT_SERVER"
					try
					{
						// Assume that first device is offering a service that we want
						IrDAEndPoint chatEndPoint = new IrDAEndPoint(l_DevsAvailable[0].DeviceID, "IRDA_CHAT_SERVER");
						m_IrDAClient.Connect(chatEndPoint);
						m_Connected = true;
						break;
					}
					catch (SocketException exc)
					{
						MessageBox.Show(exc.ToString());
					}
				}

				if (!l_foundAnyDevice)
				{
					MessageBox.Show("No devices found to share with!", "Cannot share data");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}


		// Creates a new DataSet for the phone book
		private DataSet ReturnNewPhoneBookDataSet()
		{
			DataSet    l_DataSet = new DataSet();

			// A simple DataTable with a name and an age
			DataTable  l_newTable = new DataTable("People");
			l_newTable.Columns.Add(new DataColumn("Name", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("Phone", typeof(System.String)));
			
			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);

			return l_DataSet;
		}

		private void btnNewPhoneBook_Click(object sender, System.EventArgs e)
		{
			m_PhoneBookDataSet = ReturnNewPhoneBookDataSet();

			// Set up a DataView for the phone book dataset.
			m_PhoneBookDataView = new DataView(m_PhoneBookDataSet.Tables[0]);
			m_PhoneBookDataView.Sort = "Name";
	
			// Bind the DataView to the DataGrid
			this.dgPhoneBook.DataSource = m_PhoneBookDataView;
		}

		private void btnAddEntry_Click(object sender, System.EventArgs e)
		{

			DataRow l_newRow = m_PhoneBookDataSet.Tables[0].NewRow();
			l_newRow[0] = (Convert.ToString(m_Random.Next(10000)) + "'th Random Person");
			l_newRow[1] = Convert.ToString(m_Random.Next(5550000, 5559999));
			m_PhoneBookDataSet.Tables[0].Rows.Add(l_newRow);

			m_PhoneBookDataSet.AcceptChanges();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_Connected = false;
			m_Random = new Random(m_RandomSeed);
		}

		private void btnXMLSave_Click(object sender, System.EventArgs e)
		{
			if (this.m_PhoneBookDataSet != null)
			{
				m_PhoneBookDataSet.WriteXml("\\PhoneBook.xml");
				MessageBox.Show("DataSet saved to \\PhoneBook.xml");
			}
			else
			{
				MessageBox.Show("Must create phonebook before saving it!");
			}		
		}

		private void btnXMLLoad_Click(object sender, System.EventArgs e)
		{

			m_PhoneBookDataSet = new DataSet();

			try
			{
				m_PhoneBookDataSet.ReadXml("\\PhoneBook.xml");
				// Set up a DataView for the phone book dataset.
				m_PhoneBookDataView = new DataView(m_PhoneBookDataSet.Tables[0]);
				m_PhoneBookDataView.Sort = "Name";
	
				// Bind the DataView to the DataGrid
				this.dgPhoneBook.DataSource = m_PhoneBookDataView;
			}
			catch (System.IO.IOException)
			{
				MessageBox.Show("Load from XML failed - no data file?");
			}
		}

		private void DoConnect()
		{
			if (this.cbHost.Checked)
				WaitForConnection();
			else
				MakeConnection();
		}

		private void btnBeamOut_Click(object sender, System.EventArgs e)
		{
			if (!m_Connected)
			{
				MessageBox.Show("Will now connect to remote device.");
				DoConnect();
			}
			if (this.m_PhoneBookDataSet != null)
			{

				if (this.m_Connected)
				{
					// Grab a reference to the stream in the m_IrDAClient and send the text to it.
					StreamWriter l_StreamWriter = new StreamWriter(this.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII);
					System.Xml.XmlTextWriter l_XmlTextWriter = new System.Xml.XmlTextWriter(l_StreamWriter);
					this.m_PhoneBookDataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema);
					l_XmlTextWriter.Flush();
					l_XmlTextWriter.Close();
					this.m_IrDAClient.Close();
					this.m_Connected = false;
				}
				else
				{
					MessageBox.Show("Connect failed! No data sent!");
				}
			}
			else
			{
				MessageBox.Show("Must create phonebook before beaming it out.");
			}
		}

		private void btnBeamIn_Click(object sender, System.EventArgs e)
		{
			if (!m_Connected)
			{
				MessageBox.Show("Will now connect to remote device.");
				DoConnect();
			}

			if (this.m_Connected)
			{

				m_PhoneBookDataSet = new DataSet();

				StreamReader l_StreamReader = null;
				XmlTextReader    l_XmlTextReader = null;
				l_StreamReader = new StreamReader(this.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII);

				l_XmlTextReader = new XmlTextReader(l_StreamReader);
				this.m_PhoneBookDataSet.ReadXml(l_XmlTextReader);
				l_XmlTextReader.Close();		
				this.m_Connected = false;
	
				// Set up a DataView for the phone book dataset.
				m_PhoneBookDataView = new DataView(m_PhoneBookDataSet.Tables[0]);
				m_PhoneBookDataView.Sort = "Name";
	
				// Bind the DataView to the DataGrid
				this.dgPhoneBook.DataSource = m_PhoneBookDataView;	
			}
			else
			{
				MessageBox.Show("Connect failed! No data sent!");
			}
		}

	}
}
