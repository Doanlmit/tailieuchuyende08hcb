using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace XML_DataSetView_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox lbDataSetTables;
		private System.Windows.Forms.TextBox txtXMLToLoad;
		private System.Windows.Forms.Button btnLoadXML;
		private System.Windows.Forms.MainMenu mainMenu1;

		private		DataSet		m_DataSet;
		private System.Windows.Forms.DataGrid MainDataGrid;
		private		DataView	m_DataView;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.MainDataGrid = new System.Windows.Forms.DataGrid();
			this.lbDataSetTables = new System.Windows.Forms.ListBox();
			this.txtXMLToLoad = new System.Windows.Forms.TextBox();
			this.btnLoadXML = new System.Windows.Forms.Button();
			// 
			// MainDataGrid
			// 
			this.MainDataGrid.Size = new System.Drawing.Size(240, 144);
			this.MainDataGrid.Text = "dataGrid1";
			// 
			// lbDataSetTables
			// 
			this.lbDataSetTables.Location = new System.Drawing.Point(0, 152);
			this.lbDataSetTables.Size = new System.Drawing.Size(240, 58);
			this.lbDataSetTables.SelectedIndexChanged += new System.EventHandler(this.lbDataSetTables_SelectedIndexChanged);
			// 
			// txtXMLToLoad
			// 
			this.txtXMLToLoad.Location = new System.Drawing.Point(8, 216);
			this.txtXMLToLoad.Size = new System.Drawing.Size(224, 22);
			this.txtXMLToLoad.Text = "\\PhoneBook.xml";
			// 
			// btnLoadXML
			// 
			this.btnLoadXML.Location = new System.Drawing.Point(8, 248);
			this.btnLoadXML.Size = new System.Drawing.Size(224, 24);
			this.btnLoadXML.Text = "Load XML";
			this.btnLoadXML.Click += new System.EventHandler(this.btnLoadXML_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.btnLoadXML);
			this.Controls.Add(this.txtXMLToLoad);
			this.Controls.Add(this.lbDataSetTables);
			this.Controls.Add(this.MainDataGrid);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		}

		private void btnLoadXML_Click(object sender, System.EventArgs e)
		{
			if (this.m_DataSet == null)
			{
				this.m_DataSet = new DataSet();
			}
			try
			{
				this.m_DataSet.ReadXml(this.txtXMLToLoad.Text);
				foreach(DataTable l_table in m_DataSet.Tables)
				{
					this.lbDataSetTables.Items.Add(l_table.TableName);
				}
				this.lbDataSetTables.SelectedIndex = 0;

				m_DataView = new DataView(m_DataSet.Tables[0]);
	
				// Bind the DataView to the DataGrid
				this.MainDataGrid.DataSource = m_DataView;

			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}

		private void lbDataSetTables_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			m_DataView = new DataView(m_DataSet.Tables[this.lbDataSetTables.SelectedIndex]);
	
			// Bind the DataView to the DataGrid
			this.MainDataGrid.DataSource = m_DataView;
		}
	}
}
