Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents MainDataGrid As System.Windows.Forms.DataGrid
    Friend WithEvents btnLoadXML As System.Windows.Forms.Button
    Friend WithEvents txtXMLToLoad As System.Windows.Forms.TextBox
    Friend WithEvents lbDataSetTables As System.Windows.Forms.ListBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private m_DataSet As DataSet
    Private m_DataView As DataView

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MainDataGrid = New System.Windows.Forms.DataGrid
        Me.btnLoadXML = New System.Windows.Forms.Button
        Me.txtXMLToLoad = New System.Windows.Forms.TextBox
        Me.lbDataSetTables = New System.Windows.Forms.ListBox
        '
        'MainDataGrid
        '
        Me.MainDataGrid.Size = New System.Drawing.Size(240, 144)
        Me.MainDataGrid.Text = "DataGrid1"
        '
        'btnLoadXML
        '
        Me.btnLoadXML.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnLoadXML.Location = New System.Drawing.Point(8, 248)
        Me.btnLoadXML.Size = New System.Drawing.Size(224, 24)
        Me.btnLoadXML.Text = "Load XML"
        '
        'txtXMLToLoad
        '
        Me.txtXMLToLoad.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtXMLToLoad.Location = New System.Drawing.Point(8, 216)
        Me.txtXMLToLoad.Size = New System.Drawing.Size(224, 22)
        Me.txtXMLToLoad.Text = "\PhoneBook.xml"
        '
        'lbDataSetTables
        '
        Me.lbDataSetTables.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.lbDataSetTables.Location = New System.Drawing.Point(0, 152)
        Me.lbDataSetTables.Size = New System.Drawing.Size(240, 58)
        '
        'Form1
        '
        Me.Controls.Add(Me.btnLoadXML)
        Me.Controls.Add(Me.txtXMLToLoad)
        Me.Controls.Add(Me.lbDataSetTables)
        Me.Controls.Add(Me.MainDataGrid)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub btnLoadXML_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLoadXML.Click
        If (Me.m_DataSet Is Nothing) Then
            Me.m_DataSet = New DataSet
        End If

        Try
            Me.m_DataSet.ReadXml(Me.txtXMLToLoad.Text)
            Dim i As Integer = 0
            For i = 0 To m_DataSet.Tables.Count - 1
                Me.lbDataSetTables.Items.Add(m_DataSet.Tables(i).TableName)
            Next i
            Me.lbDataSetTables.SelectedIndex = 0

            m_DataView = New DataView(m_DataSet.Tables(0))

            ' Bind the DataView to the DataGrid
            Me.MainDataGrid.DataSource = m_DataView
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try

    End Sub

    Private Sub lbDataSetTables_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbDataSetTables.SelectedIndexChanged
        m_DataView = New DataView(m_DataSet.Tables(Me.lbDataSetTables.SelectedIndex))

        ' Bind the DataView to the DataGrid
        Me.MainDataGrid.DataSource = m_DataView
    End Sub
End Class
