Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents cbHost As System.Windows.Forms.CheckBox
    Friend WithEvents btnXMLSave As System.Windows.Forms.Button
    Friend WithEvents btnAddEntry As System.Windows.Forms.Button
    Friend WithEvents btnBeamIn As System.Windows.Forms.Button
    Friend WithEvents btnBeamOut As System.Windows.Forms.Button
    Friend WithEvents btnXMLLoad As System.Windows.Forms.Button
    Friend WithEvents btnNewPhoneBook As System.Windows.Forms.Button
    Friend WithEvents dgPhoneBook As System.Windows.Forms.DataGrid
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_PhoneBookDataSet As DataSet
    Private m_PhoneBookDataView As DataView
    Private m_Connected As Boolean
    Private m_IrDAClient As System.Net.Sockets.IrDAClient

    Const m_RandomSeed As Integer = 988
    Private m_Random As Random

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.cbHost = New System.Windows.Forms.CheckBox
        Me.btnXMLSave = New System.Windows.Forms.Button
        Me.btnAddEntry = New System.Windows.Forms.Button
        Me.btnBeamIn = New System.Windows.Forms.Button
        Me.btnBeamOut = New System.Windows.Forms.Button
        Me.btnXMLLoad = New System.Windows.Forms.Button
        Me.btnNewPhoneBook = New System.Windows.Forms.Button
        Me.dgPhoneBook = New System.Windows.Forms.DataGrid
        '
        'cbHost
        '
        Me.cbHost.Location = New System.Drawing.Point(16, 240)
        Me.cbHost.Size = New System.Drawing.Size(48, 24)
        Me.cbHost.Text = "Host"
        '
        'btnXMLSave
        '
        Me.btnXMLSave.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnXMLSave.Location = New System.Drawing.Point(16, 216)
        Me.btnXMLSave.Size = New System.Drawing.Size(96, 24)
        Me.btnXMLSave.Text = "XML File Save"
        '
        'btnAddEntry
        '
        Me.btnAddEntry.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnAddEntry.Location = New System.Drawing.Point(128, 168)
        Me.btnAddEntry.Size = New System.Drawing.Size(96, 24)
        Me.btnAddEntry.Text = "Add Random"
        '
        'btnBeamIn
        '
        Me.btnBeamIn.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnBeamIn.Location = New System.Drawing.Point(128, 192)
        Me.btnBeamIn.Size = New System.Drawing.Size(96, 24)
        Me.btnBeamIn.Text = "IR Receive"
        '
        'btnBeamOut
        '
        Me.btnBeamOut.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnBeamOut.Location = New System.Drawing.Point(16, 192)
        Me.btnBeamOut.Size = New System.Drawing.Size(96, 24)
        Me.btnBeamOut.Text = "IR Send"
        '
        'btnXMLLoad
        '
        Me.btnXMLLoad.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnXMLLoad.Location = New System.Drawing.Point(128, 216)
        Me.btnXMLLoad.Size = New System.Drawing.Size(96, 24)
        Me.btnXMLLoad.Text = "XML File Load"
        '
        'btnNewPhoneBook
        '
        Me.btnNewPhoneBook.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular)
        Me.btnNewPhoneBook.Location = New System.Drawing.Point(16, 168)
        Me.btnNewPhoneBook.Size = New System.Drawing.Size(96, 24)
        Me.btnNewPhoneBook.Text = "New Phonebook"
        '
        'dgPhoneBook
        '
        Me.dgPhoneBook.Location = New System.Drawing.Point(8, 8)
        Me.dgPhoneBook.Size = New System.Drawing.Size(224, 152)
        Me.dgPhoneBook.Text = "DataGrid1"
        '
        'Form1
        '
        Me.Controls.Add(Me.dgPhoneBook)
        Me.Controls.Add(Me.cbHost)
        Me.Controls.Add(Me.btnXMLSave)
        Me.Controls.Add(Me.btnAddEntry)
        Me.Controls.Add(Me.btnBeamIn)
        Me.Controls.Add(Me.btnBeamOut)
        Me.Controls.Add(Me.btnXMLLoad)
        Me.Controls.Add(Me.btnNewPhoneBook)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_Connected = False
        m_Random = New Random(m_RandomSeed)
    End Sub

    ' Creates a new DataSet for the phone book
    Private Function ReturnNewPhoneBookDataSet() As DataSet

        Dim l_DataSet As DataSet = New DataSet

        ' A simple DataTable with a name and an age
        Dim l_newTable As DataTable = New DataTable("People")
        l_newTable.Columns.Add(New DataColumn("Name", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("Phone", System.Type.GetType("System.String")))

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)

        Return l_DataSet
    End Function
    Private Sub btnNewPhoneBook_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewPhoneBook.Click
        m_PhoneBookDataSet = ReturnNewPhoneBookDataSet()

        ' Set up a DataView for the phone book dataset.
        m_PhoneBookDataView = New DataView(m_PhoneBookDataSet.Tables(0))
        m_PhoneBookDataView.Sort = "Name"

        ' Bind the DataView to the DataGrid
        Me.dgPhoneBook.DataSource = m_PhoneBookDataView
    End Sub

    Private Sub btnAddEntry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddEntry.Click
        Dim l_newRow As DataRow = m_PhoneBookDataSet.Tables(0).NewRow()
        l_newRow(0) = (Convert.ToString(m_Random.Next(10000)) + "'th Random Person")
        l_newRow(1) = Convert.ToString(m_Random.Next(5550000, 5559999))
        m_PhoneBookDataSet.Tables(0).Rows.Add(l_newRow)

        m_PhoneBookDataSet.AcceptChanges()
    End Sub
    Private Sub WaitForConnection()
        Try
            Dim l_IrDAListener As System.Net.Sockets.IrDAListener = New System.Net.Sockets.IrDAListener("IRDA_CHAT_SERVER")

            ' Listen for anyone who wants to connect
            l_IrDAListener.Start()

            ' And now pull the first queued connection request out as an IrDAClient
            m_IrDAClient = l_IrDAListener.AcceptIrDAClient()
            m_Connected = True

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub


    Private Sub MakeConnection()

        ' In this method, we attempt to connect with another device which is
        ' waiting for a connection.  We assume that the other device is
        ' called the "IRDA_CHAT_SERVER".  We will tell users what devices are
        ' in range with a MessageBox and then hope that "IRDA_CHAT_SERVER" is in
        ' range.
        Const MAX_DEVICES = 5
        Try
            Me.m_IrDAClient = New System.Net.Sockets.IrDAClient

            Dim l_foundAnyDevice As Boolean
            l_foundAnyDevice = False

            ' Find out who's out there to connect with...
            Dim l_DevsAvailable() As System.Net.Sockets.IrDADeviceInfo
            l_DevsAvailable = m_IrDAClient.DiscoverDevices(MAX_DEVICES)

            ' Show a MessageBox telling user every device we see out there
            Dim i As Integer
            i = 0
            While ((i < l_DevsAvailable.Length) And (m_Connected = False))
                l_foundAnyDevice = True

                ' Now try to connect to the devices, hoping it offers a service named "IRDA_CHAT_SERVER"
                Try
                    ' Assume that first device is offering a service that we want
                    Dim chatEndPoint As System.Net.IrDAEndPoint
                    chatEndPoint = New System.Net.IrDAEndPoint(l_DevsAvailable(0).DeviceID, "IRDA_CHAT_SERVER")
                    m_IrDAClient.Connect(chatEndPoint)
                    m_Connected = True

                Catch exc As System.Net.Sockets.SocketException
                End Try

                If (l_foundAnyDevice = False) Then
                    MessageBox.Show("No devices found to share with!", "Cannot share data")
                End If
            End While
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub



    Private Sub DoConnect()
        If (Me.cbHost.Checked = True) Then
            WaitForConnection()
        Else
            MakeConnection()
        End If
    End Sub

    Private Sub btnBeamOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeamOut.Click
        If (m_Connected = False) Then
            MessageBox.Show("Will now connect to remote device.")
            DoConnect()
        End If
        If (Not (Me.m_PhoneBookDataSet Is Nothing)) Then
            If (Me.m_Connected = True) Then

                ' Grab a reference to the stream in the m_IrDAClient and send the text to it.
                Dim l_StreamWriter As System.IO.StreamWriter = New System.IO.StreamWriter(Me.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII)
                Dim l_XmlTextWriter As System.Xml.XmlTextWriter = New System.Xml.XmlTextWriter(l_StreamWriter)
                Me.m_PhoneBookDataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema)
                l_XmlTextWriter.Flush()
                l_XmlTextWriter.Close()
                Me.m_IrDAClient.Close()
                Me.m_Connected = False
            Else
                MessageBox.Show("Connect failed! No data sent!")
            End If
        Else
            MessageBox.Show("Must create phonebook before beaming it out.")
        End If
    End Sub

    Private Sub btnBeamIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBeamIn.Click
        If (Me.m_Connected = True) Then

            MessageBox.Show("Will now connect to remote device.")
            DoConnect()
        End If

        If (Me.m_Connected) Then
            m_PhoneBookDataSet = New DataSet

            Dim l_StreamReader As System.IO.StreamReader = Nothing
            Dim l_XmlTextReader As System.Xml.XmlTextReader = Nothing
            l_StreamReader = New System.IO.StreamReader(Me.m_IrDAClient.GetStream(), System.Text.Encoding.ASCII)

            l_XmlTextReader = New System.Xml.XmlTextReader(l_StreamReader)
            Me.m_PhoneBookDataSet.ReadXml(l_XmlTextReader)
            l_XmlTextReader.Close()
            Me.m_Connected = False

            ' Set up a DataView for the phone book dataset.
            m_PhoneBookDataView = New DataView(m_PhoneBookDataSet.Tables(0))
            m_PhoneBookDataView.Sort = "Name"

            ' Bind the DataView to the DataGrid
            Me.dgPhoneBook.DataSource = m_PhoneBookDataView
        Else
            MessageBox.Show("Connect failed! No data sent!")
        End If

    End Sub

    Private Sub btnXMLSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXMLSave.Click
        If (Not (Me.m_PhoneBookDataSet Is Nothing)) Then
            m_PhoneBookDataSet.WriteXml("\PhoneBook.xml")
            MessageBox.Show("DataSet saved to \PhoneBook.xml")
        Else
            MessageBox.Show("Must create phonebook before saving it!")
        End If
    End Sub

    Private Sub btnXMLLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXMLLoad.Click
        m_PhoneBookDataSet = New DataSet
        Try
            m_PhoneBookDataSet.ReadXml("\PhoneBook.xml")
            ' Set up a DataView for the phone book dataset.
            m_PhoneBookDataView = New DataView(m_PhoneBookDataSet.Tables(0))
            m_PhoneBookDataView.Sort = "Name"

            ' Bind the DataView to the DataGrid
            Me.dgPhoneBook.DataSource = m_PhoneBookDataView
        Catch exc As System.IO.IOException
            MessageBox.Show("Load from XML failed - no data file?")
        End Try
    End Sub
End Class
