using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace XML_Creator
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnGo;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.btnGo = new System.Windows.Forms.Button();
			// 
			// btnGo
			// 
			this.btnGo.Location = new System.Drawing.Point(56, 200);
			this.btnGo.Size = new System.Drawing.Size(120, 32);
			this.btnGo.Text = "Go";
			this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.btnGo);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnDataSet_OneTable()
		{
			DataSet    l_DataSet = new DataSet();

			// Create a data table that holds a "Name" and a "PhoneNumber"
			DataTable  l_newTable = new DataTable("Demo Table");
			l_newTable.Columns.Add(new DataColumn("AString", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("AnInt16", typeof(System.Int16)));
			l_newTable.Columns.Add(new DataColumn("AnInt32", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("AnInt64", typeof(System.Int64)));
			l_newTable.Columns.Add(new DataColumn("AUInt16", typeof(System.UInt16)));
			l_newTable.Columns.Add(new DataColumn("AUInt32", typeof(System.UInt32)));
			l_newTable.Columns.Add(new DataColumn("AUInt64", typeof(System.UInt64)));
			l_newTable.Columns.Add(new DataColumn("AFloat", typeof(System.Single)));
			l_newTable.Columns.Add(new DataColumn("ADecimal", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("ABoolean", typeof(System.Boolean)));
			l_newTable.Columns.Add(new DataColumn("AChar", typeof(System.Char)));
			l_newTable.Columns.Add(new DataColumn("ADateTime", typeof(System.DateTime)));
			
			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Now put a few names in...

			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "AString1";
			l_newRow[1] = 1;
			l_newRow[2] = 2;
			l_newRow[3] = 3;
			l_newRow[4] = 4;
			l_newRow[5] = 5;
			l_newRow[6] = 6;
			l_newRow[7] = 7;
			l_newRow[8] = 8;
			l_newRow[9] = true;
			l_newRow[10] = 'c';
			l_newRow[11] = new System.DateTime(2001,6,16);
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "AString2";
			l_newRow[1] = 10;
			l_newRow[2] = 20;
			l_newRow[3] = 30;
			l_newRow[4] = 40;
			l_newRow[5] = 50;
			l_newRow[6] = 60;
			l_newRow[7] = 70;
			l_newRow[8] = 80;
			l_newRow[9] = false;
			l_newRow[10] = 'd';
			l_newRow[11] = new System.DateTime(2003,6,24);
			l_DataSet.Tables[0].Rows.Add(l_newRow);


			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnDataSet_AutoIncrementAndUniqueConstraint()
		{
			DataSet    l_DataSet = new DataSet();

			// Create a data table that holds a "Name", "PhoneNumber", and "ContactID"
			DataTable  l_newTable = new DataTable("Phone Contacts");
			l_newTable.Columns.Add(new DataColumn("Name", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("PhoneNumber", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			

			// Don't allow the "Name" DataColumnn to be null
			l_newTable.Columns["Name"].AllowDBNull = false;

			// Set up the ContactID DataColumn as autoincrement by 5, starting at 10
			// That makes ContactID much like a primary key
			l_newTable.Columns["ContactID"].AutoIncrement = true;
			l_newTable.Columns["ContactID"].AutoIncrementSeed = 10;
			l_newTable.Columns["ContactID"].AutoIncrementStep = 5;

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Add a UniqueConstraint to the phone number column
			UniqueConstraint l_UniqueConstraint = new UniqueConstraint(l_DataSet.Tables[0].Columns["PhoneNumber"]);
			l_DataSet.Tables[0].Constraints.Add(l_UniqueConstraint);


			// Now put a few names in...
			// GEORGE WASHINGTON
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "George Washington";
			l_newRow[1] = "340-1776";
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// BEN FRANKLIN
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow["Name"] = "Ben Franklin";					// Searching by column name is SLOWER on the .NET CF!
			l_newRow["PhoneNumber"] = "336-3211";			// Searching by column name is SLOWER on the .NET CF!
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// ALEXANDER HAMILTON
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Alexander Hamilton";			
			l_newRow[1] = "756-3211";			
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}


		private DataSet ReturnDataSet_MultiTable_Expression_FKConstraint()
		{
			DataSet    l_DataSet = new DataSet();

			// Create a data table that holds a "FirstName", "LastName", "FullName" and "ContactID"
			DataTable  l_newTable = new DataTable("PhoneContactsMainTable");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("FirstName", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("LastName", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("FullName", typeof(System.String)));
			
			// Set up the ContactID DataColumn as autoincrement by 5, starting at 10
			// That makes ContactID much like a primary key
			l_newTable.Columns["ContactID"].AutoIncrement = true;
			l_newTable.Columns["ContactID"].AutoIncrementSeed = 10;
			l_newTable.Columns["ContactID"].AutoIncrementStep = 5;


			// Make the "FullName" a computed field that is the concatenation of the first name and
			// the last name.
			l_newTable.Columns["FullName"].Expression = "FirstName + ' ' + LastName";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data table that holds cholesterol readings for each person
			// This data table is a child to the "PhoneContactsMainTable"
			l_newTable = new DataTable("Cholesterol");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("Reading1", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading2", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading3", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("AverageReading", typeof(System.Decimal)));
			
			// Make the "AverageReading" column a computed column by using an expression
			l_newTable.Columns["AverageReading"].Expression = "(Reading1 + Reading2 + Reading3) / 3";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data table that holds blood pressure readings for each person
			// This data table is a child to the "PhoneContactsMainTable"
			l_newTable = new DataTable("BloodPressure");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("Reading1", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading2", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading3", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("AverageReading", typeof(System.Decimal)));

			// Make the "AverageReading" column a computed column by using an expression
			l_newTable.Columns["AverageReading"].Expression = "(Reading1 + Reading2 + Reading3) / 3";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a ForeignKeyConstraint between the two tables.
			// When a parent row in the PhoneContactsMainTableis deleted,
			// all of its child rows in the BloodPressure table are also deleted.
			ForeignKeyConstraint l_ForeignKC = new ForeignKeyConstraint("MainToCholesterolFKConstraint",
				l_DataSet.Tables["PhoneContactsMainTable"].Columns["ContactID"],
				l_DataSet.Tables["BloodPressure"].Columns["ContactID"]);

			// RYATES Thinks that trying to cascade avoids the exception
			l_ForeignKC.DeleteRule = Rule.Cascade;
			l_ForeignKC.UpdateRule = Rule.Cascade;
			l_ForeignKC.AcceptRejectRule = AcceptRejectRule.Cascade;

			l_DataSet.Tables[2].Constraints.Add(l_ForeignKC);
			l_DataSet.EnforceConstraints = true;




			// Now put a few names into the PhoneContactsMainTable
			// GEORGE WASHINGTON
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[1] = "George";
			l_newRow[2] = "Washington";
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// BEN FRANKLIN
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow["FirstName"] = "Ben";				// Searching by column name is SLOWER on the .NET CF!
			l_newRow["LastName"] = "Franklin";			// Searching by column name is SLOWER on the .NET CF!
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// ALEXANDER HAMILTON
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[1] = "Alexander";			
			l_newRow[2] = "Hamilton";			
			l_DataSet.Tables[0].Rows.Add(l_newRow);


			// Insert an entry into the Cholesterol table for George Washington
			l_newRow = l_DataSet.Tables["Cholesterol"].NewRow();
			l_newRow["ContactID"] = l_DataSet.Tables["PhoneContactsMainTable"].Rows[0]["ContactID"];
			l_newRow["Reading1"] = 200;
			l_newRow["Reading2"] = 300;
			l_newRow["Reading3"] = 500;
			l_DataSet.Tables["Cholesterol"].Rows.Add(l_newRow);


			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}



		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnDataSet_MultiTable_Relation()
		{
			DataSet    l_DataSet = new DataSet();

			// Create a data table that holds a "FirstName", "LastName", "FullName" and "ContactID"
			DataTable  l_newTable = new DataTable("PhoneContactsMainTable");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("FirstName", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("LastName", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("FullName", typeof(System.String)));
			
			// Set up the ContactID DataColumn as autoincrement by 5, starting at 10
			// That makes ContactID much like a primary key
			l_newTable.Columns["ContactID"].AutoIncrement = true;
			l_newTable.Columns["ContactID"].AutoIncrementSeed = 10;
			l_newTable.Columns["ContactID"].AutoIncrementStep = 5;


			// Make the "FullName" a computed field that is the concatenation of the first name and
			// the last name.
			l_newTable.Columns["FullName"].Expression = "FirstName + ' ' + LastName";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data table that holds cholesterol readings for each person
			// This data table is a child to the "PhoneContactsMainTable"
			l_newTable = new DataTable("Cholesterol");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("Reading1", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading2", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading3", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("AverageReading", typeof(System.Decimal)));
			
			// Make the "AverageReading" column a computed column by using an expression
			l_newTable.Columns["AverageReading"].Expression = "(Reading1 + Reading2 + Reading3) / 3";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data table that holds blood pressure readings for each person
			// This data table is a child to the "PhoneContactsMainTable"
			l_newTable = new DataTable("BloodPressure");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("Reading1", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading2", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading3", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("AverageReading", typeof(System.Decimal)));

			// Make the "AverageReading" column a computed column by using an expression
			l_newTable.Columns["AverageReading"].Expression = "(Reading1 + Reading2 + Reading3) / 3";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data relation between the PhoneContactsMainTable and the Cholesterol table
			// We will no longer be allowed to delete a row from PhoneContactMainTable if it has
			// children in the Cholesterol table
			DataRelation l_newRelation = new DataRelation("MainContactToCholesterolRelation",
				l_DataSet.Tables["PhoneContactsMainTable"].Columns["ContactID"],
				l_DataSet.Tables["Cholesterol"].Columns["ContactID"]);

			l_DataSet.Relations.Add(l_newRelation);


			// Now put a few names into the PhoneContactsMainTable
			// GEORGE WASHINGTON
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[1] = "George";
			l_newRow[2] = "Washington";
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// BEN FRANKLIN
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow["FirstName"] = "Ben";				// Searching by column name is SLOWER on the .NET CF!
			l_newRow["LastName"] = "Franklin";			// Searching by column name is SLOWER on the .NET CF!
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// ALEXANDER HAMILTON
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[1] = "Alexander";			
			l_newRow[2] = "Hamilton";			
			l_DataSet.Tables[0].Rows.Add(l_newRow);


			// Insert an entry into the Cholesterol table for George Washington
			l_newRow = l_DataSet.Tables["Cholesterol"].NewRow();
			l_newRow["ContactID"] = l_DataSet.Tables["PhoneContactsMainTable"].Rows[0]["ContactID"];
			l_newRow["Reading1"] = 200;
			l_newRow["Reading2"] = 300;
			l_newRow["Reading3"] = 500;
			l_DataSet.Tables["Cholesterol"].Rows.Add(l_newRow);


			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}

		private void btnGo_Click(object sender, System.EventArgs e)
		{
			System.Xml.XmlTextWriter l_XmlTextWriter = null;

			DataSet l_DataSet = ReturnDataSet_OneTable();
			l_XmlTextWriter = new System.Xml.XmlTextWriter(new System.IO.StreamWriter("\\OneSimpleTableDataSet.xml"));
			l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema);
			l_XmlTextWriter.Close();

			
			l_DataSet = ReturnDataSet_AutoIncrementAndUniqueConstraint();
			l_XmlTextWriter = new System.Xml.XmlTextWriter(new System.IO.StreamWriter("\\DataSet_AutoInc_NotNull_UniqueContraint.xml"));
			l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema);
			l_XmlTextWriter.Close();


			
			l_DataSet = ReturnDataSet_MultiTable_Expression_FKConstraint();
			l_XmlTextWriter = new System.Xml.XmlTextWriter(new System.IO.StreamWriter("\\DataSet_MultiTable_FKConstraint.xml"));
			l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema);
			l_XmlTextWriter.Close();


			l_DataSet = ReturnDataSet_MultiTable_Relation();
			l_XmlTextWriter = new System.Xml.XmlTextWriter(new System.IO.StreamWriter("\\DataSet_MultiTable_Relation.xml"));
			l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema);
			l_XmlTextWriter.Close();

			MessageBox.Show("Done");

			// RESEARCH CODE: Read the xml back through a stream connected to a file...
			//
			//
			System.Xml.XmlTextReader l_XmlTextReader = new System.Xml.XmlTextReader(new System.IO.StreamReader("\\DataSet_AutoInc_NotNull_UniqueContraint.xml"));
			l_DataSet.Clear();
			l_DataSet.ReadXml(l_XmlTextReader, XmlReadMode.ReadSchema);
			l_XmlTextReader.Close();

			// Test: Write schema only
			l_DataSet.WriteXmlSchema("\\SCHEMA_DataSet_AutoInc_NotNull_UniqueContraint.xml");

			// Test: Read schema only from xml
			DataSet l_AnotherDS = new DataSet();
			l_AnotherDS.ReadXmlSchema("\\DataSet_AutoInc_NotNull_UniqueContraint.xml");


			// Test: Write the XML but no schema
			l_XmlTextWriter = new System.Xml.XmlTextWriter(new System.IO.StreamWriter("\\NO_SCHEMA_DataSet_AutoInc_NotNull_UniqueContraint.xml"));
			l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.IgnoreSchema);
			l_XmlTextWriter.Close();


			// Test: Read XML, ignore schema if it is present.
			l_AnotherDS = new DataSet();
			l_XmlTextReader = new System.Xml.XmlTextReader(new System.IO.StreamReader("\\DataSet_AutoInc_NotNull_UniqueContraint.xml"));
			l_AnotherDS.ReadXml(l_XmlTextReader, XmlReadMode.IgnoreSchema);
			l_XmlTextReader.Close();

			// Test: Infer the schema
			l_AnotherDS = new DataSet();
			l_XmlTextReader = new System.Xml.XmlTextReader(new System.IO.StreamReader("\\DataSet_AutoInc_NotNull_UniqueContraint.xml"));
			l_AnotherDS.ReadXml(l_XmlTextReader, XmlReadMode.InferSchema);
			l_XmlTextReader.Close();

			// Memory Stream
			try
			{
				// Write to a memory stream
				byte[] l_OutBuff = new byte[4000];
				System.IO.MemoryStream l_OutMemStream = new System.IO.MemoryStream(l_OutBuff, 0, 4000, true, true);
				l_XmlTextWriter = new System.Xml.XmlTextWriter(l_OutMemStream, System.Text.Encoding.Default);
				l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.IgnoreSchema);
				l_XmlTextWriter.Close();
				l_OutMemStream.Close();
				

				// Get buffer with l_MemStream.GetBuffer();

				// Read from a memory Stream
				byte[] l_InBuff = l_OutMemStream.GetBuffer();
				DataSet l_MemStreamDataSet = new DataSet();
				System.IO.MemoryStream l_InMemStream = new System.IO.MemoryStream(l_InBuff, 0, 4000, false, true);
				l_XmlTextReader = new System.Xml.XmlTextReader(l_InMemStream);
				l_MemStreamDataSet.ReadXml(l_XmlTextReader, XmlReadMode.ReadSchema);
				l_XmlTextReader.Close();
				l_InMemStream.Close();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
			
			// Create exception on purpose
			try
			{
				l_AnotherDS.ReadXml("NO_EXIST.XML");
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}


		}
	}
}
