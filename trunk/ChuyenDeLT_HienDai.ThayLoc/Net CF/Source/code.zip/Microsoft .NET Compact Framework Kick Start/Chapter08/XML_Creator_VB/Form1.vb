Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents btnGo As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.btnGo = New System.Windows.Forms.Button
        '
        'btnGo
        '
        Me.btnGo.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.btnGo.Location = New System.Drawing.Point(56, 200)
        Me.btnGo.Size = New System.Drawing.Size(120, 32)
        Me.btnGo.Text = "Go"
        '
        'Form1
        '
        Me.Controls.Add(Me.btnGo)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    ' Creates a new DataSet and fills it with phone book entries programmatically
    Private Function ReturnDataSet_OneTable() As DataSet

        Dim l_DataSet As DataSet = New DataSet

        ' Create a data table that holds a "Name" and a "PhoneNumber"
        Dim l_newTable As DataTable = New DataTable("Demo Table")
        l_newTable.Columns.Add(New DataColumn("AString", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("AnInt16", System.Type.GetType("System.Int16")))
        l_newTable.Columns.Add(New DataColumn("AnInt32", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("AnInt64", System.Type.GetType("System.Int64")))
        l_newTable.Columns.Add(New DataColumn("AUInt16", System.Type.GetType("System.UInt16")))
        l_newTable.Columns.Add(New DataColumn("AUInt32", System.Type.GetType("System.UInt32")))
        l_newTable.Columns.Add(New DataColumn("AUInt64", System.Type.GetType("System.UInt64")))
        l_newTable.Columns.Add(New DataColumn("AFloat", System.Type.GetType("System.Single")))
        l_newTable.Columns.Add(New DataColumn("ADecimal", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("ABoolean", System.Type.GetType("System.Boolean")))
        l_newTable.Columns.Add(New DataColumn("AChar", System.Type.GetType("System.Char")))
        l_newTable.Columns.Add(New DataColumn("ADateTime", System.Type.GetType("System.DateTime")))

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Now put a few names in...
        Dim l_newRow As DataRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "AString1"
        l_newRow(1) = 1
        l_newRow(2) = 2
        l_newRow(3) = 3
        l_newRow(4) = 4
        l_newRow(5) = 5
        l_newRow(6) = 6
        l_newRow(7) = 7
        l_newRow(8) = 8
        l_newRow(9) = True
        l_newRow(10) = Convert.ToChar("c")
        l_newRow(11) = New System.DateTime(2001, 6, 16)
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "AString2"
        l_newRow(1) = 10
        l_newRow(2) = 20
        l_newRow(3) = 30
        l_newRow(4) = 40
        l_newRow(5) = 50
        l_newRow(6) = 60
        l_newRow(7) = 70
        l_newRow(8) = 80
        l_newRow(9) = False
        l_newRow(10) = Convert.ToChar("d")
        l_newRow(11) = New System.DateTime(2003, 6, 24)
        l_DataSet.Tables(0).Rows.Add(l_newRow)


        ' Commit the changes
        l_DataSet.AcceptChanges()

        Return l_DataSet
    End Function

    ' Creates a new DataSet and fills it with phone book entries programmatically
    Private Function ReturnDataSet_AutoIncrementAndUniqueConstraint() As DataSet

        Dim l_DataSet As DataSet = New DataSet

        ' Create a data table that holds a "Name", "PhoneNumber", and "ContactID"
        Dim l_newTable As DataTable = New DataTable("Phone Contacts")
        l_newTable.Columns.Add(New DataColumn("Name", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("PhoneNumber", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))


        ' Don't allow the "Name" DataColumnn to be null
        l_newTable.Columns("Name").AllowDBNull = False

        ' Set up the ContactID DataColumn as autoincrement by 5, starting at 10
        ' That makes ContactID much like a primary key
        l_newTable.Columns("ContactID").AutoIncrement = True
        l_newTable.Columns("ContactID").AutoIncrementSeed = 10
        l_newTable.Columns("ContactID").AutoIncrementStep = 5

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Add a UniqueConstraint to the phone number column
        Dim l_UniqueConstraint As UniqueConstraint = New UniqueConstraint(l_DataSet.Tables(0).Columns("PhoneNumber"))
        l_DataSet.Tables(0).Constraints.Add(l_UniqueConstraint)


        ' Now put a few names in...
        ' GEORGE WASHINGTON
        Dim l_newRow As DataRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "George Washington"
        l_newRow(1) = "340-1776"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' BEN FRANKLIN
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow("Name") = "Ben Franklin"      ' Searching by column name is SLOWER on the .NET CF!
        l_newRow("PhoneNumber") = "336-3211"    ' Searching by column name is SLOWER on the .NET CF!
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' ALEXANDER HAMILTON
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Alexander Hamilton"
        l_newRow(1) = "756-3211"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' Commit the changes
        l_DataSet.AcceptChanges()

        Return l_DataSet
    End Function


    Private Function ReturnDataSet_MultiTable_Expression_FKConstraint() As DataSet

        Dim l_DataSet As DataSet = New DataSet

        ' Create a data table that holds a "FirstName", "LastName", "FullName" and "ContactID"
        Dim l_newTable As DataTable = New DataTable("PhoneContactsMainTable")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("FirstName", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("LastName", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("FullName", System.Type.GetType("System.String")))

        ' Set up the ContactID DataColumn as autoincrement by 5, starting at 10
        ' That makes ContactID much like a primary key
        l_newTable.Columns("ContactID").AutoIncrement = True
        l_newTable.Columns("ContactID").AutoIncrementSeed = 10
        l_newTable.Columns("ContactID").AutoIncrementStep = 5


        ' Make the "FullName" a computed field that is the concatenation of the first name and
        ' the last name.
        l_newTable.Columns("FullName").Expression = "FirstName + ' ' + LastName"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a data table that holds cholesterol readings for each person
        ' This data table is a child to the "PhoneContactsMainTable"
        l_newTable = New DataTable("Cholesterol")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("Reading1", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading2", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading3", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("AverageReading", System.Type.GetType("System.Decimal")))

        ' Make the "AverageReading" column a computed column by using an expression
        l_newTable.Columns("AverageReading").Expression = "(Reading1 + Reading2 + Reading3) / 3"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a data table that holds blood pressure readings for each person
        ' This data table is a child to the "PhoneContactsMainTable"
        l_newTable = New DataTable("BloodPressure")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("Reading1", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading2", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading3", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("AverageReading", System.Type.GetType("System.Decimal")))

        ' Make the "AverageReading" column a computed column by using an expression
        l_newTable.Columns("AverageReading").Expression = "(Reading1 + Reading2 + Reading3) / 3"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a ForeignKeyConstraint between the two tables.
        ' When a parent row in the PhoneContactsMainTableis deleted,
        ' all of its child rows in the BloodPressure table are also deleted.
        Dim l_ForeignKC As ForeignKeyConstraint = New ForeignKeyConstraint("MainToCholesterolFKConstraint", l_DataSet.Tables("PhoneContactsMainTable").Columns("ContactID"), l_DataSet.Tables("BloodPressure").Columns("ContactID"))

        ' RYATES Thinks that trying to cascade avoids the exception
        l_ForeignKC.DeleteRule = Rule.Cascade
        l_ForeignKC.UpdateRule = Rule.Cascade
        l_ForeignKC.AcceptRejectRule = AcceptRejectRule.Cascade

        l_DataSet.Tables(2).Constraints.Add(l_ForeignKC)
        l_DataSet.EnforceConstraints = True




        ' Now put a few names into the PhoneContactsMainTable
        ' GEORGE WASHINGTON
        Dim l_newRow As DataRow = l_DataSet.Tables(0).NewRow()
        l_newRow(1) = "George"
        l_newRow(2) = "Washington"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' BEN FRANKLIN
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow("FirstName") = "Ben"     ' Searching by column name is SLOWER on the .NET CF!
        l_newRow("LastName") = "Franklin"    ' Searching by column name is SLOWER on the .NET CF!
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' ALEXANDER HAMILTON
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(1) = "Alexander"
        l_newRow(2) = "Hamilton"
        l_DataSet.Tables(0).Rows.Add(l_newRow)


        ' Insert an entry into the Cholesterol table for George Washington
        l_newRow = l_DataSet.Tables("Cholesterol").NewRow()
        l_newRow("ContactID") = l_DataSet.Tables("PhoneContactsMainTable").Rows(0)("ContactID")
        l_newRow("Reading1") = 200
        l_newRow("Reading2") = 300
        l_newRow("Reading3") = 500
        l_DataSet.Tables("Cholesterol").Rows.Add(l_newRow)


        ' Commit the changes
        l_DataSet.AcceptChanges()

        Return l_DataSet
    End Function



    ' Creates a new DataSet and fills it with phone book entries programmatically
    Private Function ReturnDataSet_MultiTable_Relation() As DataSet

        Dim l_DataSet As DataSet = New DataSet

        ' Create a data table that holds a "FirstName", "LastName", "FullName" and "ContactID"
        Dim l_newTable As DataTable = New DataTable("PhoneContactsMainTable")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("FirstName", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("LastName", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("FullName", System.Type.GetType("System.String")))

        ' Set up the ContactID DataColumn as autoincrement by 5, starting at 10
        ' That makes ContactID much like a primary key
        l_newTable.Columns("ContactID").AutoIncrement = True
        l_newTable.Columns("ContactID").AutoIncrementSeed = 10
        l_newTable.Columns("ContactID").AutoIncrementStep = 5


        ' Make the "FullName" a computed field that is the concatenation of the first name and
        ' the last name.
        l_newTable.Columns("FullName").Expression = "FirstName + ' ' + LastName"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a data table that holds cholesterol readings for each person
        ' This data table is a child to the "PhoneContactsMainTable"
        l_newTable = New DataTable("Cholesterol")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("Reading1", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading2", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading3", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("AverageReading", System.Type.GetType("System.Decimal")))

        ' Make the "AverageReading" column a computed column by using an expression
        l_newTable.Columns("AverageReading").Expression = "(Reading1 + Reading2 + Reading3) / 3"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a data table that holds blood pressure readings for each person
        ' This data table is a child to the "PhoneContactsMainTable"
        l_newTable = New DataTable("BloodPressure")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("Reading1", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading2", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading3", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("AverageReading", System.Type.GetType("System.Decimal")))

        ' Make the "AverageReading" column a computed column by using an expression
        l_newTable.Columns("AverageReading").Expression = "(Reading1 + Reading2 + Reading3) / 3"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a data relation between the PhoneContactsMainTable and the Cholesterol table
        ' We will no longer be allowed to delete a row from PhoneContactMainTable if it has
        ' children in the Cholesterol table
        Dim l_newRelation As DataRelation = New DataRelation("MainContactToCholesterolRelation", _
         l_DataSet.Tables("PhoneContactsMainTable").Columns("ContactID"), _
         l_DataSet.Tables("Cholesterol").Columns("ContactID"))

        l_DataSet.Relations.Add(l_newRelation)


        ' Now put a few names into the PhoneContactsMainTable
        ' GEORGE WASHINGTON
        Dim l_newRow As DataRow = l_DataSet.Tables(0).NewRow()
        l_newRow(1) = "George"
        l_newRow(2) = "Washington"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' BEN FRANKLIN
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow("FirstName") = "Ben"     ' Searching by column name is SLOWER on the .NET CF!
        l_newRow("LastName") = "Franklin"    ' Searching by column name is SLOWER on the .NET CF!
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' ALEXANDER HAMILTON
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(1) = "Alexander"
        l_newRow(2) = "Hamilton"
        l_DataSet.Tables(0).Rows.Add(l_newRow)


        ' Insert an entry into the Cholesterol table for George Washington
        l_newRow = l_DataSet.Tables("Cholesterol").NewRow()
        l_newRow("ContactID") = l_DataSet.Tables("PhoneContactsMainTable").Rows(0)("ContactID")
        l_newRow("Reading1") = 200
        l_newRow("Reading2") = 300
        l_newRow("Reading3") = 500
        l_DataSet.Tables("Cholesterol").Rows.Add(l_newRow)


        ' Commit the changes
        l_DataSet.AcceptChanges()

        Return l_DataSet
    End Function

    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        Dim l_XmlTextWriter As System.Xml.XmlTextWriter = Nothing

        Dim l_DataSet As DataSet = ReturnDataSet_OneTable()
        l_XmlTextWriter = New System.Xml.XmlTextWriter(New System.IO.StreamWriter("\OneSimpleTableDataSet.xml"))
        l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema)
        l_XmlTextWriter.Close()


        l_DataSet = ReturnDataSet_AutoIncrementAndUniqueConstraint()
        l_XmlTextWriter = New System.Xml.XmlTextWriter(New System.IO.StreamWriter("\DataSet_AutoInc_NotNull_UniqueContraint.xml"))
        l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema)
        l_XmlTextWriter.Close()



        l_DataSet = ReturnDataSet_MultiTable_Expression_FKConstraint()
        l_XmlTextWriter = New System.Xml.XmlTextWriter(New System.IO.StreamWriter("\DataSet_MultiTable_FKConstraint.xml"))
        l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema)
        l_XmlTextWriter.Close()


        l_DataSet = ReturnDataSet_MultiTable_Relation()
        l_XmlTextWriter = New System.Xml.XmlTextWriter(New System.IO.StreamWriter("\DataSet_MultiTable_Relation.xml"))
        l_DataSet.WriteXml(l_XmlTextWriter, XmlWriteMode.WriteSchema)
        l_XmlTextWriter.Close()

        MessageBox.Show("Done")

    End Sub
End Class
