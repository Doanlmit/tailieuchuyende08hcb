using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Sams.KickStart.NetCF.PerfCounterApp
{
	/// <summary>
	/// Summary description for PerfCounterComparison.
	/// </summary>
	public class PerfCounterComparison : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label lblValueF1;
		private System.Windows.Forms.Label lblNF1;
		private System.Windows.Forms.Label lblMeanF1;
		private System.Windows.Forms.Label lblMaxF1;
		private System.Windows.Forms.Label lblMinF1;
		private System.Windows.Forms.Label lblMaxF2;
		private System.Windows.Forms.Label lblMinF2;
		private System.Windows.Forms.Label lblMeanF2;
		private System.Windows.Forms.Label lblNF2;
		private System.Windows.Forms.Label lblValueF2;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PerfCounterComparison(NetCFPerfCounter counterOne, NetCFPerfCounter counterTwo) :
			this()
		{
			this.Text = counterOne.Name;
			
			this.lblValueF1.Text = counterOne.Value.ToString();
			this.lblValueF2.Text = counterTwo.Value.ToString();

			this.lblNF1.Text = counterOne.N.ToString();
			this.lblNF2.Text = counterTwo.N.ToString();

			this.lblMeanF1.Text = counterOne.Mean.ToString();
			this.lblMeanF2.Text = counterTwo.Mean.ToString();

			this.lblMinF1.Text = counterOne.Min.ToString();
			this.lblMinF2.Text = counterTwo.Min.ToString();

			this.lblMaxF1.Text = counterOne.Max.ToString();
			this.lblMaxF2.Text = counterTwo.Max.ToString();
		}
		
		public PerfCounterComparison()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.lblValueF1 = new System.Windows.Forms.Label();
			this.lblNF1 = new System.Windows.Forms.Label();
			this.lblMeanF1 = new System.Windows.Forms.Label();
			this.lblMinF1 = new System.Windows.Forms.Label();
			this.lblMaxF1 = new System.Windows.Forms.Label();
			this.lblMaxF2 = new System.Windows.Forms.Label();
			this.lblMinF2 = new System.Windows.Forms.Label();
			this.lblMeanF2 = new System.Windows.Forms.Label();
			this.lblNF2 = new System.Windows.Forms.Label();
			this.lblValueF2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Value:";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 80);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "N:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 112);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(40, 16);
			this.label3.TabIndex = 2;
			this.label3.Text = "Mean:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 144);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(40, 16);
			this.label4.TabIndex = 3;
			this.label4.Text = "Min:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 176);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 16);
			this.label5.TabIndex = 4;
			this.label5.Text = "Max:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(64, 16);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(64, 16);
			this.label6.TabIndex = 5;
			this.label6.Text = "File One";
			this.label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(168, 16);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(64, 16);
			this.label7.TabIndex = 6;
			this.label7.Text = "File Two";
			this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// lblValueF1
			// 
			this.lblValueF1.Location = new System.Drawing.Point(56, 48);
			this.lblValueF1.Name = "lblValueF1";
			this.lblValueF1.Size = new System.Drawing.Size(88, 16);
			this.lblValueF1.TabIndex = 7;
			this.lblValueF1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblNF1
			// 
			this.lblNF1.Location = new System.Drawing.Point(56, 80);
			this.lblNF1.Name = "lblNF1";
			this.lblNF1.Size = new System.Drawing.Size(88, 16);
			this.lblNF1.TabIndex = 9;
			this.lblNF1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMeanF1
			// 
			this.lblMeanF1.Location = new System.Drawing.Point(56, 112);
			this.lblMeanF1.Name = "lblMeanF1";
			this.lblMeanF1.Size = new System.Drawing.Size(88, 16);
			this.lblMeanF1.TabIndex = 11;
			this.lblMeanF1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMinF1
			// 
			this.lblMinF1.Location = new System.Drawing.Point(56, 144);
			this.lblMinF1.Name = "lblMinF1";
			this.lblMinF1.Size = new System.Drawing.Size(88, 16);
			this.lblMinF1.TabIndex = 13;
			this.lblMinF1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMaxF1
			// 
			this.lblMaxF1.Location = new System.Drawing.Point(56, 176);
			this.lblMaxF1.Name = "lblMaxF1";
			this.lblMaxF1.Size = new System.Drawing.Size(88, 16);
			this.lblMaxF1.TabIndex = 15;
			this.lblMaxF1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMaxF2
			// 
			this.lblMaxF2.Location = new System.Drawing.Point(160, 176);
			this.lblMaxF2.Name = "lblMaxF2";
			this.lblMaxF2.Size = new System.Drawing.Size(88, 16);
			this.lblMaxF2.TabIndex = 22;
			this.lblMaxF2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMinF2
			// 
			this.lblMinF2.Location = new System.Drawing.Point(160, 144);
			this.lblMinF2.Name = "lblMinF2";
			this.lblMinF2.Size = new System.Drawing.Size(88, 16);
			this.lblMinF2.TabIndex = 21;
			this.lblMinF2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblMeanF2
			// 
			this.lblMeanF2.Location = new System.Drawing.Point(160, 112);
			this.lblMeanF2.Name = "lblMeanF2";
			this.lblMeanF2.Size = new System.Drawing.Size(88, 16);
			this.lblMeanF2.TabIndex = 20;
			this.lblMeanF2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblNF2
			// 
			this.lblNF2.Location = new System.Drawing.Point(160, 80);
			this.lblNF2.Name = "lblNF2";
			this.lblNF2.Size = new System.Drawing.Size(88, 16);
			this.lblNF2.TabIndex = 19;
			this.lblNF2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblValueF2
			// 
			this.lblValueF2.Location = new System.Drawing.Point(160, 48);
			this.lblValueF2.Name = "lblValueF2";
			this.lblValueF2.Size = new System.Drawing.Size(88, 16);
			this.lblValueF2.TabIndex = 18;
			this.lblValueF2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PerfCounterComparison
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(258, 200);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblMaxF2,
																		  this.lblMinF2,
																		  this.lblMeanF2,
																		  this.lblNF2,
																		  this.lblValueF2,
																		  this.lblMaxF1,
																		  this.lblMinF1,
																		  this.lblMeanF1,
																		  this.lblNF1,
																		  this.lblValueF1,
																		  this.label7,
																		  this.label6,
																		  this.label5,
																		  this.label4,
																		  this.label3,
																		  this.label2,
																		  this.label1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "PerfCounterComparison";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "Perf Counter Comparison";
			this.ResumeLayout(false);

		}
		#endregion
	}
}
