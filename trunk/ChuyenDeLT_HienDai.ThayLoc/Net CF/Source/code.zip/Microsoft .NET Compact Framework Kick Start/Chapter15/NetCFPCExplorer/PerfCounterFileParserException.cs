using System;

namespace Sams.KickStart.NetCF.PerfCounterApp
{
    public class PerfCounterFileParserException : Exception
    {
        string m_FileName;
        int m_LineNumber;
        int m_LinePosition;

        public PerfCounterFileParserException(string msg, string fileName, int lineNumber, int linePosition)            
            : base(msg)
        {
            m_FileName = fileName;
            m_LineNumber = lineNumber;
            m_LinePosition = linePosition;
        }
        
        public PerfCounterFileParserException(string msg, string fileName, int lineNumber, int linePosition, Exception innerException)
            : base(msg, innerException)
        {
            m_FileName = fileName;
            m_LineNumber = lineNumber;
            m_LinePosition = linePosition;
        }

        public string FileName
        {
            get{ return m_FileName; }
        }

        public int LineNumber
        {
            get{ return m_LineNumber; }
        }

        public int LinePosition
        {
            get{ return m_LinePosition; }
        }
    }
}