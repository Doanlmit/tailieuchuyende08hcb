using System;
using System.IO;
using System.Text;
using System.Collections;

namespace Sams.KickStart.NetCF.PerfCounterApp
{
	public class PerfCounterFileParser : IDisposable
	{
        string          m_FileName;
        StreamReader    m_Reader;
        ArrayList       m_PerfCounters;
        int             m_LineNumber;
        int             m_LinePosition;
        
		public PerfCounterFileParser(string fileName)
		{
            m_FileName = fileName;		
            m_Reader = new StreamReader(new FileStream(m_FileName, FileMode.Open, FileAccess.Read));
            
            m_PerfCounters = new ArrayList();
            m_LineNumber = m_LinePosition = 1;
		}

        public ArrayList Parse()
        {
            NetCFPerfCounter perfCounter;

            // Read the file header
            ReadHeader();

            // Read the performance counters 
            while(null != (perfCounter = ReadPerfCounter()))
            {
                m_PerfCounters.Add(perfCounter);
            }

            // Return the perf counters to the caller
            return m_PerfCounters;
        }
                        
        public void ReadHeader()
        {
            string line;
            line = m_Reader.ReadLine();

            if(line == null)
                ThrowException("Unexpected end of file. Expecting first line of the file header");
            
            line = m_Reader.ReadLine();
            if(line == null)
                ThrowException("Unexpected end of file. Expecting second line of the file header");

            ++m_LineNumber;
            if(!line.StartsWith("counter"))
                ThrowException("Expected the header row of the file");
        }

        public NetCFPerfCounter ReadPerfCounter()
        {
            string line;
            line = m_Reader.ReadLine();
            
            ++m_LineNumber;
            if(line == null)
                return null;

            int startNdx = 0, 
                endNdx = 0,
                lineLength = line.Length;                        

            // Create the perf counter object while reading the name from the file
            NetCFPerfCounter perfCounter = new NetCFPerfCounter(ReadName(line, lineLength, startNdx, ref endNdx));                        
            ReadWhitespace(line, lineLength, ref endNdx);
            
            // get the value
            startNdx = endNdx;            
            perfCounter.Value = ReadNumericValue(line, lineLength, startNdx, ref endNdx);
            ReadWhitespace(line, lineLength, ref endNdx);
            
            // get the n value
            startNdx = endNdx;
            perfCounter.N = ReadNumericValue(line, lineLength, startNdx, ref endNdx);
            ReadWhitespace(line, lineLength, ref endNdx);

            // get the mean value
            startNdx = endNdx;
            perfCounter.Mean = ReadNumericValue(line, lineLength, startNdx, ref endNdx);
            ReadWhitespace(line, lineLength, ref endNdx);

            // get the min value
            startNdx = endNdx;
            perfCounter.Min = ReadNumericValue(line, lineLength, startNdx, ref endNdx);
            ReadWhitespace(line, lineLength, ref endNdx);

            // get the max value
            startNdx = endNdx;
            perfCounter.Max = ReadNumericValue(line, lineLength, startNdx, ref endNdx);

            return perfCounter;
        }

        public void ReadWhitespace(string line, int lineLength, ref int ndx)
        {
            // skip whitespace
            while(ndx < lineLength && char.IsWhiteSpace(line[ndx]))
            {
                ++ndx;
            }
            
            m_LinePosition = ndx;
            if(ndx >= lineLength || Char.IsWhiteSpace(line[ndx]))
            {
                ThrowException("Found end of line or whitespace where text was expected.");                
            }
        }

        public string ReadName(string line, int lineLength, int startNdx, ref int endNdx)
        {
            while( endNdx < lineLength                      &&
                 ( !Char.IsWhiteSpace( line[endNdx] )     ||  
                 ( !Char.IsWhiteSpace( line[endNdx + 1] ) ) ) )
            {
                ++endNdx;
            }            
            
            // Now, we are either at the end of the line or on a whitespace character
            m_LinePosition = endNdx;
            if(endNdx >= lineLength || !Char.IsWhiteSpace(line[endNdx]) )
                ThrowException("Found end of line or whitespace where text was expected after reading counter name.");                

            return line.Substring(startNdx, endNdx);
        }

        public long ReadNumericValue(string line, int lineLength, int startNdx, ref int endNdx)
        {
            // Read each character up to a whitespace
            while( endNdx < lineLength && !Char.IsWhiteSpace(line[endNdx]))
            {
                ++endNdx;
            }    
            
            // Do we have any characters to convert???
            m_LinePosition = endNdx;
            if(startNdx == endNdx)
                ThrowException("Expected a counter value.");                
            
            try
            {
                return Int64.Parse(line.Substring(startNdx, (endNdx - startNdx)));
            }
            catch(Exception e)
            {
                ThrowException("Error reading performance counter value.", e);                
                return -1;
            }
        }

		public void Close()
		{
			if(m_Reader != null)
				m_Reader.Close();

			if(m_PerfCounters != null)
				m_PerfCounters = null;
		}

        public void ThrowException(string msg)
        {
            throw new PerfCounterFileParserException(msg, this.m_FileName, this.m_LineNumber, this.m_LinePosition);
        }

        public void ThrowException(string msg, Exception inner)
        {
            throw new PerfCounterFileParserException(msg, this.m_FileName, this.m_LineNumber, this.m_LinePosition, inner);
        }

        #region IDisposable Members

        public void Dispose()
        {
            Close();
        }

        #endregion
    }
}
