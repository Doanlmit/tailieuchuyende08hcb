using System;
using System.Collections;

namespace Sams.KickStart.NetCF.PerfCounterApp
{
    public class PerfCounterDescriptionTable
    {
        private static Hashtable DescriptionTable;

        static PerfCounterDescriptionTable()
        {
            DescriptionTable = new Hashtable();

            DescriptionTable.Add("Execution Engine Startup Time",
                "The time from when the execution engine first gets control, after the OS has loaded the exe and dll�s, to when the execution engine is about to call the main method of the application.");
            DescriptionTable.Add("Total Program Run Time",
                "The time from when the execution engine first gets control to when the execution engine terminates. The time is measured in milliseconds. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Peak Bytes Allocated",
                "The largest number of bytes allocated at once. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Number Of Objects Allocated",
                "The total number of objects allocated by the execution engine. This includes every object that was created while the program was executing. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Bytes Allocated",
                "The number of bytes allocated for the all of the objects allocated in the system. The value n is the number of objects allocated. The mean value is the mean number of bytes allocated per object. The min value is the size of the smallest object. The max value is the size of the largest object allocated. All values except n are measured in bytes. The n value is measured in objects and should be equal to the value of the \"Number of Objects Allocated\" counter.");
            DescriptionTable.Add("Number Of Simple Collections",
                "The number of simple collections performed by the garbage collector during the execution of the application. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Bytes Collected By Simple Collection",
                "The total number of bytes freed during all of the simple collection that occurred during the program run. The n value is the number of simple collections that occurred and should be equal to the the value of \"Number of Simple Collections\" counter. The mean, min, max are self explanatory.");
            DescriptionTable.Add("Bytes In Use After Simple Collection",
                "The sum of all the bytes that were still actively being references after each simple collection. The n value is the number of simple collections that occurred and should be equal to the value of the \"Number of Simple Collections\" counter. The mean, min, max are self explanatory.");
            DescriptionTable.Add("Time In Simple Collect",
                "The total amount of timespent in the garbage collector doing simple collections.  This counter�s is measured in milliseconds. The n, mean, min, and max values are not collected for this counter.");
            DescriptionTable.Add("Number Of Compact Collections",
                "The total number of compact collections that occurred during application execution. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Bytes Collected By Compact Collections",
                "The total number of bytes freed during all the copact collections that occurred during application execution. The n value is the total number of compact collections that occurred and should be equal to the value of the \"Number of Compact Collections\" counter. The mean, min, max are self explanatory.");
            DescriptionTable.Add("Bytes In Use After Compact Collection",
                "The sum of all the bytes that were still actively being referenced after each compact collection occurred.  The n value is the number of compact collections that occurred and should be equal to the value of the \"Number of Compact Collections\" counter. The mean, min, max are self explanatory.");
            DescriptionTable.Add("Time In Compact Collect",
                "The total amount of time that the garbage collector spent doing compact collections. This counter is measured in milliseconds. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Number Of Full Collections",
                "The total number of full collections done by the garbage collector during application execution. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Bytes Collected By Full Collection",
                "The total number of bytes freed during all the full collections that occurred during application execution. The n value is the total number of full collections that occurred and should be equal to the value of the \"Number of Full Collections\" counter. The mean, min, max are self explanatory.");
            DescriptionTable.Add("Bytes In Use After Full Collection",
                "The sum of all the bytes that were still actively being referenced after each full collection occurred.  The n value is the number of full collections that occurred and should be equal to the value of the \"Number of Full Collections\" counter. The mean, min, max are self explanatory.");
            DescriptionTable.Add("Time In Full Collection",
                "The total amount of time that the garbage collector spent doing full collections. This counter is measured in milliseconds. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("GC Number Of Application Induced Collections",
                "The number of collections that were manually invoked by the application by calling GC.Collect. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("GC Latency Time",
                "This counter measures the total amount of time spent in the garbage collector doing all collections during the application execution. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Bytes Jitted",
                "The total amount of MSIL code that was Just-In-Time compiled. The n value is the number of methods jitted and should be equal to the \"Number of Methods Jitted\" counter. The mean value is the mean number of bytes jitted per method. The min value is the smallest number of bytes jitted in one method and the max value is the largest number of bytes jitted in one method.");
            DescriptionTable.Add("Native Bytes Jitted",
                "The total amount of native instructions created while Jitting the MSIL of the application. The n value is the number of methods jitted and should be equal to the \"Number of Methods Jitted\" counter. The mean value is the mean number of native instructions, in bytes, created per method. The min value is the smallest number of native instruction, in bytes, created by jitting a method. And the max value is the largest number of native instructions, in bytes, created by jitted a method.");
            DescriptionTable.Add("Number of Methods Jitted",
                "The total number of methods jitted during the program run. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Bytes Pitched",
                "The total number of native instructions, measured in bytes, released from memory after beening Just-In-Time compiled. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Number of Methods Pitched",
                "The total number of methods released from memory after having been Just-In-Time compiled. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Number of Exceptions",
                "The number of exceptions that were thrown during application execution. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Number of Calls",
                "The number of calls that the JIT could make directly. This means the JIT could generate an instruction(s) that result in a direct call to the method. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Number of Virtual Calls",
                "The number of calls that the JIT could not make directly. This means that inorder to call the method the JIT first needed to compile the method and then determine how to call the method.");
            DescriptionTable.Add("Number Of Virtual Call Cache Hits",
                "The number of virtual calls where resolved by the virtual call lookup cache. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Number of PInvoke Calls",
                "The total number of P/Invoke calls that were made during application execution. The values n, mean, min, and max are not collected for this counter.");
            DescriptionTable.Add("Total Bytes In Use After Collection",
                "The peak memory, managed and unmanaged, in use by the application as measured immediately following each garbage collection. The n value is the number of garbage collections that occurred during application execution. The mean, min & max values are self explanatory.");
        }    
    
        public static string LookUpDescription(string key)
        {
            object description = DescriptionTable[key];

            return (string)(null == description ? null : description);
        }        

        private PerfCounterDescriptionTable()
        {
            // intentionally left blank
        }
    }
}