using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Sams.KickStart.NetCF.PerfCounterApp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class PerfCounterListForm : System.Windows.Forms.Form
	{		
        private System.Windows.Forms.MainMenu mnuMain;
        private System.Windows.Forms.ListView lvwPerCounters;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuItem mnuHelp;
        private System.Windows.Forms.MenuItem mnuAbout;
		private System.Windows.Forms.OpenFileDialog openFileDlg = new OpenFileDialog();
		private System.Windows.Forms.MenuItem mnuFile;
		private System.Windows.Forms.MenuItem mnuOpen;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem mnuExit;
		private System.Windows.Forms.MenuItem mnuClose;
		private System.Windows.Forms.MenuItem mnuCompare;
		private System.Windows.Forms.Label lblDescription;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PerfCounterListForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.lvwPerCounters = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.mnuMain = new System.Windows.Forms.MainMenu();
            this.mnuFile = new System.Windows.Forms.MenuItem();
            this.mnuOpen = new System.Windows.Forms.MenuItem();
            this.mnuCompare = new System.Windows.Forms.MenuItem();
            this.mnuClose = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.mnuExit = new System.Windows.Forms.MenuItem();
            this.mnuHelp = new System.Windows.Forms.MenuItem();
            this.mnuAbout = new System.Windows.Forms.MenuItem();
            this.lblDescription = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lvwPerCounters
            // 
            this.lvwPerCounters.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                             this.columnHeader1,
                                                                                             this.columnHeader2,
                                                                                             this.columnHeader3,
                                                                                             this.columnHeader4,
                                                                                             this.columnHeader5,
                                                                                             this.columnHeader6});
            this.lvwPerCounters.GridLines = true;
            this.lvwPerCounters.Location = new System.Drawing.Point(8, 8);
            this.lvwPerCounters.MultiSelect = false;
            this.lvwPerCounters.Name = "lvwPerCounters";
            this.lvwPerCounters.Size = new System.Drawing.Size(608, 448);
            this.lvwPerCounters.TabIndex = 0;
            this.lvwPerCounters.View = System.Windows.Forms.View.Details;
            this.lvwPerCounters.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lvwPerCounters_KeyDown);
            this.lvwPerCounters.DoubleClick += new System.EventHandler(this.lvwPerCounters_DoubleClick);
            this.lvwPerCounters.SelectedIndexChanged += new System.EventHandler(this.lvwPerCounters_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Value";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "N";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Mean";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Min";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Max";
            // 
            // mnuMain
            // 
            this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                      this.mnuFile,
                                                                                      this.mnuHelp});
            // 
            // mnuFile
            // 
            this.mnuFile.Index = 0;
            this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                      this.mnuOpen,
                                                                                      this.mnuCompare,
                                                                                      this.mnuClose,
                                                                                      this.menuItem4,
                                                                                      this.mnuExit});
            this.mnuFile.Text = "File";
            // 
            // mnuOpen
            // 
            this.mnuOpen.Index = 0;
            this.mnuOpen.Text = "Open...";
            this.mnuOpen.Click += new System.EventHandler(this.mnuOpen_Click);
            // 
            // mnuCompare
            // 
            this.mnuCompare.Index = 1;
            this.mnuCompare.Text = "Compare...";
            this.mnuCompare.Click += new System.EventHandler(this.mnuCompare_Click);
            // 
            // mnuClose
            // 
            this.mnuClose.Index = 2;
            this.mnuClose.Text = "Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // menuItem4
            // 
            this.menuItem4.Index = 3;
            this.menuItem4.Text = "-";
            // 
            // mnuExit
            // 
            this.mnuExit.Index = 4;
            this.mnuExit.Text = "Exit";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // mnuHelp
            // 
            this.mnuHelp.Index = 1;
            this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                    this.mnuAbout});
            this.mnuHelp.Text = "Help";
            // 
            // mnuAbout
            // 
            this.mnuAbout.Index = 0;
            this.mnuAbout.Text = "About...";
            // 
            // lblDescription
            // 
            this.lblDescription.Location = new System.Drawing.Point(8, 472);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(608, 72);
            this.lblDescription.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 456);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Counter Description:";
            // 
            // PerfCounterListForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(624, 545);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.lvwPerCounters);
            this.Menu = this.mnuMain;
            this.Name = "PerfCounterListForm";
            this.Text = "NetCF Perf Counter Explorer";
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new PerfCounterListForm());
		}

        private void mnuOpen_Click(object sender, System.EventArgs e)
        {
            string fileName = GetFileName();
			if(null == fileName)
				return;

            this.ClearDescription();
			this.lvwPerCounters.Items.Clear();
            try
            {
                using (PerfCounterFileParser parser = new PerfCounterFileParser(fileName))
                {
                    ArrayList perfCounters = parser.Parse();
                    foreach(NetCFPerfCounter counter in perfCounters)
                    {
                        ListViewItem lvi = new ListViewItem(counter.Name);                    
                        lvi.SubItems.Add(counter.Value.ToString());
                        lvi.SubItems.Add(counter.N.ToString());
                        lvi.SubItems.Add(counter.Mean.ToString());
                        lvi.SubItems.Add(counter.Min.ToString());
                        lvi.SubItems.Add(counter.Max.ToString());

                        lvi.Tag = counter;
                        this.lvwPerCounters.Items.Add(lvi);
                    }
                }
            }
            catch(PerfCounterFileParserException pe)
            {                
                string errorStr = 
                    string.Format("An error occured parsing the performance counter file: \n\n{0}\nFile Name: {1} \nLine Number: {2} \nLine Position: {3}",
                    pe.Message, pe.FileName, pe.LineNumber, pe.LinePosition);
                
                MessageBox.Show(this, errorStr, "Parser Error");                    
            }
            catch(Exception ex)
            {
                MessageBox.Show(this,
                                "Unexpected exception occurred while parsing the perforamance counter file.\n" + ex,
                                "Parser Error");
            }

            ClearDescription();
        }

        private void mnuClose_Click(object sender, System.EventArgs e)
        {
			this.lvwPerCounters.Items.Clear();
            this.ClearDescription();
        }

		private void mnuCompare_Click(object sender, System.EventArgs e)
		{
            string fileOne, fileTwo;
            PerfCounterFileParser parserOne = null, parserTwo = null;

			fileOne = GetFileName();
			if(null == fileOne) return;
			
			fileTwo = GetFileName();
			if(null == fileTwo) return;
            
            try
            {

                parserOne = new PerfCounterFileParser(fileOne);
                ArrayList countersOne = parserOne.Parse();

                parserTwo = new PerfCounterFileParser(fileTwo);
                ArrayList countersTwo = parserTwo.Parse();

			
				if(countersOne.Count != countersTwo.Count)
				{
					MessageBox.Show("Could not compare the two files");
					return;
				}

                this.ClearDescription();
				this.lvwPerCounters.Items.Clear();
				for(int ndx = 0; ndx < countersOne.Count; ++ndx)
				{
					NetCFPerfCounter counterOne = (NetCFPerfCounter)countersOne[ndx];
					NetCFPerfCounter counterTwo = (NetCFPerfCounter)countersTwo[ndx];

					ListViewItem lvi = new ListViewItem(counterOne.Name);                    
					AddSubItem(lvi, (counterOne.Value - counterTwo.Value));
					AddSubItem(lvi, (counterOne.N - counterTwo.N));
					AddSubItem(lvi, (counterOne.Mean - counterTwo.Mean));
					AddSubItem(lvi, (counterOne.Min - counterTwo.Min));
					AddSubItem(lvi, (counterOne.Max - counterTwo.Max));

					NetCFPerfCounter[] counters = {counterOne, counterTwo};
					lvi.Tag = counters;
					this.lvwPerCounters.Items.Add(lvi);                                
				}

			}
            catch(PerfCounterFileParserException pe)
            {                
                string errorStr = 
                    string.Format("An error occured parsing the performance counter file: \n\n{0}\nFile Name: {1} \nLine Number: {2} \nLine Position: {3}",
                    pe.Message, pe.FileName, pe.LineNumber, pe.LinePosition);
                
                MessageBox.Show(this, errorStr, "Parser Error");                    
            }
            catch(Exception ex)
            {
                MessageBox.Show(this, 
                                "Unexpected exception occurred while parsing the perforamance counter file.\n" + ex,
                                "Parser Error");
            }
			finally
			{
				if(parserOne != null)
                    parserOne.Close();

				if(parserTwo != null)
                    parserTwo.Close();
			}
        }		

		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void lvwPerCounters_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ListView.SelectedListViewItemCollection items = this.lvwPerCounters.SelectedItems;
			if(items.Count <= 0)
				return;

			ListViewItem lvi = this.lvwPerCounters.SelectedItems[0];
			object description = PerfCounterDescriptionTable.LookUpDescription(lvi.Text);

			this.lblDescription .Text = (description == null) ? 
				string.Empty : 
				(string)description;
		}       

		private void lvwPerCounters_DoubleClick(object sender, System.EventArgs e)
		{            
		    DisplayCounterDetails();
		}        

        private void lvwPerCounters_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
                DisplayCounterDetails();
        }        

        private void DisplayCounterDetails()
        {
            ListView.SelectedListViewItemCollection items = this.lvwPerCounters.SelectedItems;
            if(items.Count <= 0)
                return;

            ListViewItem lvi = this.lvwPerCounters.SelectedItems[0];
            if(lvi.Tag is NetCFPerfCounter[])
            {
                NetCFPerfCounter[] counters = (NetCFPerfCounter[])lvi.Tag;
                PerfCounterComparison pccDlg = 
                    new PerfCounterComparison(counters[0], counters[1]);
 
                pccDlg.Show();
            }
        }

        private string GetFileName()
        {
            if(DialogResult.OK != openFileDlg.ShowDialog(this))
                return null;

            return openFileDlg.FileName;
        }

        private void AddSubItem(ListViewItem lvi, long value)
        {
            lvi.SubItems.Add(
                value < 0 ?
                value.ToString() :
                value == 0 ?
                value.ToString() :
                "+" + value.ToString());
        }

        private void ClearDescription()
        {
            this.lblDescription.Text = string.Empty;
        }
	}
}
