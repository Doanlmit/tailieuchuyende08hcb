Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents checkBox5 As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.checkBox5 = New System.Windows.Forms.CheckBox
        Me.checkBox4 = New System.Windows.Forms.CheckBox
        Me.checkBox3 = New System.Windows.Forms.CheckBox
        Me.checkBox2 = New System.Windows.Forms.CheckBox
        Me.checkBox1 = New System.Windows.Forms.CheckBox
        '
        'checkBox5
        '
        Me.checkBox5.AutoCheck = False
        Me.checkBox5.Checked = True
        Me.checkBox5.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Me.checkBox5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.checkBox5.Location = New System.Drawing.Point(60, 225)
        Me.checkBox5.Text = "McIntosh"
        Me.checkBox5.ThreeState = True
        '
        'checkBox4
        '
        Me.checkBox4.AutoCheck = False
        Me.checkBox4.Checked = True
        Me.checkBox4.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Me.checkBox4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.checkBox4.Location = New System.Drawing.Point(60, 169)
        Me.checkBox4.Text = "Granny Smith"
        Me.checkBox4.ThreeState = True
        '
        'checkBox3
        '
        Me.checkBox3.AutoCheck = False
        Me.checkBox3.Checked = True
        Me.checkBox3.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Me.checkBox3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.checkBox3.Location = New System.Drawing.Point(60, 113)
        Me.checkBox3.Size = New System.Drawing.Size(120, 20)
        Me.checkBox3.Text = "Golden Delicious"
        Me.checkBox3.ThreeState = True
        '
        'checkBox2
        '
        Me.checkBox2.AutoCheck = False
        Me.checkBox2.Checked = True
        Me.checkBox2.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Me.checkBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.checkBox2.Location = New System.Drawing.Point(60, 65)
        Me.checkBox2.Size = New System.Drawing.Size(96, 16)
        Me.checkBox2.Text = "Red Delicious"
        Me.checkBox2.ThreeState = True
        '
        'checkBox1
        '
        Me.checkBox1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.checkBox1.Location = New System.Drawing.Point(44, 25)
        Me.checkBox1.Size = New System.Drawing.Size(152, 20)
        Me.checkBox1.Text = "I Like Apples"
        '
        'Form1
        '
        Me.Controls.Add(Me.checkBox5)
        Me.Controls.Add(Me.checkBox4)
        Me.Controls.Add(Me.checkBox3)
        Me.Controls.Add(Me.checkBox2)
        Me.Controls.Add(Me.checkBox1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub SetIndeterminate(ByVal chkBox As CheckBox, ByVal isIndeterminate As Boolean)
        If isIndeterminate Then
            chkBox.AutoCheck = False
            chkBox.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Else
            chkBox.AutoCheck = True
            chkBox.CheckState = System.Windows.Forms.CheckState.Unchecked
        End If
    End Sub

    Private Sub checkBox1_CheckStateChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles checkBox1.CheckStateChanged
        Dim indeterminate As Boolean
        If checkBox1.CheckState = CheckState.Unchecked Then
            indeterminate = True
        Else
            indeterminate = False
        End If

        SetIndeterminate(checkBox2, indeterminate)
        SetIndeterminate(checkBox3, indeterminate)
        SetIndeterminate(checkBox4, indeterminate)
        SetIndeterminate(checkBox5, indeterminate)
    End Sub
End Class
