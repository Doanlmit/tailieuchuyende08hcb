Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents contextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents checkBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem6 As System.Windows.Forms.MenuItem

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label1 = New System.Windows.Forms.Label
        Me.contextMenu1 = New System.Windows.Forms.ContextMenu
        Me.checkBox3 = New System.Windows.Forms.CheckBox
        Me.checkBox2 = New System.Windows.Forms.CheckBox
        Me.checkBox1 = New System.Windows.Forms.CheckBox
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.menuItem4 = New System.Windows.Forms.MenuItem
        Me.menuItem5 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.Add(Me.MenuItem7)
        '
        'label1
        '
        Me.label1.ContextMenu = Me.contextMenu1
        Me.label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.label1.Location = New System.Drawing.Point(8, 128)
        Me.label1.Size = New System.Drawing.Size(224, 16)
        Me.label1.Text = "Tab-and-hold me for a context menu."
        '
        'contextMenu1
        '
        '
        'checkBox3
        '
        Me.checkBox3.Location = New System.Drawing.Point(24, 72)
        Me.checkBox3.Size = New System.Drawing.Size(184, 20)
        Me.checkBox3.Text = "Display MenuItem 3"
        '
        'checkBox2
        '
        Me.checkBox2.Location = New System.Drawing.Point(24, 40)
        Me.checkBox2.Size = New System.Drawing.Size(184, 20)
        Me.checkBox2.Text = "Display MenuItem 2"
        '
        'checkBox1
        '
        Me.checkBox1.Location = New System.Drawing.Point(24, 8)
        Me.checkBox1.Size = New System.Drawing.Size(184, 20)
        Me.checkBox1.Text = "Display MenuItem 1"
        '
        'MenuItem7
        '
        Me.MenuItem7.Text = "Exit"
        '
        ' menuItem1
        ' 
        Me.menuItem1.Text = "MenuItem 1"
        ' 
        ' menuItem2
        ' 
        Me.menuItem2.Text = "MenuItem 2"
        ' 
        ' menuItem3
        ' 
        Me.menuItem3.Text = "MenuItem 3"
        ' 
        ' menuItem4
        ' 
        Me.menuItem4.MenuItems.Add(menuItem5)
        Me.menuItem4.Text = "Default Item 1"
        ' 
        ' menuItem5
        ' 
        Me.menuItem5.Text = "Default Item 2"
        '
        'Form1
        '
        Me.Controls.Add(Me.checkBox3)
        Me.Controls.Add(Me.checkBox2)
        Me.Controls.Add(Me.checkBox1)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub menuItem1_Click(ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles menuItem1.Click
        MessageBox.Show("You selected MenuItem 1")
    End Sub

    Private Sub menuItem2_Click(ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles menuItem2.Click
        MessageBox.Show("You selected MenuItem 2")
    End Sub

    Private Sub menuItem3_Click(ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles menuItem3.Click
        MessageBox.Show("You selected MenuItem 3")
    End Sub

    Private Sub menuItem4_Click(ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles menuItem4.Click
        MessageBox.Show("You selected MenuItem 4")
    End Sub

    Private Sub menuItem5_Click(ByVal sender As Object, ByVal e As System.EventArgs) _
    Handles menuItem5.Click
        MessageBox.Show("You selected MenuItem 5")
    End Sub

    Private Sub contextMenu1_Popup(ByVal sender As Object, ByVal e As System.EventArgs) Handles contextMenu1.Popup
        contextMenu1.MenuItems.Clear()

        If checkBox1.Checked Then
            contextMenu1.MenuItems.Add(menuItem1)

            If checkBox2.Checked Then
                contextMenu1.MenuItems.Add(menuItem2)
            End If

            If checkBox3.Checked Then
                contextMenu1.MenuItems.Add(menuItem3)
            End If

            ' Always add the default menu 
            contextMenu1.MenuItems.Add(menuItem4)
        End If
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        Application.Exit()
    End Sub
End Class
