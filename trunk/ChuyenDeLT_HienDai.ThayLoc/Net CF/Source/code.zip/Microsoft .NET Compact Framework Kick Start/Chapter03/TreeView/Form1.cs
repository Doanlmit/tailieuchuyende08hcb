using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace TreeView
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.ImageList imageList1;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode();
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode();
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "Exit";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // treeView1
            // 
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(16, 8);
            treeNode1.ImageIndex = 0;
            treeNode2.ImageIndex = 0;
            treeNode3.ImageIndex = 0;
            treeNode3.SelectedImageIndex = 0;
            treeNode3.Text = "Red Delicious";
            treeNode4.ImageIndex = 4;
            treeNode4.SelectedImageIndex = 4;
            treeNode4.Text = "Jonathan";
            treeNode5.ImageIndex = 5;
            treeNode5.SelectedImageIndex = 5;
            treeNode5.Text = "Rome";
            treeNode6.ImageIndex = 6;
            treeNode6.SelectedImageIndex = 6;
            treeNode6.Text = "Winesap";
            treeNode2.Nodes.Add(treeNode3);
            treeNode2.Nodes.Add(treeNode4);
            treeNode2.Nodes.Add(treeNode5);
            treeNode2.Nodes.Add(treeNode6);
            treeNode2.SelectedImageIndex = 0;
            treeNode2.Text = "Red Apples";
            treeNode7.ImageIndex = 2;
            treeNode8.ImageIndex = 2;
            treeNode8.SelectedImageIndex = 2;
            treeNode8.Text = "Granny Smith";
            treeNode7.Nodes.Add(treeNode8);
            treeNode7.SelectedImageIndex = 2;
            treeNode7.Text = "Green Apples";
            treeNode9.ImageIndex = 1;
            treeNode10.ImageIndex = 1;
            treeNode10.SelectedImageIndex = 1;
            treeNode10.Text = "Golden Delicious";
            treeNode9.Nodes.Add(treeNode10);
            treeNode9.SelectedImageIndex = 1;
            treeNode9.Text = "Yellow Apples";
            treeNode11.ImageIndex = 3;
            treeNode12.ImageIndex = 3;
            treeNode12.SelectedImageIndex = 3;
            treeNode12.Text = "McIntosh";
            treeNode11.Nodes.Add(treeNode12);
            treeNode11.SelectedImageIndex = 3;
            treeNode11.Text = "Red & Yellow Apples";
            treeNode1.Nodes.Add(treeNode2);
            treeNode1.Nodes.Add(treeNode7);
            treeNode1.Nodes.Add(treeNode9);
            treeNode1.Nodes.Add(treeNode11);
            treeNode1.SelectedImageIndex = 0;
            treeNode1.Text = "Apples";
            this.treeView1.Nodes.Add(treeNode1);
            this.treeView1.Size = new System.Drawing.Size(208, 184);
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource1"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource2"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource3"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource4"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource5"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource6"))));
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 208);
            this.label1.Size = new System.Drawing.Size(208, 16);
            this.label1.Text = "You Selected:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 112);
            this.label2.Size = new System.Drawing.Size(208, 16);
            // 
            // Form1
            // 
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.treeView1);
            this.Menu = this.mainMenu1;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void menuItem1_Click(object sender, System.EventArgs e) {
            Application.Exit();
        }

        private void treeView1_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e) {
            TreeNode selNode = e.Node;
            this.label2.Text = selNode.Text;
        }

        private void Form1_Load(object sender, System.EventArgs e) {
        
        }
	}
}
