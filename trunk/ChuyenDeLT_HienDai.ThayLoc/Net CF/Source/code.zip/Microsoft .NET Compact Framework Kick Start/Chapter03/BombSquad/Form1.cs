using System;
using System.Data;
using System.Drawing;
using System.Threading;
using System.Collections;
using System.Windows.Forms;

namespace ProgrssBar
{
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button button2;
		private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.Timer timerButtonMove;
        private System.Windows.Forms.Timer timerProgressBar;        

        private int counter = 0;
        private bool gameOver = true;
        private Random rand = new Random(Environment.TickCount);        
        

		public Form1()
		{
			InitializeComponent();			
		}

        protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.button2 = new System.Windows.Forms.Button();
            this.timerButtonMove = new System.Windows.Forms.Timer();
            this.timerProgressBar = new System.Windows.Forms.Timer();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "Exit";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // button1
            // 
            this.button1.Size = new System.Drawing.Size(72, 24);
            this.button1.Text = "Diffuse";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(64, 240);
            this.progressBar1.Maximum = 60;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(8, 240);
            this.button2.Size = new System.Drawing.Size(32, 24);
            this.button2.Text = "Go";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // timerButtonMove
            // 
            this.timerButtonMove.Interval = 500;
            this.timerButtonMove.Tick += new System.EventHandler(this.timerButtonMove_Tick);
            // 
            // timerProgressBar
            // 
            this.timerProgressBar.Interval = 500;
            this.timerProgressBar.Tick += new System.EventHandler(this.timerProgressBar_Tick);
            // 
            // Form1
            // 
            this.Controls.Add(this.button2);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.button1);
            this.Menu = this.mainMenu1;
            this.Text = "Bomb Squad";

        }
		#endregion

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void button1_Click(object sender, System.EventArgs e) {                        
            if( !gameOver ) {                
                EndGame();
                MessageBox.Show("Nice Work, You're Alive!", "Congrats!");                
            }
        }

        private void button2_Click(object sender, System.EventArgs e) {            
            ResetGame();    
            StartGame();
        }     
            

        private void StartGame() {
            this.timerButtonMove.Enabled = true;
            this.timerProgressBar.Enabled = true;
        }

        private void ResetGame() {
            progressBar1.Value = 0; 
            gameOver = false;                       
            button2.Enabled = false;
            button1.Location = new Point(0,0);
        }
        
        private void EndGame() {
            this.timerButtonMove.Enabled = false;
            this.timerProgressBar.Enabled = false;

            counter = 0;     
            this.gameOver = true;            
            this.button2.Enabled = true;
        }        
               
        private void menuItem1_Click(object sender, System.EventArgs e) {
            Application.Exit();
        }

        private void timerButtonMove_Tick(object sender, System.EventArgs e) {
            if(!gameOver) {                
                this.button1.Location = 
                    new Point(rand.Next(0, 168), rand.Next(0, 216));                               
            }else {
                EndGame();
            }
        }

        private void timerProgressBar_Tick(object sender, System.EventArgs e) {            
            if( counter < 60 ) {
                if( gameOver )
                    return;                
                
                if(this.progressBar1.Value < this.progressBar1.Maximum)
                    this.progressBar1.Value += 1;
                
                ++counter;
            } else {
                if( !gameOver ) {
                    EndGame();                    
                    MessageBox.Show("Boom!", "Loser");                                        
                }
            }
        }       
	}
}
