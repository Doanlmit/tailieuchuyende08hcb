using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace CheckBoxControl
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            // 
            // checkBox1
            // 
            this.checkBox1.Location = new System.Drawing.Point(24, 32);
            this.checkBox1.Size = new System.Drawing.Size(152, 20);
            this.checkBox1.Text = "I Like Apples";
            this.checkBox1.CheckStateChanged += new System.EventHandler(this.checkBox1_CheckStateChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoCheck = false;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox2.Location = new System.Drawing.Point(40, 72);
            this.checkBox2.Size = new System.Drawing.Size(96, 16);
            this.checkBox2.Text = "Red Delicious";
            this.checkBox2.ThreeState = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoCheck = false;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox3.Location = new System.Drawing.Point(40, 120);
            this.checkBox3.Size = new System.Drawing.Size(120, 20);
            this.checkBox3.Text = "Golden Delicious";
            this.checkBox3.ThreeState = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoCheck = false;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox4.Location = new System.Drawing.Point(40, 176);
            this.checkBox4.Text = "Granny Smith";
            this.checkBox4.ThreeState = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoCheck = false;
            this.checkBox5.Checked = true;
            this.checkBox5.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.checkBox5.Location = new System.Drawing.Point(40, 232);
            this.checkBox5.Text = "McIntosh";
            this.checkBox5.ThreeState = true;
            // 
            // Form1
            // 
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Menu = this.mainMenu1;
            this.Text = "Apples";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void checkBox1_CheckStateChanged(object sender, System.EventArgs e) {
            bool setIndeterminate = (this.checkBox1.CheckState == CheckState.Unchecked);

            SetIndeterminate(this.checkBox2, setIndeterminate);
            SetIndeterminate(this.checkBox3, setIndeterminate);
            SetIndeterminate(this.checkBox4, setIndeterminate);
            SetIndeterminate(this.checkBox5, setIndeterminate);     
        }

        private void SetIndeterminate(CheckBox chkBox, bool isIndeterminate) {
            if(isIndeterminate) {
                chkBox.AutoCheck = false;            
                chkBox.CheckState = System.Windows.Forms.CheckState.Indeterminate;                
            }
            else {
                chkBox.AutoCheck = true;         
                chkBox.CheckState = System.Windows.Forms.CheckState.Unchecked;                
            }
        }

        private void label1_TextChanged(object sender, System.EventArgs e) {
        
        }
	}
}
