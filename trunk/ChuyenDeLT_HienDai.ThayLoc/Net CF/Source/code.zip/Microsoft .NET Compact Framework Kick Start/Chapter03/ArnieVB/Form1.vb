Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents radioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.radioButton4 = New System.Windows.Forms.RadioButton
        Me.radioButton3 = New System.Windows.Forms.RadioButton
        Me.radioButton2 = New System.Windows.Forms.RadioButton
        Me.radioButton1 = New System.Windows.Forms.RadioButton
        Me.label1 = New System.Windows.Forms.Label
        '
        'radioButton4
        '
        Me.radioButton4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.radioButton4.Location = New System.Drawing.Point(16, 184)
        Me.radioButton4.Size = New System.Drawing.Size(208, 24)
        Me.radioButton4.Text = "Conan the Barbarian "
        '
        'radioButton3
        '
        Me.radioButton3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.radioButton3.Location = New System.Drawing.Point(16, 144)
        Me.radioButton3.Size = New System.Drawing.Size(208, 32)
        Me.radioButton3.Text = "Hercules in New York"
        '
        'radioButton2
        '
        Me.radioButton2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.radioButton2.Location = New System.Drawing.Point(16, 112)
        Me.radioButton2.Size = New System.Drawing.Size(208, 20)
        Me.radioButton2.Text = "The Terminator"
        '
        'radioButton1
        '
        Me.radioButton1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.radioButton1.Location = New System.Drawing.Point(16, 72)
        Me.radioButton1.Size = New System.Drawing.Size(208, 32)
        Me.radioButton1.Text = "Pumping Iron"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(16, 8)
        Me.label1.Size = New System.Drawing.Size(208, 40)
        Me.label1.Text = "What was the name of Arnold Swarzennegger's first movie?"
        '
        'Form1
        '
        Me.Controls.Add(Me.radioButton4)
        Me.Controls.Add(Me.radioButton3)
        Me.Controls.Add(Me.radioButton2)
        Me.Controls.Add(Me.radioButton1)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub radioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radioButton1.CheckedChanged
        If radioButton1.Checked Then
            MessageBox.Show("Nope, Pumping Iron (1977). The year Ronnie Yates was born!", "Wrong!")
        End If
    End Sub
    Private Sub radioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radioButton3.CheckedChanged
        If radioButton3.Checked Then
            MessageBox.Show("Yes, Hercules in New York (1970)! A cult classic.", _
            "Correct!", _
            MessageBoxButtons.OK, _
            MessageBoxIcon.Exclamation, _
            MessageBoxDefaultButton.Button1)
        End If
    End Sub
    Private Sub _
    radioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
    Handles radioButton2.CheckedChanged
        If radioButton2.Checked Then
            MessageBox.Show("Wrong, The Terminator (1984) O.J Simpson almost got the role...", "Wrong!")
        End If
    End Sub
    Private Sub radioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radioButton4.CheckedChanged
        If radioButton4.Checked Then
            MessageBox.Show("You got nada! Conan (1982) The Austrian Oak almost died making this movie.", "Wrong!")
        End If
    End Sub
End Class
