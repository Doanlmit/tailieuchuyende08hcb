Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents trackBar2 As System.Windows.Forms.TrackBar
    Friend WithEvents trackBar1 As System.Windows.Forms.TrackBar
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.trackBar2 = New System.Windows.Forms.TrackBar
        Me.trackBar1 = New System.Windows.Forms.TrackBar
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.ForeColor = System.Drawing.SystemColors.Highlight
        Me.label2.Location = New System.Drawing.Point(124, 139)
        Me.label2.Size = New System.Drawing.Size(72, 32)
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(124, 107)
        Me.label1.Size = New System.Drawing.Size(72, 16)
        Me.label1.Text = "Values:"
        '
        'trackBar2
        '
        Me.trackBar2.Location = New System.Drawing.Point(28, 83)
        Me.trackBar2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.trackBar2.Size = New System.Drawing.Size(45, 168)
        '
        'trackBar1
        '
        Me.trackBar1.Location = New System.Drawing.Point(28, 19)
        Me.trackBar1.Size = New System.Drawing.Size(184, 45)
        '
        'Form1
        '
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.trackBar2)
        Me.Controls.Add(Me.trackBar1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub trackBar1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trackBar1.ValueChanged
        Me.trackBar2.Value = Me.trackBar1.Value
        Me.label2.Text = Me.trackBar1.Value.ToString()
    End Sub
End Class
