using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace NumericUpDown
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(8, 56);
            this.numericUpDown1.Maximum = new System.Decimal(new int[] {
                                                                           2003,
                                                                           0,
                                                                           0,
                                                                           0});
            this.numericUpDown1.Minimum = new System.Decimal(new int[] {
                                                                           1900,
                                                                           0,
                                                                           0,
                                                                           0});
            this.numericUpDown1.Value = new System.Decimal(new int[] {
                                                                         190012,
                                                                         0,
                                                                         0,
                                                                         131072});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 24);
            this.label1.Size = new System.Drawing.Size(184, 16);
            this.label1.Text = "In what year were you born?";
            this.label1.ParentChanged += new System.EventHandler(this.label1_ParentChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 120);
            this.label2.Size = new System.Drawing.Size(224, 24);
            // 
            // Form1
            // 
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numericUpDown1);
            this.Menu = this.mainMenu1;
            this.Text = "Form1";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        static string msg = "You are ~{0} years young.";
        private void numericUpDown1_ValueChanged(object sender, System.EventArgs e) {
            int yearsOld = System.DateTime.Now.Year - (int)this.numericUpDown1.Value;
            this.label2.Text = String.Format(msg, yearsOld);            
        }

        private void label1_ParentChanged(object sender, System.EventArgs e) {
        
        }        
	}
}
