Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents tpAssembly As System.Windows.Forms.TabControl
    Friend WithEvents tabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents comboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents lbTypes As System.Windows.Forms.ListBox
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents tabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents lbProperties As System.Windows.Forms.ListBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents tabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents lbFields As System.Windows.Forms.ListBox
    Friend WithEvents tabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents lbMethods As System.Windows.Forms.ListBox
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_Assembly As System.Reflection.Assembly
    Private m_Type As Type
    Private m_Types() As Type
    Private m_Methods() As System.Reflection.MethodInfo
    Private m_Properties() As System.Reflection.PropertyInfo
    Private m_Fields() As System.Reflection.FieldInfo

    Private Shared DataDir = "\My Documents\Reflector\"
    Private Shared PreviousFilesFileName = "previousfiles.txt"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.tpAssembly = New System.Windows.Forms.TabControl
        Me.tabPage1 = New System.Windows.Forms.TabPage
        Me.comboBox1 = New System.Windows.Forms.ComboBox
        Me.lbTypes = New System.Windows.Forms.ListBox
        Me.button2 = New System.Windows.Forms.Button
        Me.label2 = New System.Windows.Forms.Label
        Me.button1 = New System.Windows.Forms.Button
        Me.label1 = New System.Windows.Forms.Label
        Me.tabPage3 = New System.Windows.Forms.TabPage
        Me.lbProperties = New System.Windows.Forms.ListBox
        Me.label4 = New System.Windows.Forms.Label
        Me.tabPage2 = New System.Windows.Forms.TabPage
        Me.label3 = New System.Windows.Forms.Label
        Me.lbFields = New System.Windows.Forms.ListBox
        Me.tabPage4 = New System.Windows.Forms.TabPage
        Me.lbMethods = New System.Windows.Forms.ListBox
        Me.label5 = New System.Windows.Forms.Label
        '
        'tpAssembly
        '
        Me.tpAssembly.Controls.Add(Me.tabPage1)
        Me.tpAssembly.Controls.Add(Me.tabPage3)
        Me.tpAssembly.Controls.Add(Me.tabPage2)
        Me.tpAssembly.Controls.Add(Me.tabPage4)
        Me.tpAssembly.SelectedIndex = 0
        Me.tpAssembly.Size = New System.Drawing.Size(240, 272)
        '
        'tabPage1
        '
        Me.tabPage1.Controls.Add(Me.comboBox1)
        Me.tabPage1.Controls.Add(Me.lbTypes)
        Me.tabPage1.Controls.Add(Me.button2)
        Me.tabPage1.Controls.Add(Me.label2)
        Me.tabPage1.Controls.Add(Me.button1)
        Me.tabPage1.Controls.Add(Me.label1)
        Me.tabPage1.Location = New System.Drawing.Point(4, 4)
        Me.tabPage1.Size = New System.Drawing.Size(232, 246)
        Me.tabPage1.Text = "Types"
        '
        'comboBox1
        '
        Me.comboBox1.Location = New System.Drawing.Point(8, 24)
        Me.comboBox1.Size = New System.Drawing.Size(216, 22)
        '
        'lbTypes
        '
        Me.lbTypes.Location = New System.Drawing.Point(8, 96)
        Me.lbTypes.Size = New System.Drawing.Size(216, 142)
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(168, 48)
        Me.button2.Size = New System.Drawing.Size(56, 24)
        Me.button2.Text = "Open"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 80)
        Me.label2.Size = New System.Drawing.Size(104, 16)
        Me.label2.Text = "Select Type:"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(104, 48)
        Me.button1.Size = New System.Drawing.Size(56, 24)
        Me.button1.Text = "Browse"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Size = New System.Drawing.Size(216, 16)
        Me.label1.Text = "Assembly File:"
        '
        'tabPage3
        '
        Me.tabPage3.Controls.Add(Me.lbProperties)
        Me.tabPage3.Controls.Add(Me.label4)
        Me.tabPage3.Location = New System.Drawing.Point(4, 4)
        Me.tabPage3.Size = New System.Drawing.Size(232, 246)
        Me.tabPage3.Text = "Properties"
        '
        'lbProperties
        '
        Me.lbProperties.Location = New System.Drawing.Point(8, 32)
        Me.lbProperties.Size = New System.Drawing.Size(216, 184)
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(8, 8)
        Me.label4.Size = New System.Drawing.Size(216, 16)
        Me.label4.Text = "Properties"
        '
        'tabPage2
        '
        Me.tabPage2.Controls.Add(Me.label3)
        Me.tabPage2.Controls.Add(Me.lbFields)
        Me.tabPage2.Location = New System.Drawing.Point(4, 4)
        Me.tabPage2.Size = New System.Drawing.Size(232, 246)
        Me.tabPage2.Text = "Fields"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 8)
        Me.label3.Size = New System.Drawing.Size(216, 16)
        Me.label3.Text = "Fields"
        '
        'lbFields
        '
        Me.lbFields.Location = New System.Drawing.Point(8, 32)
        Me.lbFields.Size = New System.Drawing.Size(216, 184)
        '
        'tabPage4
        '
        Me.tabPage4.Controls.Add(Me.lbMethods)
        Me.tabPage4.Controls.Add(Me.label5)
        Me.tabPage4.Location = New System.Drawing.Point(4, 4)
        Me.tabPage4.Size = New System.Drawing.Size(232, 246)
        Me.tabPage4.Text = "Methods"
        '
        'lbMethods
        '
        Me.lbMethods.Location = New System.Drawing.Point(8, 32)
        Me.lbMethods.Size = New System.Drawing.Size(216, 184)
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(8, 8)
        Me.label5.Size = New System.Drawing.Size(216, 16)
        Me.label5.Text = "Methods"
        '
        'Form1
        '
        Me.Controls.Add(Me.tpAssembly)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub AddFileToPreviousFileList(ByVal prevFile As String)
        Dim i As Int32

        For i = 0 To Me.comboBox1.Items.Count
            If Me.comboBox1.Items(i).ToString().Equals(prevFile) Then
                Return
            End If
        Next i

        Me.comboBox1.Items.Add(prevFile)
    End Sub

    Private Sub LoadPreviousFiles()
        Dim line As String
        Dim fileName As String
        fileName = DataDir & "\" & PreviousFilesFileName

        'Make sure the data directory exists
        If Not System.IO.Directory.Exists(DataDir) Then
            System.IO.Directory.CreateDirectory(DataDir)
        End If

        ' Load the previous names from the data file
        If Not System.IO.File.Exists(fileName) Then
            System.IO.File.Create(fileName).Close()
        Else
            Dim sr As System.IO.StreamReader
            sr = New System.IO.StreamReader(New System.IO.FileStream(fileName, System.IO.FileMode.Open, System.IO.FileAccess.Read))
            line = sr.ReadLine()
            While Not line Is Nothing
                Me.comboBox1.Items.Add(line)
                line = sr.ReadLine()
            End While
            sr.Close()
        End If
    End Sub

    Private Sub StorePreviousFiles()
        Dim fileName As String
        fileName = DataDir & "\" & PreviousFilesFileName

        ' Make sure the data directory exists
        If Not System.IO.Directory.Exists(DataDir) Then
            System.IO.Directory.CreateDirectory(DataDir)
        End If

        ' Load the previous names from the data file
        Dim sw As System.IO.StreamWriter
        If System.IO.File.Exists(fileName) Then
            sw = New System.IO.StreamWriter(fileName, True)
        Else
            sw = New System.IO.StreamWriter(System.IO.File.Create(fileName))
        End If

        Dim i As Int32
        For i = 0 To i < Me.comboBox1.Items.Count
            sw.WriteLine(Me.comboBox1.Items(i).ToString())
        Next i
    End Sub

    Private Sub LoadTypes()
        If m_Assembly Is Nothing Then
            Return
        End If

        Cursor.Current = Cursors.WaitCursor
        m_Types = m_Assembly.GetTypes()
        Me.lbTypes.DataSource = m_Types
        Me.lbTypes.DisplayMember = "Name"
        Cursor.Current = Cursors.WaitCursor
    End Sub

    Private Sub LoadFields()
        If m_Assembly Is Nothing Or m_Type Is Nothing Then
            Return
        End If

        Cursor.Current = Cursors.WaitCursor
        Me.label3.Text = String.Format("Fields For {0}", m_Type.Name)
        Me.m_Fields = m_Type.GetFields()
        BindReflectionInfo(Me.lbFields, Me.m_Fields)
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub LoadMethods()
        If m_Assembly Is Nothing Or m_Type Is Nothing Then
            Return
        End If

        Cursor.Current = Cursors.WaitCursor
        Me.label5.Text = String.Format("Methods For {0}", m_Type.Name)
        Me.m_Methods = m_Type.GetMethods()
        BindReflectionInfo(Me.lbMethods, Me.m_Methods)
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub LoadProperties()
        If m_Assembly Is Nothing Or m_Type Is Nothing Then
            Return
        End If

        Cursor.Current = Cursors.WaitCursor
        Me.label4.Text = String.Format("Properties For {0}", m_Type.Name)
        Me.m_Properties = m_Type.GetProperties()
        BindReflectionInfo(Me.lbProperties, Me.m_Properties)
        Cursor.Current = Cursors.Default
    End Sub

    Private Sub BindReflectionInfo(ByVal lbInfo As ListBox, ByVal info As System.Reflection.MemberInfo())
        If m_Assembly Is Nothing Or info Is Nothing Then
            Return
        End If

        lbInfo.DataSource = info
        lbInfo.DisplayMember = "Name"
    End Sub


    Private Sub lbProperties_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbProperties.SelectedIndexChanged
        If m_Assembly Is Nothing Or lbTypes.SelectedIndex < 0 Then
            Return
        End If

        m_Type = m_Assembly.GetType(Me.lbTypes.SelectedItem.ToString())
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LoadPreviousFiles()
    End Sub

    Private Sub tpAssembly_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles tpAssembly.SelectedIndexChanged
        If Me.tpAssembly.SelectedIndex = 1 Then
            LoadProperties()
        ElseIf Me.tpAssembly.SelectedIndex = 2 Then
            LoadFields()
        ElseIf Me.tpAssembly.SelectedIndex = 3 Then
            LoadMethods()
        End If
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim res As DialogResult
        Dim openFileDialog1 As OpenFileDialog
        openFileDialog1 = New OpenFileDialog

        res = openFileDialog1.ShowDialog()

        If DialogResult.OK = res Then
            Dim fileName As String
            fileName = openFileDialog1.FileName

            Dim i As Int32
            For i = 0 To i < Me.comboBox1.Items.Count
                If Me.comboBox1.Items(i).ToString().Equals(fileName) Then
                    Me.comboBox1.SelectedIndex = i
                    Return
                End If
            Next i

            Me.comboBox1.Items.Add(fileName)
            Me.comboBox1.SelectedIndex = Me.comboBox1.Items.Count - 1
        End If
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        If Me.comboBox1.SelectedItem Is Nothing Then
            Return
        End If

        Dim assemblyFileName As String
        assemblyFileName = Me.comboBox1.SelectedItem.ToString()

        If Not System.IO.File.Exists(assemblyFileName) Then
            MessageBox.Show("The specified Assembly file does not exist")
            Return
        End If

        Try
            m_Assembly = System.Reflection.Assembly.LoadFrom(assemblyFileName)
            AddFileToPreviousFileList(assemblyFileName)
        Catch ex As Exception
            MessageBox.Show("Could not load the specified assembly.")
            Return
        End Try

        LoadTypes()
        If Not m_Assembly Is Nothing And Me.lbTypes.SelectedIndex >= 0 Then
            m_Type = m_Assembly.GetType(Me.lbTypes.SelectedItem.ToString())
        End If
    End Sub

    Private Sub lbTypes_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbTypes.SelectedIndexChanged
        If m_Assembly Is Nothing Or Me.lbTypes.SelectedIndex < 0 Then
            Return
        End If

            m_Type = m_Assembly.GetType(me.lbTypes.SelectedItem.ToString())
    End Sub
End Class
