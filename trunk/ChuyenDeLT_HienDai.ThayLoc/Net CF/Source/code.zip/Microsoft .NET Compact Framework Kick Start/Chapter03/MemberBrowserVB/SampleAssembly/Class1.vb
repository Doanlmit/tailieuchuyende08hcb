Public Class Student
    Public m_FirstName As String
    Public m_LastName As String
    Public m_MiddleName As String
    Public m_StudentID As Int64

    Public ReadOnly Property Name() As String
        Get
            Return m_FirstName & " " & m_MiddleName + " " & m_LastName
        End Get
    End Property

    Public ReadOnly Property StudentID() As Int64
        Get
            Return StudentID
        End Get
    End Property

    Public Sub RegisterStudent()
    End Sub
End Class

Public Class Course
    Dim m_Name As String
    Dim m_CourseID As Int64
    Dim m_Department As String

    Public Property Name() As String
        Get
            Return m_Name
        End Get

        Set(ByVal Value As String)
            m_Name = value
        End Set
    End Property

    Public Property CourseID() As Int64
        Get
            Return m_CourseID
        End Get
        Set(ByVal Value As Int64)
            m_CourseID = Value
        End Set
    End Property

    Public Property Department() As String
        Get
            Return m_Department
        End Get
        Set(ByVal Value As String)
            m_Department = Value
        End Set
    End Property

    Public Sub AddStudent(ByVal s As Student)
    End Sub
End Class
