Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents lblOpenFile As System.Windows.Forms.Label
    Friend WithEvents toolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents toolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents toolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents lblSaveFile As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents imageList1 As System.Windows.Forms.ImageList
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label4 = New System.Windows.Forms.Label
        Me.lblOpenFile = New System.Windows.Forms.Label
        Me.toolBar1 = New System.Windows.Forms.ToolBar
        Me.toolBarButton1 = New System.Windows.Forms.ToolBarButton
        Me.toolBarButton2 = New System.Windows.Forms.ToolBarButton
        Me.lblSaveFile = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.imageList1 = New System.Windows.Forms.ImageList
        '
        'label4
        '
        Me.label4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label4.Location = New System.Drawing.Point(8, 80)
        Me.label4.Size = New System.Drawing.Size(152, 16)
        Me.label4.Text = "File Selected For Saving:"
        '
        'lblOpenFile
        '
        Me.lblOpenFile.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.lblOpenFile.Location = New System.Drawing.Point(8, 32)
        Me.lblOpenFile.Size = New System.Drawing.Size(224, 16)
        '
        'toolBar1
        '
        Me.toolBar1.Buttons.Add(Me.toolBarButton1)
        Me.toolBar1.Buttons.Add(Me.toolBarButton2)
        Me.toolBar1.ImageList = Me.imageList1
        '
        'toolBarButton1
        '
        Me.toolBarButton1.ImageIndex = 0
        '
        'toolBarButton2
        '
        Me.toolBarButton2.ImageIndex = 1
        '
        'lblSaveFile
        '
        Me.lblSaveFile.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.lblSaveFile.Location = New System.Drawing.Point(8, 96)
        Me.lblSaveFile.Size = New System.Drawing.Size(224, 16)
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Size = New System.Drawing.Size(152, 16)
        Me.label1.Text = "File Selected For Opening:"
        '
        'imageList1
        '
        Me.imageList1.Images.Add(CType(resources.GetObject("resource"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource1"), System.Drawing.Image))
        Me.imageList1.ImageSize = New System.Drawing.Size(16, 16)
        '
        'Form1
        '
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.lblOpenFile)
        Me.Controls.Add(Me.lblSaveFile)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.toolBar1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub toolBar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles toolBar1.ButtonClick
        If e.Button Is toolBarButton1 Then
            Dim dlg As OpenFileDialog
            dlg = New OpenFileDialog
            Dim res As DialogResult
            res = dlg.ShowDialog()

            If res = DialogResult.OK Then
                lblOpenFile.Text = dlg.FileName
            End If
        ElseIf e.Button Is toolBarButton2 Then
            Dim dlg As SaveFileDialog
            dlg = New SaveFileDialog
            Dim res As DialogResult
            res = dlg.ShowDialog()

            If res = DialogResult.OK Then
                lblSaveFile.Text = dlg.FileName
            End If
        End If
    End Sub
End Class
