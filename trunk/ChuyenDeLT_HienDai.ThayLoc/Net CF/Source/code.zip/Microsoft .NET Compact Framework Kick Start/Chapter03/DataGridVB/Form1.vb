Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_DataTable As DataTable

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

        '
        ' Generate the apples DataTable and bind it
        ' to the DataGrid.
        '
        GenerateAndBindDataTable()

        '
        ' Customize the appearance of the DataGrid
        '
        CustomizeDataGrid()
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents label2 As System.Windows.Forms.Label
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label5 = New System.Windows.Forms.Label
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.DataGrid1 = New System.Windows.Forms.DataGrid
        Me.label2 = New System.Windows.Forms.Label
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(8, 232)
        Me.label5.Size = New System.Drawing.Size(224, 16)
        Me.label5.Text = "Type:"
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(128, 200)
        Me.label4.Size = New System.Drawing.Size(104, 20)
        Me.label4.Text = "Column:"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 200)
        Me.label3.Size = New System.Drawing.Size(104, 20)
        Me.label3.Text = "Row:"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 160)
        Me.label1.Size = New System.Drawing.Size(224, 16)
        Me.label1.Text = "Selected Cell Text:"
        '
        'DataGrid1
        '
        Me.DataGrid1.Location = New System.Drawing.Point(8, 8)
        Me.DataGrid1.Size = New System.Drawing.Size(224, 144)
        Me.DataGrid1.Text = "DataGrid1"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(8, 176)
        Me.label2.Size = New System.Drawing.Size(224, 16)
        '
        'Form1
        '
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.DataGrid1)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Public Sub GenerateAndBindDataTable()
        Me.m_DataTable = New DataTable("Apples")
        Me.m_DataTable.Columns.Add("Name", Type.GetType("System.String"))
        Me.m_DataTable.Columns.Add("Usage", Type.GetType("System.String"))
        Me.m_DataTable.Columns.Add("Availability", Type.GetType("System.String"))

        AddRow("Red Delicious", "Snacking", "All Year")
        AddRow("Golden Delicious", "All Purpose", "Sept-June")
        AddRow("Rome", "Baking", "Oct-Aug")
        AddRow("Winesap", "Snacking", "All Year")
        AddRow("Granny Smith", "Snacking", "All-Year")
        AddRow("McIntosh", "All Purpose", "Sept-June")
        AddRow("Jonathan", "All Purpose", "Sept-Aug")

        Me.DataGrid1.DataSource = Me.m_DataTable
    End Sub

    Private Sub AddRow(ByVal name As String, ByVal usage As String, ByVal availability As String)
        Dim row As DataRow
        row = Me.m_DataTable.NewRow()
        row(0) = name
        row(1) = usage
        row(2) = availability
        Me.m_DataTable.Rows.Add(row)
    End Sub

    Private Sub CustomizeDataGrid()
        DataGrid1.BackColor = Color.LightBlue
        DataGrid1.ForeColor = Color.DarkBlue
        DataGrid1.SelectionBackColor = Color.DarkBlue
        DataGrid1.SelectionForeColor = Color.LightBlue

        Dim dgts As DataGridTableStyle
        dgts = New DataGridTableStyle
        dgts.MappingName = "Apples"

        Dim nameColumn As DataGridTextBoxColumn
        nameColumn = New DataGridTextBoxColumn
        nameColumn.MappingName = "Name"
        nameColumn.HeaderText = "Apple Name"
        nameColumn.Width = 80
        dgts.GridColumnStyles.Add(nameColumn)

        Dim useColumn As DataGridTextBoxColumn
        useColumn = New DataGridTextBoxColumn
        useColumn.MappingName = "Usage"
        useColumn.HeaderText = "Best usage"
        useColumn.Width = 80
        dgts.GridColumnStyles.Add(useColumn)

        Dim avalColumn As DataGridTextBoxColumn
        avalColumn = New DataGridTextBoxColumn
        avalColumn.MappingName = "Availability"
        avalColumn.HeaderText = "Best Time to Buy"
        avalColumn.Width = 80
        dgts.GridColumnStyles.Add(avalColumn)

        Me.DataGrid1.TableStyles.Add(dgts)
    End Sub

    Private Sub DataGrid1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGrid1.MouseUp
        Dim hitInfo As System.Windows.Forms.DataGrid.HitTestInfo
        hitInfo = DataGrid1.HitTest(e.X, e.Y)

        Me.label2.Text = String.Empty
        Me.label3.Text = String.Format("Row: {0}", hitInfo.Row)
        Me.label4.Text = String.Format("Column: {0}", hitInfo.Column)
        Me.label5.Text = String.Format("Type: {0}", hitInfo.Type.ToString())

        If hitInfo.Type = System.Windows.Forms.DataGrid.HitTestType.Cell Then
            Dim selCell As Object
            selCell = DataGrid1.Item(hitInfo.Row, hitInfo.Column)
            If Not selCell Is Nothing Then
                Me.label2.Text = selCell.ToString()
            End If
        End If
    End Sub
End Class
