using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace ScrollBar
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.label1 = new System.Windows.Forms.Label();
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.LargeChange = 20;
            this.hScrollBar1.Location = new System.Drawing.Point(56, 56);
            this.hScrollBar1.Size = new System.Drawing.Size(104, 13);
            this.hScrollBar1.SmallChange = 10;
            this.hScrollBar1.ValueChanged += new System.EventHandler(this.hScrollBar1_ValueChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 24);
            this.label1.Size = new System.Drawing.Size(208, 16);
            this.label1.Text = "Scroll Bar Value: 0";
            // 
            // Form1
            // 
            this.Controls.Add(this.label1);
            this.Controls.Add(this.hScrollBar1);
            this.Menu = this.mainMenu1;
            this.Text = "Form1";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void hScrollBar1_ValueChanged(object sender, System.EventArgs e) {
            this.label1.Text = string.Format("Scroll Bar Value: {0}", this.hScrollBar1.Value);
        }
	}
}
