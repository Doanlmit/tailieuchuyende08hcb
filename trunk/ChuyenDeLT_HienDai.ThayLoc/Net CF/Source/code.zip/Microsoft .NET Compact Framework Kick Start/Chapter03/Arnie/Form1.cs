using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace RadioButtonControl
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 8);
            this.label1.Size = new System.Drawing.Size(208, 40);
            this.label1.Text = "What was the name of Arnold Swarzennegger's first movie?";
            this.label1.ParentChanged += new System.EventHandler(this.label1_ParentChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.Location = new System.Drawing.Point(16, 72);
            this.radioButton1.Size = new System.Drawing.Size(208, 32);
            this.radioButton1.Text = "Pumping Iron";
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.Location = new System.Drawing.Point(16, 112);
            this.radioButton2.Size = new System.Drawing.Size(208, 20);
            this.radioButton2.Text = "The Terminator";
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.Location = new System.Drawing.Point(16, 144);
            this.radioButton3.Size = new System.Drawing.Size(208, 32);
            this.radioButton3.Text = "Hercules in New York";
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.Location = new System.Drawing.Point(16, 184);
            this.radioButton4.Size = new System.Drawing.Size(208, 24);
            this.radioButton4.Text = "Conan the Barbarian ";
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // Form1
            // 
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label1);
            this.Menu = this.mainMenu1;
            this.Text = "Form1";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void label1_ParentChanged(object sender, System.EventArgs e) {
        
        }

        private void radioButton3_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton3.Checked)
                MessageBox.Show("Yes, Hercules in New York (1970)! A cult classic.",
                    "Correct!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Exclamation,
                    MessageBoxDefaultButton.Button1);
        }

        private void radioButton1_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton1.Checked)
                MessageBox.Show("Nope, Pumping Iron (1977). The year Ronnie Yates was born!", "Wrong!");
        }

        private void radioButton2_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton2.Checked)
                MessageBox.Show("Wrong, The Terminator (1984) O.J Simpson almost got the role...", "Wrong!");
        }

        private void radioButton4_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton4.Checked)
                MessageBox.Show("You got nada! Conan (1982) The Austrian Oak almost died making this movie.", "Wrong!");
        }
	}
}
