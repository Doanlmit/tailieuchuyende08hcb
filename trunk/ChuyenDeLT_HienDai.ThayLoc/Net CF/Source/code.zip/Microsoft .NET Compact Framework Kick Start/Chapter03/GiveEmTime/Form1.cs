using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace ButtonControl
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Button button;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.button = new System.Windows.Forms.Button();
            // 
            // button
            // 
            this.button.Location = new System.Drawing.Point(56, 216);
            this.button.Size = new System.Drawing.Size(136, 20);
            this.button.Text = "What is the Time?";
            this.button.Click += new System.EventHandler(this.btnSayHello_Click);
            // 
            // Form1
            // 
            this.Controls.Add(this.button);
            this.Text = "Give \'Em Time";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void btnSayHello_Click(object sender, System.EventArgs e) {
            MessageBox.Show(DateTime.Now.ToShortTimeString(), 
                "The Current Time Is", 
                MessageBoxButtons.OK, 
                MessageBoxIcon.Exclamation, 
                MessageBoxDefaultButton.Button1);
        }        
	}
}
