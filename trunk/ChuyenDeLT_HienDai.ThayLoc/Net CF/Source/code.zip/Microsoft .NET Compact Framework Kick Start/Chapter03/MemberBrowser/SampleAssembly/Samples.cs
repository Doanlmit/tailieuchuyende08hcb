using System;
using System.Data;

namespace SampleAssembly
{
    class Student {
        string m_FirstName;
        string m_LastName;
        string m_MiddleName;
        public Int64 m_StudentID;

        public string Name {
            get {return m_FirstName + " " + m_MiddleName + " " + m_LastName;}
        }

        public Int64 StudentID {
            get {return StudentID;}
        }

        public void RegisterStudent() {
        }
    }

    class Course {
        string m_Name;
        Int64 m_CourseID;
        string m_Department;

        public string Name {
            get {return m_Name;}
            set {m_Name = value;}
        }

        public Int64 CourseID {
            get{return m_CourseID;}
            set{m_CourseID = value;}
        }

        public string Department {
            get {return m_Department;}
            set {m_Department = value;}            
        }

        public void AddStudent(Student s) {
        }
    }    

    class Test {
        public static void Main(){
        }
    }
}
