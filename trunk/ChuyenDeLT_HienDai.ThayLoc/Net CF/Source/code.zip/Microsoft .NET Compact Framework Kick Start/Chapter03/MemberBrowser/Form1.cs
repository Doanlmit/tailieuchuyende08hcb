using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Reflection;
using System.IO;


namespace TabbedPane
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.TabControl tpAssembly;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
		private System.Windows.Forms.MainMenu mainMenu1;
        private System.Windows.Forms.ListBox lbTypes;                
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbFields;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbProperties;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lbMethods;
        private System.Windows.Forms.ComboBox comboBox1;        
        private System.Windows.Forms.ImageList imageList1;

        private Assembly m_Assembly;
        private Type m_Type;
        private Type[] m_Types;                
        private MethodInfo[] m_Methods;
        private PropertyInfo[] m_Properties;        
        private FieldInfo[] m_Fields;        

        private static string DataDir = @"\My Documents\Reflector\";
        private System.Windows.Forms.OpenFileDialog openFileDialog1;        
        private static string PreviousFilesFileName = "previousfiles.txt";

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.tpAssembly = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lbTypes = new System.Windows.Forms.ListBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.lbFields = new System.Windows.Forms.ListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lbProperties = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.lbMethods = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "Exit";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // tpAssembly
            // 
            this.tpAssembly.Controls.Add(this.tabPage1);
            this.tpAssembly.Controls.Add(this.tabPage3);
            this.tpAssembly.Controls.Add(this.tabPage2);
            this.tpAssembly.Controls.Add(this.tabPage4);
            this.tpAssembly.SelectedIndex = 0;
            this.tpAssembly.Size = new System.Drawing.Size(240, 272);
            this.tpAssembly.SelectedIndexChanged += new System.EventHandler(this.tpAssembly_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.lbTypes);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Size = new System.Drawing.Size(232, 246);
            this.tabPage1.Text = "Types";
            // 
            // comboBox1
            // 
            this.comboBox1.Location = new System.Drawing.Point(8, 24);
            this.comboBox1.Size = new System.Drawing.Size(216, 22);
            // 
            // lbTypes
            // 
            this.lbTypes.Location = new System.Drawing.Point(8, 96);
            this.lbTypes.Size = new System.Drawing.Size(216, 142);
            this.lbTypes.SelectedIndexChanged += new System.EventHandler(this.lbTypes_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(168, 48);
            this.button2.Size = new System.Drawing.Size(56, 24);
            this.button2.Text = "Open";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 80);
            this.label2.Size = new System.Drawing.Size(104, 16);
            this.label2.Text = "Select Type:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(104, 48);
            this.button1.Size = new System.Drawing.Size(56, 24);
            this.button1.Text = "Browse";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Size = new System.Drawing.Size(216, 16);
            this.label1.Text = "Assembly File:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.lbFields);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Size = new System.Drawing.Size(232, 246);
            this.tabPage2.Text = "Fields";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 8);
            this.label3.Size = new System.Drawing.Size(216, 16);
            this.label3.Text = "Fields";
            // 
            // lbFields
            // 
            this.lbFields.Location = new System.Drawing.Point(8, 32);
            this.lbFields.Size = new System.Drawing.Size(216, 184);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lbProperties);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Size = new System.Drawing.Size(232, 246);
            this.tabPage3.Text = "Properties";
            // 
            // lbProperties
            // 
            this.lbProperties.Location = new System.Drawing.Point(8, 32);
            this.lbProperties.Size = new System.Drawing.Size(216, 184);
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(8, 8);
            this.label4.Size = new System.Drawing.Size(216, 16);
            this.label4.Text = "Properties";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.lbMethods);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Size = new System.Drawing.Size(232, 246);
            this.tabPage4.Text = "Methods";
            // 
            // lbMethods
            // 
            this.lbMethods.Location = new System.Drawing.Point(8, 32);
            this.lbMethods.Size = new System.Drawing.Size(216, 184);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(8, 8);
            this.label5.Size = new System.Drawing.Size(216, 16);
            this.label5.Text = "Methods";
            // 
            // imageList1
            // 
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "DLL|*.dll|Exe|*.exe";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(240, 293);
            this.Controls.Add(this.tpAssembly);
            this.Menu = this.mainMenu1;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void button1_Click(object sender, System.EventArgs e) {
            if(DialogResult.OK == this.openFileDialog1.ShowDialog()) {                
                string fileName = this.openFileDialog1.FileName;
                for(int i = 0; i < this.comboBox1.Items.Count; ++i) {
                    if(this.comboBox1.Items[i].ToString().Equals(fileName)) {
                        this.comboBox1.SelectedIndex = i;
                        return;
                    }
                }

                this.comboBox1.Items.Add(fileName);
                this.comboBox1.SelectedIndex = this.comboBox1.Items.Count - 1;                
            }
        }

        private void button2_Click(object sender, System.EventArgs e) {
            if(this.comboBox1.SelectedItem == null)
                return;

            string assemblyFileName = this.comboBox1.SelectedItem.ToString();
            if(!File.Exists(assemblyFileName)) {
                MessageBox.Show("The specified Assembly file does not exist");
                return;
            }

            try {
                m_Assembly = Assembly.LoadFrom(assemblyFileName);
                AddFileToPreviousFileList(assemblyFileName);
            } catch (Exception) {
                MessageBox.Show("Could not load the specified assembly.");
                return;
            }
                
            LoadTypes();
            if(m_Assembly != null && this.lbTypes.SelectedIndex >= 0)                            
                m_Type = m_Assembly.GetType(this.lbTypes.SelectedItem.ToString());
        }

        private void AddFileToPreviousFileList(string prevFile) {            
            for(int i = 0; i < this.comboBox1.Items.Count; ++i) {
                if(this.comboBox1.Items[i].ToString().Equals(prevFile))
                    return;
            }
                                   
            this.comboBox1.Items.Add(prevFile);            
        }

        private void LoadPreviousFiles() {
            string line;            
            string fileName = DataDir + "\\" + PreviousFilesFileName;            

            // Make sure the data directory exists
            if(!Directory.Exists(DataDir)) {
                Directory.CreateDirectory(DataDir);
            }
                                   
            // Load the previous names from the data file
            if(!File.Exists(fileName)) {
                File.Create(fileName).Close();                
            } else {                            
                using(StreamReader sr = new StreamReader(new FileStream(fileName, FileMode.Open, FileAccess.Read))) {
                    while((line = sr.ReadLine()) != null) {
                        this.comboBox1.Items.Add(line);
                    }
                }
            }            
        }

        private void StorePreviousFiles() {
            string fileName = DataDir + "\\" + PreviousFilesFileName;            

            // Make sure the data directory exists
            if(!Directory.Exists(DataDir)) {
                Directory.CreateDirectory(DataDir);
            }
                                   
            // Load the previous names from the data file
            using(StreamWriter sw = File.Exists(fileName) ?
                      new StreamWriter(fileName, true) :
                      new StreamWriter(File.Create(fileName))) {
             
                for(int i = 0; i < this.comboBox1.Items.Count; ++i) {
                    sw.WriteLine(this.comboBox1.Items[i].ToString());                
                }
            }
        }

        private void LoadTypes() {
            if(m_Assembly == null)
                return;

            Cursor.Current = Cursors.WaitCursor;
            m_Types = m_Assembly.GetTypes();
            this.lbTypes.DataSource = m_Types;
            this.lbTypes.DisplayMember = "Name";                        
            Cursor.Current = Cursors.WaitCursor;
        }

        private void LoadFields() {           
            if(m_Assembly == null || m_Type == null)
                return;
            
            Cursor.Current = Cursors.WaitCursor;
            this.label3.Text = string.Format("Fields For {0}", m_Type.Name);
            this.m_Fields = m_Type.GetFields();
            BindReflectionInfo(this.lbFields, this.m_Fields);
            Cursor.Current = Cursors.Default;
        }

        private void LoadMethods() {
            if(m_Assembly == null || m_Type == null)
                return;

            Cursor.Current = Cursors.WaitCursor;
            this.label5.Text = string.Format("Methods For {0}", m_Type.Name);
            this.m_Methods = m_Type.GetMethods();
            BindReflectionInfo(this.lbMethods, this.m_Methods);
            Cursor.Current = Cursors.Default;
        }

        private void LoadProperties() {
            if(m_Assembly == null || m_Type == null)
                return;
            
            Cursor.Current = Cursors.WaitCursor;
            this.label4.Text = string.Format("Properties For {0}", m_Type.Name);
            this.m_Properties = m_Type.GetProperties();
            BindReflectionInfo(this.lbProperties, this.m_Properties);
            Cursor.Current = Cursors.Default;
        }

        private void tpAssembly_SelectedIndexChanged(object sender, System.EventArgs e) {            
            switch(this.tpAssembly.SelectedIndex) {
                case 1: // Load Preoperties
                    LoadProperties();
                    break;
                case 2: // Load Fields
                    LoadFields();
                    break;
                case 3: // Load Methods
                    LoadMethods();
                    break;
            }            
        }
        
        private void BindReflectionInfo(ListBox lbInfo, MemberInfo[] info) {
            if(m_Assembly == null || info == null)
                return;
            
            lbInfo.DataSource = info;
            lbInfo.DisplayMember = "Name";            
        }

        private void menuItem1_Click(object sender, System.EventArgs e) {
            StorePreviousFiles();
            Application.Exit();
        }        

        private void Form1_Load(object sender, System.EventArgs e) {
            LoadPreviousFiles();                        
        }

        private void lbTypes_SelectedIndexChanged(object sender, System.EventArgs e) {
            if(m_Assembly == null || this.lbTypes.SelectedIndex < 0)
                return;

            m_Type = m_Assembly.GetType(this.lbTypes.SelectedItem.ToString());
        }
	}    
}
