Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents numericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.numericUpDown1 = New System.Windows.Forms.NumericUpDown
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 104)
        Me.label2.Size = New System.Drawing.Size(224, 24)
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Size = New System.Drawing.Size(184, 16)
        Me.label1.Text = "In what year were you born?"
        '
        'numericUpDown1
        '
        Me.numericUpDown1.Location = New System.Drawing.Point(8, 40)
        Me.numericUpDown1.Maximum = New Decimal(New Integer() {2003, 0, 0, 0})
        Me.numericUpDown1.Minimum = New Decimal(New Integer() {1900, 0, 0, 0})
        Me.numericUpDown1.Value = New Decimal(New Integer() {190012, 0, 0, 131072})
        '
        'Form1
        '
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.numericUpDown1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub numericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles numericUpDown1.ValueChanged
        Dim yearsOld As Int32
        yearsOld = System.DateTime.Now.Year - numericUpDown1.Value
        label2.Text = String.Format("You are ~{0} years young.", yearsOld.ToString())
    End Sub
End Class
