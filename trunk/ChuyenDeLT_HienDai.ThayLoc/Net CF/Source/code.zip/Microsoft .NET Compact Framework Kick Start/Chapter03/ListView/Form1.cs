using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace ListView
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem1 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem2 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem3 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem4 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem5 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem6 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem7 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem8 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem9 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem10 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem11 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem12 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem13 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Windows.Forms.ListViewItem.ListViewSubItem listViewSubItem14 = new System.Windows.Forms.ListViewItem.ListViewSubItem();
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            // 
            // listView1
            // 
            this.listView1.Columns.Add(this.columnHeader1);
            this.listView1.Columns.Add(this.columnHeader2);
            this.listView1.Columns.Add(this.columnHeader3);
            listViewItem1.Checked = true;
            listViewItem1.ImageIndex = 0;
            listViewSubItem1.Text = "Snacking";
            listViewSubItem2.Text = "All Year";
            listViewItem1.SubItems.Add(listViewSubItem1);
            listViewItem1.SubItems.Add(listViewSubItem2);
            listViewItem1.Text = "Red Delicious";
            listViewItem2.ImageIndex = 1;
            listViewSubItem3.Text = "All Purpose";
            listViewSubItem4.Text = "Sept-June";
            listViewItem2.SubItems.Add(listViewSubItem3);
            listViewItem2.SubItems.Add(listViewSubItem4);
            listViewItem2.Text = "Golden Delicious";
            listViewItem3.ImageIndex = 2;
            listViewSubItem5.Text = "Snacking";
            listViewSubItem6.Text = "All Year";
            listViewItem3.SubItems.Add(listViewSubItem5);
            listViewItem3.SubItems.Add(listViewSubItem6);
            listViewItem3.Text = "Granny Smith";
            listViewItem4.ImageIndex = 3;
            listViewSubItem7.Text = "All Purpose";
            listViewSubItem8.Text = "Sept-June";
            listViewItem4.SubItems.Add(listViewSubItem7);
            listViewItem4.SubItems.Add(listViewSubItem8);
            listViewItem4.Text = "McIntosh";
            listViewItem5.ImageIndex = 4;
            listViewSubItem9.Text = "All Purpose";
            listViewSubItem10.Text = "Sept-Aug";
            listViewItem5.SubItems.Add(listViewSubItem9);
            listViewItem5.SubItems.Add(listViewSubItem10);
            listViewItem5.Text = "Jonathan";
            listViewItem6.ImageIndex = 5;
            listViewSubItem11.Text = "Baking";
            listViewSubItem12.Text = "Oct-Aug";
            listViewItem6.SubItems.Add(listViewSubItem11);
            listViewItem6.SubItems.Add(listViewSubItem12);
            listViewItem6.Text = "Rome";
            listViewItem7.ImageIndex = 6;
            listViewSubItem13.Text = "All Purpose";
            listViewSubItem14.Text = "Nov-July";
            listViewItem7.SubItems.Add(listViewSubItem13);
            listViewItem7.SubItems.Add(listViewSubItem14);
            listViewItem7.Text = "Winesap";
            this.listView1.Items.Add(listViewItem1);
            this.listView1.Items.Add(listViewItem2);
            this.listView1.Items.Add(listViewItem3);
            this.listView1.Items.Add(listViewItem4);
            this.listView1.Items.Add(listViewItem5);
            this.listView1.Items.Add(listViewItem6);
            this.listView1.Items.Add(listViewItem7);
            this.listView1.LargeImageList = this.imageList1;
            this.listView1.Location = new System.Drawing.Point(8, 24);
            this.listView1.Size = new System.Drawing.Size(224, 128);
            this.listView1.SmallImageList = this.imageList1;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 104;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Purpose";
            this.columnHeader2.Width = 69;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Size = new System.Drawing.Size(104, 16);
            this.label1.Text = "Types of Apples:";
            // 
            // imageList1
            // 
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource1"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource2"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource3"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource4"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource5"))));
            this.imageList1.Images.Add(((System.Drawing.Image)(resources.GetObject("resource6"))));
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            // 
            // radioButton1
            // 
            this.radioButton1.Location = new System.Drawing.Point(8, 160);
            this.radioButton1.Size = new System.Drawing.Size(88, 20);
            this.radioButton1.Text = "Details View";
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.radioButton2.Location = new System.Drawing.Point(120, 160);
            this.radioButton2.Size = new System.Drawing.Size(112, 20);
            this.radioButton2.Text = "Large Icon View";
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.radioButton3.Location = new System.Drawing.Point(120, 184);
            this.radioButton3.Size = new System.Drawing.Size(112, 20);
            this.radioButton3.Text = "Small Icon View";
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular);
            this.radioButton4.Location = new System.Drawing.Point(8, 184);
            this.radioButton4.Size = new System.Drawing.Size(72, 20);
            this.radioButton4.Text = "List View";
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "Exit";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Availability";
            this.columnHeader3.Width = 60;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 216);
            this.label2.Size = new System.Drawing.Size(88, 16);
            this.label2.Text = "Selected Item:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 232);
            this.label3.Size = new System.Drawing.Size(224, 16);
            // 
            // Form1
            // 
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Menu = this.mainMenu1;
            this.Text = " ";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void radioButton1_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton1.Checked) {
                this.imageList1.ImageSize = new Size(16, 16);
                this.listView1.View = View.Details;
            }
        }

        private void radioButton2_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton2.Checked) {
                this.imageList1.ImageSize = new Size(64, 64);
                this.listView1.View = View.LargeIcon;
            }
        }

        private void radioButton3_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton3.Checked) {
                this.imageList1.ImageSize = new Size(32, 32);
                this.listView1.View = View.SmallIcon;
            }
        }

        private void radioButton4_CheckedChanged(object sender, System.EventArgs e) {
            if(this.radioButton4.Checked) {                
                this.imageList1.ImageSize = new Size(16, 16);
                this.listView1.View = View.List;
            }
        }

        private void menuItem1_Click(object sender, System.EventArgs e) {
            Application.Exit();            
        }

        private void listView1_SelectedIndexChanged(object sender, System.EventArgs e) {            
            if(this.listView1.SelectedIndices.Count <= 0)
                return;

            int selNdx = this.listView1.SelectedIndices[0];
            if(selNdx >= 0)
                label3.Text = listView1.Items[selNdx].Text;
        }
	}
}
