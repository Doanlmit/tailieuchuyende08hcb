Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents progressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents timerProgressBar As System.Windows.Forms.Timer
    Friend WithEvents timerButtonMove As System.Windows.Forms.Timer
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Dim counter As Int32
    Dim gameOver As Boolean
    Dim rand As New Random(Environment.TickCount)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        counter = 0
        gameOver = True
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button2 = New System.Windows.Forms.Button
        Me.progressBar1 = New System.Windows.Forms.ProgressBar
        Me.button1 = New System.Windows.Forms.Button
        Me.timerProgressBar = New System.Windows.Forms.Timer
        Me.timerButtonMove = New System.Windows.Forms.Timer
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.Add(Me.MenuItem1)
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(14, 243)
        Me.button2.Size = New System.Drawing.Size(32, 24)
        Me.button2.Text = "Go"
        '
        'progressBar1
        '
        Me.progressBar1.Location = New System.Drawing.Point(70, 243)
        Me.progressBar1.Maximum = 60
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(6, 3)
        Me.button1.Size = New System.Drawing.Size(72, 24)
        Me.button1.Text = "Diffuse"
        '
        'timerProgressBar
        '
        Me.timerProgressBar.Interval = 500
        '
        'timerButtonMove
        '
        Me.timerButtonMove.Interval = 500
        '
        'MenuItem1
        '
        Me.MenuItem1.Text = "Exit"
        '
        'Form1
        '
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.progressBar1)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        If Not gameOver Then
            EndGame()
            MessageBox.Show("Nice Work, You're Alive!", "Congrats!")
        End If
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        ResetGame()
        StartGame()
    End Sub

    Private Sub StartGame()
        Me.timerButtonMove.Enabled = True
        Me.timerProgressBar.Enabled = True
    End Sub

    Private Sub ResetGame()
        progressBar1.Value = 0
        gameOver = False
        button2.Enabled = False
        button1.Location = New Point(0, 0)
    End Sub

    Private Sub EndGame()
        Me.timerButtonMove.Enabled = False
        Me.timerProgressBar.Enabled = False

        counter = 0
        Me.gameOver = True
        Me.button2.Enabled = True
    End Sub

    Private Sub timerButtonMove_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles timerButtonMove.Tick
        If Not gameOver Then
            Me.button1.Location = _
            New Point(rand.Next(0, 168), rand.Next(0, 216))
        Else
            EndGame()
        End If
    End Sub

    Private Sub timerProgressBar_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles timerProgressBar.Tick
        If counter < 60 Then
            If gameOver Then
                Return
            End If

            If Me.progressBar1.Value < Me.progressBar1.Maximum Then
                Me.progressBar1.Value = Me.progressBar1.Value + 1

                counter = counter + 1
            Else
                If Not gameOver Then
                    EndGame()
                    MessageBox.Show("Boom!", "Loser")
                End If
            End If
        End If
    End Sub

    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click
        Application.Exit()
    End Sub
End Class
