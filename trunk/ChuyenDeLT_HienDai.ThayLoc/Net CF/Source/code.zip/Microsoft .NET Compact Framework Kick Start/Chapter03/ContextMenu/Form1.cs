using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace SmartDeviceApplication1
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.ContextMenu contextMenu1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.MenuItem menuItem2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuItem menuItem3;
        private System.Windows.Forms.MenuItem menuItem4;
        private System.Windows.Forms.MenuItem menuItem5;
        private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItem6 = new System.Windows.Forms.MenuItem();
            this.contextMenu1 = new System.Windows.Forms.ContextMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuItem3 = new System.Windows.Forms.MenuItem();
            this.menuItem4 = new System.Windows.Forms.MenuItem();
            this.menuItem5 = new System.Windows.Forms.MenuItem();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem6);
            // 
            // menuItem6
            // 
            this.menuItem6.Text = "Exit";
            this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
            // 
            // contextMenu1
            // 
            this.contextMenu1.Popup += new System.EventHandler(this.contextMenu1_Popup);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "MenuItem 1";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.Text = "MenuItem 2";
            this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.Location = new System.Drawing.Point(24, 16);
            this.checkBox1.Size = new System.Drawing.Size(184, 20);
            this.checkBox1.Text = "Display MenuItem 1";
            this.checkBox1.CheckStateChanged += new System.EventHandler(this.checkBox1_CheckStateChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.Location = new System.Drawing.Point(24, 48);
            this.checkBox2.Size = new System.Drawing.Size(184, 20);
            this.checkBox2.Text = "Display MenuItem 2";
            // 
            // checkBox3
            // 
            this.checkBox3.Location = new System.Drawing.Point(24, 80);
            this.checkBox3.Size = new System.Drawing.Size(184, 20);
            this.checkBox3.Text = "Display MenuItem 3";
            // 
            // label1
            // 
            this.label1.ContextMenu = this.contextMenu1;
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(8, 136);
            this.label1.Size = new System.Drawing.Size(224, 16);
            this.label1.Text = "Tab-and-hold me for a context menu.";
            // 
            // menuItem3
            // 
            this.menuItem3.Text = "MenuItem 3";
            this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
            // 
            // menuItem4
            // 
            this.menuItem4.MenuItems.Add(this.menuItem5);
            this.menuItem4.Text = "Default Item 1";
            // 
            // menuItem5
            // 
            this.menuItem5.Text = "Default Item 2";
            this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click_1);
            // 
            // Form1
            // 
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Menu = this.mainMenu1;
            this.Text = "Form1";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void menuItem1_Click(object sender, System.EventArgs e) {
            MessageBox.Show("You selected MenuItem 1");
        }

        private void menuItem2_Click(object sender, System.EventArgs e) {
            MessageBox.Show("You selected MenuItem 2");
        }

        private void menuItem5_Click(object sender, System.EventArgs e) {
            MessageBox.Show("You selected MenuItem 3");
        }

        private void menuItem3_Click(object sender, System.EventArgs e) {
            MessageBox.Show("You selected MenuItem 3");
        }

        private void menuItem5_Click_1(object sender, System.EventArgs e) {
            MessageBox.Show("You selected Default Item 2");
        }

        private void contextMenu1_Popup(object sender, System.EventArgs e) {
            this.contextMenu1.MenuItems.Clear();
            
            if(this.checkBox1.Checked)
                this.contextMenu1.MenuItems.Add(this.menuItem1);

            if(this.checkBox2.Checked)
                this.contextMenu1.MenuItems.Add(this.menuItem2);

            if(this.checkBox3.Checked)
                this.contextMenu1.MenuItems.Add(this.menuItem3);

            // Always add the default menu 
            this.contextMenu1.MenuItems.Add(this.menuItem4);
        }

        private void menuItem6_Click(object sender, System.EventArgs e) {
            Application.Exit();
        }

        private void checkBox1_CheckStateChanged(object sender, System.EventArgs e) {
        
        }              
	}
}
