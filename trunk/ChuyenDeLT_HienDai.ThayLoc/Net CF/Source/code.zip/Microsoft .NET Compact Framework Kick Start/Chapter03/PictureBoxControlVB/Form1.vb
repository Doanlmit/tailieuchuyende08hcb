Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents imageList1 As System.Windows.Forms.ImageList
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button3 = New System.Windows.Forms.Button
        Me.button2 = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.imageList1 = New System.Windows.Forms.ImageList
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        '
        'button3
        '
        Me.button3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button3.Location = New System.Drawing.Point(52, 227)
        Me.button3.Size = New System.Drawing.Size(144, 24)
        Me.button3.Text = "Load From ImageList"
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button2.Location = New System.Drawing.Point(124, 195)
        Me.button2.Size = New System.Drawing.Size(104, 24)
        Me.button2.Text = "Load From Res"
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(12, 195)
        Me.button1.Size = New System.Drawing.Size(104, 24)
        Me.button1.Text = "Load From File"
        '
        'imageList1
        '
        Me.imageList1.Images.Add(CType(resources.GetObject("resource"), System.Drawing.Image))
        Me.imageList1.ImageSize = New System.Drawing.Size(92, 156)
        '
        'pictureBox1
        '
        Me.pictureBox1.Location = New System.Drawing.Point(16, 8)
        Me.pictureBox1.Size = New System.Drawing.Size(208, 168)
        '
        'Form1
        '
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.button3)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        pictureBox1.Image = New Bitmap("\Program Files\PictureBoxControlVB\tinyemulator_content.jpg")
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        pictureBox1.Image = _
                New Bitmap(System.Reflection.Assembly.GetExecutingAssembly(). _
                GetManifestResourceStream("PictureBoxControlVB.tinyemulator_res.jpg"))
    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        pictureBox1.Image = imageList1.Images(0)
    End Sub
End Class
