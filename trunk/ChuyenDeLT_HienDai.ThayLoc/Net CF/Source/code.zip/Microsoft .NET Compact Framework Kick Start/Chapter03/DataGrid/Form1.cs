using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using HitTestInfo = System.Windows.Forms.DataGrid.HitTestInfo;
using HitTestType = System.Windows.Forms.DataGrid.HitTestType;

namespace DataGrid
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.DataGrid dataGrid1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MainMenu mainMenu1;

		private DataTable m_DataTable;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// Generate the apples DataTable and bind it
			// to the DataGrid.
			//
			GenerateAndBindDataTable();

			//
			// Customize the appearance of the DataGrid
			//
			CustomizeDataGrid();
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{            
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.dataGrid1 = new System.Windows.Forms.DataGrid();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "Exit";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // dataGrid1
            // 
            this.dataGrid1.Location = new System.Drawing.Point(8, 16);
            this.dataGrid1.Size = new System.Drawing.Size(224, 136);
            this.dataGrid1.Text = "dataGrid1";
            this.dataGrid1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dataGrid1_MouseUp);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 168);
            this.label1.Size = new System.Drawing.Size(224, 16);
            this.label1.Text = "Selected Cell Text:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 184);
            this.label2.Size = new System.Drawing.Size(224, 16);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 200);
            this.label3.Size = new System.Drawing.Size(104, 20);
            this.label3.Text = "Row:";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(128, 200);
            this.label4.Size = new System.Drawing.Size(104, 20);
            this.label4.Text = "Column:";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(8, 232);
            this.label5.Size = new System.Drawing.Size(224, 16);
            this.label5.Text = "Type:";
            // 
            // Form1
            // 
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGrid1);
            this.Menu = this.mainMenu1;
            this.Text = "Form1";

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		public void GenerateAndBindDataTable() {
			this.m_DataTable = new DataTable("Apples");
			this.m_DataTable.Columns.Add("Name", typeof(string));
			this.m_DataTable.Columns.Add("Usage", typeof(string));
			this.m_DataTable.Columns.Add("Availability", typeof(string));

			AddRow("Red Delicious", "Snacking", "All Year");
			AddRow("Golden Delicious", "All Purpose", "Sept-June");
			AddRow("Rome", "Baking", "Oct-Aug");
			AddRow("Winesap", "Snacking", "All Year");
			AddRow("Granny Smith", "Snacking", "All-Year");
			AddRow("McIntosh", "All Purpose", "Sept-June");
			AddRow("Jonathan", "All Purpose", "Sept-Aug");

			this.dataGrid1.DataSource = this.m_DataTable;
		}
		
		private void AddRow(string name, string usage, string availability){
			DataRow row = this.m_DataTable.NewRow();
			row[0] = name;
			row[1] = usage;
			row[2] = availability;
			this.m_DataTable.Rows.Add(row);
		}

		private void CustomizeDataGrid() {
			dataGrid1.BackColor = Color.LightBlue;
			dataGrid1.ForeColor = Color.DarkBlue;
			dataGrid1.SelectionBackColor = Color.DarkBlue;
			dataGrid1.SelectionForeColor = Color.LightBlue;

			DataGridTableStyle dgts = new DataGridTableStyle();
			dgts.MappingName = "Apples";

			DataGridTextBoxColumn nameColumn = new DataGridTextBoxColumn();
			nameColumn.MappingName = "Name";
			nameColumn.HeaderText = "Apple Name";
			nameColumn.Width = 80;
			dgts.GridColumnStyles.Add(nameColumn);

			DataGridTextBoxColumn useColumn = new DataGridTextBoxColumn();
			useColumn.MappingName = "Usage";
			useColumn.HeaderText = "Best usage";
			useColumn.Width = 80;
			dgts.GridColumnStyles.Add(useColumn);

			DataGridTextBoxColumn avalColumn = new DataGridTextBoxColumn();
			avalColumn.MappingName = "Availability";
			avalColumn.HeaderText = "Best Time to Buy";
			avalColumn.Width = 80;
			dgts.GridColumnStyles.Add(avalColumn);

			this.dataGrid1.TableStyles.Add(dgts);
		}

        private void dataGrid1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e) {
            HitTestInfo hitInfo = dataGrid1.HitTest(e.X, e.Y);
            
            this.label2.Text = string.Empty;    
			this.label3.Text = string.Format("Row: {0}", hitInfo.Row);
			this.label4.Text = string.Format("Column: {0}", hitInfo.Column);
			this.label5.Text = string.Format("Type: {0}", hitInfo.Type.ToString());

            if(hitInfo.Type == HitTestType.Cell) {
                object selCell = dataGrid1[hitInfo.Row, hitInfo.Column];
                if(selCell != null)
                    this.label2.Text = selCell.ToString();
            }
        }

		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
	}
}
