Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents radioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents imageList1 As System.Windows.Forms.ImageList
    Friend WithEvents radioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents listView1 As System.Windows.Forms.ListView
    Friend WithEvents columnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents columnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents columnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem
        Dim ListViewSubItem1 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewSubItem2 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewItem2 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem
        Dim ListViewSubItem3 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewSubItem4 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewItem3 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem
        Dim ListViewSubItem5 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewSubItem6 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewItem4 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem
        Dim ListViewSubItem7 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewSubItem8 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewItem5 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem
        Dim ListViewSubItem9 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewSubItem10 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewItem6 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem
        Dim ListViewSubItem11 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewSubItem12 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewItem7 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem
        Dim ListViewSubItem13 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Dim ListViewSubItem14 As System.Windows.Forms.ListViewItem.ListViewSubItem = New System.Windows.Forms.ListViewItem.ListViewSubItem
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.radioButton4 = New System.Windows.Forms.RadioButton
        Me.imageList1 = New System.Windows.Forms.ImageList
        Me.radioButton3 = New System.Windows.Forms.RadioButton
        Me.radioButton2 = New System.Windows.Forms.RadioButton
        Me.radioButton1 = New System.Windows.Forms.RadioButton
        Me.label1 = New System.Windows.Forms.Label
        Me.listView1 = New System.Windows.Forms.ListView
        Me.columnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.columnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.columnHeader3 = New System.Windows.Forms.ColumnHeader
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(8, 232)
        Me.label3.Size = New System.Drawing.Size(224, 16)
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(8, 216)
        Me.label2.Size = New System.Drawing.Size(88, 16)
        Me.label2.Text = "Selected Item:"
        '
        'radioButton4
        '
        Me.radioButton4.Location = New System.Drawing.Point(8, 184)
        Me.radioButton4.Size = New System.Drawing.Size(72, 20)
        Me.radioButton4.Text = "List View"
        '
        'imageList1
        '
        Me.imageList1.Images.Add(CType(resources.GetObject("resource"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource1"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource2"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource3"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource4"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource5"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource6"), System.Drawing.Image))
        Me.imageList1.ImageSize = New System.Drawing.Size(16, 16)
        '
        'radioButton3
        '
        Me.radioButton3.Location = New System.Drawing.Point(120, 184)
        Me.radioButton3.Size = New System.Drawing.Size(112, 20)
        Me.radioButton3.Text = "Small Icon View"
        '
        'radioButton2
        '
        Me.radioButton2.Location = New System.Drawing.Point(120, 160)
        Me.radioButton2.Size = New System.Drawing.Size(112, 20)
        Me.radioButton2.Text = "Large Icon View"
        '
        'radioButton1
        '
        Me.radioButton1.Location = New System.Drawing.Point(8, 160)
        Me.radioButton1.Size = New System.Drawing.Size(88, 20)
        Me.radioButton1.Text = "Details View"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Size = New System.Drawing.Size(104, 16)
        Me.label1.Text = "Types of Apples:"
        '
        'listView1
        '
        Me.listView1.Columns.Add(Me.columnHeader1)
        Me.listView1.Columns.Add(Me.columnHeader2)
        Me.listView1.Columns.Add(Me.columnHeader3)
        ListViewItem1.Checked = True
        ListViewItem1.ImageIndex = 0
        ListViewSubItem1.Text = "Snacking"
        ListViewSubItem2.Text = "All Year"
        ListViewItem1.SubItems.Add(ListViewSubItem1)
        ListViewItem1.SubItems.Add(ListViewSubItem2)
        ListViewItem1.Text = "Red Delicious"
        ListViewItem2.ImageIndex = 1
        ListViewSubItem3.Text = "All Purpose"
        ListViewSubItem4.Text = "Sept-June"
        ListViewItem2.SubItems.Add(ListViewSubItem3)
        ListViewItem2.SubItems.Add(ListViewSubItem4)
        ListViewItem2.Text = "Golden Delicious"
        ListViewItem3.ImageIndex = 2
        ListViewSubItem5.Text = "Snacking"
        ListViewSubItem6.Text = "All Year"
        ListViewItem3.SubItems.Add(ListViewSubItem5)
        ListViewItem3.SubItems.Add(ListViewSubItem6)
        ListViewItem3.Text = "Granny Smith"
        ListViewItem4.ImageIndex = 3
        ListViewSubItem7.Text = "All Purpose"
        ListViewSubItem8.Text = "Sept-June"
        ListViewItem4.SubItems.Add(ListViewSubItem7)
        ListViewItem4.SubItems.Add(ListViewSubItem8)
        ListViewItem4.Text = "McIntosh"
        ListViewItem5.ImageIndex = 4
        ListViewSubItem9.Text = "All Purpose"
        ListViewSubItem10.Text = "Sept-Aug"
        ListViewItem5.SubItems.Add(ListViewSubItem9)
        ListViewItem5.SubItems.Add(ListViewSubItem10)
        ListViewItem5.Text = "Jonathan"
        ListViewItem6.ImageIndex = 5
        ListViewSubItem11.Text = "Baking"
        ListViewSubItem12.Text = "Oct-Aug"
        ListViewItem6.SubItems.Add(ListViewSubItem11)
        ListViewItem6.SubItems.Add(ListViewSubItem12)
        ListViewItem6.Text = "Rome"
        ListViewItem7.ImageIndex = 6
        ListViewSubItem13.Text = "All Purpose"
        ListViewSubItem14.Text = "Nov-July"
        ListViewItem7.SubItems.Add(ListViewSubItem13)
        ListViewItem7.SubItems.Add(ListViewSubItem14)
        ListViewItem7.Text = "Winesap"
        Me.listView1.Items.Add(ListViewItem1)
        Me.listView1.Items.Add(ListViewItem2)
        Me.listView1.Items.Add(ListViewItem3)
        Me.listView1.Items.Add(ListViewItem4)
        Me.listView1.Items.Add(ListViewItem5)
        Me.listView1.Items.Add(ListViewItem6)
        Me.listView1.Items.Add(ListViewItem7)
        Me.listView1.LargeImageList = Me.imageList1
        Me.listView1.Location = New System.Drawing.Point(8, 24)
        Me.listView1.Size = New System.Drawing.Size(224, 128)
        Me.listView1.SmallImageList = Me.imageList1
        Me.listView1.View = System.Windows.Forms.View.Details
        '
        'columnHeader1
        '
        Me.columnHeader1.Text = "Name"
        Me.columnHeader1.Width = 104
        '
        'columnHeader2
        '
        Me.columnHeader2.Text = "Purpose"
        Me.columnHeader2.Width = 69
        '
        'columnHeader3
        '
        Me.columnHeader3.Text = "Availability"
        Me.columnHeader3.Width = 60
        '
        'Form1
        '
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.radioButton4)
        Me.Controls.Add(Me.radioButton3)
        Me.Controls.Add(Me.radioButton2)
        Me.Controls.Add(Me.radioButton1)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.listView1)
        Me.Controls.Add(Me.label3)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub radioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radioButton1.CheckedChanged
        If Me.radioButton1.Checked Then
            Me.imageList1.ImageSize = New Size(16, 16)
            Me.listView1.View = View.Details
        End If
    End Sub

    Private Sub radioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radioButton2.CheckedChanged
        If Me.radioButton2.Checked Then
            Me.imageList1.ImageSize = New Size(64, 64)
            Me.listView1.View = View.LargeIcon
        End If
    End Sub

    Private Sub radioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radioButton3.CheckedChanged
        If Me.radioButton3.Checked Then
            Me.imageList1.ImageSize = New Size(32, 32)
            Me.listView1.View = View.SmallIcon
        End If
    End Sub


    Private Sub radioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radioButton4.CheckedChanged
        If Me.radioButton4.Checked Then
            Me.imageList1.ImageSize = New Size(16, 16)
            Me.listView1.View = View.List
        End If
    End Sub

    Private Sub listView1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listView1.SelectedIndexChanged
        If Me.listView1.SelectedIndices.Count <= 0 Then
            Return
        End If

        Dim selNdx = Me.listView1.SelectedIndices(0)
        If selNdx >= 0 Then
            label3.Text = listView1.Items(selNdx).Text
        End If
    End Sub
End Class


