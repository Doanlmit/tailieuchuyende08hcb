Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents treeView1 As System.Windows.Forms.TreeView
    Friend WithEvents imageList1 As System.Windows.Forms.ImageList
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents label2 As System.Windows.Forms.Label
    Private Sub InitializeComponent()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.label1 = New System.Windows.Forms.Label
        Me.treeView1 = New System.Windows.Forms.TreeView
        Me.imageList1 = New System.Windows.Forms.ImageList
        Me.label2 = New System.Windows.Forms.Label
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(16, 208)
        Me.label1.Size = New System.Drawing.Size(208, 16)
        Me.label1.Text = "You Selected:"
        '
        'treeView1
        '
        Me.treeView1.ImageList = Me.imageList1
        Me.treeView1.Location = New System.Drawing.Point(16, 8)
        TreeNode1.ImageIndex = 0
        TreeNode2.ImageIndex = 0
        TreeNode3.ImageIndex = 0
        TreeNode3.SelectedImageIndex = 0
        TreeNode3.Text = "Red Delicious"
        TreeNode4.ImageIndex = 4
        TreeNode4.SelectedImageIndex = 4
        TreeNode4.Text = "Jonathan"
        TreeNode5.ImageIndex = 5
        TreeNode5.SelectedImageIndex = 5
        TreeNode5.Text = "Rome"
        TreeNode6.ImageIndex = 6
        TreeNode6.SelectedImageIndex = 6
        TreeNode6.Text = "Winesap"
        TreeNode2.Nodes.Add(TreeNode3)
        TreeNode2.Nodes.Add(TreeNode4)
        TreeNode2.Nodes.Add(TreeNode5)
        TreeNode2.Nodes.Add(TreeNode6)
        TreeNode2.SelectedImageIndex = 0
        TreeNode2.Text = "Red Apples"
        TreeNode7.ImageIndex = 3
        TreeNode8.ImageIndex = 3
        TreeNode8.SelectedImageIndex = 3
        TreeNode8.Text = "Granny Smith"
        TreeNode7.Nodes.Add(TreeNode8)
        TreeNode7.SelectedImageIndex = 3
        TreeNode7.Text = "Green Apples"
        TreeNode9.ImageIndex = 1
        TreeNode10.ImageIndex = 1
        TreeNode10.SelectedImageIndex = 1
        TreeNode10.Text = "Golden Delicious"
        TreeNode9.Nodes.Add(TreeNode10)
        TreeNode9.SelectedImageIndex = 1
        TreeNode9.Text = "Yellow Apples"
        TreeNode11.ImageIndex = 2
        TreeNode12.ImageIndex = 2
        TreeNode12.SelectedImageIndex = 2
        TreeNode12.Text = "McIntosh"
        TreeNode11.Nodes.Add(TreeNode12)
        TreeNode11.SelectedImageIndex = 2
        TreeNode11.Text = "Red & Yellow Apples"
        TreeNode1.Nodes.Add(TreeNode2)
        TreeNode1.Nodes.Add(TreeNode7)
        TreeNode1.Nodes.Add(TreeNode9)
        TreeNode1.Nodes.Add(TreeNode11)
        TreeNode1.SelectedImageIndex = 0
        TreeNode1.Text = "Apples"
        Me.treeView1.Nodes.Add(TreeNode1)
        Me.treeView1.Size = New System.Drawing.Size(208, 184)
        '
        'imageList1
        '
        Me.imageList1.Images.Add(CType(resources.GetObject("resource"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource1"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource2"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource3"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource4"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource5"), System.Drawing.Image))
        Me.imageList1.Images.Add(CType(resources.GetObject("resource6"), System.Drawing.Image))
        Me.imageList1.ImageSize = New System.Drawing.Size(16, 16)
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(16, 224)
        Me.label2.Size = New System.Drawing.Size(208, 16)
        '
        'Form1
        '
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.treeView1)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub treeView1_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles treeView1.AfterSelect
        Dim selNode As TreeNode
        selNode = e.Node
        Me.label2.Text = selNode.Text
    End Sub
End Class
