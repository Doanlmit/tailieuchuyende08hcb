Imports AsyncQuotableQuotesClientVB.localhost

Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button

#Region " Windows Form Designer generated code "

    Public Sub New()

        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Size = New System.Drawing.Size(384, 80)
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(248, 104)
        Me.Label2.Size = New System.Drawing.Size(152, 16)
        Me.Label2.Text = "- Ronnie Yates"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.Label3.Location = New System.Drawing.Point(288, 120)
        Me.Label3.Size = New System.Drawing.Size(112, 16)
        Me.Label3.Text = "2003"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(8, 112)
        Me.Button1.Size = New System.Drawing.Size(112, 24)
        Me.Button1.Text = "Get Quote"
        '
        'Form1
        '
        Me.ClientSize = New System.Drawing.Size(410, 144)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Text = "Quotable Quotes Client"

    End Sub

    Public Shared Sub Main()
        Application.Run(New Form1)
    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim qs As New QuoteService
        Dim quote As Quote
        Dim getQuoteCB As New AsyncCallback(AddressOf Form1.GetQuoteCallBack)

        Dim callBackState(2) As Object
        callBackState(0) = qs
        callBackState(1) = Me

        qs.BeginGetQuote(getQuoteCB, callBackState)
    End Sub

    Private Sub UpdateQuoteUI(ByVal quote As Quote)
        Me.Label1.Text = quote.Str
        Me.Label2.Text = "= " & quote.Author
        If quote.Data = "Unknown" Then
            Me.Label3.Text = String.Empty
        Else
            Me.Label3.Text = quote.Data
        End If
    End Sub

    Shared Sub GetQuoteCallBack(ByVal ar As IAsyncResult)
        Dim callBackState() = CType(ar.AsyncState, Object())
        Dim qs As New QuoteService
        Dim app As Form1
        Dim quote As Quote

        quote = qs.EndGetQuote(ar)
        If quote Is Nothing Then
            MessageBox.Show("No quote object received.")
            Return
        End If

        app = CType(callBackState(1), Form1)
        app.UpdateQuoteUI(quote)
    End Sub

End Class
