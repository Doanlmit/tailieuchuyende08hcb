Imports System.Web.Services
Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.Common

<WebService(Namespace:="http://netcfkickstart/QuoteService", _
  Description:="Provides access to famous quotes")> _
Public Class QuoteService
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents quoteConnection As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdGetQuote As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdGetLargestID As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmdGetQuotes As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents daQuotesDS As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.quoteConnection = New System.Data.SqlClient.SqlConnection
        Me.cmdGetQuote = New System.Data.SqlClient.SqlCommand
        Me.cmdGetLargestID = New System.Data.SqlClient.SqlCommand
        Me.cmdGetQuotes = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.daQuotesDS = New System.Data.SqlClient.SqlDataAdapter
        '
        'quoteConnection
        '
        Me.quoteConnection.ConnectionString = "workstation id=""RYATES-DEV10"";packet size=4096;integrated security=SSPI;data sour" & _
        "ce=""RYATES-DEV10"";persist security info=True;initial catalog=QuotableQuotes"
        '
        'cmdGetQuote
        '
        Me.cmdGetQuote.CommandText = "dbo.[GetQuote]"
        Me.cmdGetQuote.CommandType = System.Data.CommandType.StoredProcedure
        Me.cmdGetQuote.Connection = Me.quoteConnection
        Me.cmdGetQuote.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        Me.cmdGetQuote.Parameters.Add(New System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.BigInt, 8))
        '
        'cmdGetLargestID
        '
        Me.cmdGetLargestID.CommandText = "dbo.[GetLargestQuoteID]"
        Me.cmdGetLargestID.CommandType = System.Data.CommandType.StoredProcedure
        Me.cmdGetLargestID.Connection = Me.quoteConnection
        Me.cmdGetLargestID.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        '
        'cmdGetQuotes
        '
        Me.cmdGetQuotes.CommandText = "dbo.[GetQuotes]"
        Me.cmdGetQuotes.CommandType = System.Data.CommandType.StoredProcedure
        Me.cmdGetQuotes.Connection = Me.quoteConnection
        Me.cmdGetQuotes.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT id, Quote, Author, DateSpoken FROM Quotes"
        Me.SqlSelectCommand1.Connection = Me.quoteConnection
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO Quotes(id, Quote, Author, DateSpoken) VALUES (@id, @Quote, @Author, @" & _
        "DateSpoken); SELECT id, Quote, Author, DateSpoken FROM Quotes"
        Me.SqlInsertCommand1.Connection = Me.quoteConnection
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.BigInt, 8, "id"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Quote", System.Data.SqlDbType.VarChar, 1024, "Quote"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Author", System.Data.SqlDbType.VarChar, 256, "Author"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DateSpoken", System.Data.SqlDbType.VarChar, 128, "DateSpoken"))
        '
        'daQuotesDS
        '
        Me.daQuotesDS.InsertCommand = Me.SqlInsertCommand1
        Me.daQuotesDS.SelectCommand = Me.SqlSelectCommand1
        Me.daQuotesDS.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Quotes", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("id", "id"), New System.Data.Common.DataColumnMapping("Quote", "Quote"), New System.Data.Common.DataColumnMapping("Author", "Author"), New System.Data.Common.DataColumnMapping("DateSpoken", "DateSpoken")})})

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Public ReadOnly Property LargestID() As Int64
        Get
            Dim largeID As Object
            largeID = Me.cmdGetLargestID.ExecuteScalar()

            If (largeID Is Nothing) Or Not (TypeOf largeID Is Int64) Then
                Return 0
            End If

            Return CLng(largeID)
        End Get
    End Property
#End Region

    <WebMethod()> _
    Public Function GetQuote() As Quote
        Me.quoteConnection.Open()

        Try
            Dim largeID As Long
            largeID = LargestID()

            If -1 = largeID Then
                Return Nothing
            End If

            Dim randomQuoteID As Int64
            Dim rand As New Random(DateTime.Now.Millisecond)

            randomQuoteID = rand.Next(CInt(largeID))
            Me.cmdGetQuote.Parameters("@id") = _
                New SqlParameter("@id", randomQuoteID)

            Dim reader As SqlDataReader
            reader = Me.cmdGetQuote.ExecuteReader()

            If Not reader.Read() Then
                Return Nothing
            End If

            Dim quote As New Quote
            quote.Str = reader.GetString(0)
            quote.Author = reader.GetString(1)
            quote.Data = reader.GetString(2)

            Return quote
        Finally
            Me.quoteConnection.Close()
        End Try
    End Function

    <WebMethod()> _
    Public Function GetQuotes() As DataSet
        Me.quoteConnection.Open()

        Try
            Dim quotesDS As DataSet
            Dim quotesDa As SqlDataAdapter
            quotesDS = New DataSet
            quotesDa = New SqlDataAdapter(Me.cmdGetQuotes)

            quotesDa.Fill(quotesDS)
            Return quotesDS
        Finally
            Me.quoteConnection.Close()
        End Try
    End Function

    <WebMethod()> _
    Public Function GeTypedQuotes() As DataSet
        Me.quoteConnection.Open()

        Try
            Dim quotesDS As New QuotesDataSet
            Me.daQuotesDS.Fill(quotesDS)

            Return quotesDS
        Finally
            Me.quoteConnection.Close()
        End Try
    End Function
End Class

Public Class Quote
    Public Str As String
    Public Author As String
    Public Data As String
End Class
