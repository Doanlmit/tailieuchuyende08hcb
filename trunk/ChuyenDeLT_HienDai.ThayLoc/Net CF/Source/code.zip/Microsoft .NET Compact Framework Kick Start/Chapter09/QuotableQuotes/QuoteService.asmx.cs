using System;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace QuotableQuotes
{
    [WebService(Namespace="http://netcfkickstart/QuoteService", Description="Provides access to famous quotes")]
	public class QuoteService : System.Web.Services.WebService
	{
		public QuoteService()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

        private Random rand = new Random(DateTime.Now.Millisecond);
        private System.Data.SqlClient.SqlConnection quoteConnection;
        private System.Data.SqlClient.SqlCommand cmdGetLargestID;
        private System.Data.SqlClient.SqlCommand cmdGetQuote;
        private System.Data.SqlClient.SqlCommand cmdGetQuotes;
        private System.Data.SqlClient.SqlCommand sqlSelectCommand1;
        private System.Data.SqlClient.SqlCommand sqlInsertCommand1;
        private System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
        private System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
        private System.Data.SqlClient.SqlDataAdapter daQuotesDS;

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.quoteConnection = new System.Data.SqlClient.SqlConnection();
            this.cmdGetLargestID = new System.Data.SqlClient.SqlCommand();
            this.cmdGetQuote = new System.Data.SqlClient.SqlCommand();
            this.cmdGetQuotes = new System.Data.SqlClient.SqlCommand();
            this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
            this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
            this.daQuotesDS = new System.Data.SqlClient.SqlDataAdapter();
            // 
            // quoteConnection
            // 
            this.quoteConnection.ConnectionString = "workstation id=\"RYATES-DEV4\";packet size=4096;integrated security=SSPI;data sourc" +
                "e=\"RYATES-DEV4\";persist security info=True;initial catalog=QuotableQuotes";
            // 
            // cmdGetLargestID
            // 
            this.cmdGetLargestID.CommandText = "dbo.[GetLargestQuoteID]";
            this.cmdGetLargestID.CommandType = System.Data.CommandType.StoredProcedure;
            this.cmdGetLargestID.Connection = this.quoteConnection;
            this.cmdGetLargestID.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
            // 
            // cmdGetQuote
            // 
            this.cmdGetQuote.CommandText = "dbo.[GetQuote]";
            this.cmdGetQuote.CommandType = System.Data.CommandType.StoredProcedure;
            this.cmdGetQuote.Connection = this.quoteConnection;
            this.cmdGetQuote.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
            this.cmdGetQuote.Parameters.Add(new System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.BigInt, 8));
            // 
            // cmdGetQuotes
            // 
            this.cmdGetQuotes.CommandText = "dbo.[GetQuotes]";
            this.cmdGetQuotes.CommandType = System.Data.CommandType.StoredProcedure;
            this.cmdGetQuotes.Connection = this.quoteConnection;
            this.cmdGetQuotes.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
            // 
            // sqlSelectCommand1
            // 
            this.sqlSelectCommand1.CommandText = "SELECT id, Quote, Author, DateSpoken FROM Quotes";
            this.sqlSelectCommand1.Connection = this.quoteConnection;
            // 
            // sqlInsertCommand1
            // 
            this.sqlInsertCommand1.CommandText = "INSERT INTO Quotes(id, Quote, Author, DateSpoken) VALUES (@id, @Quote, @Author, @" +
                "DateSpoken); SELECT id, Quote, Author, DateSpoken FROM Quotes WHERE (id = @id)";
            this.sqlInsertCommand1.Connection = this.quoteConnection;
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.BigInt, 8, "id"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Quote", System.Data.SqlDbType.VarChar, 1024, "Quote"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Author", System.Data.SqlDbType.VarChar, 256, "Author"));
            this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DateSpoken", System.Data.SqlDbType.VarChar, 128, "DateSpoken"));
            // 
            // sqlUpdateCommand1
            // 
            this.sqlUpdateCommand1.CommandText = @"UPDATE Quotes SET id = @id, Quote = @Quote, Author = @Author, DateSpoken = @DateSpoken WHERE (id = @Original_id) AND (Author = @Original_Author) AND (DateSpoken = @Original_DateSpoken) AND (Quote = @Original_Quote); SELECT id, Quote, Author, DateSpoken FROM Quotes WHERE (id = @id)";
            this.sqlUpdateCommand1.Connection = this.quoteConnection;
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.BigInt, 8, "id"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Quote", System.Data.SqlDbType.VarChar, 1024, "Quote"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Author", System.Data.SqlDbType.VarChar, 256, "Author"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@DateSpoken", System.Data.SqlDbType.VarChar, 128, "DateSpoken"));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_id", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "id", System.Data.DataRowVersion.Original, null));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Author", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Author", System.Data.DataRowVersion.Original, null));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DateSpoken", System.Data.SqlDbType.VarChar, 128, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DateSpoken", System.Data.DataRowVersion.Original, null));
            this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Quote", System.Data.SqlDbType.VarChar, 1024, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Quote", System.Data.DataRowVersion.Original, null));
            // 
            // sqlDeleteCommand1
            // 
            this.sqlDeleteCommand1.CommandText = "DELETE FROM Quotes WHERE (id = @Original_id) AND (Author = @Original_Author) AND " +
                "(DateSpoken = @Original_DateSpoken) AND (Quote = @Original_Quote)";
            this.sqlDeleteCommand1.Connection = this.quoteConnection;
            this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_id", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "id", System.Data.DataRowVersion.Original, null));
            this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Author", System.Data.SqlDbType.VarChar, 256, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Author", System.Data.DataRowVersion.Original, null));
            this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_DateSpoken", System.Data.SqlDbType.VarChar, 128, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "DateSpoken", System.Data.DataRowVersion.Original, null));
            this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_Quote", System.Data.SqlDbType.VarChar, 1024, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "Quote", System.Data.DataRowVersion.Original, null));
            // 
            // daQuotesDS
            // 
            this.daQuotesDS.DeleteCommand = this.sqlDeleteCommand1;
            this.daQuotesDS.InsertCommand = this.sqlInsertCommand1;
            this.daQuotesDS.SelectCommand = this.sqlSelectCommand1;
            this.daQuotesDS.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
                                                                                                 new System.Data.Common.DataTableMapping("Table", "Quotes", new System.Data.Common.DataColumnMapping[] {
                                                                                                                                                                                                           new System.Data.Common.DataColumnMapping("id", "id"),
                                                                                                                                                                                                           new System.Data.Common.DataColumnMapping("Quote", "Quote"),
                                                                                                                                                                                                           new System.Data.Common.DataColumnMapping("Author", "Author"),
                                                                                                                                                                                                           new System.Data.Common.DataColumnMapping("DateSpoken", "DateSpoken")})});
            this.daQuotesDS.UpdateCommand = this.sqlUpdateCommand1;

        }

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

        [WebMethod]
        public Quote GetQuote()
        {
            quoteConnection.Open();            
            
            try
            {
                Int64 randomQuoteId = rand.Next((int)LargestID);            
                cmdGetQuote.Parameters["@id"] = new SqlParameter("@id", randomQuoteId);

                SqlDataReader reader = cmdGetQuote.ExecuteReader();
                if(!reader.Read())
                    return null;

                Quote q = new Quote();
                q.String = reader.GetString(0);		// Get Quote String
                q.Author = reader.GetString(1);		// Get author's name
                q.Date = reader.GetString(2);		// Get the spoken date

                return q;
            }
            finally
            {
                quoteConnection.Close();
            }
        }      

        [WebMethod]
        public DataSet GetQuotes()
        {
            quoteConnection.Open();            
            
            try
            {
                DataSet quotesDS = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(this.cmdGetQuotes);
                
                da.Fill(quotesDS);

                return quotesDS;
            }
            finally
            {
                quoteConnection.Close();
            }
        }

        [WebMethod]
        public DataSet GetTypedQuotes()
        {
            quoteConnection.Open();            
            
            try
            {
                QuotesDataSet quotesDS = new QuotesDataSet();
                this.daQuotesDS.Fill(quotesDS);                               
                
                return quotesDS;
            }
            finally
            {
                quoteConnection.Close();
            }
        }

        public Int64 LargestID
        {
            get
            {
                object largestID = cmdGetLargestID.ExecuteScalar();
                if(largestID== null || !(largestID is Int64))
                    return 0;

                return (Int64)largestID;
            }
        }
	}

    public class Quote
    {	
        public string String;
        public string Author;
        public string Date;
    }
}
