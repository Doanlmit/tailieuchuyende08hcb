using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

using AsynQuotableQuotesClient.QuoteServiceWebReference;

namespace AsynQuotableQuotesClient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Button btnQuote;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.Label lblQuote;
    
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnQuote = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblQuote = new System.Windows.Forms.Label();
            // 
            // btnQuote
            // 
            this.btnQuote.Location = new System.Drawing.Point(9, 116);
            this.btnQuote.Size = new System.Drawing.Size(88, 24);
            this.btnQuote.Text = "Get Quote";
            this.btnQuote.Click += new System.EventHandler(this.btnQuote_Click);
            // 
            // lblDate
            // 
            this.lblDate.Location = new System.Drawing.Point(248, 124);
            this.lblDate.Size = new System.Drawing.Size(112, 16);
            this.lblDate.Text = "2003";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAuthor
            // 
            this.lblAuthor.Location = new System.Drawing.Point(112, 100);
            this.lblAuthor.Size = new System.Drawing.Size(248, 16);
            this.lblAuthor.Text = "- Ronnie Yates";
            this.lblAuthor.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblQuote
            // 
            this.lblQuote.Location = new System.Drawing.Point(17, 12);
            this.lblQuote.Size = new System.Drawing.Size(344, 80);
            this.lblQuote.Text = "\"Press \'Get Quote\' to view a cool quote from a famous person.\"";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(370, 152);
            this.Controls.Add(this.btnQuote);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblAuthor);
            this.Controls.Add(this.lblQuote);
            this.Text = "Async Quotable Quotes Client";
            this.Closed += new System.EventHandler(this.Form1_Closed);

        }
		#endregion

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void btnQuote_Click(object sender, System.EventArgs e)
        {
            QuoteService qs = new QuoteService();            
            // Set the url of the proxy to the proper url of the web service                

            AsyncCallback getQuoteCB = new AsyncCallback(
                AsynQuotableQuotesClient.Form1.GetQuoteCallBack);

            object[] callBackState = {qs, this};
            qs.BeginGetQuote(getQuoteCB, callBackState);    
        }

        public static void GetQuoteCallBack(IAsyncResult ar)
        {
            object[] callBackState = (object[])ar.AsyncState;
            QuoteService qs = (QuoteService)callBackState[0];
            Form1 app = (Form1)callBackState[1];

            Quote quote = qs.EndGetQuote(ar);

            if(null == quote)
            {
                MessageBox.Show("No quote object received.");
                return;
            }

            app.UpdateQuoteUI(quote);            
        }

        private void UpdateQuoteUI(Quote quote)
        {            
            lblQuote.Text = quote.String;
            lblAuthor.Text = "- " + quote.Author;
            lblDate.Text = ( quote.Date == "Unknown" ) ? string.Empty : quote.Date;
        }

        private void Form1_Closed(object sender, System.EventArgs e)
        {
            Application.Exit();
        }        
	}
}
