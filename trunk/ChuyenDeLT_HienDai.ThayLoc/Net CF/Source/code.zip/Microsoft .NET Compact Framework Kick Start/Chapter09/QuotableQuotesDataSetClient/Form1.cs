using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

using QuotableQuotesDataSetClient.QuoteServiceWebReference;

namespace QuotableQuotesDataSetClient
{
	public class Form1 : System.Windows.Forms.Form
	{
        private System.Windows.Forms.Button btnQuote;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.Label lblQuote;

        private DataSet quotesDataSet;		// The quotes dataset
        private int curQuoteRowNdx;			// current quote row index 

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.btnQuote = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblQuote = new System.Windows.Forms.Label();
            // 
            // btnQuote
            // 
            this.btnQuote.Location = new System.Drawing.Point(9, 116);
            this.btnQuote.Size = new System.Drawing.Size(88, 24);
            this.btnQuote.Text = "Get Quote";
            this.btnQuote.Click += new System.EventHandler(this.btnQuote_Click);
            // 
            // lblDate
            // 
            this.lblDate.Location = new System.Drawing.Point(248, 124);
            this.lblDate.Size = new System.Drawing.Size(112, 16);
            this.lblDate.Text = "2003";
            this.lblDate.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblAuthor
            // 
            this.lblAuthor.Location = new System.Drawing.Point(112, 100);
            this.lblAuthor.Size = new System.Drawing.Size(248, 16);
            this.lblAuthor.Text = "- Ronnie Yates";
            this.lblAuthor.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblQuote
            // 
            this.lblQuote.Location = new System.Drawing.Point(17, 12);
            this.lblQuote.Size = new System.Drawing.Size(344, 80);
            this.lblQuote.Text = "\"Press \'Get Quote\' to view a cool quote from a famous person.\"";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(370, 152);
            this.Controls.Add(this.btnQuote);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblAuthor);
            this.Controls.Add(this.lblQuote);
            this.Text = "Quotable Quotes DataSet Client";

        }
		#endregion

		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void btnQuote_Click(object sender, System.EventArgs e)
        {
            if(null == quotesDataSet)
            {
                QuoteService qs = new QuoteService();
				// Set the url of the proxy to the proper url of the web service

                quotesDataSet =  qs.GetQuotes();
                curQuoteRowNdx = 0;
            }

			if( quotesDataSet.Tables.Count >= 0 )
			{
				MessageBox.Show("Could not retreive the quotes dataset.");
				return;
			}

            if(curQuoteRowNdx >= quotesDataSet.Tables[0].Rows.Count)
                curQuoteRowNdx = 0;

            DataRow quote = quotesDataSet.Tables[0].Rows[curQuoteRowNdx];
            curQuoteRowNdx++;

            UpdateQuoteUI(quote, 0);            
        }

        private void UpdateQuoteUI(DataRow quote, int offset)
        {
            lblQuote.Text = (string)quote[offset];
            lblAuthor.Text = "-" + quote[offest + 1];
            lblDate.Text = ( "Unknown" == (string)quote[offest + 2] ) ?
                string.Empty :
                (string)quote[offest + 2];
        }
	}
}
