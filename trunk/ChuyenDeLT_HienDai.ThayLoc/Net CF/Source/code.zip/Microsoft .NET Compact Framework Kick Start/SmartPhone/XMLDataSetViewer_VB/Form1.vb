Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents dgDataSet As System.Windows.Forms.DataGrid
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_DataSet As DataSet
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtXmlToLoad As System.Windows.Forms.TextBox
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.dgDataSet = New System.Windows.Forms.DataGrid
        Me.txtXmlToLoad = New System.Windows.Forms.TextBox
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.Add(Me.MenuItem1)
        Me.MainMenu1.MenuItems.Add(Me.MenuItem2)
        '
        'dgDataSet
        '
        Me.dgDataSet.Size = New System.Drawing.Size(176, 160)
        Me.dgDataSet.Text = "DataGrid1"
        '
        'txtXmlToLoad
        '
        Me.txtXmlToLoad.Font = New System.Drawing.Font("Nina", 9.0!, System.Drawing.FontStyle.Regular)
        Me.txtXmlToLoad.Location = New System.Drawing.Point(0, 160)
        Me.txtXmlToLoad.Size = New System.Drawing.Size(176, 22)
        Me.txtXmlToLoad.Text = "\Storage\Program Files\XMLDataSetViewer_VB\SampleDataSet.xml"
        '
        'MenuItem1
        '
        Me.MenuItem1.Text = "Exit"
        '
        'MenuItem2
        '
        Me.MenuItem2.Text = "Load XML"
        '
        'Form1
        '
        Me.Controls.Add(Me.txtXmlToLoad)
        Me.Controls.Add(Me.dgDataSet)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        If (Me.m_DataSet Is Nothing) Then

            Me.m_DataSet = New DataSet
        End If
        Me.m_DataSet.Clear()

        Try
            m_DataSet.ReadXml(Me.txtXmlToLoad.Text)

            ' Set up a DataView 
            Dim l_DataView As DataView = New DataView(m_DataSet.Tables(0))
            Me.dgDataSet.DataSource = l_DataView

        Catch ex As Exception
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Sub MenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem1.Click
        Application.Exit()
    End Sub
End Class
