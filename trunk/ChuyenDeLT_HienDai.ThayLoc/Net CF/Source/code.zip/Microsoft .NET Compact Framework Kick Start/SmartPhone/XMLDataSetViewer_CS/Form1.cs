using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace XMLDataSetViewer_CS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dgDataSet;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.TextBox txtXmlToLoad;
		private System.Windows.Forms.MainMenu mainMenu1;

		private DataSet m_DataSet;
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.dgDataSet = new System.Windows.Forms.DataGrid();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.txtXmlToLoad = new System.Windows.Forms.TextBox();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.Add(this.menuItem1);
			this.mainMenu1.MenuItems.Add(this.menuItem2);
			// 
			// dgDataSet
			// 
			this.dgDataSet.Size = new System.Drawing.Size(176, 152);
			this.dgDataSet.Text = "dataGrid1";
			// 
			// menuItem1
			// 
			this.menuItem1.Text = "Exit";
			this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Text = "Load XML";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// txtXmlToLoad
			// 
			this.txtXmlToLoad.Font = new System.Drawing.Font("Nina", 9F, System.Drawing.FontStyle.Regular);
			this.txtXmlToLoad.Location = new System.Drawing.Point(0, 152);
			this.txtXmlToLoad.Size = new System.Drawing.Size(176, 22);
			this.txtXmlToLoad.Text = "\\Storage\\Program Files\\XMLDataSetViewer_CS\\SampleDataSet.xml";
			// 
			// Form1
			// 
			this.Controls.Add(this.txtXmlToLoad);
			this.Controls.Add(this.dgDataSet);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void menuItem1_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			if (this.m_DataSet == null)
			{
				this.m_DataSet = new DataSet();
			}
			this.m_DataSet.Clear();
			try
			{
				m_DataSet.ReadXml(this.txtXmlToLoad.Text);

				// Set up a DataView 
				DataView l_DataView = new DataView(m_DataSet.Tables[0]);
				this.dgDataSet.DataSource = l_DataView;

			}	
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}
		}
	}
}
