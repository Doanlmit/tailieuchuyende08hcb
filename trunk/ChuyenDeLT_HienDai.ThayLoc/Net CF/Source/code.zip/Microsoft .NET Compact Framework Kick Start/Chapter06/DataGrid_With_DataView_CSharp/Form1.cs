using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace DataGrid_With_DataView_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid dataGrid1;
		private System.Windows.Forms.MainMenu mainMenu1;

		DataSet m_DataSet;
		DataView m_sortAgeDataView;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.dataGrid1 = new System.Windows.Forms.DataGrid();
			// 
			// dataGrid1
			// 
			this.dataGrid1.Location = new System.Drawing.Point(32, 16);
			this.dataGrid1.Size = new System.Drawing.Size(184, 120);
			this.dataGrid1.Text = "dataGrid1";
			// 
			// Form1
			// 
			this.Controls.Add(this.dataGrid1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnPopulatedDataSet()
		{
			DataSet    l_DataSet = new DataSet();

			// A simple DataTable with a name and an age
			DataTable  l_newTable = new DataTable("People");
			l_newTable.Columns.Add(new DataColumn("Name", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("Age", typeof(System.Int32)));
			
			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Now put a few names in...
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "David Smith";
			l_newRow[1] = 45;
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Mary Jones";				
			l_newRow[1] = 18;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Jane Little";			
			l_newRow[1] = 34;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "James Kingston";			
			l_newRow[1] = 12;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Susan SameAge";			
			l_newRow[1] = 12;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Velma Knighton";			
			l_newRow[1] = 84;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}



		private void Form1_Load(object sender, System.EventArgs e)
		{
			// m_phoneBookDS is declared as a DataSet and it is a member of the main class for
			// this project.
			m_DataSet = ReturnPopulatedDataSet();	

			// Set up a DataView that sorts by age first, then by Name in descending order
			m_sortAgeDataView = new DataView(m_DataSet.Tables[0]);
			m_sortAgeDataView.Sort = "Age DESC, Name DESC";
	
			// Simply by setting the DataSource to our DataView, the DataView will paint automatically
			// in a friendly way.
			this.dataGrid1.DataSource = m_sortAgeDataView;
		}
	}
}
