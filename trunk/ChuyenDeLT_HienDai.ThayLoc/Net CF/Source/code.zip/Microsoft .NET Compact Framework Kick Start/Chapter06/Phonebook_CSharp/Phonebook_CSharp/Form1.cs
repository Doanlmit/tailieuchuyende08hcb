using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace Phonebook_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.MainMenu mainMenu1;

		DataSet m_phonebookDS;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 40);
			this.listBox1.Size = new System.Drawing.Size(224, 198);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Size = new System.Drawing.Size(224, 16);
			this.label1.Text = "My Phonebook Entries";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 240);
			this.button1.Size = new System.Drawing.Size(224, 20);
			this.button1.Text = "Randomize Phone Numbers";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.listBox1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnPopulatedDataSet()
		{
			DataSet    l_DataSet = new DataSet();

			// Create a data table that holds a "Name" and a "PhoneNumber"
			DataTable  l_newTable = new DataTable("Phone Contacts");
			l_newTable.Columns.Add(new DataColumn("Name", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("PhoneNumber", typeof(System.String)));
			
			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Now put a few names in...

			// GEORGE WASHINGTON
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "George Washington";
			l_newRow[1] = "555 340-1776";
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// BEN FRANKLIN
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow["Name"] = "Ben Franklin";					// Searching by column name is SLOWER on the .NET CF!
			l_newRow["PhoneNumber"] = "555 336-3211";			// Searching by column name is SLOWER on the .NET CF!
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// ALEXANDER HAMILTON
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Alexander Hamilton";			
			l_newRow[1] = "555 756-3211";			
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}

		// Paints the phone book data into the main window.
		private void PaintPhonebookData(DataSet phonebookEntriesDataSet)
		{
			this.listBox1.Items.Clear();

			for (int i = 0; i < phonebookEntriesDataSet.Tables[0].Rows.Count; i++)
			{
				this.listBox1.Items.Add(phonebookEntriesDataSet.Tables[0].Rows[i][0] + "  " + phonebookEntriesDataSet.Tables[0].Rows[i][1]);
			}
		}


		private void Form1_Load(object sender, System.EventArgs e)
		{
			// m_phoneBookDS is declared as a DataSet and it is a member of the main class for
			// this project.
			m_phonebookDS = ReturnPopulatedDataSet();
			PaintPhonebookData(m_phonebookDS);
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			int l_Seed = 38911;
			Random l_randomGenerator = new Random(l_Seed);

			// This loop updates the phone number to a random value
			for (int i = 0; i < m_phonebookDS.Tables[0].Rows.Count; i++)
			{
				// We use numeric indexing for performance.

				// Column 1 is the phone number.
				//                              |
				//                              V
				m_phonebookDS.Tables[0].Rows[i][1] = l_randomGenerator.Next().ToString();
			}
			m_phonebookDS.AcceptChanges();

			// Now paint the data.
			PaintPhonebookData(m_phonebookDS);
		}
	}
}
