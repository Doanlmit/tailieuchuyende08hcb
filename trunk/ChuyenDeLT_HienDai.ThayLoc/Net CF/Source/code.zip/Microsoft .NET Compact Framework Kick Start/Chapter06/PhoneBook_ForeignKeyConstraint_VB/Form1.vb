Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents listBox2 As System.Windows.Forms.ListBox
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_phonebookDS As DataSet

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button2 = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.listBox2 = New System.Windows.Forms.ListBox
        Me.listBox1 = New System.Windows.Forms.ListBox
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(24, 223)
        Me.button2.Size = New System.Drawing.Size(192, 32)
        Me.button2.Text = "Delete row - no trigger"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(24, 175)
        Me.button1.Size = New System.Drawing.Size(192, 32)
        Me.button1.Text = "Trigger ForeignKeyConstraint"
        '
        'listBox2
        '
        Me.listBox2.Location = New System.Drawing.Point(8, 87)
        Me.listBox2.Size = New System.Drawing.Size(224, 44)
        '
        'listBox1
        '
        Me.listBox1.Location = New System.Drawing.Point(8, 15)
        Me.listBox1.Size = New System.Drawing.Size(224, 58)
        '
        'Form1
        '
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.listBox2)
        Me.Controls.Add(Me.listBox1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    Private Function ReturnPopulatedDataSet() As DataSet
        Dim l_DataSet As DataSet
        l_DataSet = New DataSet

        ' Create a data table that holds a "FirstName", "LastName", "FullName" and "ContactID"
        Dim l_newTable As DataTable
        l_newTable = New DataTable("PhoneContactsMainTable")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("FirstName", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("LastName", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("FullName", System.Type.GetType("System.String")))

        ' Set up the ContactID DataColumn as autoincrement by 5, starting at 10
        ' That makes ContactID much like a primary key
        l_newTable.Columns("ContactID").AutoIncrement = True
        l_newTable.Columns("ContactID").AutoIncrementSeed = 10
        l_newTable.Columns("ContactID").AutoIncrementStep = 5


        ' Make the "FullName" a computed field that is the concatenation of the first name and
        ' the last name.
        l_newTable.Columns("FullName").Expression = "FirstName + ' ' + LastName"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a data table that holds cholesterol readings for each person
        ' This data table is a child to the "PhoneContactsMainTable"
        l_newTable = New DataTable("Cholesterol")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("Reading1", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading2", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading3", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("AverageReading", System.Type.GetType("System.Decimal")))

        ' Make the "AverageReading" column a computed column by using an expression
        l_newTable.Columns("AverageReading").Expression = "(Reading1 + Reading2 + Reading3) / 3"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a data table that holds blood pressure readings for each person
        ' This data table is a child to the "PhoneContactsMainTable"
        l_newTable = New DataTable("BloodPressure")
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))
        l_newTable.Columns.Add(New DataColumn("Reading1", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading2", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("Reading3", System.Type.GetType("System.Decimal")))
        l_newTable.Columns.Add(New DataColumn("AverageReading", System.Type.GetType("System.Decimal")))

        ' Make the "AverageReading" column a computed column by using an expression
        l_newTable.Columns("AverageReading").Expression = "(Reading1 + Reading2 + Reading3) / 3"

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Create a ForeignKeyConstraint between the two tables.
        ' When a parent row in the PhoneContactsMainTableis deleted,
        ' all of its child rows in the BloodPressure table are also deleted.
        Dim l_ForeignKC As ForeignKeyConstraint
        l_ForeignKC = New ForeignKeyConstraint("MainToCholesterolFKConstraint", _
    l_DataSet.Tables("PhoneContactsMainTable").Columns("ContactID"), _
    l_DataSet.Tables("BloodPressure").Columns("ContactID"))


        l_ForeignKC.DeleteRule = Rule.Cascade
        l_ForeignKC.UpdateRule = Rule.Cascade
        l_ForeignKC.AcceptRejectRule = AcceptRejectRule.Cascade

        l_DataSet.Tables(2).Constraints.Add(l_ForeignKC)
        l_DataSet.EnforceConstraints = True


        ' Now put a few names into the PhoneContactsMainTable
        ' GEORGE WASHINGTON
        Dim l_newRow As DataRow
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(1) = "George"
        l_newRow(2) = "Washington"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' BEN FRANKLIN
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow("FirstName") = "Ben"     ' Searching by column name is SLOWER on the .NET CF!
        l_newRow("LastName") = "Franklin"    ' Searching by column name is SLOWER on the .NET CF!
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' ALEXANDER HAMILTON
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(1) = "Alexander"
        l_newRow(2) = "Hamilton"
        l_DataSet.Tables(0).Rows.Add(l_newRow)


        ' Insert an entry into the Cholesterol table for George Washington
        l_newRow = l_DataSet.Tables("Cholesterol").NewRow()
        l_newRow("ContactID") = l_DataSet.Tables("PhoneContactsMainTable").Rows(0)("ContactID")
        l_newRow("Reading1") = 200
        l_newRow("Reading2") = 300
        l_newRow("Reading3") = 500
        l_DataSet.Tables("Cholesterol").Rows.Add(l_newRow)


        ' Commit the changes
        l_DataSet.AcceptChanges()

        Return l_DataSet
    End Function
    Private Sub PaintDataSet(ByVal phonebookEntriesDataSet As DataSet)
        Me.listBox1.Items.Clear()
        Me.listBox2.Items.Clear()

        Dim i As Integer
        For i = 0 To phonebookEntriesDataSet.Tables(0).Rows.Count - 1
            Me.listBox1.Items.Add(System.Convert.ToString(phonebookEntriesDataSet.Tables(0).Rows(i)("ContactID")) + " " + phonebookEntriesDataSet.Tables(0).Rows(i)("FullName"))
        Next i

        For i = 0 To phonebookEntriesDataSet.Tables(1).Rows.Count - 1

            Me.listBox2.Items.Add(System.Convert.ToString(phonebookEntriesDataSet.Tables(1).Rows(i)("ContactID")) + " " + _
             System.Convert.ToString(phonebookEntriesDataSet.Tables(1).Rows(i)("Reading1")) + " " + _
             System.Convert.ToString(phonebookEntriesDataSet.Tables(1).Rows(i)("Reading2")) + " " + _
             System.Convert.ToString(phonebookEntriesDataSet.Tables(1).Rows(i)("Reading3")) + " " + _
             System.Convert.ToString(phonebookEntriesDataSet.Tables(1).Rows(i)("AverageReading")))
        Next i
    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' m_phoneBookDS is declared as a DataSet and it is a member of the main class for
        ' this project.
        m_phonebookDS = ReturnPopulatedDataSet()
        PaintDataSet(m_phonebookDS)

    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        ' Delete "George Washington".  This row has child rows and so it will trigger the ForeignKeyConstraint,
        ' and an exception is thrown
        Try			
            m_phonebookDS.Tables(0).Rows(0).Delete()

            m_phonebookDS.AcceptChanges()
        Catch ex As Exception
            MessageBox.Show(ex.ToString())
            PaintDataSet(m_phonebookDS)
        End Try
    End Sub


    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        ' Delete "Alexander Hamilton" who has no children rows, so this is
        ' the ForeignKeyConstraint will do nothing.
        m_phonebookDS.Tables(0).Rows(2).Delete()

        m_phonebookDS.AcceptChanges()

        PaintDataSet(m_phonebookDS)
    End Sub
End Class
