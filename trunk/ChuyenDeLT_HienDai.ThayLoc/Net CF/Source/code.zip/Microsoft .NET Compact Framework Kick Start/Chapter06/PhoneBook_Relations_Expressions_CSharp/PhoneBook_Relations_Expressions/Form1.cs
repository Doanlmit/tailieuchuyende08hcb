using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace PhoneBook_Relations_Expressions
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;

		DataSet m_phonebookDS;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 0);
			this.listBox1.Size = new System.Drawing.Size(216, 44);
			// 
			// listBox2
			// 
			this.listBox2.Location = new System.Drawing.Point(8, 64);
			this.listBox2.Size = new System.Drawing.Size(216, 44);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(16, 168);
			this.button1.Size = new System.Drawing.Size(208, 32);
			this.button1.Text = "Delete row, trigger DataRelation";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(16, 216);
			this.button2.Size = new System.Drawing.Size(208, 32);
			this.button2.Text = "Delete row don\'t trigger";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.listBox2);
			this.Controls.Add(this.listBox1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnPopulatedDataSet()
		{
			DataSet    l_DataSet = new DataSet();

			// Create a data table that holds a "FirstName", "LastName", "FullName" and "ContactID"
			DataTable  l_newTable = new DataTable("PhoneContactsMainTable");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("FirstName", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("LastName", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("FullName", typeof(System.String)));
			
			// Set up the ContactID DataColumn as autoincrement by 5, starting at 10
			// That makes ContactID much like a primary key
			l_newTable.Columns["ContactID"].AutoIncrement = true;
			l_newTable.Columns["ContactID"].AutoIncrementSeed = 10;
			l_newTable.Columns["ContactID"].AutoIncrementStep = 5;


			// Make the "FullName" a computed field that is the concatenation of the first name and
			// the last name.
			l_newTable.Columns["FullName"].Expression = "FirstName + ' ' + LastName";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data table that holds cholesterol readings for each person
			// This data table is a child to the "PhoneContactsMainTable"
			l_newTable = new DataTable("Cholesterol");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("Reading1", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading2", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading3", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("AverageReading", typeof(System.Decimal)));
			
			// Make the "AverageReading" column a computed column by using an expression
			l_newTable.Columns["AverageReading"].Expression = "(Reading1 + Reading2 + Reading3) / 3";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data table that holds blood pressure readings for each person
			// This data table is a child to the "PhoneContactsMainTable"
			l_newTable = new DataTable("BloodPressure");
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			l_newTable.Columns.Add(new DataColumn("Reading1", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading2", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("Reading3", typeof(System.Decimal)));
			l_newTable.Columns.Add(new DataColumn("AverageReading", typeof(System.Decimal)));

			// Make the "AverageReading" column a computed column by using an expression
			l_newTable.Columns["AverageReading"].Expression = "(Reading1 + Reading2 + Reading3) / 3";

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Create a data relation between the PhoneContactsMainTable and the Cholesterol table
			// We will no longer be allowed to delete a row from PhoneContactMainTable if it has
			// children in the Cholesterol table
			DataRelation l_newRelation = new DataRelation("MainContactToCholesterolRelation",
															l_DataSet.Tables["PhoneContactsMainTable"].Columns["ContactID"],
															l_DataSet.Tables["Cholesterol"].Columns["ContactID"]);

			l_DataSet.Relations.Add(l_newRelation);





			// Now put a few names into the PhoneContactsMainTable
			// GEORGE WASHINGTON
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[1] = "George";
			l_newRow[2] = "Washington";
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// BEN FRANKLIN
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow["FirstName"] = "Ben";				// Searching by column name is SLOWER on the .NET CF!
			l_newRow["LastName"] = "Franklin";			// Searching by column name is SLOWER on the .NET CF!
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// ALEXANDER HAMILTON
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[1] = "Alexander";			
			l_newRow[2] = "Hamilton";			
			l_DataSet.Tables[0].Rows.Add(l_newRow);


			// Insert an entry into the Cholesterol table for George Washington
			l_newRow = l_DataSet.Tables["Cholesterol"].NewRow();
			l_newRow["ContactID"] = l_DataSet.Tables["PhoneContactsMainTable"].Rows[0]["ContactID"];
			l_newRow["Reading1"] = 200;
			l_newRow["Reading2"] = 300;
			l_newRow["Reading3"] = 500;
			l_DataSet.Tables["Cholesterol"].Rows.Add(l_newRow);


			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}

		// Paints the phone book data into the main window.
		private void PaintPhonebookData(DataSet phonebookEntriesDataSet)
		{
			this.listBox1.Items.Clear();
			this.listBox2.Items.Clear();

			for (int i = 0; i < phonebookEntriesDataSet.Tables[0].Rows.Count; i++)
			{
				this.listBox1.Items.Add(phonebookEntriesDataSet.Tables[0].Rows[i]["ContactID"] + " " + phonebookEntriesDataSet.Tables[0].Rows[i]["FullName"]);
			}

			for (int i = 0; i < phonebookEntriesDataSet.Tables[1].Rows.Count; i++)
			{
				this.listBox2.Items.Add(phonebookEntriesDataSet.Tables[1].Rows[i]["ContactID"] + " " + 
					phonebookEntriesDataSet.Tables[1].Rows[i]["Reading1"] + " " +
					phonebookEntriesDataSet.Tables[1].Rows[i]["Reading2"] + " " +
					phonebookEntriesDataSet.Tables[1].Rows[i]["Reading3"] + " " +
					phonebookEntriesDataSet.Tables[1].Rows[i]["AverageReading"]);
			}
		}


		private void Form1_Load(object sender, System.EventArgs e)
		{
			// m_phoneBookDS is declared as a DataSet and it is a member of the main class for
			// this project.
			m_phonebookDS = ReturnPopulatedDataSet();
			PaintPhonebookData(m_phonebookDS);				
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			// Delete "George Washington".  This row has child rows and so it will trigger the DataRelation,
			// and the child rows will be deleted
			m_phonebookDS.Tables[0].Rows[0].Delete();

			m_phonebookDS.AcceptChanges();

			PaintPhonebookData(m_phonebookDS);
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			// Delete "Alexander Hamilton" who has no children rows, so this is
			// the DataRelation will do nothing.
			m_phonebookDS.Tables[0].Rows[2].Delete();

			m_phonebookDS.AcceptChanges();

			PaintPhonebookData(m_phonebookDS);
		}
	}
}
