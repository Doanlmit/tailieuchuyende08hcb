Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_phonebookDS As System.Data.DataSet

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button1 = New System.Windows.Forms.Button
        Me.label1 = New System.Windows.Forms.Label
        Me.listBox1 = New System.Windows.Forms.ListBox
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(8, 237)
        Me.button1.Size = New System.Drawing.Size(224, 20)
        Me.button1.Text = "Randomize Phone Numbers"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 13)
        Me.label1.Size = New System.Drawing.Size(224, 16)
        Me.label1.Text = "My Phonebook Entries"
        '
        'listBox1
        '
        Me.listBox1.Location = New System.Drawing.Point(8, 37)
        Me.listBox1.Size = New System.Drawing.Size(224, 198)
        '
        'Form1
        '
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.listBox1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Function ReturnPopulatedDataSet() As DataSet
        Dim l_DataSet As New DataSet

        ' Create a data table that holds a "Name" and a "PhoneNumber"
        Dim l_newTable As New DataTable("Phone Contacts")
        l_newTable.Columns.Add(New DataColumn("Name", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("PhoneNumber", System.Type.GetType("System.String")))

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Now put a few names in...
        ' GEORGE WASHINGTON
        Dim l_newRow As DataRow
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "George Washington"
        l_newRow(1) = "555 340-1776"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' BEN FRANKLIN
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow("Name") = "Ben Franklin"     ' Searching by column name is SLOWER on the .NET CF!
        l_newRow("PhoneNumber") = "555 336-3211"   ' Searching by column name is SLOWER on the .NET CF!
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        'ALEXANDER HAMILTON
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Alexander Hamilton"
        l_newRow(1) = "555 756-3211"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' Commit the changes
        l_DataSet.AcceptChanges()

        ReturnPopulatedDataSet = l_DataSet

    End Function
    Private Sub PaintPhoneBookData(ByVal phonebookEntriesDataSet As DataSet)
        Me.listBox1.Items.Clear()

        Dim i As Integer
        For i = 0 To phonebookEntriesDataSet.Tables(0).Rows.Count - 1
            Me.listBox1.Items.Add(phonebookEntriesDataSet.Tables(0).Rows(i)(0) + "  " + phonebookEntriesDataSet.Tables(0).Rows(i)(1))
        Next i
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' m_phoneBookDS is declared as a DataSet and it is a member of the main class for
        ' this project.
        Me.m_phonebookDS = ReturnPopulatedDataSet()
        PaintPhoneBookData(m_phonebookDS)
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim l_Seed As Integer
        l_Seed = 38911

        Dim l_randomGenerator As Random
        l_randomGenerator = New Random(l_Seed)

        ' This loop updates the phone number to a random value
        Dim i As Integer
        For i = 0 To m_phonebookDS.Tables(0).Rows.Count - 1
            ' We use numeric indexing for performance.

            ' Column 1 is the phone number.
            '                               |
            '                               V
            m_phonebookDS.Tables(0).Rows(i)(1) = l_randomGenerator.Next().ToString()
        Next i

        m_phonebookDS.AcceptChanges()

        ' Now paint the data.
        PaintPhoneBookData(m_phonebookDS)

    End Sub
End Class
