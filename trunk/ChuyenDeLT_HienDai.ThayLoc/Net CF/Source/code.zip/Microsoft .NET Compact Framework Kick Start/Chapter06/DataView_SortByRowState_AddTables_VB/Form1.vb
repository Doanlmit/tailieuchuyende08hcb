Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents listBox3 As System.Windows.Forms.ListBox
    Friend WithEvents listBox2 As System.Windows.Forms.ListBox
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button2 = New System.Windows.Forms.Button
        Me.listBox3 = New System.Windows.Forms.ListBox
        Me.listBox2 = New System.Windows.Forms.ListBox
        Me.listBox1 = New System.Windows.Forms.ListBox
        Me.button1 = New System.Windows.Forms.Button
        Me.label3 = New System.Windows.Forms.Label
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button2.Location = New System.Drawing.Point(12, 207)
        Me.button2.Size = New System.Drawing.Size(216, 24)
        Me.button2.Text = "Add and delete some rows"
        '
        'listBox3
        '
        Me.listBox3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.listBox3.Location = New System.Drawing.Point(12, 151)
        Me.listBox3.Size = New System.Drawing.Size(216, 44)
        '
        'listBox2
        '
        Me.listBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.listBox2.Location = New System.Drawing.Point(12, 87)
        Me.listBox2.Size = New System.Drawing.Size(216, 44)
        '
        'listBox1
        '
        Me.listBox1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.listBox1.Location = New System.Drawing.Point(12, 23)
        Me.listBox1.Size = New System.Drawing.Size(216, 44)
        '
        'button1
        '
        Me.button1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.button1.Location = New System.Drawing.Point(12, 239)
        Me.button1.Size = New System.Drawing.Size(216, 24)
        Me.button1.Text = "Call AcceptChanges"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label3.Location = New System.Drawing.Point(12, 135)
        Me.label3.Size = New System.Drawing.Size(216, 16)
        Me.label3.Text = "Deleted rows"
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label2.Location = New System.Drawing.Point(12, 71)
        Me.label2.Size = New System.Drawing.Size(208, 16)
        Me.label2.Text = "Added rows"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.label1.Location = New System.Drawing.Point(12, 7)
        Me.label1.Size = New System.Drawing.Size(216, 16)
        Me.label1.Text = "Unmodified Rows"
        '
        'Form1
        '
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.listBox3)
        Me.Controls.Add(Me.listBox2)
        Me.Controls.Add(Me.listBox1)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private m_DataSet As DataSet
    Private m_addedRowsView As DataView
    Private m_deletedRowsView As DataView
    Private m_Random As Random

    Private Function ReturnPopulatedDataSet() As DataSet
        Dim l_DataSet As DataSet
        l_DataSet = New DataSet

        ' A simple DataTable with a name and an age
        Dim l_newTable As DataTable
        l_newTable = New DataTable("People")
        l_newTable.Columns.Add(New DataColumn("Name", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("Age", System.Type.GetType("System.Int32")))

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Now put a few names in...
        Dim l_newRow As DataRow
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "David Smith"
        l_newRow(1) = 45
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Mary Jones"
        l_newRow(1) = 18
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Jane Little"
        l_newRow(1) = 34
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "James Kingston"
        l_newRow(1) = 12
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Susan SameAge"
        l_newRow(1) = 12
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Velma Knighton"
        l_newRow(1) = 84
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' Commit the changes
        l_DataSet.AcceptChanges()


        ' Set up the DataViews....
        ' me DataView only shows rows that have been added
        m_addedRowsView = New DataView(l_DataSet.Tables(0))
        m_addedRowsView.RowStateFilter = DataViewRowState.Added


        ' me DataView only shows rows that have been deleted.
        m_deletedRowsView = New DataView(l_DataSet.Tables(0))
        m_deletedRowsView.RowStateFilter = DataViewRowState.Deleted

        Return l_DataSet
    End Function
    Private Sub PaintDataSet(ByVal in_DataSet As DataSet)
        Me.listBox1.Items.Clear()
        Me.listBox2.Items.Clear()
        Me.listBox3.Items.Clear()

        Dim i As Integer
        For i = 0 To in_DataSet.Tables(0).Rows.Count - 1
            ' We cannot directly access deleted rows, so we have to be careful only
            ' to paint in unchanged rows.
            If in_DataSet.Tables(0).Rows(i).RowState = DataRowState.Unchanged Then
                Me.listBox1.Items.Add(System.Convert.ToString(in_DataSet.Tables(0).Rows(i)(0)) + "  " + System.Convert.ToString(in_DataSet.Tables(0).Rows(i)(1)))
            End If
        Next i

        ' Paint the DataView that only shows newly added rows
        For i = 0 To m_addedRowsView.Count - 1
            Me.listBox2.Items.Add(m_addedRowsView(i)("Name") + "   " + System.Convert.ToString(m_addedRowsView(i)("Age")))
        Next i

        ' Paint the DataView that only shows deleted rows
        For i = 0 To m_deletedRowsView.Count - 1
            Me.listBox3.Items.Add(m_deletedRowsView(i)("Name") + "   " + System.Convert.ToString(m_deletedRowsView(i)("Age")))
        Next i

    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' m_DataSet is declared as a DataSet and it is a member of the main class for
        ' this project.
        Dim l_Seed As Integer
        l_Seed = 34244
        m_Random = New Random(l_Seed)
        m_DataSet = ReturnPopulatedDataSet()
        PaintDataSet(m_DataSet)

    End Sub



    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        m_DataSet.AcceptChanges()
        PaintDataSet(m_DataSet)
    End Sub


    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        ' Delete two rows
        m_DataSet.Tables(0).Rows(0).Delete()
        m_DataSet.Tables(0).Rows(1).Delete()

        ' Add two new rows
        Dim l_maxRandom As Integer
        l_maxRandom = 100
        Dim l_firstNewDataRowView As DataRowView
        l_firstNewDataRowView = m_addedRowsView.AddNew()
        l_firstNewDataRowView("Name") = "NewPerson" + m_Random.Next(l_maxRandom).ToString()
        l_firstNewDataRowView("Age") = m_Random.Next(l_maxRandom)
        l_firstNewDataRowView.EndEdit()

        Dim l_secondNewDataRowView As DataRowView
        l_secondNewDataRowView = m_addedRowsView.AddNew()
        l_secondNewDataRowView("Name") = "NewPerson" + m_Random.Next(l_maxRandom).ToString()
        l_secondNewDataRowView("Age") = m_Random.Next(l_maxRandom)
        l_secondNewDataRowView.EndEdit()
        PaintDataSet(m_DataSet)
    End Sub

End Class
