Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private m_phonebookDS As DataSet

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.button2 = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.listBox1 = New System.Windows.Forms.ListBox
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(12, 241)
        Me.button2.Size = New System.Drawing.Size(216, 20)
        Me.button2.Text = "Violate AllowDBNull"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(12, 217)
        Me.button1.Size = New System.Drawing.Size(216, 20)
        Me.button1.Text = "Violate Constraint"
        '
        'listBox1
        '
        Me.listBox1.Location = New System.Drawing.Point(12, 9)
        Me.listBox1.Size = New System.Drawing.Size(216, 198)
        '
        'Form1
        '
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.listBox1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    ' Creates a new DataSet and fills it with phone book entries programmatically
    Private Function ReturnPopulatedDataSet() As DataSet
        Dim l_DataSet As DataSet
        l_DataSet = New DataSet

        ' Create a data table that holds a "Name", "PhoneNumber", and "ContactID"
        Dim l_newTable As DataTable
        l_newTable = New DataTable("Phone Contacts")
        l_newTable.Columns.Add(New DataColumn("Name", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("PhoneNumber", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("ContactID", System.Type.GetType("System.Int32")))


        ' Don't allow the "Name" DataColumnn to be null
        l_newTable.Columns("Name").AllowDBNull = False

        ' Set up the ContactID DataColumn as autoincrement by 5, starting at 10
        ' That makes ContactID much like a primary key
        l_newTable.Columns("ContactID").AutoIncrement = True
        l_newTable.Columns("ContactID").AutoIncrementSeed = 10
        l_newTable.Columns("ContactID").AutoIncrementStep = 5

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Add a UniqueConstraint to the phone number column
        Dim l_UniqueConstraint As UniqueConstraint
        l_UniqueConstraint = New UniqueConstraint(l_DataSet.Tables(0).Columns("PhoneNumber"))
        l_DataSet.Tables(0).Constraints.Add(l_UniqueConstraint)


        ' Now put a few names in...
        ' GEORGE WASHINGTON
        Dim l_newRow As DataRow
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "George Washington"
        l_newRow(1) = "340-1776"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' BEN FRANKLIN
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow("Name") = "Ben Franklin"      ' Searching by column name is SLOWER on the .NET CF!
        l_newRow("PhoneNumber") = "336-3211"    ' Searching by column name is SLOWER on the .NET CF!
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' ALEXANDER HAMILTON
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Alexander Hamilton"
        l_newRow(1) = "756-3211"
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' Commit the changes
        l_DataSet.AcceptChanges()

        Return l_DataSet
    End Function
    ' Paints the phone book data into the main window.
    Private Sub PaintPhonebookData(ByVal phonebookEntriesDataSet As DataSet)
        Me.listBox1.Items.Clear()

        Dim i As Integer
        For i = 0 To phonebookEntriesDataSet.Tables(0).Rows.Count - 1
            Me.listBox1.Items.Add(System.Convert.ToString(phonebookEntriesDataSet.Tables(0).Rows(i)("ContactID")) + " " + System.Convert.ToString(phonebookEntriesDataSet.Tables(0).Rows(i)(0)) + " " + System.Convert.ToString(phonebookEntriesDataSet.Tables(0).Rows(i)(1)))
        Next i

    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        ' We're going to add two row with the same phone number on the first
        ' table in the DataSet
        ' That will cause an exception because of the UniqueConstraint in the
        ' Constraints collection inside the table.
        Try
            Dim l_newRow As DataRow
            l_newRow = m_phonebookDS.Tables(0).NewRow()
            l_newRow(0) = "Mister Nobody"
            l_newRow(1) = "5551212"
            m_phonebookDS.Tables(0).Rows.Add(l_newRow)

            l_newRow = m_phonebookDS.Tables(0).NewRow()
            l_newRow(0) = "Constraint Violator"
            l_newRow(1) = "5551212"
            m_phonebookDS.Tables(0).Rows.Add(l_newRow)

            ' This is going to throw an exception because the phone number is
            ' DBNull and that violates a constraint.
            m_phonebookDS.AcceptChanges()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "Exception adding a new row")
        End Try

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' m_phoneBookDS is declared as a DataSet and it is a member of the main class for
        ' this project.
        m_phonebookDS = ReturnPopulatedDataSet()
        PaintPhonebookData(m_phonebookDS)
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        Try
            Dim l_newRow As DataRow
            l_newRow = m_phonebookDS.Tables(0).NewRow()
            l_newRow(1) = "5555587"

            ' This is going to throw an exception because the "Name" DataColumn
            ' was never set, so it is DBNull, and that is not allowed for that
            ' DataColumn
            m_phonebookDS.Tables(0).Rows.Add(l_newRow)

            m_phonebookDS.AcceptChanges()
        Catch ex As Exception
            MessageBox.Show(ex.ToString(), "Exception adding a new row")
        End Try
    End Sub
End Class
