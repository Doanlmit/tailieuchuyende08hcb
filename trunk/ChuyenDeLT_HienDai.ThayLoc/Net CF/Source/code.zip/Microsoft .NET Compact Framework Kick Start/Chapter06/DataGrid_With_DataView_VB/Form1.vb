Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Private m_DataSet As DataSet
    Private m_sortAgeDataView As DataView

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.DataGrid1 = New System.Windows.Forms.DataGrid
        '
        'DataGrid1
        '
        Me.DataGrid1.Location = New System.Drawing.Point(48, 32)
        Me.DataGrid1.Size = New System.Drawing.Size(152, 152)
        Me.DataGrid1.Text = "DataGrid1"
        '
        'Form1
        '
        Me.Controls.Add(Me.DataGrid1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region
    Private Function ReturnPopulatedDataset() As DataSet
        Dim l_DataSet As DataSet
        l_DataSet = New DataSet

        ' A simple DataTable with a name and an age
        Dim l_newTable As DataTable
        l_newTable = New DataTable("People")
        l_newTable.Columns.Add(New DataColumn("Name", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("Age", System.Type.GetType("System.Int32")))

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)

        ' Now put a few names in...
        Dim l_newRow As DataRow
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "David Smith"
        l_newRow(1) = 45
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Mary Jones"
        l_newRow(1) = 18
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Jane Little"
        l_newRow(1) = 34
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "James Kingston"
        l_newRow(1) = 12
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Susan SameAge"
        l_newRow(1) = 12
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Velma Knighton"
        l_newRow(1) = 84
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' Commit the changes
        l_DataSet.AcceptChanges()

        ReturnPopulatedDataset = l_DataSet
    End Function

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' m_phoneBookDS is declared as a DataSet and it is a member of the main class for
        ' this project.
        m_DataSet = ReturnPopulatedDataset()

        ' Set up a DataView that sorts by age first, then by Name in descending order
        m_sortAgeDataView = New DataView(m_DataSet.Tables(0))
        m_sortAgeDataView.Sort = "Age DESC, Name DESC"

        ' Simply by setting the DataSource to our DataView, the DataView will paint automatically
        ' in a friendly way.
        Me.DataGrid1.DataSource = m_sortAgeDataView

    End Sub
End Class
