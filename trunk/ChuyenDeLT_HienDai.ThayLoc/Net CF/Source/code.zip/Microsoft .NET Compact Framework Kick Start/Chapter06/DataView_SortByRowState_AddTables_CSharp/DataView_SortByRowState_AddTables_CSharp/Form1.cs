using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace DataView_SortByRowState_AddTables_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.ListBox listBox3;
		private System.Windows.Forms.MainMenu mainMenu1;

		private DataSet m_DataSet;
		private DataView m_addedRowsView;
		private System.Windows.Forms.Button button2;
		private DataView m_deletedRowsView;
		private Random m_Random;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.listBox3 = new System.Windows.Forms.ListBox();
			this.button2 = new System.Windows.Forms.Button();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Size = new System.Drawing.Size(216, 16);
			this.label1.Text = "Unmodified Rows";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 72);
			this.label2.Size = new System.Drawing.Size(208, 16);
			this.label2.Text = "Added rows";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 136);
			this.label3.Size = new System.Drawing.Size(216, 16);
			this.label3.Text = "Deleted rows";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 240);
			this.button1.Size = new System.Drawing.Size(216, 24);
			this.button1.Text = "Call AcceptChanges";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 24);
			this.listBox1.Size = new System.Drawing.Size(216, 44);
			// 
			// listBox2
			// 
			this.listBox2.Location = new System.Drawing.Point(8, 88);
			this.listBox2.Size = new System.Drawing.Size(216, 44);
			// 
			// listBox3
			// 
			this.listBox3.Location = new System.Drawing.Point(8, 152);
			this.listBox3.Size = new System.Drawing.Size(216, 44);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(8, 208);
			this.button2.Size = new System.Drawing.Size(216, 24);
			this.button2.Text = "Add and delete some rows";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.button2);
			this.Controls.Add(this.listBox3);
			this.Controls.Add(this.listBox2);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnPopulatedDataSet()
		{
			DataSet    l_DataSet = new DataSet();

			// A simple DataTable with a name and an age
			DataTable  l_newTable = new DataTable("People");
			l_newTable.Columns.Add(new DataColumn("Name", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("Age", typeof(System.Int32)));
			
			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Now put a few names in...
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "David Smith";
			l_newRow[1] = 45;
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Mary Jones";				
			l_newRow[1] = 18;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Jane Little";			
			l_newRow[1] = 34;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "James Kingston";			
			l_newRow[1] = 12;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Susan SameAge";			
			l_newRow[1] = 12;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Velma Knighton";			
			l_newRow[1] = 84;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// Commit the changes
			l_DataSet.AcceptChanges();
			


			// Set up the DataViews....
			// This DataView only shows rows that have been added
			m_addedRowsView = new DataView(l_DataSet.Tables[0]);
			m_addedRowsView.RowStateFilter = DataViewRowState.Added;


			// This DataView only shows rows that have been deleted.
			m_deletedRowsView = new DataView(l_DataSet.Tables[0]);
			m_deletedRowsView.RowStateFilter = DataViewRowState.Deleted;

			return l_DataSet;
		}

		// Paints the phone book data into the main window.
		private void PaintDataSet(DataSet in_DataSet)
		{
			this.listBox1.Items.Clear();
			this.listBox2.Items.Clear();
			this.listBox3.Items.Clear();

			for (int i = 0; i < in_DataSet.Tables[0].Rows.Count; i++)
			{
				// We cannot directly access deleted rows, so we have to be careful only
				// to paint in unchanged rows.
				if (in_DataSet.Tables[0].Rows[i].RowState == DataRowState.Unchanged)
				{
					this.listBox1.Items.Add(in_DataSet.Tables[0].Rows[i][0] + "  " + in_DataSet.Tables[0].Rows[i][1]);
				}
			}


			// Paint the DataView that only shows newly added rows
			for (int i = 0; i < m_addedRowsView.Count; i++)
			{
				this.listBox2.Items.Add(m_addedRowsView[i]["Name"] + "   " + m_addedRowsView[i]["Age"]);
			}

			// Paint the DataView that only shows deleted rows
			for (int i = 0; i < m_deletedRowsView.Count; i++)
			{
				this.listBox3.Items.Add(m_deletedRowsView[i]["Name"] + "   " + m_deletedRowsView[i]["Age"]);
			}
		}


		private void Form1_Load(object sender, System.EventArgs e)
		{
			// m_DataSet is declared as a DataSet and it is a member of the main class for
			// this project.
			int l_Seed = 34244;
			m_Random = new Random(l_Seed);
			m_DataSet = ReturnPopulatedDataSet();
			PaintDataSet(m_DataSet);				
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			m_DataSet.AcceptChanges();
			PaintDataSet(m_DataSet);
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			// Delete two rows
			m_DataSet.Tables[0].Rows[0].Delete();
			m_DataSet.Tables[0].Rows[1].Delete();

			// Add two new rows
			int l_maxRandom = 100;
			DataRowView l_firstNewDataRowView = m_addedRowsView.AddNew();
			l_firstNewDataRowView["Name"] = "NewPerson" + m_Random.Next(l_maxRandom).ToString();
			l_firstNewDataRowView["Age"] = m_Random.Next(l_maxRandom);
			l_firstNewDataRowView.EndEdit();

			DataRowView l_secondNewDataRowView = m_addedRowsView.AddNew();
			l_secondNewDataRowView["Name"] = "NewPerson" + m_Random.Next(l_maxRandom).ToString();
			l_secondNewDataRowView["Age"] = m_Random.Next(l_maxRandom);
			l_secondNewDataRowView.EndEdit();
			this.PaintDataSet(m_DataSet);

		}
	}
}
