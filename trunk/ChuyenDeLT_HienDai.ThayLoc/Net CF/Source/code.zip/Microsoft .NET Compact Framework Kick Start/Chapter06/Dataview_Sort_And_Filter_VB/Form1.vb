Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents listBox3 As System.Windows.Forms.ListBox
    Friend WithEvents listBox2 As System.Windows.Forms.ListBox
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu

    Private m_DataSet As DataSet

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.listBox3 = New System.Windows.Forms.ListBox
        Me.listBox2 = New System.Windows.Forms.ListBox
        Me.listBox1 = New System.Windows.Forms.ListBox
        '
        'listBox3
        '
        Me.listBox3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.listBox3.Location = New System.Drawing.Point(12, 168)
        Me.listBox3.Size = New System.Drawing.Size(216, 58)
        '
        'listBox2
        '
        Me.listBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.listBox2.Location = New System.Drawing.Point(12, 88)
        Me.listBox2.Size = New System.Drawing.Size(216, 58)
        '
        'listBox1
        '
        Me.listBox1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular)
        Me.listBox1.Location = New System.Drawing.Point(12, 16)
        Me.listBox1.Size = New System.Drawing.Size(216, 58)
        '
        'Form1
        '
        Me.Controls.Add(Me.listBox3)
        Me.Controls.Add(Me.listBox2)
        Me.Controls.Add(Me.listBox1)
        Me.Menu = Me.MainMenu1
        Me.Text = "Form1"

    End Sub

#End Region

    Private Function ReturnPopulatedDataSet() As DataSet
        Dim l_DataSet As DataSet
        l_DataSet = New DataSet

        ' A simple DataTable with a name and an age
        Dim l_newTable As DataTable
        l_newTable = New DataTable("People")
        l_newTable.Columns.Add(New DataColumn("Name", System.Type.GetType("System.String")))
        l_newTable.Columns.Add(New DataColumn("Age", System.Type.GetType("System.Int32")))

        ' Add the data table to the DataSet's table collection
        l_DataSet.Tables.Add(l_newTable)


        ' Now put a few names in...
        Dim l_newRow As DataRow
        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "David Smith"
        l_newRow(1) = 45
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Mary Jones"
        l_newRow(1) = 18
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Jane Little"
        l_newRow(1) = 34
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "James Kingston"
        l_newRow(1) = 12
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Susan SameAge"
        l_newRow(1) = 12
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        l_newRow = l_DataSet.Tables(0).NewRow()
        l_newRow(0) = "Velma Knighton"
        l_newRow(1) = 84
        l_DataSet.Tables(0).Rows.Add(l_newRow)

        ' Commit the changes
        l_DataSet.AcceptChanges()

        Return l_DataSet

    End Function

    ' Paints the phone book data into the main window.
    Private Sub PaintDataSet(ByVal in_DataSet As DataSet)
        Me.listBox1.Items.Clear()
        Me.listBox2.Items.Clear()
        Me.listBox3.Items.Clear()

        Dim i As Integer
        For i = 0 To in_DataSet.Tables(0).Rows.Count - 1
            Me.listBox1.Items.Add(in_DataSet.Tables(0).Rows(i)(0) + "  " + System.Convert.ToString(in_DataSet.Tables(0).Rows(i)(1)))
        Next i

        ' Set up a DataView that sorts by age first, then by Name in descending order
        Dim l_sortAgeView As DataView
        l_sortAgeView = New DataView(in_DataSet.Tables(0))
        l_sortAgeView.Sort = "Age DESC, Name DESC"

        For i = 0 To l_sortAgeView.Count - 1
            Me.listBox2.Items.Add(l_sortAgeView(i)("Name") + "   " + System.Convert.ToString(l_sortAgeView(i)("Age")))
        Next i

        ' Set up a DataView that only shows individuals aged 21 or older
        Dim l_AgeFilterView As DataView
        l_AgeFilterView = New DataView(in_DataSet.Tables(0))
        l_AgeFilterView.RowFilter = "Age >= 21"
        For i = 0 To l_AgeFilterView.Count - 1
            Me.listBox3.Items.Add(l_AgeFilterView(i)("Name") + "   " + System.Convert.ToString(l_AgeFilterView(i)("Age")))
        Next i

    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '  m_DataSet is declared as a DataSet and it is a member of the main class for
        ' this project.
        m_DataSet = ReturnPopulatedDataSet()
        PaintDataSet(m_DataSet)
    End Sub
End Class
