using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace Dataview_Sort_and_Filter_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.ListBox listBox3;
		private System.Windows.Forms.MainMenu mainMenu1;

		DataSet m_DataSet;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.listBox3 = new System.Windows.Forms.ListBox();
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 8);
			this.listBox1.Size = new System.Drawing.Size(216, 58);
			// 
			// listBox2
			// 
			this.listBox2.Location = new System.Drawing.Point(8, 80);
			this.listBox2.Size = new System.Drawing.Size(216, 58);
			// 
			// listBox3
			// 
			this.listBox3.Location = new System.Drawing.Point(8, 160);
			this.listBox3.Size = new System.Drawing.Size(216, 58);
			// 
			// Form1
			// 
			this.Controls.Add(this.listBox3);
			this.Controls.Add(this.listBox2);
			this.Controls.Add(this.listBox1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnPopulatedDataSet()
		{
			DataSet    l_DataSet = new DataSet();

			// A simple DataTable with a name and an age
			DataTable  l_newTable = new DataTable("People");
			l_newTable.Columns.Add(new DataColumn("Name", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("Age", typeof(System.Int32)));
			
			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Now put a few names in...
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "David Smith";
			l_newRow[1] = 45;
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Mary Jones";				
			l_newRow[1] = 18;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Jane Little";			
			l_newRow[1] = 34;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "James Kingston";			
			l_newRow[1] = 12;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Susan SameAge";			
			l_newRow[1] = 12;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Velma Knighton";			
			l_newRow[1] = 84;						
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}

		// Paints the phone book data into the main window.
		private void PaintDataSet(DataSet in_DataSet)
		{
			this.listBox1.Items.Clear();
			this.listBox2.Items.Clear();
			this.listBox3.Items.Clear();

			for (int i = 0; i < in_DataSet.Tables[0].Rows.Count; i++)
			{
				this.listBox1.Items.Add(in_DataSet.Tables[0].Rows[i][0] + "  " + in_DataSet.Tables[0].Rows[i][1]);
			}


			// Set up a DataView that sorts by age first, then by Name in descending order
			DataView l_sortAgeView = new DataView(in_DataSet.Tables[0]);
			l_sortAgeView.Sort = "Age DESC, Name DESC";
			for (int i = 0; i < l_sortAgeView.Count; i++)
			{
				this.listBox2.Items.Add(l_sortAgeView[i]["Name"] + "   " + l_sortAgeView[i]["Age"]);
			}

			// Set up a DataView that only shows individuals aged 21 or older
			DataView l_AgeFilterView = new DataView(in_DataSet.Tables[0]);
			l_AgeFilterView.RowFilter = "Age >= 21";
			for (int i = 0; i < l_AgeFilterView.Count; i++)
			{
				this.listBox3.Items.Add(l_AgeFilterView[i]["Name"] + "   " + l_AgeFilterView[i]["Age"]);
			}

		}


		private void Form1_Load(object sender, System.EventArgs e)
		{
			// m_DataSet is declared as a DataSet and it is a member of the main class for
			// this project.
			m_DataSet = ReturnPopulatedDataSet();
			PaintDataSet(m_DataSet);		
		}
	}
}
