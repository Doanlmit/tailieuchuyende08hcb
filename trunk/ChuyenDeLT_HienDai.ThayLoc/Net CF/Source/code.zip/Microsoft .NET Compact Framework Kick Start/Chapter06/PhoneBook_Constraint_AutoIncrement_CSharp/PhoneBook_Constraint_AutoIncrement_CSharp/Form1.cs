using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;

namespace PhoneBook_Constraint_AutoIncrement_CSharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.Button button2;

		DataSet m_phonebookDS;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 8);
			this.listBox1.Size = new System.Drawing.Size(216, 198);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 216);
			this.button1.Size = new System.Drawing.Size(216, 20);
			this.button1.Text = "Violate Constraint";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(8, 240);
			this.button2.Size = new System.Drawing.Size(216, 20);
			this.button2.Text = "Violate AllowDBNull";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.listBox1);
			this.Menu = this.mainMenu1;
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main() 
		{
			Application.Run(new Form1());
		}

		// Creates a new DataSet and fills it with phone book entries programmatically
		private DataSet ReturnPopulatedDataSet()
		{
			DataSet    l_DataSet = new DataSet();

			// Create a data table that holds a "Name", "PhoneNumber", and "ContactID"
			DataTable  l_newTable = new DataTable("Phone Contacts");
			l_newTable.Columns.Add(new DataColumn("Name", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("PhoneNumber", typeof(System.String)));
			l_newTable.Columns.Add(new DataColumn("ContactID", typeof(System.Int32)));
			

			// Don't allow the "Name" DataColumnn to be null
			l_newTable.Columns["Name"].AllowDBNull = false;

			// Set up the ContactID DataColumn as autoincrement by 5, starting at 10
			// That makes ContactID much like a primary key
			l_newTable.Columns["ContactID"].AutoIncrement = true;
			l_newTable.Columns["ContactID"].AutoIncrementSeed = 10;
			l_newTable.Columns["ContactID"].AutoIncrementStep = 5;

			// Add the data table to the DataSet's table collection
			l_DataSet.Tables.Add(l_newTable);


			// Add a UniqueConstraint to the phone number column
			UniqueConstraint l_UniqueConstraint = new UniqueConstraint(l_DataSet.Tables[0].Columns["PhoneNumber"]);
			l_DataSet.Tables[0].Constraints.Add(l_UniqueConstraint);


			// Now put a few names in...
			// GEORGE WASHINGTON
			DataRow l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "George Washington";
			l_newRow[1] = "340-1776";
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// BEN FRANKLIN
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow["Name"] = "Ben Franklin";					// Searching by column name is SLOWER on the .NET CF!
			l_newRow["PhoneNumber"] = "336-3211";			// Searching by column name is SLOWER on the .NET CF!
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// ALEXANDER HAMILTON
			l_newRow = l_DataSet.Tables[0].NewRow();
			l_newRow[0] = "Alexander Hamilton";			
			l_newRow[1] = "756-3211";			
			l_DataSet.Tables[0].Rows.Add(l_newRow);

			// Commit the changes
			l_DataSet.AcceptChanges();
			
			return l_DataSet;
		}

		// Paints the phone book data into the main window.
		private void PaintPhonebookData(DataSet phonebookEntriesDataSet)
		{
			this.listBox1.Items.Clear();

			for (int i = 0; i < phonebookEntriesDataSet.Tables[0].Rows.Count; i++)
			{
				this.listBox1.Items.Add(phonebookEntriesDataSet.Tables[0].Rows[i]["ContactID"] + " " + phonebookEntriesDataSet.Tables[0].Rows[i][0] + " " + phonebookEntriesDataSet.Tables[0].Rows[i][1]);
			}
		}



		private void Form1_Load(object sender, System.EventArgs e)
		{
			// m_phoneBookDS is declared as a DataSet and it is a member of the main class for
			// this project.
			m_phonebookDS = ReturnPopulatedDataSet();
			PaintPhonebookData(m_phonebookDS);		
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			// We're going to add two row with the same phone number on the first
			// table in the DataSet
			// That will cause an exception because of the UniqueConstraint in the
			// Constraints collection inside the table.
			try
			{
				DataRow l_newRow = m_phonebookDS.Tables[0].NewRow();
				l_newRow[0] = "Mister Nobody";
				l_newRow[1] = "5551212";
				m_phonebookDS.Tables[0].Rows.Add(l_newRow);

				l_newRow = m_phonebookDS.Tables[0].NewRow();
				l_newRow[0] = "Constraint Violator";
				l_newRow[1] = "5551212";
				m_phonebookDS.Tables[0].Rows.Add(l_newRow);

				// This is going to throw an exception because the phone number is
				// DBNull and that violates a constraint.
				m_phonebookDS.AcceptChanges();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString(), "Exception adding a new row");
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			try			
			{
				DataRow l_newRow = m_phonebookDS.Tables[0].NewRow();
				l_newRow[1] = "5555587";
				
				// This is going to throw an exception because the "Name" DataColumn
				// was never set, so it is DBNull, and that is not allowed for that
				// DataColumn
				m_phonebookDS.Tables[0].Rows.Add(l_newRow);
		
				
				m_phonebookDS.AcceptChanges();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString(), "Exception adding a new row");
			}
		}
	}
}
