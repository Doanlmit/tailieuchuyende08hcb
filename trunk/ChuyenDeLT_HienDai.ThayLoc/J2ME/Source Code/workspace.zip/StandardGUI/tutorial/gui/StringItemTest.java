package tutorial.gui;

/*--------------------------------------------------
 * StringItemTest.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class StringItemTest extends MIDlet implements CommandListener {
	private Display display; // Reference to Display object

	private Form fmMain; // Main form

	private StringItem siMsg; // StringItem

	private Command cmChange; // Change the label and message

	private Command cmExit; // Exit the MIDlet

	public StringItemTest() {
		display = Display.getDisplay(this);

		// Create text message and commands
		siMsg = new StringItem("Website: ", "www.IBM.com");
		cmChange = new Command("Change", Command.SCREEN, 1);
		cmExit = new Command("Exit", Command.EXIT, 1);

		// Create Form, add Command and StringItem, listen for events
		fmMain = new Form("StringItem Test");
		fmMain.addCommand(cmExit);
		fmMain.addCommand(cmChange);
		fmMain.append(siMsg);
		fmMain.setCommandListener(this);
	}

	// Called by application manager to start the MIDlet.
	public void startApp() {
		display.setCurrent(fmMain);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	public void commandAction(Command c, Displayable s) {
		if (c == cmChange) {
			// Change label
			siMsg.setLabel("Section: ");

			// Change text
			siMsg.setText("developerWorks");

			// Remove the command
			fmMain.removeCommand(cmChange);
		} else if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		}
	}
}
