package tutorial.gui;

/*--------------------------------------------------
 * ImplicitList.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class ImplicitList extends MIDlet implements CommandListener {
	private Display display; // Reference to Display object

	private List lsDocument; // Main list

	private Command cmExit; // Command to exit

	public ImplicitList() {
		display = Display.getDisplay(this);

		// Create the Commands
		cmExit = new Command("Exit", Command.EXIT, 1);

		try {
			// Create array of image objects
			Image images[] = { Image.createImage("/res/User.png"),
					Image.createImage("/res/Women.png"),
					Image.createImage("/res/Tool.png") };

			// Create array of corresponding string objects
			String options[] = { "Next", "Previous", "New" };

			// Create list using arrays, add commands, listen for events
			lsDocument = new List("Document Option:", List.IMPLICIT, options,
					images);

			// If you have no images, use this line to create the list
			//      lsDocument = new List("Document Option:", List.IMPLICIT, options, null);

			lsDocument.addCommand(cmExit);
			lsDocument.setCommandListener(this);
		} catch (java.io.IOException e) {
			System.err.println("Unable to locate or read .png file");
		}
	}

	public void startApp() {
		display.setCurrent(lsDocument);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	public void commandAction(Command c, Displayable s) {
		// If an implicit list generated the event
		if (c == List.SELECT_COMMAND) {
			switch (lsDocument.getSelectedIndex()) {
			case 0:
				System.out.println("Next selected");
				break;

			case 1:
				System.out.println("Previous selected");
				break;

			case 2:
				System.out.println("New selected");
				break;

			}
		} else if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		}
	}
}