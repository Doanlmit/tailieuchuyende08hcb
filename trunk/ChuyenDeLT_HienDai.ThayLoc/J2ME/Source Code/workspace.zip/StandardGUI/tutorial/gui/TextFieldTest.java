package tutorial.gui;

/*--------------------------------------------------
 * TextFieldTest.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TextFieldTest extends MIDlet implements CommandListener {
	private Display display; // Reference to Display object

	private Form fmMain; // Main form

	private Command cmTest; // Get contents of textfield

	private Command cmExit; // Command to exit the MIDlet

	private TextField tfText; // Textfield

	public TextFieldTest() {
		display = Display.getDisplay(this);

		// Create commands
		cmTest = new Command("Get Contents", Command.SCREEN, 1);
		cmExit = new Command("Exit", Command.EXIT, 1);

		// Textfield for phone number
		tfText = new TextField("Phone:", "", 10, TextField.PHONENUMBER);

		// Create Form, add Commands and textfield, listen for events
		fmMain = new Form("Phone Number");
		fmMain.addCommand(cmExit);
		fmMain.addCommand(cmTest);
		fmMain.append(tfText);
		fmMain.setCommandListener(this);
	}

	// Called by application manager to start the MIDlet.
	public void startApp() {
		display.setCurrent(fmMain);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	public void commandAction(Command c, Displayable s) {
		if (c == cmTest) {
			System.out.println("TextField contains: " + tfText.getString());
		} else if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		}
	}
}