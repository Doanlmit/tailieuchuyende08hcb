package tutorial.gui;

/*--------------------------------------------------
 * ImageTest.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class ImageTest extends MIDlet implements CommandListener {
	private Display display; // Reference to Display object

	private Form fmMain; // The main form

	private Command cmExit; // Command to exit the MIDlet

	public ImageTest() {
		display = Display.getDisplay(this);

		cmExit = new Command("Exit", Command.EXIT, 1);
		fmMain = new Form("");
		fmMain.addCommand(cmExit);
		fmMain.setCommandListener(this);

		try {
			// Read the appropriate image based on color support
			Image im = Image.createImage("/res/Women.png");

			fmMain
					.append(new ImageItem(null, im, ImageItem.LAYOUT_CENTER,
							null));

			display.setCurrent(fmMain);
		} catch (java.io.IOException e) {
			System.err.println("Unable to locate or read .png file");
		}
	}

	public void startApp() {
		display.setCurrent(fmMain);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	public void commandAction(Command c, Displayable s) {
		if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		}
	}
}