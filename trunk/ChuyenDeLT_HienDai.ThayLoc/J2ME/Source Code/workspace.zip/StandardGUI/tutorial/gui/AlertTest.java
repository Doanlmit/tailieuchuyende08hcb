package tutorial.gui;

/*--------------------------------------------------
 * AlertTest.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class AlertTest extends MIDlet implements ItemStateListener,
		CommandListener {
	private Display display; // Reference to display object

	private Form fmMain; // Main form

	private Command cmExit; // Command to exit the MIDlet

	private ChoiceGroup cgSound; // Choice group

	public AlertTest() {
		display = Display.getDisplay(this);

		// Create an exclusive (radio) choice group
		cgSound = new ChoiceGroup("Choose a sound", Choice.EXCLUSIVE);

		// Append options, with no associated images
		cgSound.append("Info", null);
		cgSound.append("Confirmation", null);
		cgSound.append("Warning", null);
		cgSound.append("Alarm", null);
		cgSound.append("Error", null);

		cmExit = new Command("Exit", Command.EXIT, 1);

		// Create Form, add components, listen for events
		fmMain = new Form("");
		fmMain.append(cgSound);
		fmMain.addCommand(cmExit);
		fmMain.setCommandListener(this);
		fmMain.setItemStateListener(this);
	}

	public void startApp() {
		display.setCurrent(fmMain);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	public void commandAction(Command c, Displayable s) {
		if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		}
	}

	public void itemStateChanged(Item item) {
		Alert al = null;

		switch (cgSound.getSelectedIndex()) {
		case 0:
			al = new Alert("Alert sound", "Info sound", null, AlertType.INFO);
			break;

		case 1:
			al = new Alert("Alert sound", "Confirmation sound", null,
					AlertType.INFO);
			break;

		case 2:
			al = new Alert("Alert sound", "Warning sound", null, AlertType.INFO);
			break;

		case 3:
			al = new Alert("Alert sound", "Alarm sound", null, AlertType.INFO);
			break;

		case 4:
			al = new Alert("Alert sound", "Error sound", null, AlertType.INFO);
			break;
		}

		if (al != null) {
			// Wait for user to acknowledge the alert
			al.setTimeout(Alert.FOREVER);

			// Display alert, show main form when done
			display.setCurrent(al, fmMain);
		}
	}
}
