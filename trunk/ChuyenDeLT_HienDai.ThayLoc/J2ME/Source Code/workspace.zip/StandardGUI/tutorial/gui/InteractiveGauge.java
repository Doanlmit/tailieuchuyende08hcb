package tutorial.gui;

/*--------------------------------------------------
 * InteractiveGauge.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class InteractiveGauge extends MIDlet implements CommandListener {
	private Display display; // Reference to display object

	private Form fmMain; // The main form

	private Command cmExit; // Exit the form

	private Gauge gaVolume; // Volume adjustment

	public InteractiveGauge() {
		display = Display.getDisplay(this);

		// Create the gauge and exit command
		gaVolume = new Gauge("Sound Level", true, 50, 4);
		cmExit = new Command("Exit", Command.EXIT, 1);

		// Create form, add commands, listen for events
		fmMain = new Form("");
		fmMain.addCommand(cmExit);
		fmMain.append(gaVolume);
		fmMain.setCommandListener(this);
	}

	// Called by application manager to start the MIDlet.
	public void startApp() {
		display.setCurrent(fmMain);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	public void commandAction(Command c, Displayable s) {
		if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		}
	}
}