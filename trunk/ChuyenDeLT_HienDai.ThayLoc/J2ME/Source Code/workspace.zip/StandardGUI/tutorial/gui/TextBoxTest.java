package tutorial.gui;

/*--------------------------------------------------
 * TextBoxTest.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TextBoxTest extends MIDlet implements CommandListener {
	private Display display; // Reference to Display object

	private TextBox tbClip; // Main textbox

	private Command cmExit; // Command to exit

	public TextBoxTest() {
		display = Display.getDisplay(this);

		// Create the Commands. Notice the priorities assigned
		cmExit = new Command("Exit", Command.EXIT, 1);

		tbClip = new TextBox("Textbox Test", "Contents go here..", 125,
				TextField.ANY);
		tbClip.addCommand(cmExit);
		tbClip.setCommandListener(this);

	}

	public void startApp() {
		display.setCurrent(tbClip);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	public void commandAction(Command c, Displayable s) {
		if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		}
	}
}
