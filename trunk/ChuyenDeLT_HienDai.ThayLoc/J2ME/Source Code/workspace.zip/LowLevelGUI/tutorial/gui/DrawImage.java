package tutorial.gui;

/*--------------------------------------------------
 * DrawImage.java
 *
 * Draw mutable image on a canvas
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class DrawImage extends MIDlet {
	private Display display; // The display

	private ImageCanvas canvas; // Canvas

	public DrawImage() {
		display = Display.getDisplay(this);
		canvas = new ImageCanvas(this);
	}

	protected void startApp() {
		display.setCurrent(canvas);
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean unconditional) {
	}

	public void exitMIDlet() {
		destroyApp(true);
		notifyDestroyed();
	}
}

/*--------------------------------------------------
 * Class ImageCanvas
 *
 * Draw mutable image
 *-------------------------------------------------*/
class ImageCanvas extends Canvas implements CommandListener {
	private Command cmExit; // Exit midlet

	private DrawImage midlet;

	private Image im = null;

	private String message = "developerWorks";

	public ImageCanvas(DrawImage midlet) {
		this.midlet = midlet;

		// Create exit command and listen for events
		cmExit = new Command("Exit", Command.EXIT, 1);
		addCommand(cmExit);
		setCommandListener(this);

		try {
			// Create mutable image
			im = Image.createImage(100, 20);

			// Get graphics object to draw onto the image
			Graphics graphics = im.getGraphics();

			// Specify a font face, style and size
			Font font = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN,
					Font.SIZE_MEDIUM);
			graphics.setFont(font);

			// Draw a filled (blue) rectangle, with rounded corners
			graphics.setColor(0, 0, 255);
			graphics.fillRoundRect(0, 0, im.getWidth() - 1, im.getHeight() - 1,
					20, 20);

			// Center text horizontally in the image. Draw text in white
			graphics.setColor(255, 255, 255);

			graphics.drawString(message, (im.getWidth() / 2)
					- (font.stringWidth(message) / 2), (im.getHeight() / 2)
					- (font.getHeight() / 2), Graphics.TOP | Graphics.LEFT);
		} catch (Exception e) {
			System.err.println("Error during image creation");
		}
	}

	/*--------------------------------------------------
	 * Draw mutable image
	 *-------------------------------------------------*/
	protected void paint(Graphics g) {
		// Clear the display
		g.setColor(255, 255, 255);
		g.fillRect(0, 0, getWidth(), getHeight());

		// Center the image on the display
		if (im != null)
			g.drawImage(im, getWidth() / 2, getHeight() / 2, Graphics.VCENTER
					| Graphics.HCENTER);
	}

	public void commandAction(Command c, Displayable d) {
		if (c == cmExit)
			midlet.exitMIDlet();
	}
}
