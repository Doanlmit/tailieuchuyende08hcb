package tutorial.gui;

/*--------------------------------------------------
 * DrawShapes.java
 *-------------------------------------------------*/
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class DrawShapes extends MIDlet {
	private Display display; // The display

	private ShapesCanvas canvas; // Canvas

	public DrawShapes() {
		display = Display.getDisplay(this);
		canvas = new ShapesCanvas(this);
	}

	protected void startApp() {
		display.setCurrent(canvas);
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean unconditional) {
	}

	public void exitMIDlet() {
		destroyApp(true);
		notifyDestroyed();
	}
}

/*--------------------------------------------------
 * Class ShapesCanvas
 *
 * Draw arcs
 *-------------------------------------------------*/
class ShapesCanvas extends Canvas implements CommandListener {
	private Command cmExit; // Exit midlet

	private DrawShapes midlet;

	public ShapesCanvas(DrawShapes midlet) {
		this.midlet = midlet;

		// Create exit command and listen for events
		cmExit = new Command("Exit", Command.EXIT, 1);
		addCommand(cmExit);
		setCommandListener(this);
	}

	/*--------------------------------------------------
	 * Draw shapes
	 *-------------------------------------------------*/
	protected void paint(Graphics g) {
		// Clear background to white
		g.setColor(255, 255, 255);
		g.fillRect(0, 0, getWidth(), getHeight());

		// Black pen
		g.setColor(0, 0, 0);

		// Start at 3 o'clock and rotate 150 degrees
		g.drawArc(10, 10, 100, 100, 0, 150);

		// Fill the arc
		//    g.fillArc(10, 10, 100, 100, 0, 150);

		// Start at 12 o'clock and rotate 150 degrees
		//    g.drawArc(10, 10, 100, 100, 90, 150);

		// Change the size of the bounding box
		// Start at 12 o'clock and rotate 150 degrees
		//    g.drawArc(15, 45, 30, 70, 90, 150);
	}

	public void commandAction(Command c, Displayable d) {
		if (c == cmExit)
			midlet.exitMIDlet();
	}
}
