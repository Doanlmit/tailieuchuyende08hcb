package tutorial.gcf;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.microedition.io.Connector;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.ImageItem;
import javax.microedition.lcdui.TextBox;
import javax.microedition.midlet.MIDlet;

public class DownloadImage extends MIDlet implements CommandListener {
	private Display display;

	private TextBox tbMain;

	private Form fmViewPng;

	private Command cmExit;

	private Command cmBack;

	public DownloadImage() {
		display = Display.getDisplay(this);
				
		// Create the form that will hold the image
		fmViewPng = new Form("");
		
//		 Create commands and add to textbox
		cmExit = new Command("Exit", Command.EXIT, 1);
		fmViewPng.addCommand(cmExit);

		// Create commands and add to form
		cmBack = new Command("Back", Command.BACK, 1);
		fmViewPng.addCommand(cmBack);
		
		// Set up a listener for form
		fmViewPng.setCommandListener(this);

		
		// Download image and place on the form
		String url = "http://localhost:8080/jsp-examples/tool.png";
		try {
			Image im;
			if ((im = getImage(url)) != null) {
				ImageItem ii = new ImageItem(null, im,
						ImageItem.LAYOUT_DEFAULT, null);

				// If there is already an image, set (replace) it
				if (fmViewPng.size() != 0)
					fmViewPng.set(0, ii);
				else
					// Append the image to the empty form
					fmViewPng.append(ii);
			} else
				fmViewPng.append("Unsuccessful download.");

			// Display the form with image
			display.setCurrent(fmViewPng);
		} catch (Exception e) {
			System.err.println("Msg: " + e.toString());
		} 

	}

	public void startApp() {
		display.setCurrent(fmViewPng);
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}

	/*--------------------------------------------------
	 * Process events
	 *-------------------------------------------------*/
	public void commandAction(Command c, Displayable s) {
		// If the Command button pressed was "Exit"
		if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		} else if (c == cmBack) {
			display.setCurrent(tbMain);
		}
	}

	/*--------------------------------------------------
	 * Open connection and download png into a byte array.
	 *-------------------------------------------------*/
	private Image getImage(String url) throws IOException {
		InputStream iStrm = (InputStream) Connector.openInputStream(url);
		Image im = null;

		try {
			ByteArrayOutputStream bStrm = new ByteArrayOutputStream();

			int ch;
			while ((ch = iStrm.read()) != -1)
				bStrm.write(ch);

			// Place into image array
			byte imageData[] = bStrm.toByteArray();

			// Create the image from the byte array
			im = Image.createImage(imageData, 0, imageData.length);
		} finally {
			// Clean up
			if (iStrm != null)
				iStrm.close();
		}

		return (im == null ? null : im);

	}
}
