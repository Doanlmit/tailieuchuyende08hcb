package tutorial.gcf;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DateFormatServlet extends HttpServlet {
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String format = request.getParameter("format");
		SimpleDateFormat simpleDate = new SimpleDateFormat(format);
		Date dt = new Date();

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.println(simpleDate.format(dt));
		out.close();
	}

	public String getServletInfo() {
		return "DateFormatServlet";
	}
}
