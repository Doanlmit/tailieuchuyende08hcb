package tutorial.gcf;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.midlet.MIDlet;

public class FileViewer extends MIDlet implements CommandListener {
	private Display display;

	private Form fmMain;

	private Command cmExit;

	private Command cmView;

	private String url = "http://localhost:8080/jsp-examples/file.txt";

	public FileViewer() {
		display = Display.getDisplay(this);

		// Create exitcommand
		cmExit = new Command("Exit", Command.EXIT, 1);

		// Create the form and add commands
		fmMain = new Form("File Viewer");
		fmMain.addCommand(cmExit);

		fmMain.setCommandListener(this);		
		try {
			String str;
			if ((str = readFile()) != null) {
				// Delete form contents
				for (int i = fmMain.size(); i > 0; i--)
					fmMain.delete(0);

				// Append downloaded string
				fmMain.append("" + str);
			}
		} catch (Exception e) {
			System.err.println("Msg: " + e.toString());
		}
	}

	public void startApp() {
		display.setCurrent(fmMain);
	}

	/*--------------------------------------------------
	 * Process events
	 *-------------------------------------------------*/
	public void commandAction(Command c, Displayable s) {
		// If the Command button pressed was "Exit"
		if (c == cmExit) {
			destroyApp(false);
			notifyDestroyed();
		} 
	}

	/*--------------------------------------------------
	 * Read file
	 *-------------------------------------------------*/
	private String readFile() throws IOException {
		HttpConnection http = null;
		InputStream iStrm = null;
		String str = null;

		try {
			// Create the connection
			http = (HttpConnection) Connector.open(url);

			// ----------------
			// Client Request
			// ----------------
			// 1) Send request method
			http.setRequestMethod(HttpConnection.GET);

			// 2) Send header information (this header is optional)
			http.setRequestProperty("User-Agent",
					"Profile/MIDP-1.0 Configuration/CLDC-1.0");

			// 3) Send body/data - No data for this request

			// ----------------
			// Server Response
			// ----------------
			System.out.println("url: " + url);
			System.out.println("-------------------------");

			// 1) Get status Line
			System.out.println("Msg: " + http.getResponseMessage());
			System.out.println("Code: " + http.getResponseCode());
			System.out.println("-------------------------");

			// 2) Get header information
			if (http.getResponseCode() == HttpConnection.HTTP_OK) {
				System.out.println("key 0: " + http.getHeaderFieldKey(0));
				System.out.println("key 1 : " + http.getHeaderFieldKey(1));
				System.out.println("key 2: " + http.getHeaderFieldKey(2));
				System.out.println("-------------------------");

				System.out
						.println("value (field) 0: " + http.getHeaderField(0));
				System.out
						.println("value (field) 1: " + http.getHeaderField(1));
				System.out
						.println("value (field) 2: " + http.getHeaderField(2));
				System.out.println("-------------------------");

				// 3) Get data (show the file contents)
				iStrm = http.openInputStream();
				int length = (int) http.getLength();
				if (length != -1) {
					// Read data in one chunk
					byte serverData[] = new byte[length];
					iStrm.read(serverData);
					str = new String(serverData);
				} else // Length not available...
				{
					ByteArrayOutputStream bStrm = new ByteArrayOutputStream();

					// Read data one character at a time
					int ch;
					while ((ch = iStrm.read()) != -1)
						bStrm.write(ch);

					str = new String(bStrm.toByteArray());
					bStrm.close();
				}

				// -----------------------------
				// Show connection information
				// -----------------------------
				System.out.println("Host: " + http.getHost());
				System.out.println("Port: " + http.getPort());
				System.out.println("Type: " + http.getType());
			}
		} finally {
			// Clean up
			if (iStrm != null)
				iStrm.close();
			if (http != null)
				http.close();
		}

		return str;

	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unconditional) {
	}
}
