<?php
/**
* @package ActiveRecord
* @subpackage Behaviours
* @author Arno Schneider <arno a.t. bermilabs dot com>
* @copyright Copyright (c) 2002-2007, Akelos Media, S.L. http://www.akelos.org
* @license GNU Lesser General Public License <http://www.gnu.org/copyleft/lesser.html>
* @ExtensionPoint BaseActiveRecord
*/
class ReflectionDocBlockTestClass
{
    function test_function() {

    }
}
?>
?>