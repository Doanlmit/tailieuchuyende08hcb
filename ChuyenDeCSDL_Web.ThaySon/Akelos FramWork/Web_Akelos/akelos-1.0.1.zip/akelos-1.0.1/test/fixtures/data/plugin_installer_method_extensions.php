<?php

/**
 * @ExtensionPoint PluginInstallerTargetClass
 *
 */
class PluginInstallerMethodExtensions
{
    function extension1()
    {
        
    }
    
    function extension2()
    {
        
    }
    
    private function _extension3()
    {
        
    }
    
    public static function _extension4()
    {
        
    }
    
}
?>