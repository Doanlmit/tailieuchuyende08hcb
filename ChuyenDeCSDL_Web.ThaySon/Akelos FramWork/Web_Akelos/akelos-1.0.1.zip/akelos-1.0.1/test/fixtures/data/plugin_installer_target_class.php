<?php

class PluginInstallerTargetClass
{
    
}
?>