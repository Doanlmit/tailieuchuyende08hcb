<?php

Ak::import('Event');

class OpenHouseMeeting extends Event
{

}

?>