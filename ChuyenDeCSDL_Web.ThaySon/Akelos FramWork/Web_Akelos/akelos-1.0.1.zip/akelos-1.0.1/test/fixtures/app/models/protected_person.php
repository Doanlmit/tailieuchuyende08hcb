<?php

class ProtectedPerson extends ActiveRecord
{
    var $_accessibleAttributes = array('name','birthday');
}

?>