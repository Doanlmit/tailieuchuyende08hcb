<?php

class PageController extends AkActionController 
{
    function index()
    {
        
    }
    function setup()
    {
        
    }
}


?>