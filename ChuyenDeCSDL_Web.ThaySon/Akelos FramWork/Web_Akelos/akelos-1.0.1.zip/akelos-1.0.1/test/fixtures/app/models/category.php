<?php
    class Category extends ActiveRecord 
    {
        var $act_as = "tree";
    } 
?>