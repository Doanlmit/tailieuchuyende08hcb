<?php
class Father extends ActiveRecord
{
    var $hasMany = 'Kids';
}
?>