<?php

class OpenHouseMeetingInstaller extends AkInstaller
{
    function install()
    {
    }

    function uninstall()
    {
    }
}

?>