<?php

class FormatsController extends ApplicationController
{
    var $layout = false;

    function index()
    {
    }
}


?>