<?php

class Dd extends ActiveRecord
{
    
    var $habtm = array('ees' => array('handler_name'=>'easy'));
}

?>