<?php

class Ee extends ActiveRecord
{
    var $habtm = array('somethings' => array('class_name'=>'Aa','table_name'=>'aas'));
}

?>