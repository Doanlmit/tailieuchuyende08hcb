<?php
class TodoItem extends ActiveRecord
{
    var $act_as = "list";
}
?>