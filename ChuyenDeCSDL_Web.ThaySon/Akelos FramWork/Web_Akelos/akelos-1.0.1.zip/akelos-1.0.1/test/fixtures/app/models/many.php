<?php
class Many extends ActiveRecord
{
    var $has_many = array('belongs');
}
?>