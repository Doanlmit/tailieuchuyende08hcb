<?php

class Account extends ActiveRecord
{
    var $belongs_to = 'person';
}

?>