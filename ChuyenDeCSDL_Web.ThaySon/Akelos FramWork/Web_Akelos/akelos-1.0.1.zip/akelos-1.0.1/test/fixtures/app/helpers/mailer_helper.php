<?php

class MailerHelper extends AkActionViewHelper
{ 
    function person_name()
    {
        return "Mr. Joe Person";
    }
}


?>