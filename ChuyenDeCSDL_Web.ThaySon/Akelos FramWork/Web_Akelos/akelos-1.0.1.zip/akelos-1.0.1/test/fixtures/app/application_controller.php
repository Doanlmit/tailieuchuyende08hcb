<?php

require_once(AK_APP_DIR.DS.'base_action_controller.php');

class ApplicationController extends BaseActionController 
{
    var $layout = false;

}

?>
