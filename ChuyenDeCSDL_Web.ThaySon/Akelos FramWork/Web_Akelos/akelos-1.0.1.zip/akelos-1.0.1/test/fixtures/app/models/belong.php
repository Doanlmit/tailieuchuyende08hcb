<?php
class Belong extends ActiveRecord
{
    var $belongs_to = array('many');
}
?>