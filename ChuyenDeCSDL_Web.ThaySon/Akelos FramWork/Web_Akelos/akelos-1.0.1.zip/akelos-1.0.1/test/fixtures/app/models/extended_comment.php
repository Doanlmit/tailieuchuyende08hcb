<?php

class ExtendedComment extends ActiveRecord 
{
    var $belongs_to = 'extended_post';
}

?>