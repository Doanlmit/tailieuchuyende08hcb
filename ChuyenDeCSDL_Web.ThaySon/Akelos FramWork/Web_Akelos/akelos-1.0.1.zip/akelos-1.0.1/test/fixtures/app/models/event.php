<?php

class Event extends ActiveRecord 
{

}

?>