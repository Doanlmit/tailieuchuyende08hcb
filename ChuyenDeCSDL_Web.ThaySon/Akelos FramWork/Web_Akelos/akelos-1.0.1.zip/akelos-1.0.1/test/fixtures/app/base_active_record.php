<?php
require_once(AK_BASE_DIR.DS.'app'.DS.substr(strrchr(__FILE__, DS), 1));

?>