<?php
    class NestedCategory extends ActiveRecord 
    {
        var $act_as = "nested_set";
    } 
?>