<?php
class Activity extends ActiveRecord
{
    var $belongsTo = 'Kid';
}
?>