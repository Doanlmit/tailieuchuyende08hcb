<?php

Ak::import('Event');

class Concert extends Event
{

}

?>