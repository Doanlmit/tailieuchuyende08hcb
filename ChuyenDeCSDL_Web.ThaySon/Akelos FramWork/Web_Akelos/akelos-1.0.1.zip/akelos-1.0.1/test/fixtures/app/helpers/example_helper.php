<?php

class ExampleHelper extends AkActionViewHelper
{ 
    function example_format($text)
    {
        return "<em><strong><small>$text</small></strong></em>";
    }
}


?>