<?php

class ConcertInstaller extends AkInstaller
{
    function install()
    {
    }

    function uninstall()
    {
    }
}

?>