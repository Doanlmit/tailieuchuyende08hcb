<?php

require_once(AK_APP_DIR.DS.'base_active_record.php');

/**
* This file is application-wide model file. You can put all 
* application-wide model-related methods here.
* 
* Add your application-wide methods in the class below, your models
* will inherit them.
*
* @package ActiveRecord
* @subpackage Base
*/
class ActiveRecord extends BaseActiveRecord 
{
}

?>
