<?php

class PageController extends ApplicationController
{
    function index()
    {
    }
}

?>