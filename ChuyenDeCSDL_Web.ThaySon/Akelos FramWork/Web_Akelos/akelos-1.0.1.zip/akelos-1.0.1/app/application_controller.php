<?php

require_once(AK_APP_DIR.DS.'base_action_controller.php');

/**
* This file is application-wide controller file. You can put all 
* application-wide controller-related methods here.
*
* Add your application-wide methods in the class below, your controllers 
* will inherit them.
* 
* @package ActionController
* @subpackage Base
*/

class ApplicationController extends BaseActionController 
{

}

?>
