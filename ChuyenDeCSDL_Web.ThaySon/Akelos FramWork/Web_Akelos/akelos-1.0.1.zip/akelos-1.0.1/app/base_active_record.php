<?php

require_once(AK_LIB_DIR.DS.'AkActiveRecord.php');

/**
 * DO NOT MODIFY manually
 * 
 * This class is only for plugins to extend the functionality
 * of the ActiveRecord 
 *
 */
class BaseActiveRecord extends AkActiveRecord 
{
    
}
?>
