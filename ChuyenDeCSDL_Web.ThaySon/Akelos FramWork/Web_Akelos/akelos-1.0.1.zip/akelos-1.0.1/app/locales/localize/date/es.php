<?php

$dictionary = array();
$dictionary['year,month,day,hour,minute'] = 'day,month,year,hour,minute'; // default order for Date-Time select lists DO NOT TRANSLATE JUST FOR SORTING PURPOSES
$dictionary['year,month,day'] = 'day,month,year'; // default order for Date-Time select lists DO NOT TRANSLATE JUST FOR SORTING PURPOSES
$dictionary['January,February,March,April,May,June,July,August,September,October,November,December'] = 'Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre';
$dictionary['1 - January,2 - February,3 - March,4 - April,5 - May,6 - June,7 - July,8 - August,9 - September,10 - October,11 - November,12 - December'] = '1 - Enero,2 - Febrero,3 - Marzo,4 - Abril,5 - Mayo,6 - Junio,7 - Julio,8 - Agosto,9 - Septiembre,10 - Octubre,11 - Noviembre,12 - Diciembre';
$dictionary['1 - Jan,2 - Feb,3 - Mar,4 - Apr,5 - May,6 - Jun,7 - Jul,8 - Aug,9 - Sep,10 - Oct,11 - Nov,12 - Dec'] = '1 - Ene,2 - Feb,3 - Mar,4 - Abr,5 - May,6 - Jun,7 - Jul,8 - Ago,9 - Sep,10 - Oct,11 - Nov,12 - Dic';
$dictionary['Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec'] = 'Ene,Feb,Mar,Abr,May,Jun,Jul,Ago,Sep,Oct,Nov,Dic';
$dictionary['Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday'] = 'Domingo,Lunes,Martes,Miércoles,Jueves,Viernes,Sábado';


?>
