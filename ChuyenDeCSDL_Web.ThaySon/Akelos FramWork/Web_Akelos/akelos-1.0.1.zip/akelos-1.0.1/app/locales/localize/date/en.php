<?php

$dictionary = array();
$dictionary['year,month,day,hour,minute'] = 'year,month,day,hour,minute'; // default order for Date-Time select lists DO NOT TRANSLATE JUST FOR SORTING PURPOSES
$dictionary['year,month,day'] = 'year,month,day'; // default order for Date-Time select lists DO NOT TRANSLATE JUST FOR SORTING PURPOSES
$dictionary['January,February,March,April,May,June,July,August,September,October,November,December'] = 'January,February,March,April,May,June,July,August,September,October,November,December';
$dictionary['Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday'] = 'Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday';
$dictionary['1 - January,2 - February,3 - March,4 - April,5 - May,6 - June,7 - July,8 - August,9 - September,10 - October,11 - November,12 - December'] = '1 - January,2 - February,3 - March,4 - April,5 - May,6 - June,7 - July,8 - August,9 - September,10 - October,11 - November,12 - December';
$dictionary['1 - Jan,2 - Feb,3 - Mar,4 - Apr,5 - May,6 - Jun,7 - Jul,8 - Aug,9 - Sep,10 - Oct,11 - Nov,12 - Dec'] = '1 - Jan,2 - Feb,3 - Mar,4 - Apr,5 - May,6 - Jun,7 - Jul,8 - Aug,9 - Sep,10 - Oct,11 - Nov,12 - Dec';
$dictionary['Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec'] = 'Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec';

?>
