<?php

$dictionary = array();
$dictionary['year,month,day,hour,minute'] = 'year,month,day,hour,minute'; // default order for Date-Time select lists DO NOT TRANSLATE JUST FOR SORTING PURPOSES
$dictionary['year,month,day'] = 'year,month,day'; // default order for Date-Time select lists DO NOT TRANSLATE JUST FOR SORTING PURPOSES
$dictionary['January,February,March,April,May,June,July,August,September,October,November,December'] = '1月,2月,3月,4月,5月,6月,7月,8月,9月,10月,11月,12月';
$dictionary['1 - January,2 - February,3 - March,4 - April,5 - May,6 - June,7 - July,8 - August,9 - September,10 - October,11 - November,12 - December'] = '1 - 1月,2 - 2月,3 - 3月,4 - 4月,5 - 5月,6 - 6月,7 - 7月,8 - 8月,9 - 9月,10 - 10月,11 - 11月,12 - 12月';
$dictionary['1 - Jan,2 - Feb,3 - Mar,4 - Apr,5 - May,6 - Jun,7 - Jul,8 - Aug,9 - Sep,10 - Oct,11 - Nov,12 - Dec'] = '1 - 睦月,2 - 如月,3 - 弥生,4 - 卯月,5 - 皐月,6 - 水無月,7 - 文月,8 - 葉月,9 - 長月,10 - 神無月,11 - 霜月,12 - 師走';
$dictionary['Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec'] = '睦月,如月,弥生,卯月,皐月,水無月,文月,葉月,長月,神無月,霜月,師走';
$dictionary['Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday'] = '日曜日,月曜日,火曜日,水曜日,木曜日,金曜日,土曜日';

?>